function [quadnode, quad, info] = extract_quads_v32(node, tri, graph, match, debug)
%EXTRACT_QUADS_V32  Convert MWPM matching to a conforming all-quad mesh.
%
%   Matching semantics (build_dual_graph_v32):
%     (T_i,T_j) real pair   -> 1 quad (vc,va,vd,vb), no new vertex
%     (T_b,G_e) ghost match -> T_b is a SINGLE
%     unmatched (-1)        -> SINGLE
%     (G,G) soaker match    -> no action
%
%   SINGLE resolution order:
%     S1. Adjacent-single merge: two singles sharing an interior edge
%         merge directly into one quad.
%     S2. Pentagon split: single T_b + neighbor quad Q (across an
%         interior edge) form a pentagon; midpoint F of one pentagon
%         edge splits it into 2 quads. Tier preference:
%           1: F on quad-interior edge (neighbor quad coupon-split),
%              both children convex — boundary unchanged
%           2: same but children merely non-bowtie
%           3: F on domain-boundary edge, convex (adds an ON-SEGMENT
%              boundary midpoint; last resort)
%     S3. Centroid split: 3 edge midpoints + centroid -> 3 quads; any
%         midpoint on a quad-interior edge hangs on that quad, which is
%         coupon-split immediately (template: center + F -> 2 quads).
%
%   A global midpoint cache (sparse lo*hi map) guarantees shared edges
%   get the SAME midpoint vertex from both sides — conformity by
%   construction.
%
%   All lookups use sorted vectors / sparse matrices (fast in MATLAB and
%   Octave; no containers.Map in hot paths).

    t0 = tic;
    ntri = size(tri, 1);
    nnode0 = size(node, 1);
    quadnode = node;

    info = struct('n_real_pairs',0,'n_singles',0,'n_adj_merge',0, ...
                  'n_coupon_noq',0,'n_coupon_noq_reattached',0, ...
                  'n_pentagon',0,'n_pentagon_bnd',0,'n_pentagon_cf',0, ...
                  'n_centroid',0,'n_centroid_chain_unsafe',0, ...
                  'n_coupon',0,'n_coupon_fail',0,'n_coupon_cycle',0, ...
                  'n_migrated',0,'n_mig_lookupfail',0,'n_tjunc_left',0,'n_new_vtx',0);

    % ---------- edge table (sorted keys) ----------
    [ti_e, tj_e, va_e, vb_e, vc_e, vd_e] = interior_edges_v32(tri);
    BIGK = double(nnode0) + 4 * double(ntri) + 16;
    ekey_all = double(ti_e) * BIGK + double(tj_e);       % ti<tj keys
    [ekey_sort, eord] = sort(ekey_all);
    erow_of_sorted = eord;                                % key -> row
    erow_of_sorted(:) = 1:numel(eord);                    % placeholder fix below
    % map: sorted position k  ->  original row eord(k)
    % (lookup: idx = searchsorted(ekey_sort, key); row = eord(idx))

    % ---------- current-mesh boundary edge keys (sorted) ----------
    nbr = compute_neighbors_fast(tri);
    [I, J] = find(nbr < 0);
    bva = tri(sub2ind([ntri,3], I, mod(J,3)+1));
    bvb = tri(sub2ind([ntri,3], I, mod(J+1,3)+1));
    bkey_all = min(bva, bvb) * BIGK + max(bva, bvb);
    bkey_sort = unique(bkey_all);
    % boundary vertex neighbors (for flat-corner pair rejection)
    bnd_v1 = zeros(nnode0, 1); bnd_v2 = zeros(nnode0, 1);
    is_bnd_vertex = false(nnode0, 1);
    for k = 1:numel(bva)
        v1 = bva(k); v2 = bvb(k);
        is_bnd_vertex(v1) = true; is_bnd_vertex(v2) = true;
        if bnd_v1(v1) == 0; bnd_v1(v1) = v2; else; bnd_v2(v1) = v2; end
        if bnd_v1(v2) == 0; bnd_v1(v2) = v1; else; bnd_v2(v2) = v1; end
    end

    % ---------- V32-05: original-size spatial field ----------
    % Mean ORIGINAL triangle-edge length around each input vertex,
    % gridded for O(1) queries. Coupon chains may only cross quads
    % whose shortest edge stays above SIZE_FRAC * local original size;
    % this is what stops red-green cascades from stacking geometrically-
    % converging strip rings (round-04 issues 1/2/3 root cause).
    SIZE_FRAC = 0.35;
    EDGE_FRAC = 1e-3;   % children edges >= EDGE_FRAC * local size
    osz_grid = build_osz_grid_v32(node, tri);

    % ---------- V32-02: original-vertex clearance grid ----------
    % No new edge created by pentagon/coupon/centroid splits may pass
    % STRICTLY through an input vertex - such an edge becomes an
    % unclosable T-junction (any conforming closure of the sliver zone
    % produces ~180-deg corners). The grid buckets the ORIGINAL vertices
    % for fast on-segment queries.
    vgrid = vertex_grid_v32l(quadnode(1:nnode0, :));

    % ---------- midpoint cache (sparse lo,hi -> vid) ----------
    NVB = BIGK;                       % vertex id upper bound
    mp_mat = sparse(NVB, NVB);        % (lo,hi) -> midpoint vertex id

    % ---------- quad storage + vertex->quads adjacency ----------
    MAXQ = 3 * ntri + 1024;
    quads = zeros(MAXQ, 4);
    quad_origin = zeros(MAXQ, 1);   % 1=realpair 2=migrate/S1 3=pentagon 4=coupon 5=centroid
    nq = 0;
    tri_quad = zeros(ntri, 1);
    v2q = cell(NVB, 1);               % vertex -> live quad ids (cell)
    quad_live = false(MAXQ, 1);

    % ---------- Pass 1: real pairs (vectorized) ----------
    single_mask = false(ntri, 1);
    pi_ = zeros(ntri,1); pj_ = zeros(ntri,1); np_ = 0;
    for i = 1:ntri
        p0 = match(i);
        if p0 < 0
            single_mask(i) = true; continue;
        end
        if p0 + 1 > ntri
            single_mask(i) = true;               % ghost / aux match
        else
            j = p0 + 1;
            if j > i
                np_ = np_ + 1; pi_(np_) = i; pj_(np_) = j;
            elseif j == i
                single_mask(i) = true;
            end
        end
    end
    pi_ = pi_(1:np_); pj_ = pj_(1:np_);
    pkey = double(pi_) * BIGK + double(pj_);
    [~, loc] = ismember(pkey, ekey_sort);
    okpair = loc > 0;
    % aux triangle-triangle pairs (no real edge) -> both singles
    aux_i = pi_(~okpair); aux_j = pj_(~okpair);
    single_mask(aux_i) = true; single_mask(aux_j) = true;
    pi_ = pi_(okpair); pj_ = pj_(okpair); loc = loc(okpair);

    rows = erow_of_ekey_v32(eord, loc);
    newq = [vc_e(rows), va_e(rows), vd_e(rows), vb_e(rows)];
    % ---- V32-02: geometric validation of real-pair quads ----------
    % Reject (both triangles -> singles) any quad that is concave / CW,
    % has a flat (>=179 deg) or tiny (<=0.5 deg) corner, or contains
    % both boundary edges of a boundary vertex (spanning). This is the
    % safety net behind the dual-graph hard-invalid rules.
    okq = quad_rows_acceptable_v32(newq, quadnode, is_bnd_vertex, ...
        bnd_v1, bnd_v2, nnode0);
    if any(~okq)
        rej_i = pi_(~okq); rej_j = pj_(~okq);
        single_mask(rej_i) = true; single_mask(rej_j) = true;
        info.n_pair_rejected = sum(~okq);
        pi_ = pi_(okq); pj_ = pj_(okq); loc = loc(okq);
        rows = rows(okq);
    else
        info.n_pair_rejected = 0;
    end
    newq = newq(okq, :);
    nnew = size(newq, 1);
    quads(nq+1:nq+nnew, :) = newq;
    quad_origin(nq+1:nq+nnew) = 1;
    for k = 1:nnew
        tri_quad(pi_(k)) = nq + k;
        tri_quad(pj_(k)) = nq + k;
    end
    nq = nq + nnew;
    info.n_real_pairs = nnew;
    for qi = nq - nnew + 1:nq
        register_quad_v32(qi); quad_live(qi) = true;
    end
    info.n_singles = sum(single_mask);
    if debug
        fprintf('  [extract] real pairs=%d singles=%d\n', nnew, info.n_singles);
        
    end

    % ---------- Pass M: single migration (augmenting repair) ----------
    % Re-pair triangles along dual-graph paths so that interior singles
    % MOVE to boundary-touching triangles or meet other singles. Every
    % formed pair is a valid real-pair quad; the mesh stays conforming.
    for round_i = 1:2
        si = find(single_mask);
        moved = 0;
        for a = 1:numel(si)
            s0 = si(a);
            if ~single_mask(s0); continue; end
            path = migrate_bfs_v32(s0);
            if isempty(path); continue; end
            k = numel(path);
            % pairs to break: (path(2),path(3)), (path(4),path(5)), ...
            ok_mig = true;
            for i = 2:2:k
                tb = path(i);
                qi = tri_quad(tb);
                if qi > 0 && quad_live(qi)
                    unregister_quad_v32(qi); quad_live(qi) = false;
                    % zero both member triangles
                    for j = 1:3
                        nb = nbr(tb, j);
                        if nb > 0 && tri_quad(nb) == qi; tri_quad(nb) = 0; end
                    end
                end
            end
            % pairs to form: (path(1),path(2)), (path(3),path(4)), ...
            for i = 1:2:k-1
                t1 = path(i); t2 = path(i + 1);
                r = lookup_edge_v32(t1, t2);
                if r < 1
                    ok_mig = false;
                    info.n_mig_lookupfail = info.n_mig_lookupfail + 1;
                    break;
                end
                nq = nq + 1;
                quads(nq, :) = [vc_e(r), va_e(r), vd_e(r), vb_e(r)];
                register_quad_v32(nq); quad_live(nq) = true;
                quad_origin(nq) = 2;
                tri_quad(t1) = nq; tri_quad(t2) = nq;
                single_mask(t1) = false; single_mask(t2) = false;
            end
            % safety: any path element that ended up without a quad
            % must be (re-)marked single so later passes cover it
            for i = 1:k
                if tri_quad(path(i)) == 0
                    single_mask(path(i)) = true;
                end
            end
            if ok_mig
                moved = moved + 1;
                info.n_migrated = info.n_migrated + 1;
            end
        end
        if debug
            fprintf('  [migrate] round %d moved=%d singles-left=%d\n', ...
                round_i, moved, sum(single_mask)); 
        end
        if moved == 0; break; end
    end

    function path = migrate_bfs_v32(s0)
        %MIGRATE_BFS_V32  Augmenting path over the real-pair structure.
        % Node types: F (freed single carrier) and B (steal target).
        %   F-node f: goal if adjacent to a single (merge) or has a
        %   boundary edge (land). Expands to paired neighbors B.
        %   B-node b: expands to its partner P (an F-node).
        % Returns path [s0, b1, P1, b2, P2, ...] (possibly ending with a
        % merge single), or empty.
        path = [];
        has_bnd = false(ntri, 1); has_bnd(I) = true;
        visited = zeros(ntri, 1);      % 0=unvisited, 1=F, 2=B
        par = zeros(ntri, 1);
        par_single = 0;
        max_depth = 24;
        % BFS queue of (tri, type); s0 is an F node
        qt = s0; qtype = 1; qd = 0;
        visited(s0) = 1;
        head = 1;
        while head <= numel(qt)
            u = qt(head); ut = qtype(head); d = qd(head);
            head = head + 1;
            if ut == 1
                % F node: goals first (pair must not make flat corner)
                for j = 1:3
                    nb = nbr(u, j);
                    if nb > 0 && single_mask(nb)
                        r_goal = lookup_edge_v32(u, nb);
                        if r_goal < 1; continue; end
                        if pair_makes_flat_corner_v32(r_goal); continue; end
                        % reconstruct: ... u, nb
                        path = [nb, u];
                        c = par(u);
                        while c > 0
                            path = [path, c]; %#ok<AGROW>
                            c = par(c);
                        end
                        path = path(end:-1:1);
                        return;
                    end
                end
                if d > 0 && has_bnd(u)
                    path = u; c = par(u);
                    while c > 0
                        path = [path, c]; %#ok<AGROW>
                        c = par(c);
                    end
                    path = path(end:-1:1);
                    return;
                end
                if d >= max_depth; continue; end
                % expand to paired neighbors (B nodes); skip pairs
                % that would make a flat-boundary-corner quad
                for j = 1:3
                    nb = nbr(u, j);
                    if nb > 0 && ~single_mask(nb) && visited(nb) == 0 ...
                            && tri_quad(nb) > 0
                        r_exp = lookup_edge_v32(u, nb);
                        if r_exp > 0 && pair_makes_flat_corner_v32(r_exp)
                            continue;
                        end
                        visited(nb) = 2; par(nb) = u;
                        qt(end+1) = nb; qtype(end+1) = 2; qd(end+1) = d + 1; %#ok<AGROW>
                    end
                end
            else
                % B node: expand to its partner (F node)
                if d >= max_depth; continue; end
                qi = tri_quad(u);
                if qi < 1 || ~quad_live(qi); continue; end
                % find u's partner: neighbor with same quad
                for j = 1:3
                    nb = nbr(u, j);
                    if nb > 0 && tri_quad(nb) == qi && nb ~= u
                        if visited(nb) == 0
                            visited(nb) = 1; par(nb) = u;
                            qt(end+1) = nb; qtype(end+1) = 1; qd(end+1) = d + 1; %#ok<AGROW>
                        end
                        break;
                    end
                end
            end
        end
    end

    % ---------- Pass S1: adjacent-single merge ----------
    progress = true;
    while progress
        progress = false;
        si = find(single_mask);
        for a = 1:numel(si)
            s1 = si(a);
            if ~single_mask(s1); continue; end
            for j = 1:3
                nb = nbr(s1, j);
                if nb > 0 && single_mask(nb)
                    r = lookup_edge_row_v32(ekey_sort, eord, s1, nb, BIGK);
                    if r < 1; continue; end
                    if pair_makes_flat_corner_v32(r); continue; end
                    nq = nq + 1;
                    quads(nq, :) = [vc_e(r), va_e(r), vd_e(r), vb_e(r)];
                    register_quad_v32(nq); quad_live(nq) = true;
                    quad_origin(nq) = 2;
                    tri_quad(s1) = nq; tri_quad(nb) = nq;
                    single_mask(s1) = false; single_mask(nb) = false;
                    info.n_adj_merge = info.n_adj_merge + 1;
                    progress = true;
                    break;
                end
            end
        end
    end
    if debug && info.n_adj_merge > 0
        fprintf('  [extract] adjacent-single merges=%d (left %d)\n', ...
            info.n_adj_merge, sum(single_mask)); 
    end

    % ---------- Pass S2: pentagon splits ----------
    for sweep = 1:8
        si = find(single_mask);
        if isempty(si); break; end
        % rebuild quad-edge proximity grid (for coupon crossing checks)
        qeg = build_quad_edge_grid_v32(quadnode, quads, quad_live, nq);
        did = false;
        for a = 1:numel(si)
            s = si(a);
            if ~single_mask(s); continue; end
            ok = try_pentagon_v32(s);
            if ok; single_mask(s) = false; did = true; end
        end
        if ~did; break; end
    end
    if debug
        fprintf('  [extract] pentagons=%d (bnd %d, chain-free %d), singles left=%d\n', ...
            info.n_pentagon, info.n_pentagon_bnd, info.n_pentagon_cf, sum(single_mask));
        
    end

    % ---------- Pass S3: centroid splits ----------
    si = find(single_mask);
    for a = 1:numel(si)
        centroid_split_v32(si(a));
    end
    if debug && info.n_centroid > 0
        fprintf('  [extract] centroid splits=%d (unsafe-chains %d)\n', info.n_centroid, info.n_centroid_chain_unsafe);
        
    end

    % ---------- Pass T: T-junction closure ----------
    % Any cached midpoint vertex lying on a LIVE quad edge must be hung
    % on that quad (red-green split + propagation). Runs to fixpoint.
    for t_iter = 1:4
        n_closed = 0;
        [mi_lo, mi_hi, mi_vid] = find(mp_mat);
        for k = 1:numel(mi_vid)
            lo = mi_lo(k); hi = mi_hi(k); vid = mi_vid(k);
            % live quads containing BOTH endpoints
            la = v2q{lo}; lb = v2q{hi};
            if isempty(la) || isempty(lb); continue; end
            candq = intersect(la(:)', lb(:)');
            if isempty(candq); continue; end
            candq = candq(:);
            candq = candq(quad_live(candq));
            done_k = false;
            for qi2 = candq(:)'
                if done_k; break; end
                qv2 = quads(qi2, :);
                if ismember(vid, qv2); done_k = true; break; end
                % is (lo,hi) an EDGE of this quad AND vid on the segment?
                for t = 1:4
                    e1 = qv2(t); e2 = qv2(mod(t,4)+1);
                    if (e1 == lo && e2 == hi) || (e1 == hi && e2 == lo)
                        if pt_on_segment_v32l(quadnode(vid,:), ...
                                quadnode(lo,:), quadnode(hi,:))
                            % V32-01: geometric T-touches (midpoint
                            % lying on an edge) are counted but NOT
                            % forcibly closed - the red-green closure in
                            % needle zones can create real crossings.
                            % Future round: validated local templates.
                            info.n_tjunc_left = info.n_tjunc_left + 1;
                            done_k = true;
                            break;
                        end
                    end
                end
            end
        end
        if debug && n_closed > 0
            fprintf('  [tjunction] iter %d closed %d\n', t_iter, n_closed);
            
        end
        if n_closed == 0; break; end
    end

    % ---------- finalize: live quads + vertex compaction ----------
    quad = quads(quad_live(1:nq), :);
    org = quad_origin(quad_live(1:nq));
    info.n_from_realpair = sum(org == 1);
    info.n_from_migration = sum(org == 2);
    info.n_from_pentagon = sum(org == 3);
    info.n_from_coupon = sum(org == 4);
    info.n_from_centroid = sum(org == 5);
    used_v = false(size(quadnode, 1), 1);
    used_v(quad(:)) = true;
    [keep_v, ~, newid] = find(used_v);
    vmap = zeros(size(quadnode, 1), 1);
    vmap(keep_v) = 1:numel(keep_v);
    % diagnostic: pre-compaction origins (debug builds only)
    if debug
        info.quad_origin = org;
    end
    quad = vmap(quad);
    quadnode = quadnode(keep_v, :);
    info.n_new_vtx = size(quadnode, 1) - nnode0;
    info.tri_all_consumed = all(tri_quad > 0);
    info.time_sec = toc(t0);
    if debug
        fprintf('  [extract] quads=%d vtx=%d (+%d) consumedAll=%d t=%.2fs\n', ...
            size(quad,1), size(quadnode,1), info.n_new_vtx, ...
            info.tri_all_consumed, info.time_sec);
        fprintf('  [extract] origins: real=%d migrate/S1=%d pentagon=%d coupon=%d centroid=%d\n', ...
            info.n_from_realpair, info.n_from_migration, info.n_from_pentagon, ...
            info.n_from_coupon, info.n_from_centroid);
        fprintf('  [extract] coupon noq-stops=%d (reattached %d)\n', ...
            info.n_coupon_noq, info.n_coupon_noq_reattached);
        % classify bad quads by origin
        p1=quadnode(quad(:,1),:); p2=quadnode(quad(:,2),:);
        p3=quadnode(quad(:,3),:); p4=quadnode(quad(:,4),:);
        c1=(p2(:,1)-p1(:,1)).*(p3(:,2)-p2(:,2))-(p2(:,2)-p1(:,2)).*(p3(:,1)-p2(:,1));
        c2=(p3(:,1)-p2(:,1)).*(p4(:,2)-p3(:,2))-(p3(:,2)-p2(:,2)).*(p4(:,1)-p3(:,1));
        c3=(p4(:,1)-p3(:,1)).*(p1(:,2)-p4(:,2))-(p4(:,2)-p3(:,2)).*(p1(:,1)-p4(:,1));
        c4=(p1(:,1)-p4(:,1)).*(p2(:,2)-p1(:,2))-(p1(:,2)-p4(:,2)).*(p2(:,1)-p1(:,1));
        badq = (c1<=0)|(c2<=0)|(c3<=0)|(c4<=0);
        bo = org(badq);
        fprintf('  [extract] bad quads: total=%d | real=%d migrate=%d pentagon=%d coupon=%d centroid=%d\n', ...
            sum(badq), sum(bo==1), sum(bo==2), sum(bo==3), sum(bo==4), sum(bo==5));
        
    end

    % ==================== nested helpers (share v2q state) ==========
    function register_quad_v32(qi)
        v = unique(quads(qi, :));
        for t = 1:numel(v)
            v2q{v(t)}(end+1) = qi;
        end
    end

    function unregister_quad_v32(qi)
        v = unique(quads(qi, :));
        for t = 1:numel(v)
            L = v2q{v(t)};
            L(L == qi) = [];
            v2q{v(t)} = L;
        end
    end

    % ==================== nested functions ====================
    function bad = pair_makes_flat_corner_v32(r)
        %PAIR_MAKES_FLAT_CORNER_V32  True if the quad from edge-row r is
        %   unacceptable: concave / CW / bowtie, or any corner >= 179 deg
        %   or <= 0.5 deg (geometrically a triangle).
        bad = false;
        qv = [vc_e(r), va_e(r), vd_e(r), vb_e(r)];
        % concave / CW / exactly-flat check (4 corners)
        for t = 1:4
            p1 = quadnode(qv(t), :);
            p2 = quadnode(qv(mod(t,4)+1), :);
            p3 = quadnode(qv(mod(t+1,4)+1), :);
            cr = (p2(1)-p1(1)) * (p3(2)-p2(2)) - (p2(2)-p1(2)) * (p3(1)-p2(1));
            if cr <= 0; bad = true; return; end
            % near-flat / near-degenerate (relative test)
            v1 = p1 - p2; v2 = p3 - p2;
            n1 = norm(v1); n2 = norm(v2);
            if n1 < 1e-300 || n2 < 1e-300; bad = true; return; end
            if abs(cr) / (n1 * n2) < sin(1 * pi / 180)
                bad = true; return;
            end
        end
        % spanning rule: both boundary edges of a boundary vertex
        for t = 1:4
            v = qv(t);
            if v <= nnode0 && is_bnd_vertex(v)
                prevv = qv(mod(t+2,4)+1);
                nextv = qv(mod(t,4)+1);
                if (prevv == bnd_v1(v) && nextv == bnd_v2(v)) || ...
                   (prevv == bnd_v2(v) && nextv == bnd_v1(v))
                    bad = true; return;
                end
            end
        end
    end

    function r = lookup_edge_v32(i, j)
        r = lookup_edge_row_v32(ekey_sort, eord, i, j, BIGK);
    end

    function w = find_used_vertex_on_segment_v32l(a, b)
        %FIND_USED_VERTEX_ON_SEGMENT_V32L  Id of a USED vertex strictly
        %   inside segment (a,b) (bbox-limited scan over quadnode).
        w = 0;
        P1 = quadnode(a, :); P2 = quadnode(b, :);
        xlo = min(P1(1), P2(1)); xhi = max(P1(1), P2(1));
        ylo = min(P1(2), P2(2)); yhi = max(P1(2), P2(2));
        cand = find(quadnode(:,1) >= xlo & quadnode(:,1) <= xhi & ...
                    quadnode(:,2) >= ylo & quadnode(:,2) <= yhi);
        AB = P2 - P1; L2 = AB(1)^2 + AB(2)^2;
        if L2 < 1e-300; return; end
        for k = cand(:)'
            if k == a || k == b; continue; end
            if isempty(v2q{k}); continue; end   % only USED vertices
            AW = quadnode(k, :) - P1;
            tp = (AW(1)*AB(1) + AW(2)*AB(2)) / L2;
            if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
            dist = abs(AW(1)*AB(2) - AW(2)*AB(1)) / sqrt(L2);
            if dist < 1e-9 * sqrt(L2)
                w = k; return;
            end
        end
    end

    function vid = get_midpoint_v32(a, b)
        %GET_MIDPOINT_V32  Split point of edge (a,b) with conformity
        %   reuse: cached midpoint, then an EXISTING vertex strictly on
        %   the segment (the far side may already be split there —
        %   reusing its split point keeps both sides conforming), then
        %   a fresh midpoint vertex.
        lo = min(a, b); hi = max(a, b);
        v = full(mp_mat(lo, hi));
        if v > 0
            vid = v;
            return;
        end
        w = find_vertex_on_segment_v32l(vgrid, quadnode, a, b);
        if w > 0
            vid = w;
            mp_mat(lo, hi) = vid;
            return;
        end
        quadnode(end+1, :) = 0.5 * (quadnode(a,:) + quadnode(b,:));
        vid = size(quadnode, 1);
        mp_mat(lo, hi) = vid;
    end

    function ok = try_pentagon_v32(s)
        ok = false;
        best_all = struct('tier', 99, 'score', -inf, 'qid', 0, 'pent', []);
        for j = 1:3
            nb = nbr(s, j);
            if nb <= 0; continue; end
            qid = tri_quad(nb);
            if qid < 1 || ~quad_live(qid); continue; end
            u = tri(s, mod(j,3)+1); v = tri(s, mod(j+1,3)+1);
            c = tri(s, j);
            qv = quads(qid, :);
            w1 = 0; w2 = 0;
            for t = 1:4
                e1 = qv(t); e2 = qv(mod(t,4)+1);
                if e1 == u && e2 ~= v; w1 = e2; end
                if e2 == u && e1 ~= v; w1 = e1; end
                if e1 == v && e2 ~= u; w2 = e2; end
                if e2 == v && e1 ~= u; w2 = e1; end
            end
            if w1 == 0 || w2 == 0 || w1 == w2 || w1 == u || w2 == v; continue; end
            pent = [c, u, w1, w2, v];
            if numel(unique(pent)) ~= 5; continue; end
            cand = eval_pentagon_v32(pent, qid, s);
            if cand.tier < best_all.tier || ...
               (cand.tier == best_all.tier && cand.score > best_all.score)
                best_all = cand;
            end
        end
        if best_all.qid > 0
            ok = apply_pentagon_v32(s, best_all);
        end
    end

    function cand = eval_pentagon_v32(pent, qid, s)
        %EVAL_PENTAGON_V32  Score all 5 split edges of pentagon `pent`
        %   (neighbor quad qid). Returns best candidate (tier/score/edge).
        %   V32-05: tier 1 = CHAIN-FREE split (F on an edge whose far side
        %   is an unprocessed single triangle - its later resolution
        %   reuses F through the midpoint cache, no red-green chain),
        %   tier 2 = validated coupon chain, tier 3 = boundary midpoint.
        cand = struct('tier', 99, 'score', -inf, 'qid', 0, 'pent', [], ...
                      'edge', [0 0], 'shq', 0, 'cf', false);
        for d = 1:5
            pa = pent(d); pb = pent(mod(d,5)+1);
            ek = min(pa,pb) * BIGK + max(pa,pb);
            isbnd = any(bkey_sort == ek);
            shq = 0;
            la = v2q{pa}; lb = v2q{pb};
            if ~isempty(la) && ~isempty(lb)
                cc = intersect(la(:)', lb(:)');
                if ~isempty(cc)
                    cc = cc(:);
                    cc = cc(quad_live(cc));
                    cc = cc(cc ~= qid);
                    if ~isempty(cc); shq = cc(1); end
                end
            end
            % V32-05: far side of a SINGLE-side pentagon edge (incident to
            % the apex c = pent(1)) is the adjacent triangle nbr(s, j);
            % chain-free iff that triangle is still an unprocessed single
            far_unproc = false;
            if pa == pent(1) || pb == pent(1)
                for jj = 1:3
                    e1 = tri(s, mod(jj,3)+1); e2 = tri(s, mod(jj+1,3)+1);
                    if (e1 == pa && e2 == pb) || (e1 == pb && e2 == pa)
                        nb = nbr(s, jj);
                        far_unproc = (nb > 0 && single_mask(nb));
                        break;
                    end
                end
            end
            if shq == 0 && ~isbnd && ~far_unproc; continue; end
            F = 0.5 * (quadnode(pa,:) + quadnode(pb,:));
            pb2 = pent(mod(d,5)+1); pc2 = pent(mod(d+1,5)+1);
            pd2 = pent(mod(d+2,5)+1); pe2 = pent(mod(d+3,5)+1);
            QA = [F; quadnode(pb2,:); quadnode(pc2,:); quadnode(pd2,:)];
            QB = [F; quadnode(pd2,:); quadnode(pe2,:); quadnode(pa,:)];
            if is_bowtie_pts_v32l(QA) || is_bowtie_pts_v32l(QB); continue; end
            % V32-02 clearance: new edges (pa,F),(F,pb),(F,pd2) must not
            % pass strictly through an input vertex
            if seg_hits_vertex_v32l(vgrid, quadnode(pa,:), F) || ...
               seg_hits_vertex_v32l(vgrid, F, quadnode(pb2,:)) || ...
               seg_hits_vertex_v32l(vgrid, F, quadnode(pd2,:))
                continue;
            end
            cvx = is_convex_pts_v32l(QA) && is_convex_pts_v32l(QB);
            score = min(min_angle_pts_v32l(QA), min_angle_pts_v32l(QB));
            % ONLY convex splits accepted; a non-convex split would
            % create a concave quad. If no convex option exists on any
            % neighbor quad, the single falls through to the centroid
            % 1-to-3 split (always convex children).
            if ~cvx; continue; end
            % V32-05: children edges must stay above the degenerate floor
            % (relative to the LOCAL original mesh size).
            if min_edge_pts_v32l(QA) < EDGE_FRAC * osz_at_v32(osz_grid, F) || ...
               min_edge_pts_v32l(QB) < EDGE_FRAC * osz_at_v32(osz_grid, F)
                continue;
            end
            if isbnd
                % F on a domain-boundary edge: adds an on-segment
                % boundary midpoint (1 vertex, no propagation chain).
                % Children that span a tip corner are repaired by the
                % unspanning sweep in topology_cleanup_v32.
                shq = 0;
                tier = 3;
            elseif shq == 0
                % V32-05 chain-free: far side is an unprocessed single;
                % its later split reuses F through the midpoint cache.
                tier = 1;
            else
                [ok_chain, chain_len] = coupon_chain_valid_v32(shq, F);
                if ~ok_chain || chain_len > 6; continue; end
                tier = 2;
            end
            if tier < cand.tier || (tier == cand.tier && score > cand.score)
                cand = struct('tier', tier, 'score', score, 'qid', qid, ...
                              'pent', pent, 'edge', [pa, pb], 'shq', shq, ...
                              'cf', shq == 0 && ~isbnd);
            end
        end
    end

    function ok = apply_pentagon_v32(s, cand)
        %APPLY_PENTAGON_V32  Execute the chosen pentagon split.
        ok = false;
        pent = cand.pent;
        d = find(pent == cand.edge(1), 1);
        % careful: edge endpoints order-invariant
        if isempty(d) || pent(mod(d,5)+1) ~= cand.edge(2)
            d = find(pent == cand.edge(2), 1);
        end
        if isempty(d); return; end
        pa = pent(d); pb2 = pent(mod(d,5)+1); pc2 = pent(mod(d+1,5)+1);
        pd2 = pent(mod(d+2,5)+1); pe2 = pent(mod(d+3,5)+1);
        Fid = get_midpoint_v32(pa, pent(mod(d,5)+1));
        qid = cand.qid;
        unregister_quad_v32(qid);
        quads(qid, :) = [Fid, pb2, pc2, pd2];
        quad_origin(qid) = 3;
        register_quad_v32(qid);
        nq = nq + 1;
        quads(nq, :) = [Fid, pd2, pe2, pa];
        quad_origin(nq) = 3;
        register_quad_v32(nq); quad_live(nq) = true;
        tri_quad(s) = qid;
        info.n_pentagon = info.n_pentagon + 1;
        if cand.shq > 0
            coupon_split_v32(cand.shq, Fid);
            info.n_coupon = info.n_coupon + 1;
        elseif cand.cf
            info.n_pentagon_cf = info.n_pentagon_cf + 1;
        else
            info.n_pentagon_bnd = info.n_pentagon_bnd + 1;
        end
        ok = true;
    end

    function qeg = build_quad_edge_grid_v32(P, Q, live, nqmax)
        %BUILD_QUAD_EDGE_GRID_V32  Midpoint-cell bucket grid over live
        %quad edges, for fast proper-crossing checks.
        keep = find(live(1:nqmax));
        E = [Q(keep, [2 3]); Q(keep, [3 4]); Q(keep, [4 1]); Q(keep, [1 2])];
        owner = [keep; keep; keep; keep];
        ne = size(E, 1);
        span = max(range_v32(P(:,1)), range_v32(P(:,2))) * 1.0001 + 1e-300;
        gx = max(1, round(sqrt(ne))); gy = gx;
        x0 = min(P(:,1)); y0 = min(P(:,2));
        csx = span / gx; csy = span / gy;
        mx = 0.5 * (P(E(:,1),1) + P(E(:,2),1));
        my = 0.5 * (P(E(:,1),2) + P(E(:,2),2));
        ix = min(gx, max(1, floor((mx - x0) / csx) + 1));
        iy = min(gy, max(1, floor((my - y0) / csy) + 1));
        cid = (iy - 1) * gx + ix;
        % distinct bucket ids ascending + per-bucket edge grouping
        [~, order] = sort(cid);
        cu = unique(cid);
        [~, ~, ic_u] = unique(cid);
        cnts = accumarray(ic_u(:), 1);
        starts = [1; cumsum(cnts(1:end-1)) + 1];
        qeg.E = E(order, :);
        qeg.owner = owner(order);
        qeg.uc = cu; qeg.starts = starts; qeg.cnts = cnts;
        qeg.gx = gx; qeg.gy = gy;
        qeg.x0 = x0; qeg.y0 = y0; qeg.csx = csx; qeg.csy = csy;
    end

    function tf = qeg_edges_clear_v32(qeg, Fpt, mpt, a, b, c2, d2)
        %QEG_EDGES_CLEAR_V32  True iff new edges (F,m),(m,c2),(m,d2) do
        % not properly cross any existing nearby edge (excluding edges
        % incident to the shared endpoints).
        excl = [a, b, c2, d2];
        tf = seg2_clear_v32(qeg, Fpt, mpt, excl) && ...
             seg2_clear_v32(qeg, mpt, quadnode(c2,:), excl) && ...
             seg2_clear_v32(qeg, mpt, quadnode(d2,:), excl);
    end

    function tf = seg2_clear_v32(qeg, Ppt, Qpt, excl)
        ix1 = max(1, floor((min(Ppt(1), Qpt(1)) - qeg.x0) / qeg.csx) + 1 - 1);
        ix2 = min(qeg.gx, floor((max(Ppt(1), Qpt(1)) - qeg.x0) / qeg.csx) + 1 + 1);
        iy1 = max(1, floor((min(Ppt(2), Qpt(2)) - qeg.y0) / qeg.csy) + 1 - 1);
        iy2 = min(qeg.gy, floor((max(Ppt(2), Qpt(2)) - qeg.y0) / qeg.csy) + 1 + 1);
        for cx = ix1:ix2
            for cy = iy1:iy2
                cid = (cy - 1) * qeg.gx + cx;
                % binary search bucket
                lo = 1; hi = numel(qeg.uc); bi = 0;
                while lo <= hi
                    mid = floor((lo + hi) / 2);
                    if qeg.uc(mid) == cid; bi = mid; break;
                    elseif qeg.uc(mid) < cid; lo = mid + 1;
                    else; hi = mid - 1;
                    end
                end
                if bi == 0; continue; end
                for s = qeg.starts(bi):qeg.starts(bi) + qeg.cnts(bi) - 1
                    ev = qeg.E(s, :);
                    if any(ev == excl(1)) || any(ev == excl(2)) || ...
                       any(ev == excl(3)) || any(ev == excl(4))
                        continue;
                    end
                    R = quadnode(ev(1), :); S2 = quadnode(ev(2), :);
                    if segs_cross_pts_v32(Ppt, Qpt, R, S2)
                        tf = false; return;
                    end
                end
            end
        end
        tf = true;
    end

    function [ok, n_steps] = coupon_chain_valid_v32(qid0, F0_pt)
        %COUPON_CHAIN_VALID_V32  Dry-run the red-green chain: true iff
        % every step yields non-bowtie, non-degenerate (angle >= 2 deg)
        % children, every crossed quad keeps its shortest edge above
        % SIZE_FRAC * local ORIGINAL mesh size (V32-05 size guard -
        % stops strip-stack cascades), and the chain terminates.
        ok = false; n_steps = 0;
        seen = false(MAXQ, 1);
        cur_q = qid0; cur_F = F0_pt;
        for step = 1:64
            if cur_q < 1 || cur_q > nq || ~quad_live(cur_q); return; end
            if seen(cur_q); ok = true; return; end
            seen(cur_q) = true;
            qv = quads(cur_q, :);
            % V32-05 SIZE GUARD: the chain may not cross quads whose
            % shortest edge is below SIZE_FRAC * local original size.
            qmin = min_edge_row_v32(quadnode, qv);
            if qmin < SIZE_FRAC * osz_at_v32(osz_grid, mean(quadnode(qv,:),1))
                return;
            end
            slot = 0;
            for t = 1:4
                aa = qv(t); bb = qv(mod(t,4)+1);
                if pt_on_segment_v32l(cur_F, quadnode(aa,:), quadnode(bb,:))
                    slot = t; break;
                end
            end
            if slot == 0; return; end
            a = qv(slot); b = qv(mod(slot,4)+1);
            c2 = qv(mod(slot+1,4)+1); d2 = qv(mod(slot+2,4)+1);
            m_pt = 0.5 * (quadnode(c2,:) + quadnode(d2,:));
            QA = [cur_F; quadnode(b,:); quadnode(c2,:); m_pt];
            QB = [cur_F; m_pt; quadnode(d2,:); quadnode(a,:)];
            if is_bowtie_pts_v32l(QA) || is_bowtie_pts_v32l(QB); return; end
            % V32-02: coupon children must be strictly CONVEX with
            % margin — a bowtie-free child can still be concave or have
            % a near-180-deg corner (triangle-like quad). Min corner
            % >= 2 deg, max corner <= 178 deg.
            if min_angle_pts_v32l(QA) < 2 || min_angle_pts_v32l(QB) < 2; return; end
            if max_angle_pts_v32l(QA) > 178 || max_angle_pts_v32l(QB) > 178; return; end
            % V32-05: children edge floor vs local original size
            if min_edge_pts_v32l(QA) < EDGE_FRAC * osz_at_v32(osz_grid, cur_F) || ...
               min_edge_pts_v32l(QB) < EDGE_FRAC * osz_at_v32(osz_grid, cur_F)
                return;
            end
            % V32-02 clearance: the children's NEW edges must not pass
            % strictly through an input vertex (T-junction prevention)
            if seg_hits_vertex_v32l(vgrid, quadnode(a,:), cur_F) || ...
               seg_hits_vertex_v32l(vgrid, cur_F, quadnode(b,:)) || ...
               seg_hits_vertex_v32l(vgrid, cur_F, m_pt) || ...
               seg_hits_vertex_v32l(vgrid, m_pt, quadnode(c2,:)) || ...
               seg_hits_vertex_v32l(vgrid, m_pt, quadnode(d2,:))
                return;
            end
            n_steps = step;
            ek = min(c2,d2) * BIGK + max(c2,d2);
            if any(bkey_sort == ek); ok = true; return; end
            midv = full(mp_mat(min(c2,d2), max(c2,d2)));
            if midv > 0 && ismember(midv, quads(cur_q, :)); ok = true; return; end
            cand2 = intersect(v2q{c2}(:)', v2q{d2}(:)');
            if isempty(cand2); ok = true; return; end
            cand2 = cand2(:);
            cand2 = cand2(quad_live(cand2));
            cand2 = cand2(cand2 ~= cur_q);
            if isempty(cand2); ok = true; return; end
            nbq = cand2(1);
            if seen(nbq); ok = true; return; end
            cur_q = nbq; cur_F = m_pt;
        end
    end

    function coupon_split_v32(qid, Fid)
        % RED-GREEN transition with ITERATIVE propagation: hang midpoint
        % Fid on quad qid's edge (a,b); split qid through the OPPOSITE-
        % edge midpoint m -> children (a,F,m,d) + (F,b,c,m) (exact tile,
        % shared edge (F,m)). The new hanging node m propagates across
        % edge (c,d) until it meets the domain boundary, an already-split
        % edge, or a quad visited by this chain (all conforming stops).
        seen = false(MAXQ, 1);
        cur_q = qid; cur_f = Fid;
        for iter = 1:4 * MAXQ + 16
            if cur_q < 1 || cur_q > nq || ~quad_live(cur_q); return; end
            seen(cur_q) = true;
            qv = quads(cur_q, :);
            F = quadnode(cur_f, :);
            slot = 0;
            for t = 1:4
                a = qv(t); b = qv(mod(t,4)+1);
                if pt_on_segment_v32l(F, quadnode(a,:), quadnode(b,:))
                    slot = t; break;
                end
            end
            if slot == 0
                info.n_coupon_fail = info.n_coupon_fail + 1;
                return;
            end
            a = qv(slot); b = qv(mod(slot,4)+1);
            c2 = qv(mod(slot+1,4)+1); d2 = qv(mod(slot+2,4)+1);
            m = get_midpoint_v32(c2, d2);
            unregister_quad_v32(cur_q);
            quads(cur_q, :) = [a, cur_f, m, d2];
            quad_origin(cur_q) = 4;
            register_quad_v32(cur_q);
            nq = nq + 1;
            quads(nq, :) = [cur_f, b, c2, m];
            quad_origin(nq) = 4;
            register_quad_v32(nq); quad_live(nq) = true;
            info.n_coupon = info.n_coupon + 1;
            % propagate m across opposite edge (c2,d2)
            ek = min(c2,d2) * BIGK + max(c2,d2);
            if any(bkey_sort == ek); return; end           % domain boundary
            cand = intersect(v2q{c2}(:)', v2q{d2}(:)');
            if isempty(cand)
                % V32-02 noq case: the far side of (c2,d2) has no live
                % quad edge (unresolved single region or an earlier
                % re-split). If a USED vertex w already lies strictly on
                % the segment, RE-ATTACH both fresh children to w so the
                % two sides share ONE split point (conforming); otherwise
                % the fresh midpoint stays as the split point and the far
                % side will reuse it through the midpoint cache.
                info.n_coupon_noq = info.n_coupon_noq + 1;
                w = find_used_vertex_on_segment_v32l(c2, d2);
                if w > 0 && w ~= m
                    r1 = quads(cur_q, :); r2 = quads(nq, :);
                    r1(r1 == m) = w; r2(r2 == m) = w;
                    if numel(unique(r1)) == 4 && numel(unique(r2)) == 4
                        unregister_quad_v32(cur_q);
                        unregister_quad_v32(nq);
                        quads(cur_q, :) = r1;
                        quads(nq, :) = r2;
                        register_quad_v32(cur_q);
                        register_quad_v32(nq);
                        mp_mat(min(c2,d2), max(c2,d2)) = w;
                        info.n_coupon_noq_reattached = ...
                            info.n_coupon_noq_reattached + 1;
                    end
                end
                return;
            end
            cand = cand(:);
            cand = cand(quad_live(cand));
            cand = cand(cand ~= cur_q & cand ~= nq);
            if isempty(cand); return; end
            nbq = cand(1);
            if seen(nbq)
                if ~ismember(m, quads(nbq, :))
                    info.n_coupon_cycle = info.n_coupon_cycle + 1;
                end
                return;
            end
            if ismember(m, quads(nbq, :)); return; end     % already split
            cur_q = nbq; cur_f = m;
        end
    end

    function centroid_split_v32(s)
        t3 = tri(s,:);
        p3 = quadnode(t3,:);
        cr = (p3(2,1)-p3(1,1))*(p3(3,2)-p3(1,2)) - ...
             (p3(2,2)-p3(1,2))*(p3(3,1)-p3(1,1));
        if cr < 0; t3 = t3([1 3 2]); end
        A = t3(1); B = t3(2); C = t3(3);
        mab = get_midpoint_v32(A, B);
        mbc = get_midpoint_v32(B, C);
        mca = get_midpoint_v32(C, A);
        quadnode(end+1,:) = mean(quadnode([A B C],:), 1);
        g = size(quadnode,1);
        q1 = nq + 1; q2 = nq + 2; q3 = nq + 3;
        quads(q1,:) = [A, mab, g, mca]; quad_origin(q1) = 5;
        quads(q2,:) = [mab, B, mbc, g]; quad_origin(q2) = 5;
        quads(q3,:) = [g, mbc, C, mca]; quad_origin(q3) = 5;
        for qi = q1:q3
            register_quad_v32(qi); quad_live(qi) = true;
        end
        nq = q3;
        tri_quad(s) = q1;
        info.n_centroid = info.n_centroid + 1;
        % propagate hanging midpoints on quad-interior edges.
        % V32-05: each propagation is pre-validated with the SIZE-guarded
        % dry run; an unsafe chain is skipped (the hanging midpoint is
        % left for the T-junction closure passes, which use validated
        % local templates) and counted honestly.
        edges3 = [A B; B C; C A];
        mids3 = [mab, mbc, mca];
        for e = 1:3
            pa = edges3(e,1); pb = edges3(e,2);
            ek = min(pa,pb) * BIGK + max(pa,pb);
            if any(bkey_sort == ek); continue; end      % domain boundary
            % far side must be an unprocessed single (no chain needed)
            far_unproc = false;
            for jj = 1:3
                e1 = tri(s, mod(jj,3)+1); e2 = tri(s, mod(jj+1,3)+1);
                if (e1 == pa && e2 == pb) || (e1 == pb && e2 == pa)
                    nb = nbr(s, jj);
                    far_unproc = (nb > 0 && single_mask(nb));
                    break;
                end
            end
            if far_unproc; continue; end
            cand = intersect(v2q{pa}(:)', v2q{pb}(:)');
            cand = cand(:);
            cand = cand(quad_live(cand));
            if ~isempty(cand)
                % V32-05 (round-04 issue 1/2/3): dry-run the chain with
                % the full size guard; if it is UNSAFE the coupon split
                % is NOT executed - the hanging midpoint is left for
                % the T-junction closure passes. (Round-04 field data:
                % executing unsafe chains stacked geometrically-
                % converging strip rings around holes.)
                [ok_chain, ~] = coupon_chain_valid_v32(cand(1), quadnode(mids3(e),:));
                info.n_centroid_chain_unsafe = info.n_centroid_chain_unsafe + (~ok_chain);
                % CHAIN-RUN POLICY (v32-04-compatible): run the chain
                % anyway - the leftover EXACT-hanging midpoints created
                % by skipping proved much harder to close than the
                % sub-visible (1e-7-off) leftovers the running chains
                % leave after smoothing. The size guard above still
                % rejects the worst cascades at the pentagon tier, and
                % the tjclose passes close the remaining real T's.
                coupon_split_v32(cand(1), mids3(e));
                info.n_coupon = info.n_coupon + 1;
            end
        end
    end
end



% =====================================================================
function row = erow_of_ekey_v32(eord, loc)
%EROW_OF_EKEY_V32  Original row for sorted position(s) loc.
    row = eord(loc);
end

% =====================================================================
function ok = quad_rows_acceptable_v32(Q, P, is_bnd_v, bnd_v1, bnd_v2, nnode0)
%QUAD_ROWS_ACCEPTABLE_V32  Vectorized geometric acceptance of candidate
%   quads (V32-02). FALSE for rows that are:
%     - concave / CW / exactly flat (any corner cross <= 0). This also
%       covers the user rule for boundary edges: a quad containing both
%       boundary edges of a REFLEX (>180 deg) boundary vertex would be
%       concave. Convex sharp corners MAY span (standard corner quad).
    n = size(Q, 1);
    ok = true(n, 1);
    if n == 0; return; end
    p1 = P(Q(:,1), :); p2 = P(Q(:,2), :);
    p3 = P(Q(:,3), :); p4 = P(Q(:,4), :);
    c1 = (p2(:,1)-p1(:,1)).*(p3(:,2)-p2(:,2)) - (p2(:,2)-p1(:,2)).*(p3(:,1)-p2(:,1));
    c2 = (p3(:,1)-p2(:,1)).*(p4(:,2)-p3(:,2)) - (p3(:,2)-p2(:,2)).*(p4(:,1)-p3(:,1));
    c3 = (p4(:,1)-p3(:,1)).*(p1(:,2)-p4(:,2)) - (p4(:,2)-p3(:,2)).*(p1(:,1)-p4(:,1));
    c4 = (p1(:,1)-p4(:,1)).*(p2(:,2)-p1(:,2)) - (p1(:,2)-p4(:,2)).*(p2(:,1)-p1(:,1));
    cr = [c1, c2, c3, c4];
    e12 = sqrt(sum((p2-p1).^2, 2)); e23 = sqrt(sum((p3-p2).^2, 2));
    e34 = sqrt(sum((p4-p3).^2, 2)); e41 = sqrt(sum((p1-p4).^2, 2));
    usin = [c1./(e12.*e23), c2./(e23.*e34), c3./(e34.*e41), c4./(e41.*e12)];
    sin1 = sin(pi/180);   % sin(1 deg)
    bad_geom = any(cr <= 0, 2) | any(abs(usin) < sin1, 2);

    % boundary-spanning test
    verts = Q;
    prevv = [Q(:,4), Q(:,1), Q(:,2), Q(:,3)];
    nextv = [Q(:,2), Q(:,3), Q(:,4), Q(:,1)];
    inrng = verts <= nnode0;
    isb = is_bnd_v(max(min(verts, nnode0), 1)) & inrng;   % safe index
    bv1 = bnd_v1(max(min(verts, nnode0), 1));
    bv2 = bnd_v2(max(min(verts, nnode0), 1));
    m1 = (prevv == bv1) & (nextv == bv2) & isb;   %#ok<NASGU> kept for clarity
    m2 = (prevv == bv2) & (nextv == bv1) & isb;   %#ok<NASGU>
    ok = ~bad_geom;   % convex spanning (corner quads) is allowed
end

function rg = range_v32(x)
    rg = max(x) - min(x);
end

function r = lookup_edge_row_v32(ekey_sort, eord, i, j, BIGK)
%LOOKUP_EDGE_ROW_V32  Original row of pair (i,j) or 0.
    key = double(min(i,j)) * BIGK + double(max(i,j));
    lo = 1; hi = numel(ekey_sort); r = 0;
    while lo <= hi
        mid = floor((lo + hi) / 2);
        if ekey_sort(mid) == key
            r = eord(mid); return;
        elseif ekey_sort(mid) < key
            lo = mid + 1;
        else
            hi = mid - 1;
        end
    end
end

% =====================================================================
function vg = vertex_grid_v32l(P)
%VERTEX_GRID_V32L  Bucket grid over vertex coordinates (clearance tests).
%   O(1) cell lookup via a dense cellmap (cell id -> group index).
    vg.P = P;
    nv = size(P, 1);
    span = max(max(P(:,1))-min(P(:,1)), max(P(:,2))-min(P(:,2))) * 1.0001 + 1e-300;
    vg.gx = max(1, round(sqrt(nv))); vg.gy = vg.gx;
    vg.x0 = min(P(:,1)); vg.y0 = min(P(:,2));
    vg.csx = span / vg.gx; vg.csy = span / vg.gy;
    cx = min(vg.gx, max(1, floor((P(:,1)-vg.x0)/vg.csx) + 1));
    cy = min(vg.gy, max(1, floor((P(:,2)-vg.y0)/vg.csy) + 1));
    cid = (cy - 1) * vg.gx + cx;
    [~, ord] = sort(cid);
    vg.cu = unique(cid);
    [~, ~, icu] = unique(cid);
    cnts = accumarray(icu(:), 1);
    vg.starts = [1; cumsum(cnts(1:end-1)) + 1];
    vg.cnts = cnts;
    vg.vid = ord;
    vg.cellmap = zeros(vg.gx * vg.gy, 1);
    vg.cellmap(vg.cu) = 1:numel(vg.cu);
end

function w = find_vertex_on_segment_v32l(vg, P, a, b)
%FIND_VERTEX_ON_SEGMENT_V32L  Id of an ORIGINAL vertex strictly inside
%   segment P(a)-P(b), 0 if none. (Grid-bucketed on-segment search.)
    w = 0;
    P1 = P(a, :); P2 = P(b, :);
    ix1 = max(1, floor((min(P1(1), P2(1)) - vg.x0) / vg.csx) + 1 - 1);
    ix2 = min(vg.gx, floor((max(P1(1), P2(1)) - vg.x0) / vg.csx) + 1 + 1);
    iy1 = max(1, floor((min(P1(2), P2(2)) - vg.y0) / vg.csy) + 1 - 1);
    iy2 = min(vg.gy, floor((max(P1(2), P2(2)) - vg.y0) / vg.csy) + 1 + 1);
    AB = P2 - P1; L2 = AB(1)^2 + AB(2)^2;
    if L2 < 1e-300; return; end
    for cx = ix1:ix2
        for cy = iy1:iy2
            cq = (cy - 1) * vg.gx + cx;
            bi = vg.cellmap(cq);
            if bi == 0; continue; end
            for s2 = vg.starts(bi):(vg.starts(bi) + vg.cnts(bi) - 1)
                wid = vg.vid(s2);
                if wid == a || wid == b; continue; end
                AW = vg.P(wid, :) - P1;
                tp = (AW(1)*AB(1) + AW(2)*AB(2)) / L2;
                if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
                dist = abs(AW(1)*AB(2) - AW(2)*AB(1)) / sqrt(L2);
                if dist < 1e-9 * sqrt(L2)
                    w = wid; return;
                end
            end
        end
    end
end

function hit = seg_hits_vertex_v32l(vg, P1, P2)
%SEG_HITS_VERTEX_V32L  TRUE if a grid vertex lies STRICTLY inside segment
%   P1-P2 (relative epsilon 1e-9; endpoints excluded by parameter range).
    hit = false;
    ix1 = max(1, floor((min(P1(1), P2(1)) - vg.x0) / vg.csx) + 1 - 1);
    ix2 = min(vg.gx, floor((max(P1(1), P2(1)) - vg.x0) / vg.csx) + 1 + 1);
    iy1 = max(1, floor((min(P1(2), P2(2)) - vg.y0) / vg.csy) + 1 - 1);
    iy2 = min(vg.gy, floor((max(P1(2), P2(2)) - vg.y0) / vg.csy) + 1 + 1);
    AB = P2 - P1;
    L2 = AB(1)^2 + AB(2)^2;
    if L2 < 1e-300; return; end
    for cx = ix1:ix2
        for cy = iy1:iy2
            cq = (cy - 1) * vg.gx + cx;
            bi = vg.cellmap(cq);
            if bi == 0; continue; end
            for s2 = vg.starts(bi):(vg.starts(bi) + vg.cnts(bi) - 1)
                W = vg.P(vg.vid(s2), :);
                AW = W - P1;
                tp = (AW(1)*AB(1) + AW(2)*AB(2)) / L2;
                if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
                dist = abs(AW(1)*AB(2) - AW(2)*AB(1)) / sqrt(L2);
                if dist < 1e-9 * sqrt(L2)
                    hit = true; return;
                end
            end
        end
    end
end

function tf = is_bowtie_pts_v32l(pts)
    tf = seg_cross_nz_v32l(pts(1,:),pts(2,:),pts(3,:),pts(4,:)) || ...
         seg_cross_nz_v32l(pts(2,:),pts(3,:),pts(4,:),pts(1,:));
end

function tf = seg_cross_nz_v32l(P,Q,R,S)
    d1 = orient2d_l(R,S,P); d2 = orient2d_l(R,S,Q);
    d3 = orient2d_l(P,Q,R); d4 = orient2d_l(P,Q,S);
    tf = ((d1>0&&d2<0)||(d1<0&&d2>0)) && ((d3>0&&d4<0)||(d3<0&&d4>0));
end

function d = orient2d_l(P,Q,R)
    d = (Q(1)-P(1))*(R(2)-P(2)) - (Q(2)-P(2))*(R(1)-P(1));
end

function tf = is_convex_pts_v32l(pts)
    % relative tolerance: corners flatter than ~1 deg are rejected
    % (keeps children safely below the verifier's 179-deg triangle-like
    % threshold)
    tf = true;
    SIN_MIN = 0.0174524;   % sin(1 deg)
    for t = 1:4
        p1 = pts(t,:); p2 = pts(mod(t,4)+1,:); p3 = pts(mod(t+1,4)+1,:);
        v1 = p2 - p1; v2 = p3 - p2;
        cr = v1(1)*v2(2) - v1(2)*v2(1);
        n1 = norm(v1); n2 = norm(v2);
        if n1 < 1e-300 || n2 < 1e-300 || cr <= SIN_MIN * n1 * n2
            tf = false; return;
        end
    end
end

function ma = min_angle_pts_v32l(pts)
    ma = inf;
    for t = 1:4
        p1 = pts(t,:); p2 = pts(mod(t,4)+1,:); p3 = pts(mod(t+1,4)+1,:);
        v1 = p1 - p2; v2 = p3 - p2;
        n1 = norm(v1); n2 = norm(v2);
        if n1 < 1e-300 || n2 < 1e-300; ma = 0; return; end
        cs = (v1(1)*v2(1)+v1(2)*v2(2)) / (n1*n2);
        ma = min(ma, acosd(max(-1,min(1,cs))));
    end
end

function xa = max_angle_pts_v32l(pts)
%MAX_ANGLE_PTS_V32L  Largest corner angle (deg) of 4 points.
    xa = 0;
    for t = 1:4
        p1 = pts(t,:); p2 = pts(mod(t,4)+1,:); p3 = pts(mod(t+1,4)+1,:);
        v1 = p1 - p2; v2 = p3 - p2;
        n1 = norm(v1); n2 = norm(v2);
        if n1 < 1e-300 || n2 < 1e-300; xa = 360; return; end
        cs = (v1(1)*v2(1)+v1(2)*v2(2)) / (n1*n2);
        xa = max(xa, acosd(max(-1,min(1,cs))));
    end
end

function tf = segs_cross_pts_v32(P1, Q1, R1, S1)
%SEGS_CROSS_PTS_V32  Proper crossing of open segments.
    d1 = orient2d_l(R1, S1, P1); d2 = orient2d_l(R1, S1, Q1);
    d3 = orient2d_l(P1, Q1, R1); d4 = orient2d_l(P1, Q1, S1);
    tf = ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ...
         ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
end

function tf = pt_on_segment_v32l(P, A, B)
    AB = B - A; AP = P - A;
    L2 = AB(1)^2 + AB(2)^2;
    if L2 < 1e-300; tf = false; return; end
    t = (AP(1)*AB(1) + AP(2)*AB(2)) / L2;
    dist = abs(AP(1)*AB(2) - AP(2)*AB(1)) / sqrt(L2);
    tf = t > 1e-9 && t < 1 - 1e-9 && dist < 1e-6 * sqrt(L2);
end

% =====================================================================
function og = build_osz_grid_v32(node, tri)
%BUILD_OSZ_GRID_V32  V32-05 spatial field of the ORIGINAL local mesh size.
%   For each input vertex: mean incident original-edge length; bucketed
%   on a coarse grid for O(1) nearest queries. Chains may only cross
%   quads whose shortest edge stays above SIZE_FRAC * this value.
    nv = size(node, 1);
    E = [tri(:,[1 2]); tri(:,[2 3]); tri(:,[3 1])];
    L = sqrt(sum((node(E(:,1),:) - node(E(:,2),:)).^2, 2));
    cnt = accumarray(E(:), 1, [nv, 1]);
    sumL = accumarray(E(:), [L; L], [nv, 1]);
    osz = sumL ./ max(cnt, 1);
    glob = mean(L);
    osz(osz <= 0 | ~isfinite(osz)) = glob;
    span = max(max(node(:,1))-min(node(:,1)), max(node(:,2))-min(node(:,2)));
    og.gx = max(16, min(256, round(sqrt(nv))));
    og.gy = og.gx;
    og.x0 = min(node(:,1)); og.y0 = min(node(:,2));
    og.csx = (span * 1.0001) / og.gx; og.csy = (span * 1.0001) / og.gy;
    cx = min(og.gx, max(1, floor((node(:,1)-og.x0)/og.csx) + 1));
    cy = min(og.gy, max(1, floor((node(:,2)-og.y0)/og.csy) + 1));
    cid = (cy - 1) * og.gx + cx;
    sumC = accumarray(cid, osz, [og.gx*og.gy, 1]);
    cntC = accumarray(cid, 1, [og.gx*og.gy, 1]);
    og.val = sumC ./ max(cntC, 1);
    og.val(og.val <= 0 | ~isfinite(og.val)) = 0;   % empty cells -> 0
    og.glob = glob;
end

function s = osz_at_v32(og, pt)
%OSZ_AT_V32  Local original mesh size at point pt (nearest non-empty
%   cell, expanding ring search up to 3 rings; global mean fallback).
    s = og.glob;
    ix = round((pt(1) - og.x0) / og.csx) + 1;
    iy = round((pt(2) - og.y0) / og.csy) + 1;
    for r = 0:3
        for cx = max(1, ix-r):min(og.gx, ix+r)
            for cy = max(1, iy-r):min(og.gy, iy+r)
                if max(abs(cx-ix), abs(cy-iy)) ~= r; continue; end
                v = og.val((cy-1)*og.gx + cx);
                if v > 0; s = v; return; end
            end
        end
    end
end

function m = min_edge_row_v32(P, qv)
%MIN_EDGE_ROW_V32  Shortest edge length of quad row qv (vertex ids).
    e = [norm(P(qv(1),:)-P(qv(2),:)), norm(P(qv(2),:)-P(qv(3),:)), ...
         norm(P(qv(3),:)-P(qv(4),:)), norm(P(qv(4),:)-P(qv(1),:))];
    m = min(e);
end

function m = min_edge_pts_v32l(pts)
%MIN_EDGE_PTS_V32L  Shortest edge length of a 4x2 point ring.
    m = min([norm(pts(2,:)-pts(1,:)), norm(pts(3,:)-pts(2,:)), ...
             norm(pts(4,:)-pts(3,:)), norm(pts(1,:)-pts(4,:))]);
end
