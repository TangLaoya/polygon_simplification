function [quadnode, quad, info] = tjclose_v32(quadnode, quad, debug, opts)
%TJCLOSE_V32  V32-05 stage 8.7: dedicated T-junction closure pass.
%   A T-junction is a USED vertex v lying STRICTLY inside a live mesh
%   edge (a,b) (v not an endpoint, v belongs to quads of its own).
%   Closure: the edge is split at v by red-green splitting the owner
%   quad on the side that does NOT yet contain v; children are
%   validated (STRICTLY CONVEX via corner cross products, corners
%   within (2, 179) deg, exact area with a scale-aware floor). The
%   split inserts a fresh vertex m on the quad's OPPOSITE edge
%   (c2,d2); if that edge is interior, m may itself hang on the far
%   side -> the closure PROPAGATES (the classic red-green chain)
%   within the SAME pass, reusing a pre-existing on-edge vertex when
%   one is present (chains absorb each other instead of colliding).
%   Full geometric guards on every split: the three new edges
%   (v,m),(m,c2),(m,d2) may not pass through a vertex and may not
%   properly cross any live mesh edge (a fresh-midpoint split only).
%   A few outer rounds re-scan for stragglers (incremental: only the
%   quads touched by the previous round).
%
%   INPUT:  quadnode, quad, debug flag
%   OUTPUT: closed mesh + info counters

    if nargin < 4; opts = struct(); end
    if nargin < 3; debug = false; end
    if ~isfield(opts, 'stop_thin'); opts.stop_thin = false; end
    t0 = tic;
    nq0 = size(quad, 1);
    info = struct('n_closed', 0, 'n_failed', 0, 'n_left', 0, ...
                  'n_rounds', 0, 'n_prop', 0, ...
                  'n_vtx_before', size(quadnode, 1), ...
                  'n_quad_before', nq0);

    % scale-aware absolute floor for exact-area guards: cross-product
    % roundoff is ~ 4*span^2*eps regardless of how tiny A_old is (dust
    % quads have A ~ 1e-9 with edges ~ 3e-5; a purely relative guard
    % 1e-12*A_old ~ 1e-21 rejects correct splits there - V32-05 fix)
    span_all = max(max(quadnode(:,1)) - min(quadnode(:,1)), ...
                   max(quadnode(:,2)) - min(quadnode(:,2)));
    AREA_FLOOR = 1e4 * eps * span_all * span_all + 1e-300;

    MAX_ROUNDS = 6;
    tj_grid = [];               % used-vertex grid (rebuilt per round)
    eg = struct('ok', false);   % live-edge grid (rebuilt per round)
    newv_list = zeros(0, 1);    % vertices appended this round
    newseg_list = zeros(0, 4);  % new segments (x1 y1 x2 y2) this round
    modq_list = zeros(0, 1);    % quads replaced/appended this round

    for round_i = 1:MAX_ROUNDS
        closed = 0; failed = 0;
        if round_i == 1
            [tlist, ok_detect] = collect_tjunctions_v32([]);
        else
            % incremental: only edges of quads modified last round
            % (every chain abort/stop leaves its hanging vertex on an
            % edge of a quad the chain touched)
            [tlist, ok_detect] = collect_tjunctions_v32(modq_list);
        end
        if ~ok_detect; break; end
        if isempty(tlist); break; end
        tj_grid = build_tj_grid_v32();
        eg = build_edge_grid_v32();
        newv_list = zeros(0, 1);
        newseg_list = zeros(0, 4);
        modq_list = zeros(0, 1);
        next_rebuild_at = 128;
        for k = 1:size(tlist, 1)
            [nc, ok, mq] = close_chain_v32(tlist(k, 1), tlist(k, 2), tlist(k, 3));
            closed = closed + nc;
            if ~ok; failed = failed + 1; end
            modq_list = [modq_list; mq]; %#ok<AGROW>
            % absorb fresh geometry into the grids periodically (keeps
            % the fresh-segment scan short and the checks complete)
            if closed >= next_rebuild_at
                tj_grid = build_tj_grid_v32();
                eg = build_edge_grid_v32();
                newv_list = zeros(0, 1);
                newseg_list = zeros(0, 4);
                next_rebuild_at = closed + 128;
            end
        end
        info.n_closed = info.n_closed + closed;
        info.n_failed = info.n_failed + failed;
        info.n_rounds = round_i;
        if closed == 0; break; end
    end

    % compaction of unused vertices
    used = false(size(quadnode, 1), 1);
    used(quad(:)) = true;
    [keep, ~, newid] = find(used); %#ok<ASGLU>
    if numel(keep) < size(quadnode, 1)
        vmap = zeros(size(quadnode, 1), 1);
        vmap(keep) = 1:numel(keep);
        quad = vmap(quad);
        quadnode = quadnode(keep, :);
    end
    [tleft, ~] = collect_tjunctions_v32([]);
    info.n_left = size(tleft, 1);
    info.tlist_left = tleft;
    info.n_vtx_after = size(quadnode, 1);
    info.n_quad_after = size(quad, 1);
    info.time_sec = toc(t0);
    if debug
        fprintf('  [tjclose] done: closed=%d (chains %d) failed=%d left=%d rounds=%d | vtx %d->%d quads %d->%d | %.2fs\n', ...
            info.n_closed, info.n_prop, info.n_failed, info.n_left, max(info.n_rounds, 1), ...
            info.n_vtx_before, info.n_vtx_after, info.n_quad_before, ...
            info.n_quad_after, info.time_sec);
    end

    % ==================== nested helpers ====================
    % NOTE: nested functions SHARE the parent workspace (MATLAB and
    % Octave alike) - every helper local uses a unique cl_/rp_/ar_/rc_/
    % eg_/ng_ prefix so the parent's v/a/b/t/qv/slot can never be
    % clobbered.

    function [nc, ok, modq] = close_chain_v32(v, a, b)
        %CLOSE_CHAIN_V32  Close the T-junction (v in edge (a,b)) and
        %   propagate the induced hanging midpoint across the mesh
        %   until a conforming stop (boundary edge, far side already
        %   split, quad revisited). Returns splits done + success +
        %   the quad rows this chain replaced/appended.
        nc = 0; ok = false; modq = zeros(0, 1);
        % owner quad of edge (a,b) that does NOT contain v
        owners = edge_owners_v32(a, b);
        if isempty(owners); return; end
        owners_c = [];
        for oi = 1:numel(owners)
            if has_edge_consecutive_v32(owners(oi), a, b)
                owners_c(end+1) = owners(oi); %#ok<AGROW>
            end
        end
        if isempty(owners_c); return; end
        cur_qi = 0;
        for oi = 1:numel(owners_c)
            if ~ismember(v, quad(owners_c(oi), :)); cur_qi = owners_c(oi); break; end
        end
        if cur_qi == 0; return; end   % v is a corner of all owners
        cur_v = v; cur_a = a; cur_b = b;
        seen_q = false(size(quad, 1), 1);
        for step = 1:64
            if cur_qi < 1 || cur_qi > size(quad, 1); return; end
            qv = quad(cur_qi, :);
            % locate the slot of edge (cur_a, cur_b)
            slot = 0;
            for t = 1:4
                e1 = qv(t); e2 = qv(mod(t,4)+1);
                if (e1 == cur_a && e2 == cur_b) || (e1 == cur_b && e2 == cur_a)
                    slot = t; break;
                end
            end
            if slot == 0; return; end
            aa = qv(slot); bb = qv(mod(slot,4)+1);
            c2 = qv(mod(slot+1,4)+1); d2 = qv(mod(slot+2,4)+1);
            % V32-05 r2: degeneracy guard (pristine sweep-C rule)
            if numel(unique([cur_a, cur_b, c2, d2, cur_v])) ~= 5; return; end
            % reuse a pre-existing on-edge vertex for the opposite edge
            % midpoint when one exists (chains absorb each other)
            mv = find_hang_on_seg_v32(c2, d2);
            if mv > 0 && mv ~= cur_v
                m = quadnode(mv, :);
            else
                mv = 0;
                m = 0.5 * (quadnode(c2,:) + quadnode(d2,:));
            end
            Pv = quadnode(cur_v,:);
            QA = [Pv; quadnode(bb,:); quadnode(c2,:); m];
            QB = [Pv; m; quadnode(d2,:); quadnode(aa,:)];
            if ~pts_ring_ok_v32(QA) || ~pts_ring_ok_v32(QB); return; end
            % exact area guard
            A_old = area_ring_pts_v32(quadnode(qv,:));
            A_new = area_ring_pts_v32(QA) + area_ring_pts_v32(QB);
            if abs(A_new - A_old) > max(1e-12 * A_old, AREA_FLOOR); return; end
            % V32-05 r2: FULL geometric guards on the three NEW edges
            % (v,m), (m,c2), (m,d2): no used vertex strictly inside
            % them, no proper crossing of live mesh edges that do not
            % share an endpoint with them (fresh midpoint only - a
            % reused vertex is already part of the mesh).
            if mv == 0 && ~new_edges_clear_v32(Pv, m, quadnode(c2,:), quadnode(d2,:), [cur_v, aa, bb, c2, d2])
                return;
            end
            % append m as a new vertex if not reused
            if mv == 0
                quadnode(end+1, :) = m;
                mv = size(quadnode, 1);
                newv_list(end+1, 1) = mv; %#ok<AGROW>
            end
            quad(cur_qi, :) = ring_ccw_ids_v32([cur_v, bb, c2, mv]);
            quad(end+1, :) = ring_ccw_ids_v32([cur_v, mv, d2, aa]); %#ok<AGROW>
            modq(end+1, 1) = cur_qi;   %#ok<AGROW>
            modq(end+1, 1) = size(quad, 1);   %#ok<AGROW>
            newseg_list(end+1, :) = [Pv, m]; %#ok<AGROW>
            newseg_list(end+1, :) = [m, quadnode(c2,:)]; %#ok<AGROW>
            newseg_list(end+1, :) = [m, quadnode(d2,:)]; %#ok<AGROW>
            nc = nc + 1;
            % ---- propagate: far side of (c2,d2) ----
            far = edge_owners_v32(c2, d2);
            far = far(far ~= cur_qi);
            far_c = [];
            for fi = 1:numel(far)
                if has_edge_consecutive_v32(far(fi), c2, d2)
                    far_c(end+1) = far(fi); %#ok<AGROW>
                end
            end
            far = far_c;
            if isempty(far)
                ok = true; return;          % boundary edge: conforming stop
            end
            qj = far(1);
            if ismember(mv, quad(qj, :))
                ok = true; return;          % far side already split there
            end
            if opts.stop_thin && quad_is_thin_v32(qj)
                % V32-05 r3: splitting a THIN far quad would create
                % dust children with sub-degree corners (the geometric
                % convergence of issue 1). STOP here; the fresh
                % midpoint becomes a debris-fix target (un-collapse)
                % in the next round of the 8.9 loop.
                ok = nc > 0;
                return;
            end
            if qj <= numel(seen_q) && seen_q(qj)
                ok = nc > 0; return;        % revisit: leave for next round
            end
            if qj > numel(seen_q)
                seen_q(end+1:qj) = false;   %#ok<AGROW>
            end
            seen_q(qj) = true;
            info.n_prop = info.n_prop + 1;
            cur_qi = qj; cur_v = mv; cur_a = c2; cur_b = d2;
        end
        ok = nc > 0;
    end

    function tf = quad_is_thin_v32(qi)
        %QUAD_IS_THIN_V32  Dust quad: area < 1e-10 or min edge < 5e-7
        %   (any split of it produces sub-degree corners).
        tf = false;
        if qi < 1 || qi > size(quad, 1); tf = true; return; end
        qv = quad(qi, :);
        pts = quadnode(qv, :);
        s2 = 0;
        for tq = 1:4
            s2 = s2 + pts(tq,1)*pts(mod(tq,4)+1,2) - pts(mod(tq,4)+1,1)*pts(tq,2);
        end
        if abs(s2) * 0.5 < 1e-10; tf = true; return; end
        me = inf;
        for tq = 1:4
            me = min(me, norm(pts(mod(tq,4)+1,:) - pts(tq,:)));
        end
        tf = me < 5e-7;
    end

    function tf = has_edge_consecutive_v32(qi, u, w)
        qrow = quad(qi, :);
        tf = false;
        for ht = 1:4
            if (qrow(ht) == u && qrow(mod(ht,4)+1) == w) || ...
               (qrow(ht) == w && qrow(mod(ht,4)+1) == u)
                tf = true; return;
            end
        end
    end

    function tf = new_edges_clear_v32(Pv, m, Pc2, Pd2, excl_ids)
        %NEW_EDGES_CLEAR_V32  Geometric guards for the three fresh new
        %   edges (v,m), (m,c2), (m,d2): (1) no USED vertex strictly
        %   inside any of them; (2) no proper crossing / near-collinear
        %   overlap with any live mesh edge (round-start edge grid +
        %   this round's fresh segments), excluding edges that share an
        %   endpoint with them. excl_ids = ALL FIVE vertex ids of the
        %   quad being split (its old edges are either kept or just
        %   replaced by this very split - the stale grid copy of a
        %   replaced edge must not be treated as a live overlap).
        tf = false;
        ng_segs = [Pv, m; m, Pc2; m, Pd2];
        % ---- (1) vertex clearance ----
        for ng_i = 1:3
            ng_P1 = ng_segs(ng_i, 1:2); ng_P2 = ng_segs(ng_i, 3:4);
            if seg_hits_vertex_local_v32(ng_P1, ng_P2); return; end
        end
        % ---- (2) crossing check vs live edges ----
        for ng_i = 1:3
            ng_P1 = ng_segs(ng_i, 1:2); ng_P2 = ng_segs(ng_i, 3:4);
            if eg.ok
                % scan ALL grid cells overlapped by the segment bbox
                ng_cx0 = max(0, floor((min(ng_P1(1),ng_P2(1)) - eg.x0) / eg.csx));
                ng_cx1 = min(eg.gx - 1, floor((max(ng_P1(1),ng_P2(1)) - eg.x0) / eg.csx));
                ng_cy0 = max(0, floor((min(ng_P1(2),ng_P2(2)) - eg.y0) / eg.csy));
                ng_cy1 = min(eg.gy - 1, floor((max(ng_P1(2),ng_P2(2)) - eg.y0) / eg.csy));
                for ng_cgx = ng_cx0:ng_cx1
                    for ng_cgy = ng_cy0:ng_cy1
                        glist = eg.bmap{ng_cgy * eg.gx + ng_cgx + 1};
                        for ng_gi = 1:numel(glist)
                            ng_e = eg.E(glist(ng_gi), :);
                            % exclude edges sharing an endpoint
                            if any(ng_e(1) == excl_ids) || any(ng_e(2) == excl_ids)
                                continue;
                            end
                            ng_Q1 = quadnode(ng_e(1), :); ng_Q2 = quadnode(ng_e(2), :);
                            if segs_touch_bad_v32(ng_P1, ng_P2, ng_Q1, ng_Q2)
                                return;
                            end
                        end
                    end
                end
            end
            % this round's fresh segments (grid does not know them)
            for ng_j = 1:size(newseg_list, 1)
                ns = newseg_list(ng_j, :);
                if segs_touch_bad_v32(ng_P1, ng_P2, ns(1:2), ns(3:4))
                    return;
                end
            end
        end
        tf = true;
    end

    function bad = segs_touch_bad_v32(P1, P2, Q1, Q2)
        %SEGS_TOUCH_BAD_V32  TRUE if segments properly cross OR overlap
        %   nearly collinearly (conservative - both are rejected).
        bad = false;
        ngd1 = orient2_local_v32(P1, P2, Q1);
        ngd2 = orient2_local_v32(P1, P2, Q2);
        ngd3 = orient2_local_v32(Q1, Q2, P1);
        ngd4 = orient2_local_v32(Q1, Q2, P2);
        ng_ps = sign(ngd1) * sign(ngd2);
        ng_qs = sign(ngd3) * sign(ngd4);
        if ng_ps < 0 && ng_qs < 0; bad = true; return; end
        % near-degenerate: an endpoint (nearly) ON the other segment
        % while the segments are not far apart -> overlap risk
        if ng_ps == 0 || ng_qs == 0
            % reject only if the ON-case is a strict interior touch
            if pt_strict_inside_v32(Q1, P1, P2) || pt_strict_inside_v32(Q2, P1, P2) || ...
               pt_strict_inside_v32(P1, Q1, Q2) || pt_strict_inside_v32(P2, Q1, Q2)
                bad = true; return;
            end
        end
    end

    function tf = pt_strict_inside_v32(Pt, A, B)
        %PT_STRICT_INSIDE_V32  Pt strictly inside segment A-B (open,
        %   relative tolerance).
        tf = false;
        ng_AB = B - A; ng_L2 = ng_AB(1)^2 + ng_AB(2)^2;
        if ng_L2 < 1e-300; return; end
        ng_AP = Pt - A;
        ng_tp = (ng_AP(1)*ng_AB(1) + ng_AP(2)*ng_AB(2)) / ng_L2;
        if ng_tp <= 1e-9 || ng_tp >= 1 - 1e-9; return; end
        ng_dist = abs(ng_AP(1)*ng_AB(2) - ng_AP(2)*ng_AB(1)) / sqrt(ng_L2);
        tf = ng_dist < 1e-9 * sqrt(ng_L2);
    end

    function d = orient2_local_v32(P, Q, R)
        d = (Q(1)-P(1)) * (R(2)-P(2)) - (Q(2)-P(2)) * (R(1)-P(1));
    end

    function hit = seg_hits_vertex_local_v32(P1, P2)
        %SEG_HITS_VERTEX_LOCAL_V32  TRUE if any used vertex (round-start
        %   grid + this round's fresh vertices) lies STRICTLY inside
        %   segment P1-P2.
        hit = false;
        ng_cands = zeros(0, 1);
        if tj_grid.ok
            ix1 = max(1, floor((min(P1(1),P2(1))-tj_grid.x0)/tj_grid.csx) + 1);
            ix2 = min(tj_grid.gx, floor((max(P1(1),P2(1))-tj_grid.x0)/tj_grid.csx) + 1);
            iy1 = max(1, floor((min(P1(2),P2(2))-tj_grid.y0)/tj_grid.csy) + 1);
            iy2 = min(tj_grid.gy, floor((max(P1(2),P2(2))-tj_grid.y0)/tj_grid.csy) + 1);
            for cxg = ix1:ix2
                for cyg = iy1:iy2
                    cqid = (cyg - 1) * tj_grid.gx + cxg;
                    lo = 1; hi = numel(tj_grid.uck); bi = 0;
                    while lo <= hi
                        mid = floor((lo+hi)/2);
                        if tj_grid.uck(mid) == cqid; bi = mid; break;
                        elseif tj_grid.uck(mid) < cqid; lo = mid+1;
                        else; hi = mid-1; end
                    end
                    if bi == 0; continue; end
                    for s = tj_grid.starts(bi):tj_grid.starts(bi)+tj_grid.cnts(bi)-1
                        ng_cands(end+1, 1) = tj_grid.uidx(tj_grid.ordv(s)); %#ok<AGROW>
                    end
                end
            end
        end
        ng_cands = [ng_cands; newv_list];
        ng_AB = P2 - P1; ng_L2 = ng_AB(1)^2 + ng_AB(2)^2;
        if ng_L2 < 1e-300; return; end
        for ci = 1:numel(ng_cands)
            w = ng_cands(ci);
            if norm(quadnode(w,:) - P1) < 1e-300 || norm(quadnode(w,:) - P2) < 1e-300
                continue;
            end
            ng_AP = quadnode(w, :) - P1;
            ng_tp = (ng_AP(1)*ng_AB(1) + ng_AP(2)*ng_AB(2)) / ng_L2;
            if ng_tp <= 1e-9 || ng_tp >= 1 - 1e-9; continue; end
            ng_dist = abs(ng_AP(1)*ng_AB(2) - ng_AP(2)*ng_AB(1)) / sqrt(ng_L2);
            if ng_dist < 1e-9 * sqrt(ng_L2)
                hit = true; return;
            end
        end
    end

    function g = build_tj_grid_v32()
        %BUILD_TJ_GRID_V32  Bucket grid over USED vertices (positions of
        %   pre-existing vertices never move inside this pass).
        g = struct('ok', false);
        nv = size(quadnode, 1);
        usedv = false(nv, 1);
        usedv(quad(:)) = true;
        uidx = find(usedv);
        if isempty(uidx); return; end
        gspan = max(max(quadnode(uidx,1)) - min(quadnode(uidx,1)), ...
                    max(quadnode(uidx,2)) - min(quadnode(uidx,2))) * 1.0001 + 1e-300;
        g.gx = max(8, round(sqrt(numel(uidx)))); g.gy = g.gx;
        g.x0 = min(quadnode(uidx,1)); g.y0 = min(quadnode(uidx,2));
        g.csx = gspan / g.gx; g.csy = gspan / g.gy;
        cx = min(g.gx, max(1, floor((quadnode(uidx,1)-g.x0)/g.csx) + 1));
        cy = min(g.gy, max(1, floor((quadnode(uidx,2)-g.y0)/g.csy) + 1));
        cid = (cy - 1) * g.gx + cx;
        [uck, ~, icu] = unique(cid);
        cnts = accumarray(icu, 1);
        g.starts = [1; cumsum(cnts(1:end-1)) + 1];
        [~, ordv] = sort(cid);
        g.uidx = uidx; g.ordv = ordv; g.uck = uck; g.cnts = cnts;
        g.ok = true;
    end

    function g = build_edge_grid_v32()
        %BUILD_EDGE_GRID_V32  Edge grid bucketed by EVERY cell an edge's
        %   bbox spans (round-start snapshot; fresh segments tracked
        %   separately). A query scanning the new segment's bbox cells
        %   then sees every possible crossing candidate - midpoint
        %   bucketing missed long edges whose midpoint sat in a far
        %   cell (3 real crossings slipped through, V32-05 r2).
        g = struct('ok', false);
        nq = size(quad, 1);
        if nq == 0; return; end
        g.E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        ne = size(g.E, 1);
        gspan = max(max(quadnode(:,1)) - min(quadnode(:,1)), ...
                    max(quadnode(:,2)) - min(quadnode(:,2))) * 1.0001 + 1e-300;
        g.gx = max(8, round(sqrt(ne))); g.gy = g.gx;
        g.x0 = min(quadnode(:,1)); g.y0 = min(quadnode(:,2));
        g.csx = gspan / g.gx; g.csy = gspan / g.gy;
        g.bmap = cell(g.gx * g.gy, 1);
        for i = 1:ne
            a = quadnode(g.E(i,1), :); b = quadnode(g.E(i,2), :);
            cx0 = max(0, floor((min(a(1),b(1)) - g.x0) / g.csx));
            cx1 = min(g.gx - 1, floor((max(a(1),b(1)) - g.x0) / g.csx));
            cy0 = max(0, floor((min(a(2),b(2)) - g.y0) / g.csy));
            cy1 = min(g.gy - 1, floor((max(a(2),b(2)) - g.y0) / g.csy));
            for cgx = cx0:cx1
                for cgy = cy0:cy1
                    cidx = cgy * g.gx + cgx + 1;
                    g.bmap{cidx}(end+1) = i; %#ok<AGROW>
                end
            end
        end
        g.ok = true;
    end

    function vid = find_hang_on_seg_v32(a, b)
        %FIND_HANG_ON_SEG_V32  Used vertex strictly inside segment (a,b)
        %   (grid scan over pre-existing vertices + this round's new
        %   ones). Returns 0 if none.
        vid = 0;
        A = quadnode(a, :); B = quadnode(b, :);
        AB = B - A; L2 = AB(1)^2 + AB(2)^2;
        if L2 < 1e-300; return; end
        cands = zeros(0, 1);
        if ~isempty(tj_grid) && tj_grid.ok
            ix1 = max(1, floor((min(A(1),B(1))-tj_grid.x0)/tj_grid.csx) + 1);
            ix2 = min(tj_grid.gx, floor((max(A(1),B(1))-tj_grid.x0)/tj_grid.csx) + 1);
            iy1 = max(1, floor((min(A(2),B(2))-tj_grid.y0)/tj_grid.csy) + 1);
            iy2 = min(tj_grid.gy, floor((max(A(2),B(2))-tj_grid.y0)/tj_grid.csy) + 1);
            for cxg = ix1:ix2
                for cyg = iy1:iy2
                    cqid = (cyg - 1) * tj_grid.gx + cxg;
                    lo = 1; hi = numel(tj_grid.uck); bi = 0;
                    while lo <= hi
                        mid = floor((lo+hi)/2);
                        if tj_grid.uck(mid) == cqid; bi = mid; break;
                        elseif tj_grid.uck(mid) < cqid; lo = mid+1;
                        else; hi = mid-1; end
                    end
                    if bi == 0; continue; end
                    for s = tj_grid.starts(bi):tj_grid.starts(bi)+tj_grid.cnts(bi)-1
                        cands(end+1, 1) = tj_grid.uidx(tj_grid.ordv(s)); %#ok<AGROW>
                    end
                end
            end
        end
        cands = [cands; newv_list];
        for ci = 1:numel(cands)
            w = cands(ci);
            if w == a || w == b; continue; end
            AP = quadnode(w, :) - A;
            tp = (AP(1)*AB(1) + AP(2)*AB(2)) / L2;
            if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
            dist = abs(AP(1)*AB(2) - AP(2)*AB(1)) / sqrt(L2);
            if dist < 1e-9 * sqrt(L2)
                vid = w; return;
            end
        end
    end

    function [tlist, ok] = collect_tjunctions_v32(scan_qids)
        %COLLECT_TJUNCTIONS_V32  [v, a, b] rows: used vertex v strictly
        %   inside live edge (a,b), v not an endpoint. Empty scan_qids =
        %   full scan; otherwise only the edges of the given quad rows
        %   are checked (incremental rounds). Tolerance matches the
        %   verifier exactly (1e-9 * sqrt(L2)) so this pass never
        %   chases sub-nanometer "T's" the verifier cannot see (dust
        %   edges) - closing those created dust quads with collinear
        %   corners (round-04 issue 2 residue).
        tlist = zeros(0, 3); ok = true;
        nv = size(quadnode, 1); nq = size(quad, 1);
        if nq == 0; return; end
        if isempty(scan_qids)
            E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        else
            scan_qids = unique(scan_qids(scan_qids >= 1 & scan_qids <= nq));
            if isempty(scan_qids); return; end
            qr = quad(scan_qids, :);
            E = [qr(:, [1 2]); qr(:, [2 3]); qr(:, [3 4]); qr(:, [4 1])];
        end
        K = double(nv) + 2;
        key = min(E(:,1), E(:,2)) * K + max(E(:,1), E(:,2));
        [skey, ord] = sort(key);
        first = [true; diff(skey) ~= 0];
        gstart = [find(first); numel(skey) + 1];
        ng = numel(gstart) - 1;
        % used vertices + spatial grid over vertices
        usedv = false(nv, 1);
        usedv(quad(:)) = true;
        uidx = find(usedv);
        % vertex grid
        if isempty(uidx); return; end
        span = max(max(quadnode(uidx,1)) - min(quadnode(uidx,1)), ...
                   max(quadnode(uidx,2)) - min(quadnode(uidx,2))) * 1.0001 + 1e-300;
        gx = max(8, round(sqrt(numel(uidx)))); gy = gx;
        x0 = min(quadnode(uidx,1)); y0 = min(quadnode(uidx,2));
        csx = span / gx; csy = span / gy;
        cx = min(gx, max(1, floor((quadnode(uidx,1)-x0)/csx) + 1));
        cy = min(gy, max(1, floor((quadnode(uidx,2)-y0)/csy) + 1));
        cid = (cy - 1) * gx + cx;
        [uck, ~, icu] = unique(cid);
        cnts = accumarray(icu, 1);
        starts = [1; cumsum(cnts(1:end-1)) + 1];
        [~, ordv] = sort(cid);
        uckeys = uck;
        for g = 1:ng
            ea = floor(skey(gstart(g)) / K); eb = mod(skey(gstart(g)), K);
            A = quadnode(ea, :); B = quadnode(eb, :);
            AB = B - A; L2 = AB(1)^2 + AB(2)^2;
            if L2 < 1e-300; continue; end
            % scan vertex grid cells overlapped by the segment bbox
            ix1 = max(1, floor((min(A(1),B(1))-x0)/csx) + 1);
            ix2 = min(gx, floor((max(A(1),B(1))-x0)/csx) + 1);
            iy1 = max(1, floor((min(A(2),B(2))-y0)/csy) + 1);
            iy2 = min(gy, floor((max(A(2),B(2))-y0)/csy) + 1);
            for cxg = ix1:ix2
                for cyg = iy1:iy2
                    cqid = (cyg - 1) * gx + cxg;
                    % binary search in uckeys
                    lo = 1; hi = numel(uckeys); bi = 0;
                    while lo <= hi
                        mid = floor((lo+hi)/2);
                        if uckeys(mid) == cqid; bi = mid; break;
                        elseif uckeys(mid) < cqid; lo = mid+1;
                        else; hi = mid-1; end
                    end
                    if bi == 0; continue; end
                    for cl_s = starts(bi):starts(bi)+cnts(bi)-1
                        cl_v = uidx(ordv(cl_s));
                        if cl_v == ea || cl_v == eb; continue; end
                        if ismember(cl_v, tlist(:, 1)); continue; end
                        AP = quadnode(cl_v, :) - A;
                        tp = (AP(1)*AB(1) + AP(2)*AB(2)) / L2;
                        if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
                        dist = abs(AP(1)*AB(2) - AP(2)*AB(1)) / sqrt(L2);
                        if dist < 1e-9 * sqrt(L2)
                            tlist(end+1, :) = [cl_v, ea, eb]; %#ok<AGROW>
                        end
                    end
                end
            end
        end
    end

    function owners = edge_owners_v32(a, b)
        %EDGE_OWNERS_V32  Live quad rows containing both a and b.
        owners = find(ismember(quad(:,1), a) | ismember(quad(:,2), a) | ...
                      ismember(quad(:,3), a) | ismember(quad(:,4), a));
        owners = owners(any(quad(owners,:) == b, 2));
    end

    function tf = pts_ring_ok_v32(pts)
        %PTS_RING_OK_V32  4-point ring: simple, strictly CONVEX (all
        %   four corner cross products positive - an angle-only check
        %   lets reflex corners through as small vector angles), corner
        %   angles within (2 deg, 179 deg), no dust edges.
        tf = false;
        rp_s2 = 0;
        for rp_t = 1:4
            rp_s2 = rp_s2 + pts(rp_t,1)*pts(mod(rp_t,4)+1,2) - pts(mod(rp_t,4)+1,1)*pts(rp_t,2);
        end
        if rp_s2 <= 1e-300; return; end
        for rp_t = 1:4
            rp_v = pts(rp_t,:);
            rp_u = pts(mod(rp_t+2,4)+1,:); rp_w = pts(mod(rp_t,4)+1,:);
            % corner cross: (v-prev) x (next-v) must be > 0 (convex CCW)
            rp_cr = (rp_v(1)-rp_u(1))*(rp_w(2)-rp_v(2)) - ...
                    (rp_v(2)-rp_u(2))*(rp_w(1)-rp_v(1));
            if rp_cr <= 1e-300; return; end
            rp_a = rp_u - rp_v; rp_b = rp_w - rp_v;
            rp_na = norm(rp_a); rp_nb = norm(rp_b);
            if rp_na < 1e-12 || rp_nb < 1e-12; return; end
            rp_cs = (rp_a(1)*rp_b(1)+rp_a(2)*rp_b(2)) / (rp_na*rp_nb);
            rp_angd = acosd(max(-1, min(1, rp_cs)));
            if rp_angd <= 2 || rp_angd >= 179; return; end
        end
        tf = true;
    end

    function a_out = area_ring_pts_v32(pts)
        ar_s2 = 0;
        for ar_t = 1:4
            ar_s2 = ar_s2 + pts(ar_t,1)*pts(mod(ar_t,4)+1,2) - pts(mod(ar_t,4)+1,1)*pts(ar_t,2);
        end
        a_out = 0.5 * abs(ar_s2);
    end

    function qv_out = ring_ccw_ids_v32(ids)
        %RING_CCW_IDS_V32  Rotate/reverse ids to CCW ring order.
        rc_s = 0;
        for rc_t = 1:4
            rc_s = rc_s + quadnode(ids(rc_t),1)*quadnode(ids(mod(rc_t,4)+1),2) - ...
                      quadnode(ids(mod(rc_t,4)+1),1)*quadnode(ids(rc_t),2);
        end
        qv_out = ids;
        if rc_s < 0; qv_out = ids([1 4 3 2]); end
    end
end
