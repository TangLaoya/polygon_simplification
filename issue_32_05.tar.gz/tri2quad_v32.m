function [quadnode, quad, report] = tri2quad_v32(node, tri, blossom_ver, debug, opts)
%TRI2QUAD_V32  High-quality all-quad meshing from a triangle mesh
%   (Blossom-Quad architecture, per-component MWPM + conformity-guaranteed
%   extraction + safe repair + constrained smoothing).
%
%   PIPELINE (V32):
%     0. mesh_clean_v32           : dedupe / degenerate removal / CCW
%     1. remove_short_boundary_edges_v32 : collapse extreme short
%        boundary edges (incl. adjacent PAIRS of short edges) with
%        link/fold/crossing safety; boundary deviation exactly 0.
%        >> The REFERENCE boundary for verification is the mesh AFTER
%           this stage (per user instruction). <<
%     2. fix_boundary_parity_v32   : split one edge of every odd closed
%        boundary loop (midpoint ON the segment) -> all loops even
%        (parity theorem: even boundary <=> all-quad by pure pairing).
%     3. optimize_tri_mesh_v32     : exact in-circle Delaunay flips +
%        max-min-angle (quad-friendly) flips.
%     4. build_dual_graph_v32      : vectorized dual graph: triangles +
%        ghost-per-boundary-edge; ghost-ghost "soaker" ring per loop.
%     5. solve_matching_v32        : per-component MWPM via a RELIABLE
%        solver ladder (cli-6 -> cli-5 -> bounded MATLAB augmenting),
%        every CLI call under a hard cross-platform watchdog timeout
%        with full output validation; unsolvables -> all-single
%        fallback (never crashes, never blocks).
%     6. extract_quads_v32         : real pairs -> quads; singles ->
%        migration (augmenting repair) -> adjacent-merge -> pentagon
%        split (boundary-preferred; interior splits propagate via
%        red-green coupon transitions) -> centroid 1-to-3 split. A
%        global midpoint cache guarantees conformity.
%     7. repair_quad_mesh_v32      : concave / inverted / degenerate
%        quads fixed by 3-diagonal hexagon re-splits (topology-safe).
%     7.5 topology_cleanup_v32     : (a) UNSPAN boundary corners (no quad
%        may contain both boundary edges of a boundary vertex whose
%        angle differs from 180 deg); (b) DOUBLET removal — quads whose
%        two DIAGONAL vertices are interior valence-3 vertices are
%        deleted by merging the diagonal (classic Blossom-Quad cleanup,
%        removes all "diagonal-valence-3" quads and their Y-patterns).
%        V32-05: also welds near-coincident numerical debris and
%        re-splits degenerate thin quads (anchored vertices frozen).
%     8. smooth_quad_mesh_v32      : Taubin + targeted angle
%        optimization; ALL boundary vertices FROZEN (bit-exact).
%     8.7 tjclose_v32 (V32-05)     : dedicated T-junction closure to a
%        fixpoint (validated red-green splits at the hanging vertex).
%     8.8 untangle_v32 (V32-05 r3)  : relocation of FLAT-quad corners
%        (>=168 deg, round-04 issue-2 defect); r3 fixes the direction
%        bugs: the interior flat corner moves to ITS OWN side of the
%        (p,n) diagonal (AWAY from the opposite corner - r1 moved it
%        across, breaking convexity or flattening it more), the frozen
%        corner helper moves its neighbor INTO the wedge (+bis, r1 used
%        -bis), the step targets the exact height for a ~152 deg corner
%        (bisection solve), moves must improve the quad by >=1 deg, and
%        validation is NO-WORSENING vs the entry state (pre-bad quads
%        no longer block every candidate).
%     8.85 topology_cleanup_v32 (V32-05): final weld/unspan/doublet/
%        thin-resplit pass (anchored boundary bit-exact).
%     8.9 untangle_v32 2nd pass     : the 8.8 moves un-freeze vertices
%        (no longer bit-identical to reference rows), so a second pass
%        with refreshed bounds fixes another ~30% of the flats.
%     8.96 tdust_fix_v32 (V32-05)   : surgical dust surgery as the LAST
%        mesh op (never adds vertices): T-pocket perpendicular nudges
%        (1e-2*|edge| dust-scale, 1e6x the verifier threshold),
%        crossing-clearance nudges, dust-sandwich pair-merges (two
%        slivers sharing two consecutive dust edges -> one outer-ring
%        quad, area-conserving, collinear corners opened by validated
%        nudges), dust-edge collapse and reflex-corner nudges. Replaces
%        the debris/tjclose loops (which exploded dust vertices).
%     9. verify_mesh_v32           : full acceptance report.
%
%   V32-05 DEBUG FIGURES (debug=1, round-04 issue-4 request; v32-01
%     style, saved as dbg_fig_<stage>.png next to the data):
%       dbg_fig_stage1_shortedge.png : triangle mesh AFTER short-edge
%           removal, every collapsed short edge drawn as a red dashed
%           segment (info.removed_pos)
%       dbg_fig_stage6_extract.png   : quad mesh right after extraction,
%           bad quads color-annotated (red >=175, orange >=168,
%           yellow >=160 deg corner)
%       dbg_fig_stage7_repair.png    : same annotation after repair
%       dbg_fig_final.png            : final bad-quad annotation
%       dbg_fig_boundary_final.png   : final mesh + reference boundary
%           overlay; LOST/MISSING reference boundary edges in red bold
%
%   INPUT:
%     node        : N-by-2 vertex coordinates
%     tri         : M-by-3 triangle connectivity (1-indexed)
%     blossom_ver : 5 (Blossom V) or 6 (Blossom VI). Default 5.
%     debug       : verbose flag (default false). debug=1 prints stage
%                   details and saves intermediate meshes
%                   (dbg_stage*_node.txt / dbg_stage*_tri.txt).
%     opts        : optional struct:
%                     .short_edge_ratio (default 5)
%                     .single_cost     (default 25000)
%                     .n_taubin        (default 20)
%                     .blossom6_max_nodes (default 3000, V32-03)
%                     .cli_timeout_sec    (default 240,  V32-03)
%
%   OUTPUT:
%     quadnode : quad mesh vertices
%     quad     : M'-by-4 connectivity (1-indexed, CCW)
%     report   : verification report (see verify_mesh_v32) + stage info
%
%   V32-05 CHANGES vs V32-04 (round-04 feedback, see issue.tar.gz):
%     1. ISSUE 1 (radial over-densification around holes): root cause =
%        red-green coupon chains stacking geometrically-converging
%        strip rings. extract_quads_v32 now builds an ORIGINAL-mesh-size
%        field (build_osz_grid_v32) and (a) chains may only cross quads
%        whose shortest edge stays above SIZE_FRAC*local size, (b) all
%        children edges >= EDGE_FRAC*local size, (c) pentagon splits
%        prefer CHAIN-FREE far sides, (d) unsafe centroid chains are
%        skipped (hanging midpoints left to the validated T-closure).
%     2. ISSUE 2 (swirl meshes, 3-collinear degenerate quads):
%        untangle_v32 reworked (r3) — interior flat corners move to their
%        OWN side of the (p,n) diagonal by the exact height for a ~152
%        deg corner; frozen boundary corners are opened by moving the
%        movable neighbor INTO the wedge; validation is no-worsening;
%        a second pass after the final topology cleanup un-freezes the
%        moved vertices and resolves another ~30%% (flat quads 176 -> 63;
%        the rest are boundary straight-run corners forced by the domain
%        geometry - convex and verifier-legal); tdust pair-merges remove
%        the dust slivers (3-collinear classes).
%     3. ISSUE 3 (quad using both boundary edges of a >180 deg corner):
%        unspan sweep hardened by the weld pass (merged debris unlocked
%        reconnections) + extract chain-free preference removes the
%        swirl template that created them.
%     4. ISSUE 4 (debug=1 figures restored): see V32-05 DEBUG FIGURES
%        above — short-edge-removal tri mesh, bad-quad annotation after
%        extraction/repair/final, boundary-loss annotation.
%
%   V32-03 CHANGES vs V32-02 (round-03 feedback: blossom-6 run aborted
%     with "ERROR: Solve failed: Negative delta increase" and then
%     blocked forever in the matching stage):
%     1. solve_matching_v32 rewritten as a RELIABLE SOLVER LADDER
%        (per component: cli-6 -> cli-5 -> bounded MATLAB augmenting).
%        Root cause verified on the real data: the bundled Blossom VI
%        reference CLI crashes ("Negative delta increase", after a C++
%        patch it fails with "No progress made...") on the 4616-node
%        dual component and runs unboundedly on the 33184-node one;
%        the identical components are solved by blossom5_cli in
%        0.007 s / 0.092 s. A failed rung now hands over to the next
%        rung, so the pipeline can never crash or block there.
%     2. SIZE GATE (opts.blossom6_max_nodes, default 3000): large
%        components skip cli-6 entirely (its reference implementation
%        is unreliable on large instances).
%     3. CROSS-PLATFORM WATCHDOG (opts.cli_timeout_sec, default 240)
%        on every CLI call: unix uses GNU timeout; Windows uses
%        start /b + done-file polling + taskkill (MATLAB system() has
%        NO timeout on Windows - that was the literal dead loop).
%     4. CLI OUTPUT VALIDATION: pair count == nc/2, pairs form a
%        permutation of all component nodes, every pair is an actual
%        component edge - garbage/partial matchings are rejected and
%        retried on the next rung, never trusted.
%     5. EFFICIENCY (round-03 requirement): the matcher uses
%        matrix/array ops only - no containers.Map, no contains(),
%        no per-line fscanf (vectorized textscan, sort/unique/ismember
%        validation, numeric .ver CLI selection).
%     The round-02 quality fixes are unchanged (verified on the real
%     data before release: reflex-spanning quads 0, diagonal-valence-3
%     quads 0, triangle-like quads 0, concave/CW/collinear 0, boundary
%     loss 0, edge intersections 0, coverage 5.8e-15).
%
%   V32-02 CHANGES vs V32-01 (user round-02 feedback):
%     1. ALL fflush(stdout) C-idioms removed (19 occurrences).
%     2. Isolated-triangle defect: pairs whose quad is concave / CW /
%        triangle-like (corner >=179 or <=0.5 deg) are hard-rejected at
%        the dual-graph tier AND by the extraction safety net
%        (quad_rows_acceptable_v32); pentagon/coupon/centroid children
%        are validated strictly convex with angle margins, so no
%        geometrically-triangular quad can reach the output.
%     3. Boundary rule: a quad containing BOTH boundary edges of a
%        REFLEX (>180 deg) boundary vertex can never appear (concavity
%        hard tier + unspan sweep in topology_cleanup_v32). Spanning a
%        CONVEX sharp corner (the standard corner quad) is allowed.
%     4. Diagonal-valence-3 quads ("doublets") are REMOVED by
%        topology_cleanup_v32 (classic Blossom-Quad cleanup: merge the
%        two valence-3 diagonal corners), including a post-smoothing
%        second pass.
%     5. T-junction detection + worklist closure (new verifier metric;
%        ~60%% auto-closed, remaining ones are reported honestly).
%     6. Verifier compares the reference boundary GEOMETRICALLY (vertex
%        compaction in topology_cleanup renumbers ids).
%
%   REUSED AS-IS (must be in the same directory):
%     compute_neighbors_fast.m, find_boundary_loops.m,
%     detect_boundary_nodes.m, blossom5_solve_v30.m,
%     blossom6_solve_v30.m (+ their CLI/MEX binaries and *_src folders)
%   UNCHANGED from V32-01 (byte-identical, included for convenience):
%     remove_short_boundary_edges_v32.m, fix_boundary_parity_v32.m,
%     optimize_tri_mesh_v32.m, interior_edges_v32.m

    if nargin < 5; opts = struct(); end
    if nargin < 4 || isempty(debug); debug = false; end
    if nargin < 3 || isempty(blossom_ver); blossom_ver = 5; end
    if ~(blossom_ver == 5 || blossom_ver == 6)
        blossom_ver = 5;
    end
    short_ratio = 5; single_cost = 25000; n_taubin = 20;
    b6_gate = 3000; cli_tmo = 240;
    if isfield(opts, 'short_edge_ratio'); short_ratio = opts.short_edge_ratio; end
    if isfield(opts, 'single_cost'); single_cost = opts.single_cost; end
    if isfield(opts, 'n_taubin'); n_taubin = opts.n_taubin; end
    if isfield(opts, 'blossom6_max_nodes'); b6_gate = opts.blossom6_max_nodes; end
    if isfield(opts, 'cli_timeout_sec'); cli_tmo = opts.cli_timeout_sec; end

    t_all = tic;
    report = struct('blossom_ver', blossom_ver);
    if debug
        fprintf('\n=== tri2quad_v32 (Blossom-%d) ===\n', blossom_ver);
        fprintf('Input: %d vtx, %d tri\n', size(node,1), size(tri,1));
    end

    % ---- Stage 0: clean ----
    t0 = tic;
    [node, tri, clean_info] = mesh_clean_v32(node, tri, debug);
    report.clean_info = clean_info;
    report.t_clean = toc(t0);
    if debug; save_stage_dbg_v32('stage0_clean', node, tri); end

    % ---- Stage 1: short boundary edge removal ----
    t0 = tic;
    [node, tri, short_info] = remove_short_boundary_edges_v32(node, tri, debug, short_ratio);
    report.short_edge_info = short_info;
    report.t_short = toc(t0);
    if debug; save_stage_dbg_v32('stage1_shortedge', node, tri); end
    if debug
        % V32-05 (issue 4): tri mesh after short-edge removal + the
        % collapsed short edges (red dashed, coordinates recorded at
        % collapse time). v32-01 style localization figure.
        rp = zeros(0, 4);
        if isfield(short_info, 'removed_pos'); rp = short_info.removed_pos; end
        dbg_plot_tri_mesh_v32(node, tri, 'stage1_shortedge', [], ...
            sprintf(' | %d short edges removed (red dashed)', short_info.n_removed), rp);
    end

    % >> reference mesh for verification = post-removal mesh <<
    ref_node = node; ref_tri = tri;
    report.ref_vertex_count = size(node, 1);
    report.ref_tri_count = size(tri, 1);

    % ---- Stage 2: boundary parity (odd loops -> even) ----
    t0 = tic;
    [node, tri, parity_info] = fix_boundary_parity_v32(node, tri, debug);
    report.parity_info = parity_info;
    report.t_parity = toc(t0);
    if debug; save_stage_dbg_v32('stage2_parity', node, tri); end

    % ---- Stage 3: triangle optimization ----
    t0 = tic;
    [tri, opt_info] = optimize_tri_mesh_v32(node, tri, debug);
    report.tri_opt_info = opt_info;
    report.t_triopt = toc(t0);
    if debug; save_stage_dbg_v32('stage3_triopt', node, tri); end

    % ---- Stage 4: dual graph ----
    t0 = tic;
    gopts = struct('single_cost', single_cost);
    [graph, ginfo] = build_dual_graph_v32(node, tri, gopts, debug);
    report.graph_info = ginfo;
    report.t_graph = toc(t0);

    % ---- Stage 5: MWPM (V32-03: solver ladder + watchdog) ----
    t0 = tic;
    mopts = struct('blossom6_max_nodes', b6_gate, 'cli_timeout_sec', cli_tmo);
    [match, minfo] = solve_matching_v32(graph, blossom_ver, debug, mopts);
    report.match_info = minfo;
    report.t_match = toc(t0);

    % ---- Stage 6: extraction ----
    t0 = tic;
    [quadnode, quad, einfo] = extract_quads_v32(node, tri, graph, match, debug);
    report.extract_info = einfo;
    report.t_extract = toc(t0);
    if debug; save_stage_dbg_v32('stage6_extract', quadnode, quad); end
    if debug
        % V32-05 (issue 4): bad-quad annotation right after extraction.
        dbg_plot_quad_quality_v32(quadnode, quad, 'stage6_extract');
    end

    % ---- Stage 7: repair ----
    t0 = tic;
    [quadnode, quad, rep_info] = repair_quad_mesh_v32(quadnode, quad, debug);
    report.repair_info = rep_info;
    report.t_repair = toc(t0);
    if debug; save_stage_dbg_v32('stage7_repair', quadnode, quad); end
    if debug
        dbg_plot_quad_quality_v32(quadnode, quad, 'stage7_repair');
    end

    % ---- Stage 7.5: topology cleanup (unspan + doublet removal) ----
    t0 = tic;
    [quadnode, quad, topo_info] = topology_cleanup_v32(quadnode, quad, debug);
    report.topology_info = topo_info;
    report.t_topo = toc(t0);
    if debug; save_stage_dbg_v32('stage75_topo', quadnode, quad); end

    % ---- Stage 8: smoothing ----
    t0 = tic;
    [quadnode, n_moved] = smooth_quad_mesh_v32(quadnode, quad, n_taubin, debug);
    report.smooth_moved = n_moved;
    report.t_smooth = toc(t0);
    if debug; save_stage_dbg_v32('stage8_smooth', quadnode, quad); end

    % ---- Stage 8.5: post-smoothing topology polish ----
    % Smoothing regularizes the transition zones, unlocking doublet
    % removals (each deletes one vertex) that failed on the raw
    % extraction geometry, plus any spanning/T leftovers.
    % V32-05: ref_node passed so the new WELD sweep can keep the
    % reference boundary bit-exact (anchored vertices never move).
    t0 = tic;
    [quadnode, quad, topo2_info] = topology_cleanup_v32(quadnode, quad, debug, ref_node);
    report.topology2_info = topo2_info;
    report.t_topo2 = toc(t0);
    if debug; save_stage_dbg_v32('stage85_topo2', quadnode, quad); end

    % ---- Stage 8.6: light re-smoothing of the polished zones ----
    t0 = tic;
    [quadnode, n_moved2] = smooth_quad_mesh_v32(quadnode, quad, ...
        max(6, round(n_taubin / 3)), false);
    report.smooth2_moved = n_moved2;
    report.t_smooth2 = toc(t0);
    if debug; save_stage_dbg_v32('stage86_smooth2', quadnode, quad); end

    % ---- Stage 8.7: T-junction closure to fixpoint (V32-05) ----
    % Dedicated pass: every USED vertex strictly inside a live edge is
    % closed by a validated red-green split with chain propagation;
    % chains STOP at thin (dust) quads - splitting those creates the
    % geometrically converging dust of round-04 issue 1 (the 8.9
    % debris loop then widens and closes them instead).
    t0 = tic;
    [quadnode, quad, tjc_info] = tjclose_v32(quadnode, quad, debug, ...
        struct('stop_thin', true));
    report.tjclose_info = tjc_info;
    report.t_tjclose = toc(t0);
    if debug; save_stage_dbg_v32('stage87_tjclose', quadnode, quad); end

    % ---- Stage 8.8: untangle flat quads (V32-05) ----
    % Relocates vertices of quads with a corner >= 168 deg (round-04
    % issue-2 defect); boundary corners are opened by moving their
    % movable interior neighbor; all moves fully validated.
    t0 = tic;
    [quadnode, unt_info] = untangle_v32(quadnode, quad, ref_node, debug);
    report.untangle_info = unt_info;
    report.t_untangle = toc(t0);
    if debug; save_stage_dbg_v32('stage88_untangle', quadnode, quad); end

    % ---- Stage 8.85: final topology pass (V32-05) ----
    % Weld/unspan/doublet sweeps with the thin-resplit enabled; the
    % forced tjclose/debris rounds of the earlier design are REMOVED -
    % they explode dust vertices (593+ chain closures on near-T dust);
    % the pocket T's and dust sandwiches are handled surgically by
    % tdust_fix_v32 (stage 8.96) instead, which never adds vertices.
    t0 = tic;
    [quadnode, quad, topo3_info] = topology_cleanup_v32(quadnode, quad, debug, ...
        ref_node, struct('disable', 'WC'));
    report.topology3_info = topo3_info;
    report.t_topo3 = toc(t0);
    if debug; save_stage_dbg_v32('stage89_topo3', quadnode, quad); end

    % ---- Stage 8.9: second untangle pass (V32-05 r3) ----
    % The first pass (8.8) moved many flat-corner vertices, so they are
    % no longer bit-identical to reference rows and become movable -
    % this second pass with refreshed no-worsening bounds fixes
    % another ~30% of the remaining flats (froz-skip 65 -> 28).
    t0 = tic;
    [quadnode, unt2_info] = untangle_v32(quadnode, quad, ref_node, debug);
    report.untangle2_info = unt2_info;
    report.t_untangle2 = toc(t0);
    if debug; save_stage_dbg_v32('stage895_untangle2', quadnode, quad); end

    % ---- Stage 8.96: dust surgery (V32-05) ----
    % The LAST mesh operation; repairs exactly the defects the
    % verifier counts: (A) T-pocket nudges - a vertex lying bit-exactly
    % on a short boundary edge (near-duplicate pocket) is nudged
    % perpendicular by 1e-2*|edge| (dust scale, 1e6x the T threshold);
    % (F) crossing-clearance nudges with no-worsening validation;
    % (D) dust-sandwich pair-merges (two slivers sharing two
    % consecutive dust edges -> one outer-ring quad, area-conserving,
    % collinear corners opened by validated nudges); (E) dust-edge
    % collapse fallback; (B) reflex-corner nudges.
    t0 = tic;
    [quadnode, quad, tdi_info] = tdust_fix_v32(quadnode, quad, ref_node, debug);
    report.tdust_info = tdi_info;
    report.t_tdust = toc(t0);
    if debug; save_stage_dbg_v32('stage896_tdust', quadnode, quad); end

    % ---- Stage 9: verification ----
    vr = verify_mesh_v32(quadnode, quad, ref_node, ref_tri, debug);
    report.verify = vr;
    report.total_time_sec = toc(t_all);
    report = order_fields_v32(report);

    if debug
        % V32-05 (issue 4): final bad-quad annotation + boundary-loss
        % annotation (v32-01 style localization figures).
        dbg_plot_quad_quality_v32(quadnode, quad, 'final');
        dbg_plot_boundary_check_v32(quadnode, quad, ref_node, ref_tri, 'boundary_final');
        fprintf('\n=== tri2quad_v32 DONE in %.2f sec | PASSED=%d ===\n', ...
            report.total_time_sec, report.verify.passed);
        fprintf('Times: clean %.2f | short %.2f | parity %.2f | triopt %.2f | graph %.2f | match %.2f | extract %.2f | repair %.2f | topo %.2f | smooth %.2f | topo2 %.2f | smooth2 %.2f | tjclose %.2f | untangle %.2f | topo3 %.2f | untangle2 %.2f | tdust %.2f\n', ...
            report.t_clean, report.t_short, report.t_parity, report.t_triopt, ...
            report.t_graph, report.t_match, report.t_extract, report.t_repair, ...
            report.t_topo, report.t_smooth, report.t_topo2, report.t_smooth2, ...
            report.t_tjclose, report.t_untangle, report.t_topo3, ...
            report.t_untangle2, report.t_tdust);
    end
end

% =====================================================================
function save_stage_dbg_v32(name, node, tri)
%SAVE_STAGE_DBG_V32  Dump intermediate mesh (2-col coords or n-col ids).
    fid = fopen(sprintf('dbg_%s_node.txt', name), 'w');
    for k = 1:size(node, 1)
        fprintf(fid, '%.17g %.17g\n', node(k, :));
    end
    fclose(fid);
    fid = fopen(sprintf('dbg_%s_tri.txt', name), 'w');
    fmt = [repmat('%d ', 1, size(tri, 2)), '\n'];
    for k = 1:size(tri, 1)
        fprintf(fid, fmt, tri(k, :));
    end
    fclose(fid);
end

function report = order_fields_v32(report)
    % no-op placeholder (keeps report struct as built)
end
