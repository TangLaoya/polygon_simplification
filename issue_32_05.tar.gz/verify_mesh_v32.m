function report = verify_mesh_v32(quadnode, quad, ref_node, ref_tri, debug)
%VERIFY_MESH_V32  Comprehensive acceptance verification (all checks the
%   user requires), against the REFERENCE triangle mesh = the mesh AFTER
%   short-edge removal (per user instruction: boundary must be checked
%   against the post-removal boundary, not the raw input).
%
%   CHECKS:
%     1. boundary_preserved : every reference boundary edge appears in
%        the quad mesh as a boundary edge or as a CHAIN of boundary
%        edges with all interior chain vertices strictly ON the segment
%        (collinear subdivision, geometric deviation 0). This accepts
%        on-segment midpoints (parity splits / pentagon boundary splits)
%        but nothing else.
%     2. coverage          : |sum(quad area)| == |sum(tri area)| (rel
%        1e-6) AND mesh edge-manifold AND closed boundary AND no edge
%        self-intersections -> exact tiling.
%     3. conformity        : every interior quad edge shared by exactly
%        2 quads; boundary edges by exactly 1; no edge with 3+ owners.
%     4. no_intersections  : no two quad edges properly cross (spatial
%        hash + exact predicates; adjacent edges excluded).
%     5. no_concave / no_collinear : corner cross products all > 0
%        (strictly convex quads; collinear counted separately).
%     5b. V32-02 topology checks: no boundary-spanning quad (a quad
%         containing BOTH boundary edges of a boundary vertex whose
%         angle differs from 180 deg); no diagonal-valence-3 quad (two
%         opposite interior valence-3 corners — removed by
%         topology_cleanup_v32); no triangle-like quad (corner angle
%         >= 179 or <= 1 deg — three collinear vertices); no
%         T-junctions (vertex strictly inside a non-incident edge).
%     6. quality stats     : min/median angles, scaled Jacobian, aspect
%        ratio, vertex ratio vs reference mesh.
%
%   OUTPUT report struct with all metrics + .passed aggregate.

    if nargin < 5; debug = false; end
    t0 = tic;
    report = struct();

    nq = size(quad, 1);
    nv = size(quadnode, 1);
    ntri_ref = size(ref_tri, 1);
    nv_ref = size(ref_node, 1);

    % ---------- edges & conformity ----------
    E = [quad(:,[2 3]); quad(:,[3 4]); quad(:,[4 1]); quad(:,[1 2])];
    Es = sort(E, 2);
    [ue, ~, ic] = unique(Es, 'rows');
    ecnt = accumarray(ic(:), 1);
    report.n_edges = numel(ue);
    report.n_bnd_edges = sum(ecnt == 1);
    report.n_int_edges = sum(ecnt == 2);
    report.n_overshared_edges = sum(ecnt >= 3);
    report.conformity_ok = report.n_overshared_edges == 0;

    % ---------- boundary preservation vs reference ----------
    % V32-02: topology_cleanup compacts vertices (merged doublet corners
    % disappear), so IDs cannot be compared across the pipeline. Match
    % reference vertices to quad-mesh vertices BY COORDINATES (exact row
    % match): boundary vertices are bit-exact throughout (frozen in
    % smoothing, never moved by any topological op).
    nbr_ref = compute_neighbors_fast(ref_tri);
    [Ir, Jr] = find(nbr_ref < 0);
    bva = ref_tri(sub2ind([ntri_ref,3], Ir, mod(Jr,3)+1));
    bvb = ref_tri(sub2ind([ntri_ref,3], Ir, mod(Jr+1,3)+1));
    ref_bnd = [min(bva, bvb), max(bva, bvb)];
    qbnd = ue(ecnt == 1, :);

    [tf_row, iq_row] = ismember(ref_node, quadnode, 'rows');
    map_ref = zeros(nv_ref, 1);
    map_ref(tf_row) = iq_row(tf_row);

    % boundary adjacency of the quad mesh (walk chains)
    badj = cumsum_sparse_pairs_v32(qbnd, nv);
    n_missing_bnd = 0;
    n_lost_vtx = 0;
    missing_list = zeros(0, 2);
    qbkey_lo = qbnd(:,1); qbkey_hi = qbnd(:,2);
    for k = 1:size(ref_bnd, 1)
        a = map_ref(ref_bnd(k, 1)); b = map_ref(ref_bnd(k, 2));
        if a == 0 || b == 0
            n_lost_vtx = n_lost_vtx + 1;   % boundary vertex vanished
            n_missing_bnd = n_missing_bnd + 1;
            continue;
        end
        if is_edge_in_set_v32(a, b, qbkey_lo, qbkey_hi)
            continue;
        end
        if ~walk_on_segment_chain_v32(a, b, quadnode, badj, qbkey_lo, qbkey_hi, 0)
            n_missing_bnd = n_missing_bnd + 1;
            if size(missing_list, 1) < 50
                missing_list(end+1, :) = [a, b]; %#ok<AGROW>
            end
        end
    end
    report.n_lost_boundary_vertices = n_lost_vtx;
    report.n_missing_boundary = n_missing_bnd;
    report.missing_boundary_edges = missing_list;
    report.boundary_preserved = n_missing_bnd == 0;

    % ---------- area / coverage ----------
    p1 = quadnode(quad(:,1), :); p2 = quadnode(quad(:,2), :);
    p3 = quadnode(quad(:,3), :); p4 = quadnode(quad(:,4), :);
    % quad area = half of [2*A(tri p1p2p3) + 2*A(tri p1p3p4)]
    qa = 0.5 * abs( ...
        (p2(:,1)-p1(:,1)).*(p3(:,2)-p1(:,2)) - (p2(:,2)-p1(:,2)).*(p3(:,1)-p1(:,1)) + ...
        (p3(:,1)-p1(:,1)).*(p4(:,2)-p1(:,2)) - (p3(:,2)-p1(:,2)).*(p4(:,1)-p1(:,1)));
    ta1 = ref_node(ref_tri(:,1), :); ta2 = ref_node(ref_tri(:,2), :);
    ta3 = ref_node(ref_tri(:,3), :);
    ta = 0.5 * abs((ta2(:,1)-ta1(:,1)).*(ta3(:,2)-ta1(:,2)) - ...
                   (ta2(:,2)-ta1(:,2)).*(ta3(:,1)-ta1(:,1)));
    report.area_tri = sum(ta);
    report.area_quad = sum(qa);
    report.area_rel_error = abs(report.area_quad - report.area_tri) / report.area_tri;
    report.coverage_ok = report.area_rel_error < 1e-6 && report.conformity_ok;

    % ---------- convexity / collinearity ----------
    c1 = crossr2_v32(p1, p2, p3); c2 = crossr2_v32(p2, p3, p4);
    c3 = crossr2_v32(p3, p4, p1); c4 = crossr2_v32(p4, p1, p2);
    cr_all = [c1, c2, c3, c4];
    report.n_cw_quads = sum(all(cr_all < 0, 2));
    report.n_concave_quads = sum(any(cr_all < 0, 2) & any(cr_all > 0, 2));
    tol_scale = max(abs(quadnode(:)));
    col_tol = 1e-12 * tol_scale^2;
    report.n_collinear_corners = sum(abs(cr_all(:)) < col_tol);
    report.n_degenerate_quads = sum(all(abs(cr_all) < col_tol, 2));
    report.no_concave = report.n_concave_quads == 0 && report.n_cw_quads == 0;

    % ---------- V32-02: topology metrics (valence / spanning) ----------
    % vertex valence from unique edges; boundary vertices from 1-owner edges
    vval = accumarray([ue(:,1); ue(:,2)], 1, [nv, 1]);
    isbnd_v = false(nv, 1);
    qbnd2 = ue(ecnt == 1, :);
    isbnd_v(qbnd2(:)) = true;
    bnd_v1 = zeros(nv, 1); bnd_v2 = zeros(nv, 1);
    for k = 1:size(qbnd2, 1)
        a2 = qbnd2(k, 1); b2 = qbnd2(k, 2);
        if bnd_v1(a2) == 0; bnd_v1(a2) = b2; else; bnd_v2(a2) = b2; end
        if bnd_v1(b2) == 0; bnd_v1(b2) = a2; else; bnd_v2(b2) = a2; end
    end
    % spanning corners: quad corner w, its prev/next in-quad corners are
    % exactly w's two boundary neighbors, and the corner angle EXCEEDS
    % 180.5 deg (reflex — the user rule; convex corner quads and
    % geometrically invisible straight runs may span)
    prevslot = [quad(:,4), quad(:,1), quad(:,2), quad(:,3)];
    nextslot = [quad(:,2), quad(:,3), quad(:,4), quad(:,1)];
    span_corner = false(nq, 4);
    for t = 1:4
        w = quad(:, t);
        m_nbr = (prevslot(:, t) == bnd_v1(w) & nextslot(:, t) == bnd_v2(w)) | ...
                (prevslot(:, t) == bnd_v2(w) & nextslot(:, t) == bnd_v1(w));
        span_corner(:, t) = isbnd_v(w) & m_nbr;
    end
    ang_all = corner_angles_v32(quadnode, quad);
    report.n_spanning_corners = sum(span_corner(:));
    report.n_spanning_convex = sum(any(span_corner & (ang_all < 179.5), 2));
    report.n_spanning_quads = sum(any(span_corner & (ang_all > 180.5), 2));
    % diagonal-valence-3 quads (doublets): opposite interior valence-3
    val3i = (vval == 3) & ~isbnd_v;
    dbl = (val3i(quad(:,1)) & val3i(quad(:,3))) | ...
          (val3i(quad(:,2)) & val3i(quad(:,4)));
    report.n_doublet_quads = sum(dbl);
    report.n_interior_val3 = sum(val3i);
    % triangle-like quads: corner >= 179 deg or <= 1 deg
    report.n_triangle_like = sum(any(ang_all >= 179 | ang_all <= 1, 2));

    % ---------- V32-02: T-junctions ----------
    report.n_tjunctions = count_tjunctions_v32(quadnode, ue);

    % ---------- edge self-intersections (spatial hash) ----------
    report.n_edge_intersections = count_edge_intersections_v32(quadnode, E);
    report.no_intersections = report.n_edge_intersections == 0;

    % ---------- quality statistics ----------
    report.min_angle_min = min(ang_all(:));
    report.min_angle_median = median(min(ang_all, [], 2));
    report.n_angle_below_20 = sum(min(ang_all, [], 2) < 20);
    report.n_angle_below_30 = sum(min(ang_all, [], 2) < 30);
    report.max_angle_max = max(ang_all(:));
    report.n_flat168 = sum(any(ang_all >= 168, 2));   % V32-05 issue-2 metric
    % scaled Jacobian per quad: min sin(corner)
    sj = min(sin(deg2rad(ang_all)), [], 2);
    report.sj_min = min(sj);
    report.sj_median = median(sj);
    report.n_sj_below_03 = sum(sj < 0.3);
    % aspect ratio: longest/shortest edge
    el = [sqrt(sum((p2-p1).^2, 2)); sqrt(sum((p3-p2).^2, 2)); ...
          sqrt(sum((p4-p3).^2, 2)); sqrt(sum((p1-p4).^2, 2))];
    elr = reshape(el, nq, 4);
    report.aspect_max = max(max(elr, [], 2) ./ max(min(elr, [], 2), 1e-300));
    nv_used = numel(unique(quad(:)));
    report.vertex_ratio = nv_used / nv_ref;
    report.vertex_count = nv_used;
    report.n_vertex_rows = nv;
    report.quad_count = nq;

    % ---------- aggregate ----------
    report.passed = report.boundary_preserved && report.coverage_ok && ...
        report.conformity_ok && report.no_intersections && report.no_concave && ...
        report.n_collinear_corners == 0 && report.vertex_ratio <= 1.5 && ...
        report.n_spanning_quads == 0 && report.n_triangle_like == 0 && ...
        report.n_doublet_quads == 0 && report.n_tjunctions == 0;
    report.time_sec = toc(t0);

    if debug
        disp(['  [verify] boundary missing/lost: ' num2str(n_missing_bnd) ' / ' num2str(size(ref_bnd,1))]);
        disp(['  [verify] area rel error: ' num2str(report.area_rel_error, '%.3e') ' coverage=' num2str(report.coverage_ok)]);
        disp(['  [verify] concave=' num2str(report.n_concave_quads) ' CW=' num2str(report.n_cw_quads) ...
              ' collinear=' num2str(report.n_collinear_corners) ' degenerate=' num2str(report.n_degenerate_quads)]);
        disp(['  [verify] spanning quads=' num2str(report.n_spanning_quads) ...
              ' diag-val3 quads=' num2str(report.n_doublet_quads) ...
              ' triangle-like=' num2str(report.n_triangle_like) ...
              ' T-junctions=' num2str(report.n_tjunctions)]);
        disp(['  [verify] edge intersections: ' num2str(report.n_edge_intersections)]);
        disp(['  [verify] minAngle=' num2str(report.min_angle_min, '%.2f') ' med=' num2str(report.min_angle_median, '%.2f') ...
              ' SJmin=' num2str(report.sj_min, '%.3f') ' vtxRatio=' num2str(report.vertex_ratio, '%.4f')]);
        disp(['  [verify] #ang<20=' num2str(report.n_angle_below_20) ' #ang<30=' num2str(report.n_angle_below_30) ...
              ' aspectMax=' num2str(report.aspect_max, '%.1f')]);
        disp(['  [verify] PASSED=' num2str(report.passed)]);
    end
end

% =====================================================================
function n = count_tjunctions_v32(P, ue)
%COUNT_TJUNCTIONS_V32  Vertices lying STRICTLY inside a mesh edge they
%   are not an endpoint of (T-junctions / hanging nodes). Spatial bucket
%   grid over edge midpoints, 3x3 neighborhood scan per vertex.
    n = 0;
    ne = size(ue, 1);
    nv = size(P, 1);
    if ne == 0; return; end
    span = max(max(P(:,1)) - min(P(:,1)), max(P(:,2)) - min(P(:,2))) * 1.0001 + 1e-300;
    gx = max(1, round(sqrt(ne))); gy = gx;
    x0 = min(P(:,1)); y0 = min(P(:,2));
    csx = span / gx; csy = span / gy;
    mx = 0.5 * (P(ue(:,1),1) + P(ue(:,2),1));
    my = 0.5 * (P(ue(:,1),2) + P(ue(:,2),2));
    ix = min(gx, max(1, floor((mx - x0) / csx) + 1));
    iy = min(gy, max(1, floor((my - y0) / csy) + 1));
    cid = (iy - 1) * gx + ix;
    [~, order] = sort(cid);
    cu = unique(cid);
    [~, ~, ic_u] = unique(cid);
    cnts = accumarray(ic_u(:), 1);
    starts = [1; cumsum(cnts(1:end-1)) + 1];
    ueS = ue(order, :);
    for v = 1:nv
        vx = P(v, 1); vy = P(v, 2);
        cx = floor((vx - x0) / csx) + 1;
        cy = floor((vy - y0) / csy) + 1;
        for dx = -1:1
            ccx = cx + dx;
            if ccx < 1 || ccx > gx; continue; end
            for dy = -1:1
                ccy = cy + dy;
                if ccy < 1 || ccy > gy; continue; end
                cidq = (ccy - 1) * gx + ccx;
                lo = 1; hi = numel(cu); bi = 0;
                while lo <= hi
                    mid = floor((lo + hi) / 2);
                    if cu(mid) == cidq; bi = mid; break;
                    elseif cu(mid) < cidq; lo = mid + 1;
                    else; hi = mid - 1;
                    end
                end
                if bi == 0; continue; end
                for s = starts(bi):starts(bi) + cnts(bi) - 1
                    a = ueS(s, 1); b = ueS(s, 2);
                    if v == a || v == b; continue; end
                    A = P(a, :); B = P(b, :);
                    AB = B - A; AV = [vx, vy] - A;
                    L2 = AB(1)^2 + AB(2)^2;
                    if L2 < 1e-300; continue; end
                    tp = (AV(1)*AB(1) + AV(2)*AB(2)) / L2;
                    if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
                    dist = abs(AV(1)*AB(2) - AV(2)*AB(1)) / sqrt(L2);
                    if dist < 1e-9 * sqrt(L2)
                        n = n + 1;
                    end
                end
            end
        end
    end
end

% =====================================================================
function adj = cumsum_sparse_pairs_v32(edges, nv)
%CUMSUM_SPARSE_PAIRS_V32  Vertex -> neighbor-list adjacency (cell).
    adj = cell(nv, 1);
    for k = 1:size(edges, 1)
        a = edges(k, 1); b = edges(k, 2);
        adj{a}(end+1) = b; %#ok<AGROW>
        adj{b}(end+1) = a; %#ok<AGROW>
    end
end

% =====================================================================
function tf = is_edge_in_set_v32(a, b, lo, hi)
%IS_EDGE_IN_SET_V32  Sorted edge (a<b) present in (lo,hi) column pair.
    % binary search over sorted rows
    key_lo = min(a, b); key_hi = max(a, b);
    tf = any(lo == key_lo & hi == key_hi);
end

% =====================================================================
function found = walk_on_segment_chain_v32(a, b, P, adj, lo, hi, depth)
%WALK_ON_SEGMENT_CHAIN_V32  DFS from a to b along boundary edges whose
%   vertices all lie strictly ON segment (a,b).
    if depth > 6; found = false; return; end
    A = P(a, :); B = P(b, :);
    AB = B - A; L2 = AB(1)^2 + AB(2)^2;
    if L2 < 1e-300; found = false; return; end
    nbrs = adj{a};
    for k = 1:numel(nbrs)
        m = nbrs(k);
        if m == b
            if is_edge_in_set_v32(a, b, lo, hi)
                found = true; return;
            end
            continue;
        end
        if ~is_edge_in_set_v32(min(a,m), max(a,m), lo, hi) && ~is_edge_in_set_v32(a, m, lo, hi)
            continue;
        end
        M = P(m, :);
        t_par = ((M(1)-A(1))*AB(1) + (M(2)-A(2))*AB(2)) / L2;
        d = abs((M(1)-A(1))*AB(2) - (M(2)-A(2))*AB(1)) / sqrt(L2);
        if t_par > 1e-12 && t_par < 1 - 1e-12 && d < 1e-9 * sqrt(L2)
            if walk_on_segment_chain_v32(m, b, P, adj, lo, hi, depth + 1)
                found = true; return;
            end
        end
    end
    found = false;
end

% =====================================================================
function c = crossr2_v32(p1, p2, p3)
    c = (p2(:,1)-p1(:,1)).*(p3(:,2)-p2(:,2)) - ...
        (p2(:,2)-p1(:,2)).*(p3(:,1)-p2(:,1));
end

% =====================================================================
function ang = corner_angles_v32(P, quad)
%CORNER_ANGLES_V32  4 corner angles per quad (degrees, CCW interior).
    p1 = P(quad(:,1), :); p2 = P(quad(:,2), :);
    p3 = P(quad(:,3), :); p4 = P(quad(:,4), :);
    ang = [angr2_v32(p1, p2, p3), angr2_v32(p2, p3, p4), ...
           angr2_v32(p3, p4, p1), angr2_v32(p4, p1, p2)];
end

function a = angr2_v32(pa, pb, pc)
    v1 = pa - pb; v2 = pc - pb;
    n1 = sqrt(v1(:,1).^2 + v1(:,2).^2); n2 = sqrt(v2(:,1).^2 + v2(:,2).^2);
    cs = (v1(:,1).*v2(:,1) + v1(:,2).*v2(:,2)) ./ (n1 .* n2 + 1e-300);
    a = acosd(max(-1, min(1, cs)));
end

% =====================================================================
function n_cross = count_edge_intersections_v32(P, E)
%COUNT_EDGE_INTERSECTIONS_V32  Proper crossings between non-adjacent
%   quad edges (spatial hash buckets, exact orientation predicates).
    ne = size(E, 1);
    if ne == 0; n_cross = 0; return; end
    span = max(max(P(:,1)) - min(P(:,1)), max(P(:,2)) - min(P(:,2))) * 1.0001 + 1e-300;
    gx = max(1, round(sqrt(ne))); gy = gx;
    x0 = min(P(:,1)); y0 = min(P(:,2));
    cs = span / gx;
    n_cross = count_cross_fast_v32(P, E, gx, gy, x0, y0, cs);
end

function n_cross = count_cross_fast_v32(P, E, gx, gy, x0, y0, cs)
    ne = size(E, 1);
    mx = 0.5 * (P(E(:,1),1) + P(E(:,2),1));
    my = 0.5 * (P(E(:,1),2) + P(E(:,2),2));
    ix = min(gx, max(1, floor((mx - x0) / cs) + 1));
    iy = min(gy, max(1, floor((my - y0) / cs) + 1));
    cid = (iy - 1) * gx + ix;
    [uc, order] = sort(cid);
    [~, ~, uidx] = unique(uc);
    cnts = accumarray(uidx(:), 1);
    starts = [1; cumsum(cnts(1:end-1)) + 1];
    eid = order;
    n_cross = 0;
    nb = min(numel(uc), numel(starts));
    for b = 1:nb
        s = starts(b); e = min(starts(b) + cnts(b) - 1, numel(eid));
        ids = eid(s:e);
        nk = numel(ids);
        for i = 1:nk-1
            e1 = ids(i);
            a1 = E(e1,1); b1 = E(e1,2);
            for j = i+1:nk
                e2 = ids(j);
                a2 = E(e2,1); b2 = E(e2,2);
                if a1 == a2 || a1 == b2 || b1 == a2 || b1 == b2
                    continue;   % adjacent
                end
                if segs_properly_cross_v32(P(a1,:), P(b1,:), P(a2,:), P(b2,:))
                    n_cross = n_cross + 1;
                    if n_cross > 100000; return; end
                end
            end
        end
    end
end

function tf = segs_properly_cross_v32(P, Q, R, S)
%SEGS_PROPERLY_CROSS_V32  Strict proper crossing with relative epsilon:
%   near-zero orientations (endpoint-on-edge TOUCHES, e.g. midpoints
%   lying on a segment) are NOT counted as crossings.
    persistent eps_rel
    if isempty(eps_rel); eps_rel = 1e-9; end
    d1 = orient2_v32(R, S, P); d2 = orient2_v32(R, S, Q);
    d3 = orient2_v32(P, Q, R); d4 = orient2_v32(P, Q, S);
    lRS = norm(S - R); lPQ = norm(Q - P);
    e1 = eps_rel * lRS * norm(P - R);
    e2 = eps_rel * lRS * norm(Q - R);
    e3 = eps_rel * lPQ * norm(R - P);
    e4 = eps_rel * lPQ * norm(S - P);
    s1 = sign_safe_v32(d1, e1); s2 = sign_safe_v32(d2, e2);
    s3 = sign_safe_v32(d3, e3); s4 = sign_safe_v32(d4, e4);
    if s1 == 0 || s2 == 0 || s3 == 0 || s4 == 0
        tf = false; return;   % touching (incl. endpoint-on-edge)
    end
    tf = (s1 ~= s2) && (s3 ~= s4);
end

function s = sign_safe_v32(d, eps_abs)
    if d > eps_abs; s = 1;
    elseif d < -eps_abs; s = -1;
    else; s = 0;
    end
end

function d = orient2_v32(P, Q, R)
    d = (Q(1)-P(1)) * (R(2)-P(2)) - (Q(2)-P(2)) * (R(1)-P(1));
end
