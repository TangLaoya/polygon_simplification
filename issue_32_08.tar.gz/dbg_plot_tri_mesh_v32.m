function dbg_plot_tri_mesh_v32(node, tri, figname, highlight_pairs, title_extra, extra_segs)
%DBG_PLOT_TRI_MESH_V32  V32-05 debug figure: triangle mesh (stage dumps).
%   Optional highlight_pairs (Mx2 vertex ids) drawn as red bold edges.
%   Optional extra_segs (Kx4 [x1 y1 x2 y2] COORDINATE segments, V32-05)
%   drawn as red dashed bold lines (e.g. positions of collapsed short
%   edges from remove_short_boundary_edges info.removed_pos).
%   Saves figname .png next to the data; figures are opened in MATLAB,
%   guarded with try/catch for headless Octave.

    if nargin < 6; extra_segs = zeros(0, 4); end
    if nargin < 5; title_extra = ''; end
    if nargin < 4; highlight_pairs = zeros(0, 2); end
    ti = sprintf('tri mesh %s%s', figname, title_extra);
    try
        figure('Name', ti, 'NumberTitle', 'off');
        hold on; axis equal; axis off;
        patch('faces', tri, 'vertices', node, ...
              'facecolor', [0.93 0.93 0.98], 'edgecolor', [0.25 0.25 0.25]);
        if ~isempty(highlight_pairs)
            for k = 1:size(highlight_pairs, 1)
                p = node(highlight_pairs(k, 1), :);
                q = node(highlight_pairs(k, 2), :);
                plot([p(1), q(1)], [p(2), q(2)], 'r-', 'LineWidth', 2.5);
                plot(p(1), p(2), 'ro', 'MarkerSize', 7, 'LineWidth', 1.5);
                plot(q(1), q(2), 'rs', 'MarkerSize', 7, 'LineWidth', 1.5);
            end
        end
        if ~isempty(extra_segs)
            for k = 1:size(extra_segs, 1)
                plot(extra_segs(k, [1 3]), extra_segs(k, [2 4]), 'r--', ...
                    'LineWidth', 2.0);
                plot(extra_segs(k, 1), extra_segs(k, 2), 'ro', 'MarkerSize', 6, ...
                    'LineWidth', 1.2, 'MarkerFaceColor', 'r');
            end
        end
        title(ti, 'Interpreter', 'none');
        hold off;
        try
            print(gcf, sprintf('dbg_fig_%s.png', figname), '-dpng', '-r110');
        catch
        end
        drawnow;
    catch
        % headless / no display: skip quietly
    end
end

