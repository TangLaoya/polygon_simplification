function dbg_plot_quad_quality_v32(quadnode, quad, figname, title_extra)
%DBG_PLOT_QUAD_QUALITY_V32  V32-05 debug figure: quad mesh with quality
%   annotation (v32-01 style). Red fill = corner >= 175 deg (degenerate
%   / 3-collinear); orange = >= 168 deg; yellow = >= 160 deg. Title
%   reports the counts (round-04 issues 2/3 localization aid).

    if nargin < 4; title_extra = ''; end
    nq = size(quad, 1);
    maxang = zeros(nq, 1);
    for qi = 1:nq
        maxang(qi) = max_quad_ang_v32(quadnode, quad(qi, :));
    end
    lv3 = (maxang >= 175); lv2 = (maxang >= 168) & ~lv3; lv1 = (maxang >= 160) & ~lv2 & ~lv3;
    ti = sprintf('quad mesh %s | bad quads: %d red(>=175) %d orange(>=168) %d yellow(>=160)%s', ...
        figname, sum(lv3), sum(lv2), sum(lv1), title_extra);
    try
        figure('Name', ti, 'NumberTitle', 'off');
        hold on; axis equal; axis off;
        patch('faces', quad, 'vertices', quadnode, ...
              'facecolor', [0.93 0.93 0.98], 'edgecolor', [0.3 0.3 0.3]);
        draw_bad_v32(quadnode, quad, find(lv1), [1.0 0.95 0.45]);
        draw_bad_v32(quadnode, quad, find(lv2), [1.0 0.65 0.15]);
        draw_bad_v32(quadnode, quad, find(lv3), [1.0 0.10 0.10]);
        title(ti, 'Interpreter', 'none');
        hold off;
        try
            print(gcf, sprintf('dbg_fig_%s.png', figname), '-dpng', '-r110');
        catch
        end
        drawnow;
    catch
    end
end


% ===================== local helpers =====================
function draw_bad_v32(quadnode, quad, ids, color)
    for k = 1:numel(ids)
        q = quad(ids(k), :);
        pts = quadnode(q([1 2 3 4 1]), :);
        patch(pts(:,1), pts(:,2), color, ...
              'EdgeColor', color * 0.6, 'LineWidth', 0.8);
    end
end

function ma = max_quad_ang_v32(P, qv)
    %MAX_QUAD_ANG_V32  Largest interior corner angle (deg) of one quad.
    ma = 0;
    for t = 1:4
        v = P(qv(t),:);
        u = P(qv(mod(t+2,4)+1),:);
        w = P(qv(mod(t,4)+1),:);
        a = u - v; b = w - v;
        na = norm(a); nb = norm(b);
        if na < 1e-300 || nb < 1e-300
            ma = 360; return;
        end
        cs = (a(1)*b(1)+a(2)*b(2)) / (na*nb);
        ma = max(ma, acosd(max(-1, min(1, cs))));
    end
end
