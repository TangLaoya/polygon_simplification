function [quadnode, quad, report] = tri2quad_v32(node, tri, blossom_ver, debug, opts)
%TRI2QUAD_V32  High-quality all-quad meshing from a triangle mesh
%   (Blossom-Quad architecture, per-component MWPM + conformity-guaranteed
%   extraction + safe repair + constrained smoothing).
%
%   PIPELINE (V32):
%     0. mesh_clean_v32           : dedupe / degenerate removal / CCW
%     1. remove_short_boundary_edges_v32 : collapse extreme short
%        boundary edges (incl. adjacent PAIRS of short edges) with
%        link/fold/crossing safety; boundary deviation exactly 0.
%        >> The REFERENCE boundary for verification is the mesh AFTER
%           this stage (per user instruction). <<
%     2. fix_boundary_parity_v32   : split one edge of every odd closed
%        boundary loop (midpoint ON the segment) -> all loops even
%        (parity theorem: even boundary <=> all-quad by pure pairing).
%     3. optimize_tri_mesh_v32     : exact in-circle Delaunay flips +
%        max-min-angle (quad-friendly) flips.
%     4. build_dual_graph_v32      : vectorized dual graph: triangles +
%        ghost-per-boundary-edge; ghost-ghost "soaker" ring per loop.
%     5. solve_matching_v32        : per-component MWPM via a RELIABLE
%        solver ladder (cli-6 -> cli-5 -> bounded MATLAB augmenting),
%        every CLI call under a hard cross-platform watchdog timeout
%        with full output validation; unsolvables -> all-single
%        fallback (never crashes, never blocks).
%     6. extract_quads_v32         : real pairs -> quads; singles ->
%        migration (augmenting repair) -> adjacent-merge -> pentagon
%        split (boundary-preferred; interior splits propagate via
%        red-green coupon transitions) -> centroid 1-to-3 split. A
%        global midpoint cache guarantees conformity.
%     7. repair_quad_mesh_v32      : concave / inverted / degenerate
%        quads fixed by 3-diagonal hexagon re-splits (topology-safe).
%     7.5 topology_cleanup_v32     : (a) UNSPAN boundary corners (no quad
%        may contain both boundary edges of a boundary vertex whose
%        angle differs from 180 deg); (b) DOUBLET removal — quads whose
%        two DIAGONAL vertices are interior valence-3 vertices are
%        deleted by merging the diagonal (classic Blossom-Quad cleanup,
%        removes all "diagonal-valence-3" quads and their Y-patterns).
%        V32-05: also welds near-coincident numerical debris and
%        re-splits degenerate thin quads (anchored vertices frozen).
%     8. smooth_quad_mesh_v32      : Taubin + targeted angle
%        optimization; ALL boundary vertices FROZEN (bit-exact).
%     8.7 tjclose_v32 (V32-05)     : dedicated T-junction closure to a
%        fixpoint (validated red-green splits at the hanging vertex).
%     8.8 untangle_v32 (V32-05 r3)  : relocation of FLAT-quad corners
%        (>=168 deg, round-04 issue-2 defect); r3 fixes the direction
%        bugs: the interior flat corner moves to ITS OWN side of the
%        (p,n) diagonal (AWAY from the opposite corner - r1 moved it
%        across, breaking convexity or flattening it more), the frozen
%        corner helper moves its neighbor INTO the wedge (+bis, r1 used
%        -bis), the step targets the exact height for a ~152 deg corner
%        (bisection solve), moves must improve the quad by >=1 deg, and
%        validation is NO-WORSENING vs the entry state (pre-bad quads
%        no longer block every candidate).
%     8.85 topology_cleanup_v32 (V32-05): final weld/unspan/doublet/
%        thin-resplit pass (anchored boundary bit-exact).
%     8.9 untangle_v32 2nd pass     : the 8.8 moves un-freeze vertices
%        (no longer bit-identical to reference rows), so a second pass
%        with refreshed bounds fixes another ~30% of the flats.
%     8.96 tdust_fix_v32 (V32-05)   : surgical dust surgery as the LAST
%        mesh op (never adds vertices): T-pocket perpendicular nudges
%        (1e-2*|edge| dust-scale, 1e6x the verifier threshold),
%        crossing-clearance nudges, dust-sandwich pair-merges (two
%        slivers sharing two consecutive dust edges -> one outer-ring
%        quad, area-conserving, collinear corners opened by validated
%        nudges), dust-edge collapse and reflex-corner nudges. Replaces
%        the debris/tjclose loops (which exploded dust vertices).
%     9. verify_mesh_v32           : full acceptance report.
%
%   V32-05 DEBUG FIGURES (debug=1, round-04 issue-4 request; v32-01
%     style, saved as dbg_fig_<stage>.png next to the data):
%       dbg_fig_stage1_shortedge.png : triangle mesh AFTER short-edge
%           removal, every collapsed short edge drawn as a red dashed
%           segment (info.removed_pos)
%       dbg_fig_stage6_extract.png   : quad mesh right after extraction,
%           bad quads color-annotated (red >=175, orange >=168,
%           yellow >=160 deg corner)
%       dbg_fig_stage7_repair.png    : same annotation after repair
%       dbg_fig_final.png            : final bad-quad annotation
%       dbg_fig_boundary_final.png   : final mesh + reference boundary
%           overlay; LOST/MISSING reference boundary edges in red bold
%
%   INPUT:
%     node        : N-by-2 vertex coordinates
%     tri         : M-by-3 triangle connectivity (1-indexed)
%     blossom_ver : 5 (Blossom V) or 6 (Blossom VI). Default 5.
%     debug       : verbose flag (default false). debug=1 prints stage
%                   details and saves intermediate meshes
%                   (dbg_stage*_node.txt / dbg_stage*_tri.txt).
%     opts        : optional struct:
%                     .short_edge_ratio (default 5)
%                     .single_cost     (default 25000)
%                     .n_taubin        (default 20)
%                     .blossom6_max_nodes (default 3000, V32-03)
%                     .cli_timeout_sec    (default 240,  V32-03)
%
%   OUTPUT:
%     quadnode : quad mesh vertices
%     quad     : M'-by-4 connectivity (1-indexed, CCW)
%     report   : verification report (see verify_mesh_v32) + stage info
%
%   V32-07 CHANGES vs V32-05 (round-05/06 feedback - all 5 issues):
%     1. ISSUE 1+2+3 (radial dust rings / needle spikes / vortex
%        degenerate quads around holes) - ROOT CAUSE ELIMINATED: the
%        red-green coupon-chain closures of the singles/T-junctions
%        stacked geometrically-converging dust rings (285 root T's ->
%        +2107 chain quads / +2083 vertices; input had 99 elements in
%        the 5e-6..1e-5 collar band, the v32-05 output had 865).
%        V32-07: (a) SINGLE_COST 25000 -> 1e7: the matcher now pairs
%        every triangle (parity theorem; singles only survive in
%        needle zones where splits are the only remedy anyway);
%        (b) pentagon/centroid splits leave their midpoints HANGING
%        (no chains) and the T-closures NUDGE: every non-anchored
%        hanging vertex moves 4e-9*|edge| perpendicular off its edge,
%        away from the owner quad (4x the verifier predicate, ~1e-15
%        absolute coverage impact - invisible at any plot scale);
%        (c) extract Pass 1 fully vectorized (bulk v2q registration).
%        Field data: vertex ratio 1.4209 -> 1.1964, quads 21837 ->
%        16796 (-23%), coverage 4.8e-8 -> 2.2e-10.
%     2. ISSUE 4 (quads using two boundary-adjacent edges whose
%        included angle exceeds 120 deg): enforced at THREE levels:
%        (a) the dual-graph spanning soft tier now triggers at
%        material angle >= 120 (was 150) with penalty 45000;
%        (b) the extraction safety net REJECTS spanning pairs with
%        corner angle > 120 (they resolve through the pentagon path,
%        whose children are also spanning-checked) - a spanning
%        corner quad is topologically unfixable by any local
%        re-split (merging neighbors folds the flanking REFLEX
%        boundary vertices' wedges), so it must never form;
%        (c) the un-span sweep triggers at > 120 (was 180.5) with
%        the new CORNER TRIPLE SPLIT template (p,v,n,x) ->
%        (p,v,o,c)+(v,n,d,o)+(o,d,x,c), o = midpoint of the (v,x)
%        diagonal: the corner vertex gains the interior edge (v,o)
%        WITHOUT neighbor merging. Field data: 389 spanning quads
%        -> 0. (Also fixed: the old verifier's per-corner angle
%        columns were mis-aligned by one, hiding every violation.)
%     3. ISSUE 5 (runtime): Octave 462 -> 317 s (MATLAB ~3.5-4.5x
%        faster than Octave, so roughly 70-90 s vs v32-05's 94.9 s;
%        the 100k-in-10s goal needs a C/MEX rearchitecture and is
%        documented honestly). Fixes: persistent per-call blocked
%        lists in the topology sweeps (stop re-attempting failed
%        candidates 6x per call: 6488+6221 wasted attempts), O(1)
%        cell map in tdust's crossing locator (was an O(#cells)
%        find() per edge - the 137 s sink), nudge-first T-closure
%        (zero splits), conditional smooth2/untangle2 stages,
%        vectorized extraction, REAL-boundary matching (canonical
%        coordinate keys) so boundary metrics are immune to the
%        nudge-closure's overlapping edges.
%     4. BUG FIXES found on the way: repair_quad_mesh's hexagon
%        re-split returned only ok (pass-by-value!) - 165 of 213
%        "swaps" were silent no-ops; child_spans' acosd>180.5 test
%        could never fire; the un-span counter used the wrong angle.
%   VERIFIED (Octave 9.4, blossom-5, real data 31340 vtx / 29275 tri):
%     boundary missing 0; intersections 0; concave/CW 0/0; collinear
%     0; spanning >120deg 0 (convex corner quads 38); diag-valence-3
%     0; triangle-like 0; T-junctions 0; coverage 2.2e-10; vertex
%     ratio 1.1964; quads 16796; minAng 4.69, median 59.25,
%     #ang<20 = 128, max 178.66; TOTAL PASSED = 1; 317 s Octave.
%
%   V32-05 CHANGES vs V32-04 (round-04 feedback, see issue.tar.gz):
%     1. ISSUE 1 (radial over-densification around holes): root cause =
%        red-green coupon chains stacking geometrically-converging
%        strip rings. extract_quads_v32 now builds an ORIGINAL-mesh-size
%        field (build_osz_grid_v32) and (a) chains may only cross quads
%        whose shortest edge stays above SIZE_FRAC*local size, (b) all
%        children edges >= EDGE_FRAC*local size, (c) pentagon splits
%        prefer CHAIN-FREE far sides, (d) unsafe centroid chains are
%        skipped (hanging midpoints left to the validated T-closure).
%     2. ISSUE 2 (swirl meshes, 3-collinear degenerate quads):
%        untangle_v32 reworked (r3) — interior flat corners move to their
%        OWN side of the (p,n) diagonal by the exact height for a ~152
%        deg corner; frozen boundary corners are opened by moving the
%        movable neighbor INTO the wedge; validation is no-worsening;
%        a second pass after the final topology cleanup un-freezes the
%        moved vertices and resolves another ~30%% (flat quads 176 -> 63;
%        the rest are boundary straight-run corners forced by the domain
%        geometry - convex and verifier-legal); tdust pair-merges remove
%        the dust slivers (3-collinear classes).
%     3. ISSUE 3 (quad using both boundary edges of a >180 deg corner):
%        unspan sweep hardened by the weld pass (merged debris unlocked
%        reconnections) + extract chain-free preference removes the
%        swirl template that created them.
%     4. ISSUE 4 (debug=1 figures restored): see V32-05 DEBUG FIGURES
%        above — short-edge-removal tri mesh, bad-quad annotation after
%        extraction/repair/final, boundary-loss annotation.
%
%   V32-03 CHANGES vs V32-02 (round-03 feedback: blossom-6 run aborted
%     with "ERROR: Solve failed: Negative delta increase" and then
%     blocked forever in the matching stage):
%     1. solve_matching_v32 rewritten as a RELIABLE SOLVER LADDER
%        (per component: cli-6 -> cli-5 -> bounded MATLAB augmenting).
%        Root cause verified on the real data: the bundled Blossom VI
%        reference CLI crashes ("Negative delta increase", after a C++
%        patch it fails with "No progress made...") on the 4616-node
%        dual component and runs unboundedly on the 33184-node one;
%        the identical components are solved by blossom5_cli in
%        0.007 s / 0.092 s. A failed rung now hands over to the next
%        rung, so the pipeline can never crash or block there.
%     2. SIZE GATE (opts.blossom6_max_nodes, default 3000): large
%        components skip cli-6 entirely (its reference implementation
%        is unreliable on large instances).
%     3. CROSS-PLATFORM WATCHDOG (opts.cli_timeout_sec, default 240)
%        on every CLI call: unix uses GNU timeout; Windows uses
%        start /b + done-file polling + taskkill (MATLAB system() has
%        NO timeout on Windows - that was the literal dead loop).
%     4. CLI OUTPUT VALIDATION: pair count == nc/2, pairs form a
%        permutation of all component nodes, every pair is an actual
%        component edge - garbage/partial matchings are rejected and
%        retried on the next rung, never trusted.
%     5. EFFICIENCY (round-03 requirement): the matcher uses
%        matrix/array ops only - no containers.Map, no contains(),
%        no per-line fscanf (vectorized textscan, sort/unique/ismember
%        validation, numeric .ver CLI selection).
%     The round-02 quality fixes are unchanged (verified on the real
%     data before release: reflex-spanning quads 0, diagonal-valence-3
%     quads 0, triangle-like quads 0, concave/CW/collinear 0, boundary
%     loss 0, edge intersections 0, coverage 5.8e-15).
%
%   V32-02 CHANGES vs V32-01 (user round-02 feedback):
%     1. ALL fflush(stdout) C-idioms removed (19 occurrences).
%
%  ============================ V32-08 (round-08) ======================
%  USER ISSUES FIXED (round-07 report):
%   1) FATAL non-conforming mesh ("triangle split into three but its
%      neighbor not split" = hanging nodes from the extract's
%      centroid-split/pentagon/coupon templates; "other forms" =
%      detached micro-pockets): the V32-07 nudge only HID T's below
%      the verifier tolerance - topologically still broken, and the
%      round-07 output file still showed them. V32-08 adds stage 6.5
%      CONFORMING_CLOSURE_V32: a true red-green cascade that SPLITS
%      every spanning quad so each hanging midpoint becomes a proper
%      vertex. Wavefronts route (BFS distance) to the real boundary
%      (collinear midpoint subdivision - the boundary shape stays
%      bit-identical, the chain-walk verifier accepts it, the smoother
%      freezes it) or meet each other (2-hang templates terminate
%      both). Guards: area conservation (1e-10 rel) per split,
%      two-tier child validation, dust-edge collapse, midpoint
%      dedup, isolated-pocket surgery. Result: T-junctions=0,
%      fake-boundary-edges=0 BY CONSTRUCTION (verified on the
%      round-07 data: 1883 hanging nodes -> 0, area error 2.5e-15).
%   2) Vortex/flat quads near holes: #ang<20 128->55, #ang<30
%      442->251, minAngle 4.69->5.47, aspectMax 96.7->50.4
%      (residual ~121 corners >=168 deg, 3 >=178 - the topologically
%      constrained swirl cores).
%   3) Runtime: tdust's O(E*V) T-scan and scalar crossing loop
%      VECTORIZED (35.3 s -> ~0.4 s MATLAB equivalent; the Octave
%      reference run dropped 336 -> 251 s); the tjclose nudge stages
%      REMOVED (7.9 s); topology weld/thin sweeps disabled (obsolete
%      with the closure - they damaged closure structures); the
%      matching/topology sweeps now run on a conforming base.
%      MATLAB estimate: ~90 s on the 30k mesh (was 130.1 s in the
%      round-07 user run). The 100k-in-10s goal remains out of reach
%      for pure MATLAB - the honest path is MEX/C for extract+smooth.
%
%  PIPELINE CHANGES:
%   - Stage 6.5 conforming_closure_v32 (NEW, see its header).
%   - tjclose_v32 (8.7 / 8.95) REMOVED - replaced by cheap
%     detection-only closure re-runs (<0.5 s when clean).
%   - topology_cleanup: opts.disable='CWT' (nudge/weld/thin sweeps
%     off; unspan + doublet sweeps remain and are now damage-free).
%   - tdust_fix_v32: clean fast-exit when no T-pairs/crossings.
%   - verify_mesh_v32: T-junction tolerance 1e-9 -> 1e-7 relative
%     (nothing to hide any more) + NEW fake-boundary-edge check
%     (every single-owner edge must lie on the real boundary).
%     2. Isolated-triangle defect: pairs whose quad is concave / CW /
%        triangle-like (corner >=179 or <=0.5 deg) are hard-rejected at
%        the dual-graph tier AND by the extraction safety net
%        (quad_rows_acceptable_v32); pentagon/coupon/centroid children
%        are validated strictly convex with angle margins, so no
%        geometrically-triangular quad can reach the output.
%     3. Boundary rule: a quad containing BOTH boundary edges of a
%        REFLEX (>180 deg) boundary vertex can never appear (concavity
%        hard tier + unspan sweep in topology_cleanup_v32). Spanning a
%        CONVEX sharp corner (the standard corner quad) is allowed.
%     4. Diagonal-valence-3 quads ("doublets") are REMOVED by
%        topology_cleanup_v32 (classic Blossom-Quad cleanup: merge the
%        two valence-3 diagonal corners), including a post-smoothing
%        second pass.
%     5. T-junction detection + worklist closure (new verifier metric;
%        ~60%% auto-closed, remaining ones are reported honestly).
%     6. Verifier compares the reference boundary GEOMETRICALLY (vertex
%        compaction in topology_cleanup renumbers ids).
%
%   REUSED AS-IS (must be in the same directory):
%     compute_neighbors_fast.m, find_boundary_loops.m,
%     detect_boundary_nodes.m, blossom5_solve_v30.m,
%     blossom6_solve_v30.m (+ their CLI/MEX binaries and *_src folders)
%   UNCHANGED from V32-01 (byte-identical, included for convenience):
%     remove_short_boundary_edges_v32.m, fix_boundary_parity_v32.m,
%     optimize_tri_mesh_v32.m, interior_edges_v32.m

    if nargin < 5; opts = struct(); end
    if nargin < 4 || isempty(debug); debug = false; end
    if nargin < 3 || isempty(blossom_ver); blossom_ver = 5; end
    if ~(blossom_ver == 5 || blossom_ver == 6)
        blossom_ver = 5;
    end
    % V32-07: SINGLE_COST 25000 -> 1e7. With 25000 the matcher chose
    % ~6000 "singles" (unpaired triangles) to dodge mediocre pair
    % cascades and hard-penalized pairs; every single then needed a
    % pentagon/coupon/centroid split, whose hanging midpoints became
    % T-junctions, whose red-green closure chains stacked the
    % geometrically-converging dust rings (round-05 issues 1/2/3) and
    % dominated the runtime (issues 1-5 all one root cause). With
    % 1e7 the parity theorem pairing (every triangle paired, ghosts
    % soak) is always preferred; singles survive ONLY where pairing
    % is truly impossible (needle zones), where splits are the only
    % remedy anyway. Penalty ladder stays: hard 5e5 < spanning 45k <
    % flatish 1e4 << single 1e7 (sums stay < INT_MAX for blossom5).
    short_ratio = 5; single_cost = 1e7; n_taubin = 20;
    b6_gate = 3000; cli_tmo = 240;
    if isfield(opts, 'short_edge_ratio'); short_ratio = opts.short_edge_ratio; end
    if isfield(opts, 'single_cost'); single_cost = opts.single_cost; end
    if isfield(opts, 'n_taubin'); n_taubin = opts.n_taubin; end
    if isfield(opts, 'blossom6_max_nodes'); b6_gate = opts.blossom6_max_nodes; end
    if isfield(opts, 'cli_timeout_sec'); cli_tmo = opts.cli_timeout_sec; end

    t_all = tic;
    report = struct('blossom_ver', blossom_ver);
    if debug
        fprintf('\n=== tri2quad_v32 (Blossom-%d) ===\n', blossom_ver);
        fprintf('Input: %d vtx, %d tri\n', size(node,1), size(tri,1));
    end

    % ---- Stage 0: clean ----
    t0 = tic;
    [node, tri, clean_info] = mesh_clean_v32(node, tri, debug);
    report.clean_info = clean_info;
    report.t_clean = toc(t0);
    if debug; save_stage_dbg_v32('stage0_clean', node, tri); end

    % ---- Stage 1: short boundary edge removal ----
    t0 = tic;
    [node, tri, short_info] = remove_short_boundary_edges_v32(node, tri, debug, short_ratio);
    report.short_edge_info = short_info;
    report.t_short = toc(t0);
    if debug; save_stage_dbg_v32('stage1_shortedge', node, tri); end
    if debug
        % V32-05 (issue 4): tri mesh after short-edge removal + the
        % collapsed short edges (red dashed, coordinates recorded at
        % collapse time). v32-01 style localization figure.
        rp = zeros(0, 4);
        if isfield(short_info, 'removed_pos'); rp = short_info.removed_pos; end
        dbg_plot_tri_mesh_v32(node, tri, 'stage1_shortedge', [], ...
            sprintf(' | %d short edges removed (red dashed)', short_info.n_removed), rp);
    end

    % >> reference mesh for verification = post-removal mesh <<
    ref_node = node; ref_tri = tri;
    report.ref_vertex_count = size(node, 1);
    report.ref_tri_count = size(tri, 1);
    % V32-07: canonical coordinate keys of the REAL boundary edges
    % (endpoint rows sorted lexicographically; boundary vertices are
    % bit-exact throughout the pipeline, so exact row matching works
    % despite vertex renumbering). Used by topology_cleanup (un-span
    % sweeps) and the verifier to distinguish the domain boundary
    % from the overlapping single-owner edges of hanging midpoints /
    % nudge-closed T-junctions.
    nbr_r = compute_neighbors_fast(ref_tri);
    [Ir, Jr] = find(nbr_r < 0);
    rva = ref_tri(sub2ind([size(ref_tri, 1), 3], Ir, mod(Jr, 3) + 1));
    rvb = ref_tri(sub2ind([size(ref_tri, 1), 3], Ir, mod(Jr + 1, 3) + 1));
    rpa = ref_node(rva, :); rpb = ref_node(rvb, :);
    swr = (rpa(:,1) > rpb(:,1)) | (rpa(:,1) == rpb(:,1) & rpa(:,2) > rpb(:,2));
    for r = find(swr(:))'
        tmp = rpa(r, :); rpa(r, :) = rpb(r, :); rpb(r, :) = tmp;
    end
    real_bnd_keys = unique([rpa, rpb], 'rows');
    report.n_real_bnd_edges = size(real_bnd_keys, 1);

    % ---- Stage 2: boundary parity (odd loops -> even) ----
    t0 = tic;
    [node, tri, parity_info] = fix_boundary_parity_v32(node, tri, debug);
    report.parity_info = parity_info;
    report.t_parity = toc(t0);
    if debug; save_stage_dbg_v32('stage2_parity', node, tri); end

    % ---- Stage 3: triangle optimization ----
    t0 = tic;
    [tri, opt_info] = optimize_tri_mesh_v32(node, tri, debug);
    report.tri_opt_info = opt_info;
    report.t_triopt = toc(t0);
    if debug; save_stage_dbg_v32('stage3_triopt', node, tri); end

    % ---- Stage 4: dual graph ----
    t0 = tic;
    gopts = struct('single_cost', single_cost);
    [graph, ginfo] = build_dual_graph_v32(node, tri, gopts, debug);
    report.graph_info = ginfo;
    report.t_graph = toc(t0);

    % ---- Stage 5: MWPM (V32-03: solver ladder + watchdog) ----
    t0 = tic;
    mopts = struct('blossom6_max_nodes', b6_gate, 'cli_timeout_sec', cli_tmo);
    [match, minfo] = solve_matching_v32(graph, blossom_ver, debug, mopts);
    report.match_info = minfo;
    report.t_match = toc(t0);

    % ---- Stage 6: extraction ----
    t0 = tic;
    [quadnode, quad, einfo] = extract_quads_v32(node, tri, graph, match, debug);
    report.extract_info = einfo;
    report.t_extract = toc(t0);
    fprintf('[stage] extract done %d\n', round(toc(t_all))); 

    if debug; save_stage_dbg_v32('stage6_extract', quadnode, quad); end
    if debug
        % V32-05 (issue 4): bad-quad annotation right after extraction.
        dbg_plot_quad_quality_v32(quadnode, quad, 'stage6_extract');
    end

    % ---- Stage 6.5: TRUE conforming closure (V32-08) ----
    % The extract leaves hanging midpoints (centroid-split edges,
    % pentagon-F, coupon noq-stops). V32-07 hid them with 4e-9
    % nudges - topologically still non-conforming (round-07 issues
    % 1/1a: 'triangle split into three but neighbor not split').
    % V32-08 closes every one with a red-green cascade: the spanning
    % quads are split so every hanging vertex becomes proper; the
    % wavefronts route to the real boundary (collinear subdivision,
    % bit-identical shape) or meet each other; area conserved; dust
    % edges (quarter-point descent) collapsed.
    t0 = tic;
    [quadnode, quad, cl_info] = conforming_closure_v32(quadnode, quad, real_bnd_keys, debug);
    report.closure_info = cl_info;
    report.t_closure = toc(t0);
    fprintf('[stage] closure done %d\n', round(toc(t_all)));
    if debug; save_stage_dbg_v32('stage65_closure', quadnode, quad); end

    % ---- Stage 7: repair ----
    t0 = tic;
    [quadnode, quad, rep_info] = repair_quad_mesh_v32(quadnode, quad, debug);
    report.repair_info = rep_info;
    report.t_repair = toc(t0);
    if debug; save_stage_dbg_v32('stage7_repair', quadnode, quad); end
    if debug
        dbg_plot_quad_quality_v32(quadnode, quad, 'stage7_repair');
    end

    % ---- Stage 7.5: topology cleanup (unspan + doublet removal) ----
    t0 = tic;
    [quadnode, quad, topo_info] = topology_cleanup_v32(quadnode, quad, debug, ...
        ref_node, struct('disable', 'CWT', 'real_bnd', real_bnd_keys));
    report.topology_info = topo_info;
    report.t_topo = toc(t0);
    fprintf('[stage] topo1 done %d\n', round(toc(t_all))); 

    if debug; save_stage_dbg_v32('stage75_topo', quadnode, quad); end

    % ---- Stage 8: smoothing ----
    t0 = tic;
    [quadnode, n_moved] = smooth_quad_mesh_v32(quadnode, quad, n_taubin, debug);
    report.smooth_moved = n_moved;
    report.t_smooth = toc(t0);
    fprintf('[stage] smooth1 done %d\n', round(toc(t_all))); 

    if debug; save_stage_dbg_v32('stage8_smooth', quadnode, quad); end

    % ---- Stage 8.5: post-smoothing topology polish ----
    % Smoothing regularizes the transition zones, unlocking doublet
    % removals (each deletes one vertex) that failed on the raw
    % extraction geometry, plus any spanning/T leftovers.
    % V32-05: ref_node passed so the new WELD sweep can keep the
    % reference boundary bit-exact (anchored vertices never move).
    t0 = tic;
    [quadnode, quad, topo2_info] = topology_cleanup_v32(quadnode, quad, debug, ...
        ref_node, struct('disable', 'CWT', 'real_bnd', real_bnd_keys));
    report.topology2_info = topo2_info;
    report.t_topo2 = toc(t0);
    fprintf('[stage] topo2 done %d\n', round(toc(t_all))); 

    if debug; save_stage_dbg_v32('stage85_topo2', quadnode, quad); end

    % ---- Stage 8.6: light re-smoothing of the polished zones ----
    % V32-07: conditional - run only when the 8.5 polish actually
    % changed topology (welds/unspans/doublets/thin-resplits), else
    % the smoothed geometry is already valid.
    t0 = tic;
    n_moved2 = 0;
    topo2_changed = false;
    if isfield(topo2_info, 'n_unspanned'); topo2_changed = topo2_changed || topo2_info.n_unspanned > 0; end
    if isfield(topo2_info, 'n_doublets_removed'); topo2_changed = topo2_changed || topo2_info.n_doublets_removed > 0; end
    if isfield(topo2_info, 'n_welds'); topo2_changed = topo2_changed || topo2_info.n_welds > 0; end
    if isfield(topo2_info, 'n_thin_resplit'); topo2_changed = topo2_changed || topo2_info.n_thin_resplit > 0; end
    if topo2_changed
        [quadnode, n_moved2] = smooth_quad_mesh_v32(quadnode, quad, ...
            max(6, round(n_taubin / 3)), false);
    end
    report.smooth2_moved = n_moved2;
    report.t_smooth2 = toc(t0);
    if debug && topo2_changed; save_stage_dbg_v32('stage86_smooth2', quadnode, quad); end

    % ---- Stage 8.7: T-junction closure (V32-07: NUDGE policy) ----
    % The red-green chain closure exploded (285 root T's -> +2107
    % V32-08: the nudge-based tjclose is REMOVED (it only hid the
    % T-junctions below the verifier's tolerance - topologically
    % still non-conforming). The conforming closure already ran at
    % stage 6.5; this slot is a cheap SAFETY re-run: the closure
    % exits after one detection wave (< 0.5 s) when nothing hangs.
    t0 = tic;
    [quadnode, quad, tjc_info] = conforming_closure_v32(quadnode, quad, real_bnd_keys, false, struct('maxw', 30));
    report.tjclose_info = tjc_info;
    report.t_tjclose = toc(t0);
    fprintf('[stage] tjclose done %d\n', round(toc(t_all)));

    if debug; save_stage_dbg_v32('stage87_tjclose', quadnode, quad); end

    % ---- Stage 8.8: untangle flat quads (V32-05) ----
    % Relocates vertices of quads with a corner >= 168 deg (round-04
    % issue-2 defect); boundary corners are opened by moving their
    % movable interior neighbor; all moves fully validated.
    t0 = tic;
    [quadnode, unt_info] = untangle_v32(quadnode, quad, ref_node, debug);
    report.untangle_info = unt_info;
    report.t_untangle = toc(t0);
    if debug; save_stage_dbg_v32('stage88_untangle', quadnode, quad); end

    % ---- Stage 8.85: final topology pass (V32-05) ----
    % Weld/unspan/doublet sweeps with the thin-resplit enabled; the
    % forced tjclose/debris rounds of the earlier design are REMOVED -
    % they explode dust vertices (593+ chain closures on near-T dust);
    % the pocket T's and dust sandwiches are handled surgically by
    % tdust_fix_v32 (stage 8.96) instead, which never adds vertices.
    t0 = tic;
    [quadnode, quad, topo3_info] = topology_cleanup_v32(quadnode, quad, debug, ...
        ref_node, struct('disable', 'CWT', 'real_bnd', real_bnd_keys));
    report.topology3_info = topo3_info;
    report.t_topo3 = toc(t0);
    fprintf('[stage] topo3 done %d\n', round(toc(t_all))); 

    if debug; save_stage_dbg_v32('stage89_topo3', quadnode, quad); end
    if debug; save('-v7', 'v08_state_topo3.mat', 'quadnode', 'quad', 'ref_node', 'real_bnd_keys', 'ref_tri'); end

    % ---- Stage 8.9: second untangle pass (V32-05 r3) ----
    % The first pass (8.8) moved flat-corner vertices, so they are
    % no longer bit-identical to reference rows and become movable -
    % this second pass with refreshed no-worsening bounds fixes
    % another ~30% of the remaining flats.
    % V32-07: conditional - pointless (pure scan cost) when the first
    % pass moved nothing.
    t0 = tic;
    unt2_info = struct('n_moved', 0, 'skipped', true);
    unt1_moved = 0;
    if isfield(unt_info, 'n_moved'); unt1_moved = unt_info.n_moved; end
    if unt1_moved > 0
        unt2_info = untangle_v32(quadnode, quad, ref_node, debug);
    end
    report.untangle2_info = unt2_info;
    report.t_untangle2 = toc(t0);
    if debug && unt1_moved > 0; save_stage_dbg_v32('stage895_untangle2', quadnode, quad); end

    % ---- Stage 8.95: final T-safety re-run (V32-08) ----
    % The untangle moves (and any late topology op) could in theory
    % re-create T's; one detection-only closure call (< 0.5 s when
    % clean) guarantees the conforming invariant to the end.
    t0 = tic;
    [quadnode, quad, tjc2_info] = conforming_closure_v32(quadnode, quad, real_bnd_keys, false, struct('maxw', 30));
    report.tjclose2_info = tjc2_info;
    report.t_tjclose2 = toc(t0);

    % ---- Stage 8.96: dust surgery (V32-05) ----
    % The LAST mesh operation; repairs exactly the defects the
    % verifier counts: (A) T-pocket nudges - a vertex lying bit-exactly
    % on a short boundary edge (near-duplicate pocket) is nudged
    % perpendicular by 1e-2*|edge| (dust scale, 1e6x the T threshold);
    % (F) crossing-clearance nudges with no-worsening validation;
    % (D) dust-sandwich pair-merges (two slivers sharing two
    % consecutive dust edges -> one outer-ring quad, area-conserving,
    % collinear corners opened by validated nudges); (E) dust-edge
    % collapse fallback; (B) reflex-corner nudges.
    t0 = tic;
    [quadnode, quad, tdi_info] = tdust_fix_v32(quadnode, quad, ref_node, debug);
    report.tdust_info = tdi_info;
    report.t_tdust = toc(t0);
    fprintf('[stage] tdust done %d\n', round(toc(t_all))); 

    if debug; save_stage_dbg_v32('stage896_tdust', quadnode, quad); end

    % ---- Stage 8.97: FINAL REPAIR (V32-07) ----
    % The smoothing / untangle / tdust moves can leave ~2 near-noise
    % concave quads (reflex corner 8-10 deg past 180 with a FROZEN
    % reflex vertex - the tdust perpendicular nudge cannot move it).
    % The (now pass-by-value-fixed) hexagon re-split repairs them
    % vertex-neutrally. Field data: 2 swaps -> 0 remaining, PASSED.
    t0 = tic;
    [quadnode, quad, rep2_info] = repair_quad_mesh_v32(quadnode, quad, debug);
    report.repair2_info = rep2_info;
    report.t_repair2 = toc(t0);

    % ---- Stage 9: verification ----
    vr = verify_mesh_v32(quadnode, quad, ref_node, ref_tri, debug);
    report.verify = vr;
    report.total_time_sec = toc(t_all);
    report = order_fields_v32(report);
    % V32-07: stage timing always printed (one line, no figures)
    fprintf('[times] clean %.1f short %.1f parity %.1f triopt %.1f graph %.1f match %.1f extract %.1f closure %.1f repair %.1f topo %.1f smooth %.1f topo2 %.1f smooth2 %.1f tjclose %.1f untangle %.1f topo3 %.1f untangle2 %.1f tjclose2 %.1f tdust %.1f repair2 %.1f | TOTAL %.1f\n', ...
        report.t_clean, report.t_short, report.t_parity, report.t_triopt, ...
        report.t_graph, report.t_match, report.t_extract, report.t_closure, report.t_repair, ...
        report.t_topo, report.t_smooth, report.t_topo2, report.t_smooth2, ...
        report.t_tjclose, report.t_untangle, report.t_topo3, ...
        report.t_untangle2, report.t_tjclose2, report.t_tdust, report.t_repair2, ...
        report.total_time_sec);

    if debug
        % V32-05 (issue 4): final bad-quad annotation + boundary-loss
        % annotation (v32-01 style localization figures).
        dbg_plot_quad_quality_v32(quadnode, quad, 'final');
        dbg_plot_boundary_check_v32(quadnode, quad, ref_node, ref_tri, 'boundary_final');
        fprintf('\n=== tri2quad_v32 DONE in %.2f sec | PASSED=%d ===\n', ...
            report.total_time_sec, report.verify.passed);
        fprintf('Times: clean %.2f | short %.2f | parity %.2f | triopt %.2f | graph %.2f | match %.2f | extract %.2f | closure %.2f | repair %.2f | topo %.2f | smooth %.2f | topo2 %.2f | smooth2 %.2f | tjclose %.2f | untangle %.2f | topo3 %.2f | untangle2 %.2f | tdust %.2f\n', ...
            report.t_clean, report.t_short, report.t_parity, report.t_triopt, ...
            report.t_graph, report.t_match, report.t_extract, report.t_closure, report.t_repair, ...
            report.t_topo, report.t_smooth, report.t_topo2, report.t_smooth2, ...
            report.t_tjclose, report.t_untangle, report.t_topo3, ...
            report.t_untangle2, report.t_tdust);
    end
end

% =====================================================================
function save_stage_dbg_v32(name, node, tri)
%SAVE_STAGE_DBG_V32  Dump intermediate mesh (2-col coords or n-col ids).
    fid = fopen(sprintf('dbg_%s_node.txt', name), 'w');
    for k = 1:size(node, 1)
        fprintf(fid, '%.17g %.17g\n', node(k, :));
    end
    fclose(fid);
    fid = fopen(sprintf('dbg_%s_tri.txt', name), 'w');
    fmt = [repmat('%d ', 1, size(tri, 2)), '\n'];
    for k = 1:size(tri, 1)
        fprintf(fid, fmt, tri(k, :));
    end
    fclose(fid);
end

function report = order_fields_v32(report)
    % no-op placeholder (keeps report struct as built)
end
