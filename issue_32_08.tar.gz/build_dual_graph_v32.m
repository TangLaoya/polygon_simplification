function [graph, info] = build_dual_graph_v32(node, tri, opts, debug)
%BUILD_DUAL_GRAPH_V32  Build the Blossom-Quad dual graph (vectorized).
%
%   Nodes (1-based here; converted to 0-based for the blossom solver):
%     1..ntri          : one node per triangle
%     ntri+1..ntri+M   : one GHOST node per boundary edge
%
%   Edges:
%     (T_i, T_j)  : real pair across a shared interior edge; weight =
%                   quad shape cost sum(corner-90)^2 plus V32-02
%                   penalty tiers. NO real edge is ever removed from
%                   the graph: dropping "bad" pairs (concave / flat /
%                   tiny-corner / boundary-spanning) starved needle-zone
%                   triangles of every partner and broke perfect-matching
%                   feasibility in V32-02 prototypes. Instead each bad
%                   category carries a tiered huge penalty, and the
%                   extraction safety net (quad_rows_acceptable_v32 in
%                   extract_quads_v32) rejects any surviving bad pair,
%                   resolving BOTH triangles as singles (pentagon /
%                   centroid splits). Tiers:
%                     PENALTY_HARD     : any corner reflex (concave / CW /
%                       folded), any corner >= FLAT_DEG or <= TINY_DEG
%                       (geometrically a triangle: 3 collinear vertices)
%                     PENALTY_REFLEX_BND (soft): quad contains BOTH
%                       boundary edges of a boundary vertex whose
%                       material angle >= 150 deg (user rule: adjacent
%                       boundary edges with angle > 180 deg must never be
%                       two sides of one quad; >180-deg cases are also
%                       concave = hard tier. Convex sharp corners MAY
%                       span — that is the standard corner quad and
%                       keeps the vertex count low.)
%                     PENALTY_FLATISH : soft zone, corners in
%                       [175, FLAT_DEG) or (TINY_DEG, 3]
%     (T_b, G_e)  : T_b becomes a SINGLE (pentagon / 3-quad split later).
%                   weight = SINGLE_COST - quality bonus (worse triangles
%                   split preferentially).
%     (G_e1,G_e2) : pure "soaker" edges — NO geometric action. They soak
%                   up ghosts not consumed by singles (k singles consume
%                   k ghosts; M-k ghosts pair off; parity guaranteed by
%                   the even-loop boundary). Connected as a ring per
%                   boundary loop (ghosts of consecutive boundary edges).
%
%   OUTPUT graph: .n_nodes, .edges (0-based Ex2), .weights (Ex1 integers),
%     .ntri, .M, .bnd_e (Mx2), .bnd_e_tri (Mx1)

    if nargin < 3; opts = struct(); end
    if nargin < 4; debug = false; end
    PENALTY_FLATISH    = 10000;   % soft: corner in [175,179) or (0.5,3]
    % V32-07 (issue 4): boundary-spanning soft tier now triggers at
    % material angle >= SPAN_DEG = 120 (user rule: no quad may use two
    % boundary-adjacent edges whose included angle is over ~120 deg;
    % was 150). Penalty raised to 45000 so the matcher prefers any
    % reasonable re-pairing cascade over a spanning quad; still far
    % below PENALTY_HARD / SINGLE_COST so perfect matching is never
    % blocked (survivors are un-spanned by topology_cleanup at 120).
    SPAN_DEG           = 120;
    PENALTY_REFLEX_BND = 45000;
    PENALTY_HARD       = 500000;  % concave / folded / >=179 / <=0.5 corner
    FLAT_DEG           = 179;     % corner >= this  -> hard tier
    TINY_DEG           = 0.5;     % corner <= this  -> hard tier
    SINGLE_COST        = 25000;
    if isfield(opts, 'single_cost'); SINGLE_COST = opts.single_cost; end

    ntri = size(tri, 1);
    nnode = size(node, 1);
    nbr = compute_neighbors_fast(tri);

    % ---------- boundary edges (vectorized) ----------
    [I, J] = find(nbr < 0);   % row=triangle id, col=local edge
    va_e = tri(sub2ind([ntri, 3], I, mod(J, 3) + 1));
    vb_e = tri(sub2ind([ntri, 3], I, mod(J + 1, 3) + 1));
    bnd_e = [va_e, vb_e];
    bnd_e_tri = I;
    M = size(bnd_e, 1);

    % ---------- boundary vertex neighbors ----------
    is_bnd_v = false(nnode, 1);
    is_bnd_v(bnd_e(:)) = true;
    bnd_v1 = zeros(nnode, 1);
    bnd_v2 = zeros(nnode, 1);
    key_be = min(bnd_e(:,1), bnd_e(:,2)) * double(nnode) + ...
             max(bnd_e(:,1), bnd_e(:,2));
    for r = 1:M
        v1 = bnd_e(r, 1); v2 = bnd_e(r, 2);
        if bnd_v1(v1) == 0; bnd_v1(v1) = v2; else; bnd_v2(v1) = v2; end
        if bnd_v1(v2) == 0; bnd_v1(v2) = v1; else; bnd_v2(v2) = v1; end
    end

    % ---------- material angle per boundary vertex (triangle fan sum) ---
    mat_ang = accumarray([tri(:,1); tri(:,2); tri(:,3)], ...
        [tri_corner_at_first_v32(node, tri(:,1), tri(:,2), tri(:,3)); ...
         tri_corner_at_first_v32(node, tri(:,2), tri(:,3), tri(:,1)); ...
         tri_corner_at_first_v32(node, tri(:,3), tri(:,1), tri(:,2))], ...
        [nnode, 1]);

    % ---------- interior edges + real costs (vectorized) ----------
    [ti, tj, va, vb, vc, vd] = interior_edges_v32(tri);
    [cost_real, bad_hard, spanning_real] = quad_cost_v32(node, va, vb, ...
        vc, vd, is_bnd_v, bnd_v1, bnd_v2, mat_ang, PENALTY_FLATISH, ...
        PENALTY_REFLEX_BND, PENALTY_HARD, FLAT_DEG, TINY_DEG, SPAN_DEG);

    % ---------- ghost-triangle edges ----------
    tmin = min([tri_corner_at_first_v32(node, tri(:,1), tri(:,2), tri(:,3)), ...
                tri_corner_at_first_v32(node, tri(:,2), tri(:,3), tri(:,1)), ...
                tri_corner_at_first_v32(node, tri(:,3), tri(:,1), tri(:,2))], [], 2);
    w_single = round(SINGLE_COST - 3000 * min(1, max(0, (30 - tmin(bnd_e_tri)) / 30)));
    w_single = max(w_single, 1000);

    % ---------- soaker ring per boundary loop ----------
    loops = find_boundary_loops(node, tri);
    gg_edges = zeros(M * 2, 2); gc = 0;
    for li = 1:numel(loops)
        lp = loops{li}; L = numel(lp);
        if L < 2; continue; end
        e1a = lp;                    e1b = [lp(2:end); lp(1)];   % loop edges (i, i+1)
        e2a = [lp(2:end); lp(1)];    e2b = [lp(3:end); lp(1:2)];
        k1 = min(e1a, e1b) * double(nnode) + max(e1a, e1b);
        k2 = min(e2a, e2b) * double(nnode) + max(e2a, e2b);
        [tf1, loc1] = ismember(k1, key_be);
        [tf2, loc2] = ismember(k2, key_be);
        ok = tf1 & tf2 & (loc1 ~= loc2);
        n_new = sum(ok);
        gg_edges(gc+1:gc+n_new, 1) = loc1(ok);
        gg_edges(gc+1:gc+n_new, 2) = loc2(ok);
        gc = gc + n_new;
    end
    gg_edges = gg_edges(1:gc, :);

    % ---------- assemble (0-based, deduped, min weight) ----------
    % V32-02: EVERY interior edge is kept (see header) — perfect-matching
    % feasibility first; bad categories only carry huge penalties.
    re = [ti, tj];
    rw = cost_real;
    rw = round(min(max(rw, 1), PENALTY_HARD));
    ge = [bnd_e_tri, ntri + (1:M)'];
    gw = w_single;
    so = gg_edges + ntri;
    sw = ones(size(so, 1), 1);

    edges = [re; ge; so];
    weights = [rw; gw; sw];
    key = edges(:,1) * double(ntri + M + 2) + edges(:,2);
    [~, order] = sortrows([key, weights]);
    sorted_key = key(order);
    keep = [true; diff(sorted_key) ~= 0];
    edges = edges(order(keep), :);
    weights = weights(order(keep));

    graph.n_nodes = ntri + M;
    graph.edges = edges - 1;
    graph.weights = weights;
    graph.ntri = ntri;
    graph.M = M;
    graph.bnd_e = bnd_e;
    graph.bnd_e_tri = bnd_e_tri;

    info.n_real_edges = size(re, 1);
    info.n_hard_penalized = sum(bad_hard);
    info.n_spanning_penalized = sum(spanning_real & ~bad_hard);
    info.n_ghost_tri = M;
    info.n_soaker = size(so, 1);
    info.total_nodes = graph.n_nodes;
    info.parity_ok = mod(graph.n_nodes, 2) == 0;
    if debug
        fprintf('  [dual-graph] tri=%d ghosts=%d total=%d (%s)\n', ...
            ntri, M, graph.n_nodes, mat_str_v32(info.parity_ok));
        fprintf('    real=%d (hard %d, spanning %d), tri-ghost=%d, soaker=%d\n', ...
            info.n_real_edges, info.n_hard_penalized, ...
            info.n_spanning_penalized, M, info.n_soaker);
        if ~isempty(rw)
            fprintf('    real cost min/med/max = %d / %d / %d; single ~%d\n', ...
                min(rw), round(median(rw)), max(rw), round(median(gw)));
        end
    end
end

% =====================================================================
function [ti, tj, va, vb, vc, vd] = interior_edges_v32(tri)
%INTERIOR_EDGES_V32  Interior edges with ti<tj; edge endpoints va,vb;
%   apex of ti is vc, apex of tj is vd.
    nbr = compute_neighbors_fast(tri);
    ntri = size(tri, 1);
    ti = repmat((1:ntri)', 3, 1); ti = ti(:);
    ej = repmat((1:3)', 1, ntri)'; ej = ej(:);
    nb = nbr(sub2ind([ntri, 3], ti, ej));
    mask = nb > 0 & ti < nb;
    ti = ti(mask); ej = ej(mask); tj = nb(mask);
    va = tri(sub2ind([ntri, 3], ti, mod(ej, 3) + 1));
    vb = tri(sub2ind([ntri, 3], ti, mod(ej + 1, 3) + 1));
    vc = tri(sub2ind([ntri, 3], ti, ej));
    rowsT = tri(tj, :);
    notab = ~(rowsT == va | rowsT == vb);
    vd = zeros(size(va));
    for cc = 1:3   % column-major safe extraction (row order preserved)
        sel = notab(:, cc);
        vd(sel) = rowsT(sel, cc);
    end
    vd = vd(:);
end

% =====================================================================
function [cost, bad_hard, spanning] = quad_cost_v32(node, va, vb, vc, vd, ...
    is_bnd_v, bnd_v1, bnd_v2, mat_ang, pen_flatish, pen_reflex_bnd, ...
    pen_hard, flat_deg, tiny_deg, span_deg)
%QUAD_COST_V32  Vectorized cost of quad (vc, va, vd, vb) [CCW].
%   V32-02 penalty tiers (NO edge is dropped — see build_dual_graph
%   header): hard (reflex / folded / [flat_deg,180] / <=tiny_deg corner),
%   spanning (both boundary edges of a boundary vertex inside one quad),
%   soft flatish zone. bad_hard/spanning flags returned for reporting.
    x1 = node(vc, :); x2 = node(va, :); x3 = node(vd, :); x4 = node(vb, :);
    a1 = corner_angle_v32(x4, x1, x2);   % at vc
    a2 = corner_angle_v32(x1, x2, x3);   % at va
    a3 = corner_angle_v32(x2, x3, x4);   % at vd
    a4 = corner_angle_v32(x3, x4, x1);   % at vb
    cost = (a1 - 90).^2 + (a2 - 90).^2 + (a3 - 90).^2 + (a4 - 90).^2;

    % hard tier: reflex (concave / CW) or folded corners
    concave = a1 > 180 | a2 > 180 | a3 > 180 | a4 > 180;
    folded  = a1 > 359.99 | a2 > 359.99 | a3 > 359.99 | a4 > 359.99;

    % hard tier: triangle-like (three collinear vertices)
    flat_hard = a1 >= flat_deg | a2 >= flat_deg | a3 >= flat_deg | ...
                a4 >= flat_deg | a1 <= tiny_deg | a2 <= tiny_deg | ...
                a3 <= tiny_deg | a4 <= tiny_deg;
    bad_hard = concave | folded | flat_hard;
    cost = cost + pen_hard * bad_hard;

    % soft zone: near-flat / near-degenerate corners
    flatish = (a1 >= 175 | a2 >= 175 | a3 >= 175 | a4 >= 175) | ...
              (a1 <= 3 | a2 <= 3 | a3 <= 3 | a4 <= 3);
    cost = cost + pen_flatish * flatish;

    % spanning: both boundary edges of a boundary vertex inside one quad
    verts = [vc, va, vd, vb];
    prevv = [vb, vc, va, vd];
    nextv = [va, vd, vb, vc];
    isb   = is_bnd_v(verts);
    match_nbr = (prevv == bnd_v1(verts) & nextv == bnd_v2(verts)) | ...
                (prevv == bnd_v2(verts) & nextv == bnd_v1(verts));
    % V32-07: threshold 120 deg (issue-4 user rule; was 150)
    spanning = any(isb & match_nbr & (mat_ang(verts) >= span_deg), 2);
    cost = cost + pen_reflex_bnd * spanning;
end

% =====================================================================
function ang = corner_angle_v32(p_prev, p, p_next)
%CORNER_ANGLE_V32  Interior angle (0..360) at row-point p for CCW polyline
%   p_prev -> p -> p_next. Convex CCW corner: cross(e1,e2)<0, angle=acos;
%   reflex corner: cross>0, angle = 360 - acos.
    e1 = p_prev - p; e2 = p_next - p;
    n1 = sqrt(e1(:,1).^2 + e1(:,2).^2);
    n2 = sqrt(e2(:,1).^2 + e2(:,2).^2);
    cs = (e1(:,1).*e2(:,1) + e1(:,2).*e2(:,2)) ./ (n1 .* n2 + 1e-300);
    ang = acosd(max(-1, min(1, cs)));
    cr = e1(:,1).*e2(:,2) - e1(:,2).*e2(:,1);
    ang(cr > 0) = 360 - ang(cr > 0);
end

% =====================================================================
function ang = tri_corner_at_first_v32(node, v1, v2, v3)
%TRI_CORNER_AT_FIRST_V32  Angle at v1 of triangle (v1,v2,v3), vectorized.
    e1 = node(v2,:) - node(v1,:); e2 = node(v3,:) - node(v1,:);
    n1 = sqrt(e1(:,1).^2 + e1(:,2).^2); n2 = sqrt(e2(:,1).^2 + e2(:,2).^2);
    cs = (e1(:,1).*e2(:,1) + e1(:,2).*e2(:,2)) ./ (n1 .* n2 + 1e-300);
    ang = acosd(max(-1, min(1, cs)));
end

% =====================================================================
function s = mat_str_v32(b)
    if b; s = 'EVEN'; else; s = 'ODD'; end
end
