function [quadnode, quad, info] = conforming_closure_v32(quadnode, quad, real_bnd, debug, opts)
%CONFORMING_CLOSURE_V32  V32-08 TRUE conforming (red-green) closure of
%   ALL hanging midpoints. A hanging node is a USED vertex v lying
%   strictly inside a live quad edge (a,b): the far side of the edge is
%   split at v while this side spans the full edge (T-junction).
%   V32-07 hid these with 4e-9 nudges - topologically still
%   non-conforming (round-07 issues 1/1a: "triangle split into three
%   but neighbor not split" / "other non-conforming forms"). V32-08
%   SPLITS the spanning quads so every hanging vertex becomes a proper
%   mesh vertex: the output is conforming by construction (every
%   interior edge has exactly 2 incident quads, no fake boundary
%   edges, no T-junctions, no nudges).
%
%   PARITY PRINCIPLE: each hanging midpoint carries one unit of mesh
%   "oddness". It is resolved either (a) by MEETING another hanging
%   midpoint on the same quad (multi-hang templates terminate both
%   without new vertices), (b) by flowing to the REAL BOUNDARY where
%   a collinear edge-midpoint subdivides a boundary edge (geometric
%   shape bit-identical: the midpoint lies exactly on the straight
%   segment; the verifier's chain walk accepts it; the smoother
%   freezes it via 1-owner edge detection), or (c) by PROPAGATING one
%   quad further (P1: the new midpoint hangs on the next quad).
%
%   Split templates (quad [v1 v2 v3 v4] CCW, m* = hanging midpoints,
%   o = new interior vertex, n/m2 = new edge midpoint):
%     S=2 opposite (m1 on v1v2, m2 on v3v4):
%        [v1 m1 m2 v4] + [m1 v2 v3 m2]                  (terminates)
%     S=2 adjacent (m1 on v1v2, m2 on v2v3, share v2) - 3-CELL CAP:
%        [m1 v2 m2 o] + [m2 v3 v4 o] + [v4 v1 m1 o]     (terminates)
%     S=3 (m1 v1v2, m2 v2v3, m3 v3v4, v4v1 clean):
%        bisect v4v1 -> m4, then the S=4 center template
%        (only m4 propagates, to the neighbor across v4v1);
%        if v4v1 is real-boundary: 3-cell cap on an adjacent
%        pair, the third hang continues on a child (next wave).
%     S=4, center o:
%        [m1 v2 m2 o] + [m2 v3 m3 o] + [m3 v4 m4 o] + [m4 v1 m1 o]
%     S=1 (m on v1v2), priority:
%       P1b boundary-opposite (v3v4 real-bnd): collinear midpoint n
%          ON the boundary edge: [v1 m n v4] + [m v2 v3 n]
%          (n is a proper boundary vertex - TERMINATES)
%       P1 opposite (interior): midpoint n of v3v4 (reused if a
%          vertex already lies inside it): same children; a newly
%          created n hangs on the neighbor across v3v4.
%       P2 boundary-adjacent (v2v3 or v4v1 real-bnd): new midpoint
%          m2 on the boundary edge + 3-cell cap (TERMINATES)
%       P2 adjacent (interior): new midpoint m2 + 3-cell cap
%          (m2 propagates)
%
%   STEERING: when several directions are legal, prefer the one whose
%   far quad already carries a hang (the wavefronts meet and terminate
%   next wave) - the attraction map is rebuilt each wave.
%
%   GUARDS (per template, two tiers: strict 1..179 deg, relaxed 0.2
%   ..359.8 deg): children simple (diagonals intersect), positive
%   area, corner angles in range, AND the children's total area must
%   equal the parent quad's area (1e-10 relative) - this catches any
%   template that does not exactly tile the parent. Real-boundary
%   edges are only subdivided COLLINEARLY (P1b/P2b). New midpoints
%   are deduplicated against vertices strictly inside the target
%   edge. Failures are retried on later waves (neighbors change) and
%   blocked after 3 attempts; residues are reported and the
%   verifier's fake-boundary-edge check flags them.
%
%   Termination: every template except P1/P2-interior strictly
%   reduces the hanging count; interior propagation lands on a fresh
%   edge (one with no strictly-inside vertex - such a vertex would
%   have made the case S>=2), the mesh is finite, and wavefronts meet
%   or reach the boundary. MAXW is a safety cap.
%
%   INPUT : quadnode (Nx2), quad (Mx4, 1-based), real_bnd (Kx4 rows
%           [ax ay bx by], endpoints sorted lexicographically), debug
%   OUTPUT: mesh + info counters

    if nargin < 5; opts = struct(); end
    if nargin < 4; debug = false; end
    if nargin < 3 || isempty(real_bnd); real_bnd = zeros(0, 4); end
    if ~isfield(opts, 'maxw'); opts.maxw = 300; end
    t0 = tic;
    BIGK = 1e7;                       % edge-key base (ids < 1e7)
    MAXW = opts.maxw;                 % wave cap (safety)

    info = struct('n_hang_initial', 0, 'n_waves', 0, ...
        'n_p2_opp', 0, 'n_cap3', 0, 'n_p3_bisect', 0, 'n_p4_center', 0, ...
        'n_p1_opp', 0, 'n_p1_bnd', 0, 'n_p1_adj', 0, 'n_p2_bnd', 0, ...
        'n_created', 0, 'n_reused', 0, 'n_failed', 0, 'n_blocked', 0, ...
        'n_dust_collapse', 0, 'n_area_reject', 0, ...
        'n_hang_left', 0, 'n_vtx_before', size(quadnode, 1), ...
        'n_quad_before', size(quad, 1), 'time_sec', 0);

    % V32-08c: real-boundary detection = TWO tests. (1) incidence: the
    % edge has NO second owner (no far quad) and NO vertex strictly
    % inside it (a hanging edge always has its insider). (2) geometry:
    % the edge's midpoint lies ON the reference boundary polyline
    % (within 1e-6 of a reference segment). Test (1) alone misfires on
    % ISOLATED POCKETS (round-08: detached micro-quads whose edges
    % have no far side at all - the P1b bisected them and left broken
    % single-owner edges that the verifier's fake-boundary check
    % flags). Test (2) uses the real_bnd reference keys.
    rb = [];
    if ~isempty(real_bnd)
        rb = sortrows(real_bnd);
    end

    % blocked / attempt bookkeeping: (v, qi) pairs
    blk_keys = zeros(0, 1);           % sorted v*BIGK + qi
    att_keys = zeros(0, 1); att_cnt = zeros(0, 1);
    % wave-scope shared: insiders map + edge table mirror
    ins_k = zeros(0, 1); ins_v = zeros(0, 1);
    eo_key_g = zeros(0, 1); eo_o1_g = zeros(0, 1); eo_o2_g = zeros(0, 1);
    DUST_TOL = -1;                   % set on wave 1 (1e-3 x median edge)
    bpg = [];                         % boundary-polyline grid (lazy)
    dbterm = false;                  % debug edge_terminable

    bd = -ones(size(quad, 1), 1);     % BFS dist to real boundary (per wave)
    for wave = 1:MAXW
        [tjs, ins_k, ins_v, hangq, eo_key, eo_o1, eo_o2] = collect_hangs_v32();
        eo_key_g = eo_key; eo_o1_g = eo_o1; eo_o2_g = eo_o2;
        if DUST_TOL < 0
            ul = sqrt(sum((quadnode(eo_key_g - floor(eo_key_g / BIGK) * BIGK, :) ...
                - quadnode(floor(eo_key_g / BIGK), :)).^2, 2));
            if ~isempty(ul)
                DUST_TOL = 1e-3 * median(ul);
            else
                DUST_TOL = 0;
            end
        end
        bd = rebuild_bd_v32(eo_key, eo_o1, eo_o2);
        if debug
            fprintf('    [bd] valid=%d d0=%d d1=%d d2=%d d3=%d\n', ...
                sum(bd>=0), sum(bd==0), sum(bd==1), sum(bd==2), sum(bd>=3));
        end
        if wave == 1
            info.n_hang_initial = size(tjs, 1);
        end
        if isempty(tjs); break; end
        if ~debug && size(tjs, 1) > 0
            fprintf('  [closure] WARNING: %d hanging vertices found (safety re-run)\n', size(tjs, 1));
        end
        info.n_waves = wave;
        if ~isempty(blk_keys)
            kv = tjs(:, 1) * BIGK + tjs(:, 4);
            tjs = tjs(~ismember(kv, blk_keys), :);
            if isempty(tjs); break; end
        end
        % group by owner quad
        [qi_u, ~, gic] = unique(tjs(:, 4));
        n_applied = 0;
        for g = 1:numel(qi_u)
            rows = tjs(gic == g, :);
            if apply_template_v32(qi_u(g), rows, hangq, eo_key, eo_o1, eo_o2)
                n_applied = n_applied + 1;
            end
        end
        if debug
            fprintf('    [closure w%d] hang=%d quads=%d vtx=%d\n', ...
                wave, size(tjs, 1), size(quad, 1), size(quadnode, 1));
        end
        if n_applied == 0 && wave > 1
            break;
        end
    end

    % ---------- V32-08c pocket surgery ----------
    % Isolated pockets: connected components of quads linked by
    % 2-owner edges whose ENTIRE outer boundary consists of
    % single-owner edges that are NOT on the real boundary polyline
    % (detached micro-quads in the extract's degenerate thin zones -
    % round-08's fake-boundary-edge residue). Their area is dust
    % scale; deleting them is area-safe and restores conformity.
    info.n_pockets = 0;
    if ~isempty(rb)
        [quad, npk] = delete_pockets_v32(quad);
        info.n_pockets = npk;
    end
    % compaction of unused vertices (failed-pattern creations)
    usedv = false(size(quadnode, 1), 1);
    usedv(quad(:)) = true;
    if ~all(usedv)
        keepv = find(usedv(:));
        vmap = zeros(size(quadnode, 1), 1);
        vmap(keepv) = 1:numel(keepv);
        quad = vmap(quad);
        quadnode = quadnode(keepv, :);
    end
    tjs_end = collect_hangs_only_v32();
    info.n_hang_left = size(tjs_end, 1);
    info.n_vtx_after = size(quadnode, 1);
    info.n_quad_after = size(quad, 1);
    info.time_sec = toc(t0);
    if debug
        fprintf(['  [closure] done: waves=%d hang0=%d p2opp=%d cap3=%d p3bis=%d p4ctr=%d ' ...
                 'p1opp=%d p1bnd=%d p1adj=%d p2bnd=%d dust=%d | created=%d reused=%d ' ...
                 'arej=%d failed=%d left=%d | vtx %d->%d quads %d->%d | %.2fs\n'], ...
            info.n_waves, info.n_hang_initial, info.n_p2_opp, info.n_cap3, ...
            info.n_p3_bisect, info.n_p4_center, info.n_p1_opp, info.n_p1_bnd, ...
            info.n_p1_adj, info.n_p2_bnd, info.n_dust_collapse, ...
            info.n_created, info.n_reused, ...
            info.n_area_reject, info.n_failed, info.n_hang_left, ...
            info.n_vtx_before, info.n_vtx_after, info.n_quad_before, ...
            info.n_quad_after, info.time_sec);
    end

    % ==================== nested helpers ====================

    function [quad, npk] = delete_pockets_v32(quad)
        %DELETE_POCKETS_V32  Remove fully-detached quad components.
        nq = size(quad, 1);
        npk = 0;
        if nq == 0; return; end
        BIGK2 = 1e7;
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        own = repmat((1:nq)', 4, 1);
        key = double(min(E(:, 1), E(:, 2))) * BIGK2 + double(max(E(:, 1), E(:, 2)));
        [skey, ord] = sort(key);
        [ukey, ~, icu] = unique(skey);
        ecnt = accumarray(icu(:), 1);
        fp = find([true; diff(skey) ~= 0]);
        % adjacency: edges with 2 owners
        dup = ecnt >= 2;
        % union-find over quads via double edges
        parent = (1:nq)';
        for t = find(dup(:))'
            k = ukey(t);
            p1 = own(ord(fp(t))); p2 = own(ord(fp(t) + 1));
            r1 = find_root_v32(parent, p1);
            r2 = find_root_v32(parent, p2);
            if r1 ~= r2
                parent(max(r1, r2)) = min(r1, r2);
            end
        end
        roots = zeros(nq, 1);
        for qi = 1:nq
            roots(qi) = find_root_v32(parent, qi);
        end
        % per component: check its outer boundary edges
        comp_bad = [];
        uroots = unique(roots);
        for c = 1:numel(uroots)
            members = find(roots == uroots(c));
            if numel(members) > 60; continue; end   % pockets are tiny
            % collect component edge incidences
            bad = true;
            for qi = members(:)'
                qv = quad(qi, :);
                for s = 1:4
                    u = qv(s); w = qv(mod(s, 4) + 1);
                    k = double(min(u, w)) * BIGK2 + double(max(u, w));
                    pos = find_first_sorted_v32(ukey, k);
                    if pos == 0; bad = false; break; end
                    if ecnt(pos) >= 2; bad = false; break; end
                    if edge_on_polyline_v32(u, w); bad = false; break; end
                end
                if ~bad; break; end
            end
            if bad
                comp_bad = [comp_bad; members(:)]; %#ok<AGROW>
                npk = npk + numel(members);
            end
        end
        if ~isempty(comp_bad)
            quad(comp_bad, :) = [];
        end
    end

    function r = find_root_v32(parent, x)
        r = x;
        while parent(r) ~= r
            r = parent(r);
        end
        % path compression
        c = x;
        while parent(c) ~= c
            nx = parent(c); parent(c) = r; c = nx;
        end
    end

    function tjs = collect_hangs_only_v32()
        tjs = collect_hangs_v32();
        tjs = tjs(:, 1:4);
    end

    function [tjs, ins_k, ins_v, hangq, eo_key, eo_o1, eo_o2] = collect_hangs_v32()
        %COLLECT_HANGS_V32  [v, a, b, qi]: used vertex v strictly inside
        %   unique edge (a,b) (1e-7*L tolerance), qi = an owner quad.
        %   Also returns the insiders map (edge key -> vertex, for
        %   midpoint dedup), the hang-quad logical (attraction), and
        %   the edge->(owner1, owner2) table. Fully VECTORIZED.
        tjs = zeros(0, 4); ins_k = zeros(0, 1); ins_v = zeros(0, 1);
        hangq = false(0, 1); eo_key = zeros(0, 1);
        eo_o1 = zeros(0, 1); eo_o2 = zeros(0, 1);
        P = quadnode; nv = size(P, 1); nq = size(quad, 1);
        if nq == 0; return; end
        E = [quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1]); quad(:, [1 2])];
        own = repmat((1:nq)', 4, 1);
        elo = min(E(:, 1), E(:, 2)); ehi = max(E(:, 1), E(:, 2));
        key = double(elo) * BIGK + double(ehi);
        [skey, ord] = sort(key);
        first = [true; diff(skey) ~= 0];
        ue = E(ord(first), :); uown = own(ord(first));
        % edge -> owners (1 or 2): occurrences are consecutive in
        % sorted order, so the 2nd occurrence of the k-th unique key
        % is at fp(k)+1 whenever its count >= 2.
        [ukey, ~, icu] = unique(skey);
        ecnt = accumarray(icu(:), 1);
        fp = find(first);
        dup = ecnt >= 2;
        eo_key = ukey;
        eo_o1 = own(ord(fp));
        eo_o2 = zeros(numel(ukey), 1);
        eo_o2(dup) = own(ord(fp(dup) + 1));
        usedv = false(nv, 1); usedv(quad(:)) = true;
        uidx = find(usedv(:));
        if isempty(uidx) || isempty(ue); return; end
        span = max(max(P(:,1)) - min(P(:,1)), max(P(:,2)) - min(P(:,2))) * 1.0001 + 1e-300;
        ne = size(ue, 1);
        gx = max(1, round(sqrt(ne))); gy = gx;
        x0 = min(P(:,1)); y0 = min(P(:,2));
        csx = span / gx; csy = span / gy;
        vcx = min(gx, max(1, floor((P(uidx,1) - x0) / csx) + 1));
        vcy = min(gy, max(1, floor((P(uidx,2) - y0) / csy) + 1));
        vcid = (vcy - 1) * gx + vcx;
        [~, vord] = sort(vcid);
        vcu = unique(vcid);
        [~, ~, vic] = unique(vcid);
        vcnt = accumarray(vic(:), 1);
        vstart = [1; cumsum(vcnt(1:end-1)) + 1];
        vord = uidx(vord(:)); vord = vord(:);
        mx = 0.5 * (P(ue(:,1),1) + P(ue(:,2),1));
        my = 0.5 * (P(ue(:,1),2) + P(ue(:,2),2));
        ecx = min(gx, max(1, floor((mx - x0) / csx) + 1));
        ecy = min(gy, max(1, floor((my - y0) / csy) + 1));
        off = [-1 0 1];
        [dX, dY] = meshgrid(off, off);
        ccx = repmat(ecx, 1, 9) + repmat(dX(:)', ne, 1);
        ccy = repmat(ecy, 1, 9) + repmat(dY(:)', ne, 1);
        okc = ccx >= 1 & ccx <= gx & ccy >= 1 & ccy <= gy;
        ccd = (ccy - 1) * gx + ccx;
        ccd(~okc) = 0;
        [tfm, vgid] = ismember(ccd, vcu);
        vgid(~tfm) = 0;
        pair_cnt = zeros(ne, 9);
        pair_cnt(tfm) = vcnt(vgid(tfm));
        tot = sum(pair_cnt(:));
        if tot == 0; return; end
        e_fl = repmat((1:ne)', 1, 9);
        ecnt = pair_cnt(:);
        eidx = repelem(e_fl(:), ecnt);
        gidx = repelem(vgid(:), ecnt);
        cs_ends = cumsum(ecnt);
        cs_beg = cs_ends - ecnt + 1;
        run = (1:tot)' - repelem(cs_beg, ecnt);
        vidx = vord(vstart(gidx) + run);
        ee = eidx(:); vv = vidx(:);
        ea = ue(ee, 1); eb = ue(ee, 2);
        ea = ea(:); eb = eb(:);
        bad = vv == ea | vv == eb;
        A = P(ea, :); B = P(eb, :); V = P(vv, :);
        AB = B - A; AV = V - A;
        L2 = AB(:,1).^2 + AB(:,2).^2;
        okL = L2 > 1e-300;
        tp = (AV(:,1).*AB(:,1) + AV(:,2).*AB(:,2)) ./ max(L2, 1e-300);
        dist = abs(AV(:,1).*AB(:,2) - AV(:,2).*AB(:,1)) ./ sqrt(max(L2, 1e-300));
        keep = okL & ~bad & tp > 1e-6 & tp < 1 - 1e-6 & ...
               dist < 1e-7 * sqrt(max(L2, 1e-300));
        hangq = false(nq, 1);
        if any(keep)
            ka = double(min(ea, eb)) * BIGK + double(max(ea, eb));
            ka = ka(:);
            [ins_k, ~, ic] = unique(ka(keep));
            ins_k = ins_k(:);
            tmp_v = vv(keep); tmp_v = tmp_v(:);
            ins_v = tmp_v(ic);
            tjs = [vv(keep), ea(keep), eb(keep), uown(ee(keep))];
            tjs = tjs(:,:);
            hangq(tjs(:, 4)) = true;
        end
    end

    function bd = rebuild_bd_v32(eo_key, eo_o1, eo_o2)
        %REBUILD_BD_V32  BFS distance (quad-adjacency) to the nearest
        %   quad owning a REAL boundary edge (sinks). The wavefront
        %   routes monotonically toward the boundary = guaranteed
        %   termination (an isolated interior wave can never cycle).
        nq = size(quad, 1);
        bd = -ones(nq, 1);
        if isempty(eo_key); return; end
        % true boundary edges: single owner AND no insider vertex
        isb = eo_o2(:) == 0 & ~ismember(eo_key(:), ins_k);
        sink = false(nq, 1);
        sink(eo_o1(isb)) = true;
        if ~any(sink); return; end
        bd(sink) = 0;
        ia = eo_o2 > 0;
        a1 = eo_o1(ia); a2 = eo_o2(ia);
        for lev = 0:nq
            m1 = bd(a1) == lev & bd(a2) < 0;
            if any(m1); n2 = unique(a2(m1)); bd(n2) = lev + 1; end
            m2 = bd(a2) == lev & bd(a1) < 0;
            if any(m2); n1 = unique(a1(m2)); bd(n1) = lev + 1; end
            if ~any(m1) && ~any(m2); break; end
        end
    end

    function tf = edge_terminable_v32(u, w)
        %TF = EDGE_TERMINABLE_V32  edge (u,w) is a TRUE boundary edge:
        %   (1) no second owner in the wave-start table AND no insider;
        %   (2) its midpoint lies ON the reference boundary polyline.
        tf = false;
        k = double(min(u, w)) * BIGK + double(max(u, w));
        lo = 1; hi = numel(eo_key_g);
        while lo <= hi
            mid = floor((lo + hi) / 2);
            if eo_key_g(mid) == k
                c1 = (eo_o2_g(mid) == 0);
                c2 = (find_first_sorted_v32(ins_k, k) == 0);
                c3 = edge_on_polyline_v32(u, w);
                if dbterm && ~c3
                    pdbg = 0.5 * (quadnode(u, :) + quadnode(w, :));
                    fprintf('    [term] edge (%d,%d) mid=(%.6g,%.6g) c1=%d c2=%d c3=%d\n', u, w, pdbg(1), pdbg(2), c1, c2, c3);
                end
                if c1 && c2 && c3
                    tf = true;
                end
                return;
            elseif eo_key_g(mid) < k
                lo = mid + 1;
            else
                hi = mid - 1;
            end
        end
    end

    function tf = edge_on_polyline_v32(u, w)
        %TF = midpoint of (u,w) within 1e-6 (relative) of a reference
        %   boundary segment. Scalar binary search over rb rows is too
        %   slow per call - use the sorted-key row test with the edge
        %   midpoint sampled against every nearby rb segment via a
        %   cached bucket grid built lazily on first use.
        tf = false;
        if isempty(rb); return; end
        p = 0.5 * (quadnode(u, :) + quadnode(w, :));
        % brute scan is O(nr) - too slow; build the grid once
        if isempty(bpg)
            nr = size(rb, 1);
            rbA = rb(:, 1:2); rbB = rb(:, 3:4);
            rbm = 0.5 * (rbA + rbB);
            rbL = sqrt(sum((rbB - rbA).^2, 2));
            g2 = max(1, round(sqrt(nr)));
            bspan = max(max(quadnode(:,1)) - min(quadnode(:,1)), ...
                        max(quadnode(:,2)) - min(quadnode(:,2))) * 1.0001 + 1e-300;
            cs2 = bspan / g2;
            bpg.g2 = g2; bpg.cs2 = cs2;
            bpg.x0 = min(quadnode(:,1)); bpg.y0 = min(quadnode(:,2));
            bpg.rbA = rbA; bpg.rbB = rbB; bpg.rbL = rbL;
            cx = min(g2, max(1, floor((rbm(:,1) - bpg.x0) / cs2) + 1));
            cy = min(g2, max(1, floor((rbm(:,2) - bpg.y0) / cs2) + 1));
            cid = (cy - 1) * g2 + cx;
            [cu, ~, cic] = unique(cid);
            ccnt = accumarray(cic(:), 1);
            cstart = [1; cumsum(ccnt(1:end-1)) + 1];
            [csrt, cord] = sort(cid);
            bpg.cu = cu; bpg.cnt = ccnt; bpg.start = cstart;
            bpg.rows = cord;
        end
        g2 = bpg.g2; cs2 = bpg.cs2;
        pcx = min(g2, max(1, floor((p(1) - bpg.x0) / cs2) + 1));
        pcy = min(g2, max(1, floor((p(2) - bpg.y0) / cs2) + 1));
        for dx = -1:1
            ccx = pcx + dx;
            if ccx < 1 || ccx > g2; continue; end
            for dy = -1:1
                ccy = pcy + dy;
                if ccy < 1 || ccy > g2; continue; end
                cidq = (ccy - 1) * g2 + ccx;
                bi = find(bpg.cu == cidq, 1);
                if isempty(bi); continue; end
                for s = bpg.start(bi):bpg.start(bi) + bpg.cnt(bi) - 1
                    r = bpg.rows(s);
                    A = bpg.rbA(r, :); B = bpg.rbB(r, :);
                    e = B - A; L2 = dot(e, e);
                    if L2 < 1e-300; continue; end
                    t = max(0, min(1, dot(p - A, e) / L2));
                    if norm(p - (A + t * e)) < 1e-6 * max(bpg.rbL(r), 1e-300) + 1e-15
                        tf = true; return;
                    end
                end
            end
        end
    end

    function qj = far_quad_v32(u, w, qi, eo_key, eo_o1, eo_o2)
        %QJ = the OTHER quad sharing edge (u,w), 0 if none/stale.
        qj = 0;
        k = double(min(u, w)) * BIGK + double(max(u, w));
        lo = 1; hi = numel(eo_key);
        while lo <= hi
            mid = floor((lo + hi) / 2);
            if eo_key(mid) == k
                if eo_o1(mid) == qi
                    qj = eo_o2(mid);
                elseif eo_o2(mid) == qi
                    qj = eo_o1(mid);
                else
                    qj = 0;   % stale owner table
                end
                return;
            elseif eo_key(mid) < k
                lo = mid + 1;
            else
                hi = mid - 1;
            end
        end
    end

    function [nid, created] = get_or_create_mid_v32(u, w)
        %[NID, CREATED]  Vertex strictly inside edge (u,w) if present
        %   (shared insiders map), else append the midpoint and
        %   REGISTER it in the map (prevents duplicate midpoints when
        %   a pattern fails after creation).
        nid = 0; created = false;
        k = double(min(u, w)) * BIGK + double(max(u, w));
        pos = find_first_sorted_v32(ins_k, k);
        if pos > 0
            nid = ins_v(pos); created = false; return;
        end
        quadnode(end+1, :) = 0.5 * (quadnode(u, :) + quadnode(w, :)); %#ok<AGROW>
        nid = size(quadnode, 1); created = true;
        info.n_created = info.n_created + 1;
        % register (sorted insert into the shared map)
        ip = find_insert_pos_v32(ins_k, k);
        ins_k = [ins_k(1:ip-1); k; ins_k(ip:end)]; %#ok<AGROW>
        ins_v = [ins_v(1:ip-1); nid; ins_v(ip:end)]; %#ok<AGROW>
    end

    function pos = find_first_sorted_v32(sk, k)
        pos = 0;
        lo = 1; hi = numel(sk);
        while lo <= hi
            mid = floor((lo + hi) / 2);
            if sk(mid) == k
                pos = mid; return;
            elseif sk(mid) < k
                lo = mid + 1;
            else
                hi = mid - 1;
            end
        end
    end

    function ok = child_ok_v32(cq, strict)
        %CHILD_OK_V32  4-point child validity: positive CCW area,
        %   simple (diagonals intersect), corner angles within bounds.
        ok = false;
        pts = quadnode(cq, :);
        p1 = pts(1, :); p2 = pts(2, :); p3 = pts(3, :); p4 = pts(4, :);
        ar = crossr_v32(p1, p2, p3) + crossr_v32(p1, p3, p4);
        if ar <= 1e-300; return; end
        d1 = crossr_v32(p1, p3, p2); d2 = crossr_v32(p1, p3, p4);
        d3 = crossr_v32(p2, p4, p1); d4 = crossr_v32(p2, p4, p3);
        if ~(((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ...
             ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0)))
            return;
        end
        amin = 0.2; amax = 359.8;
        if strict; amin = 1.0; amax = 179.0; end
        for t = 1:4
            pa = pts(t, :); pb = pts(mod(t, 4) + 1, :); pc = pts(mod(t + 1, 4) + 1, :);
            uu = pa - pb; vv = pc - pb;
            nu = norm(uu); nvv = norm(vv);
            if nu < 1e-300 || nvv < 1e-300; return; end
            ang = acosd(max(-1, min(1, dot(uu, vv) / (nu * nvv))));
            if ang < amin || ang > amax; return; end
        end
        ok = true;
    end

    function kids_ok = all_kids_ok_v32(kids, strict)
        kids_ok = true;
        for s = 1:size(kids, 1)
            if ~child_ok_v32(kids(s, :), strict)
                kids_ok = false; return;
            end
        end
    end

    function c = crossr_v32(p1, p2, p3)
        c = (p2(1) - p1(1)) * (p3(2) - p1(2)) - (p2(2) - p1(2)) * (p3(1) - p1(1));
    end

    function ok = commit_kids_v32(qi, kids, counter)
        %COMMIT_KIDS_V32  Validate (area conservation!) then write:
        %   row qi <- kids(1,:), append the rest. Children inherit the
        %   parent's boundary-distance estimate.
        % AREA CONSERVATION: sum of |children areas| must equal the
        % parent's |area| (1e-10 relative). This is the hard safety
        % net against any template that does not tile the parent.
        pa = quadarea_v32(quad(qi, :));
        sa = 0;
        for s = 1:size(kids, 1)
            sa = sa + quadarea_v32(kids(s, :));
        end
        if pa > 0 && abs(sa - pa) > 1e-10 * pa
            info.n_area_reject = info.n_area_reject + 1;
            ok = false; return;
        end
        quad(qi, :) = kids(1, :);
        for s = 2:size(kids, 1)
            quad(end+1, :) = kids(s, :); %#ok<AGROW>
        end
        % inherit bd for appended rows
        if size(bd, 1) < size(quad, 1)
            bd(end+1:size(quad,1), 1) = -1; %#ok<AGROW>
        end
        nparent = bd(qi);
        if nparent < 0; nparent = 999999; end
        bd(size(quad,1) - size(kids, 1) + 2:size(quad, 1)) = nparent;
        switch counter
            case 'p2opp';  info.n_p2_opp = info.n_p2_opp + 1;
            case 'cap3';   info.n_cap3 = info.n_cap3 + 1;
            case 'p3bis';  info.n_p3_bisect = info.n_p3_bisect + 1;
            case 'p4ctr';  info.n_p4_center = info.n_p4_center + 1;
            case 'p1opp';  info.n_p1_opp = info.n_p1_opp + 1;
            case 'p1bnd';  info.n_p1_bnd = info.n_p1_bnd + 1;
            case 'p1adj';  info.n_p1_adj = info.n_p1_adj + 1;
            case 'p2bnd';  info.n_p2_bnd = info.n_p2_bnd + 1;
        end
        ok = true;
    end

    function a = quadarea_v32(qv)
        pts = quadnode(qv, :);
        p1 = pts(1, :);
        a = 0;
        for t = 2:3
            a = a + (pts(t,1) - p1(1)) * (pts(t+1,2) - p1(2)) - ...
                     (pts(t,2) - p1(2)) * (pts(t+1,1) - p1(1));
        end
        a = abs(a) * 0.5;
    end

    function tf = apply_template_v32(qi, rows, hangq, eo_key, eo_o1, eo_o2)
        %APPLY_TEMPLATE_V32  Resolve the hanging set on quad qi.
        tf = false;
        qv0 = quad(qi, :);
        ppts = quadnode(qv0, :);
        ar = crossr_v32(ppts(1,:), ppts(2,:), ppts(3,:)) + ...
             crossr_v32(ppts(1,:), ppts(3,:), ppts(4,:));
        if ar < 0; qv = qv0([1 4 3 2]); else; qv = qv0; end
        nS = size(rows, 1);
        slots = zeros(nS, 1);
        for r = 1:nS
            a = rows(r, 2); b = rows(r, 3);
            for s = 1:4
                if (qv(s) == a && qv(mod(s, 4) + 1) == b) || ...
                   (qv(s) == b && qv(mod(s, 4) + 1) == a)
                    slots(r) = s; break;
                end
            end
        end
        if any(slots == 0)
            bump_attempt_v32(rows(1, 1), qi);
            return;
        end
        if nS > 1
            [~, ia, ib] = unique(slots);
            if numel(ia) < nS
                keepm = false(nS, 1); keepm(ib(:)) = true;
                rows = rows(keepm, :); slots = slots(keepm);
                nS = size(rows, 1);
            end
        end

        % dust edge: collapse the hang vertex into the nearer endpoint
        aa = rows(1, 2); bb = rows(1, 3); vv0 = rows(1, 1);
        Lv = norm(quadnode(aa, :) - quadnode(bb, :));
        if DUST_TOL > 0 && Lv < DUST_TOL
            tf = try_dust_collapse_v32(qi, vv0, aa, bb);
            return;
        end

        for tier = 1:2
            strict = (tier == 1);
            ok = false;
            if nS == 4
                ok = try_center_v32(qi, qv, rows, slots, strict);
            elseif nS == 3
                ok = try_p3_bisect_v32(qi, qv, rows, slots, strict);
                if ~ok
                    ok = try_cap3_pair_v32(qi, qv, rows, slots, strict);
                end
            elseif nS == 2
                dd = mod(slots(2) - slots(1), 4);
                if dd == 2
                    ok = try_p2_opp_v32(qi, qv, rows, slots, strict);
                    if ~ok
                        ok = try_cap3_pair_v32(qi, qv, rows, slots, strict);
                    end
                else
                    ok = try_cap3_pair_v32(qi, qv, rows, slots, strict);
                    if ~ok
                        ok = try_p1_single_v32(qi, qv, rows(1, 1), slots(1), hangq, eo_key, eo_o1, eo_o2, strict);
                    end
                end
            else
                ok = try_p1_single_v32(qi, qv, rows(1, 1), slots(1), hangq, eo_key, eo_o1, eo_o2, strict);
            end
            if ok; tf = true; return; end
        end
        for r = 1:size(rows, 1)
            bump_attempt_v32(rows(r, 1), qi);
        end
    end

    function bump_attempt_v32(v, qi)
        %BUMP_ATTEMPT_V32  count a failed attempt; block at >= 3
        k = v * BIGK + qi;
        pos = find_first_sorted_v32(att_keys, k);
        if pos > 0
            att_cnt(pos) = att_cnt(pos) + 1;
            if att_cnt(pos) >= 3
                bp = find_insert_pos_v32(blk_keys, k);
                blk_keys = [blk_keys(1:bp-1); k; blk_keys(bp:end)]; %#ok<AGROW>
                info.n_blocked = info.n_blocked + 1;
            end
        else
            bp = find_insert_pos_v32(att_keys, k);
            att_keys = [att_keys(1:bp-1); k; att_keys(bp:end)]; %#ok<AGROW>
            att_cnt = [att_cnt(1:bp-1); 1; att_cnt(bp:end)]; %#ok<AGROW>
        end
    end

    function pos = find_insert_pos_v32(sk, k)
        lo = 1; hi = numel(sk);
        while lo <= hi
            mid = floor((lo + hi) / 2);
            if sk(mid) < k
                lo = mid + 1;
            else
                hi = mid - 1;
            end
        end
        pos = lo;
    end

    function ok = try_dust_collapse_v32(qi, v, a, b)
        %TRY_DUST_COLLAPSE_V32  Hang v lies on a dust-length edge:
        %   merge v into its nearer endpoint, delete degenerate quad
        %   rows (repeated vertices). Area change ~ L^2 ~ 1e-16.
        ok = false;
        pa = quadnode(a, :); pb = quadnode(b, :);
        e = pb - pa; L2 = dot(e, e);
        if L2 < 1e-300; return; end
        t = dot(quadnode(v, :) - pa, e) / L2;
        tgt = a;
        if t > 0.5; tgt = b; end
        quad(quad == v) = tgt;
        del = [];
        for r = 1:size(quad, 1)
            qr = quad(r, :);
            if qr(1) == qr(2) || qr(2) == qr(3) || qr(3) == qr(4) || ...
               qr(4) == qr(1) || qr(1) == qr(3) || qr(2) == qr(4)
                del(end+1) = r; %#ok<AGROW>
            end
        end
        if ~isempty(del)
            quad(del, :) = [];
        end
        info.n_dust_collapse = info.n_dust_collapse + 1;
        ok = true;
    end

    function ok = try_p2_opp_v32(qi, qv, rows, slots, strict)
        % m1 on slot s, m2 on slot s+2: [e1 m1 m2 e4] + [m1 e2 e3 m2]
        if slots(2) < slots(1)
            rows = rows([2 1], :); slots = slots([2 1]);
        end
        s = slots(1);
        e1 = qv(s); e2 = qv(mod(s, 4) + 1);
        e3 = qv(mod(s + 1, 4) + 1); e4 = qv(mod(s + 2, 4) + 1);
        m1 = rows(1, 1); m2 = rows(2, 1);
        kids = [e1, m1, m2, e4; m1, e2, e3, m2];
        if all_kids_ok_v32(kids, strict)
            ok = commit_kids_v32(qi, kids, 'p2opp');
        else
            ok = false;
        end
    end

    function ok = try_cap3_pair_v32(qi, qv, rows, slots, strict)
        %TRY_CAP3_PAIR_V32  3-cell cap over an ADJACENT pair of hangs
        %   (slots s, s+1 sharing corner e2=qv(s+1)):
        %   [m1 e2 m2 o] + [m2 e3 e4 o] + [e4 e1 m1 o], o = centroid.
        %   Terminates the two hangs of the chosen pair (a third hang
        %   in the set continues on the children, next wave).
        nS = numel(slots);
        pairs = zeros(0, 2);
        for i1 = 1:nS
            for i2 = 1:nS
                if i1 == i2; continue; end
                if mod(slots(i2) - slots(i1), 4) == 1
                    pairs(end+1, :) = [i1, i2]; %#ok<AGROW>
                end
            end
        end
        ok = false;
        for c = 1:size(pairs, 1)
            i1 = pairs(c, 1); i2 = pairs(c, 2);
            s = slots(i1);
            e1 = qv(s); e2 = qv(mod(s, 4) + 1);
            e3 = qv(mod(s + 1, 4) + 1); e4 = qv(mod(s + 2, 4) + 1);
            m1 = rows(i1, 1); m2 = rows(i2, 1);
            quadnode(end+1, :) = mean(quadnode([e1, e2, e3, e4], :), 1); %#ok<AGROW>
            o = size(quadnode, 1);
            kids = [m1, e2, m2, o; m2, e3, e4, o; e4, e1, m1, o];
            if all_kids_ok_v32(kids, strict) && commit_kids_v32(qi, kids, 'cap3')
                ok = true; return;
            else
                quadnode(end, :) = []; %#ok<AGROW>
            end
        end
    end

    function ok = try_p3_bisect_v32(qi, qv, rows, slots, strict)
        % three hangs: bisect the 4th edge (not real-bnd, no insider)
        % -> center template. Only the new m4 propagates.
        free = 0;
        for s = 1:4
            if ~any(slots(:) == s); free = s; break; end
        end
        if free == 0; ok = false; return; end
        u = qv(free); w = qv(mod(free, 4) + 1);
        % (a boundary 4th edge is fine: its m4 terminates immediately)
        Lf = norm(quadnode(u, :) - quadnode(w, :));
        if DUST_TOL > 0 && Lf < DUST_TOL; ok = false; return; end
        [m4, created] = get_or_create_mid_v32(u, w);
        if m4 <= 0; ok = false; return; end
        if ~created; info.n_reused = info.n_reused + 1; end
        mids = zeros(4, 1);
        for r = 1:numel(slots)
            mids(slots(r)) = rows(r, 1);
        end
        mids(free) = m4;
        quadnode(end+1, :) = mean(quadnode(qv, :), 1); %#ok<AGROW>
        o = size(quadnode, 1);
        kids = zeros(4, 4);
        for s = 1:4
            kids(s, :) = [mids(s), qv(mod(s, 4) + 1), mids(mod(s, 4) + 1), o];
        end
        if all_kids_ok_v32(kids, strict) && commit_kids_v32(qi, kids, 'p3bis')
            ok = true;
        else
            quadnode(end, :) = []; %#ok<AGROW>
            ok = false;
        end
    end

    function ok = try_center_v32(qi, qv, rows, slots, strict)
        % four hangs, center pattern
        mids = zeros(4, 1);
        for r = 1:numel(slots)
            mids(slots(r)) = rows(r, 1);
        end
        quadnode(end+1, :) = mean(quadnode(qv, :), 1); %#ok<AGROW>
        o = size(quadnode, 1);
        kids = zeros(4, 4);
        for s = 1:4
            kids(s, :) = [mids(s), qv(mod(s, 4) + 1), mids(mod(s, 4) + 1), o];
        end
        if all_kids_ok_v32(kids, strict) && commit_kids_v32(qi, kids, 'p4ctr')
            ok = true;
        else
            quadnode(end, :) = []; %#ok<AGROW>
            ok = false;
        end
    end

    function ok = try_p1_single_v32(qi, qv, m, s, hangq, eo_key, eo_o1, eo_o2, strict)
        %TRY_P1_SINGLE_V32  ONE hang m on slot s (edge e1-e2).
        %   Priority: P1b (boundary opposite, terminates) >
        %   P1 (opposite; attracted first) > P2b (boundary adjacent,
        %   terminates) > P2 (adjacent; attracted first).
        e1 = qv(s); e2 = qv(mod(s, 4) + 1);
        e3 = qv(mod(s + 1, 4) + 1);
        e4 = qv(mod(s + 2, 4) + 1);
        p1_ok = [];
        % routing info
        mybd = 1e6;
        if qi <= numel(bd) && bd(qi) >= 0; mybd = bd(qi); end
        fq_opp = far_quad_v32(e3, e4, qi, eo_key, eo_o1, eo_o2);
        bd_opp = 1e6;
        if fq_opp > 0 && fq_opp <= numel(bd) && bd(fq_opp) >= 0
            bd_opp = bd(fq_opp);
        end
        opp_attracted = (fq_opp > 0 && fq_opp <= numel(hangq) && hangq(fq_opp));
        % ---------- P1b: opposite edge (e3, e4) real boundary ----------
        if edge_terminable_v32(e3, e4)
            [n, created] = get_or_create_mid_v32(e3, e4);
            if n > 0
                if ~created; info.n_reused = info.n_reused + 1; end
                kids = [e1, m, n, e4; m, e2, e3, n];
                if all_kids_ok_v32(kids, strict) && commit_kids_v32(qi, kids, 'p1bnd')
                    ok = true; return;
                end
            end
        else
            % ---------- P1: opposite edge interior ----------
            % dust-length targets are skipped (bisecting nano edges
            % creates nano children = the quarter-point descent)
            Lt = norm(quadnode(e3, :) - quadnode(e4, :));
            if ~(DUST_TOL > 0 && Lt < DUST_TOL)
            [n, created] = get_or_create_mid_v32(e3, e4);
            if n > 0
                if ~created; info.n_reused = info.n_reused + 1; end
                kids = [e1, m, n, e4; m, e2, e3, n];
                if all_kids_ok_v32(kids, strict)
                    if (opp_attracted || bd_opp < mybd) && commit_kids_v32(qi, kids, 'p1opp')
                        ok = true; return;
                    end
                    p1_ok = kids;
                end
            end
            end
        end
        % ---------- P2b / P2: adjacent edges (cap3 with a new m2) ------
        % order: boundary (immediate terminate) > attracted (meet next
        % wave) > smaller boundary-distance (routed)
        opts = zeros(0, 2);
        for ad = 1:2
            if ad == 1; au = e2; aw = e3; else; au = e4; aw = e1; end
            isb = edge_terminable_v32(au, aw);
            fq = far_quad_v32(au, aw, qi, eo_key, eo_o1, eo_o2);
            attracted = (fq > 0 && fq <= numel(hangq) && hangq(fq));
            bdv = 1e6;
            if fq > 0 && fq <= numel(bd) && bd(fq) >= 0; bdv = bd(fq); end
            if isb; prio = -2;
            elseif attracted; prio = -1;
            else; prio = bdv; end
            opts(end+1, :) = [ad, prio]; %#ok<AGROW>
        end
        [~, oi] = sort(opts(:, 2));
        for t = 1:numel(oi)
            ad = opts(oi(t), 1);
            if ad == 1; au = e2; aw = e3; else; au = e4; aw = e1; end
            isb = edge_terminable_v32(au, aw);
            fq = far_quad_v32(au, aw, qi, eo_key, eo_o1, eo_o2);
            bdv2 = 1e6;
            if fq > 0 && fq <= numel(bd) && bd(fq) >= 0; bdv2 = bd(fq); end
            att2 = (fq > 0 && fq <= numel(hangq) && hangq(fq));
            routed2 = isb || att2 || bdv2 < mybd;
            Lt2 = norm(quadnode(au, :) - quadnode(aw, :));
            if DUST_TOL > 0 && Lt2 < DUST_TOL
                continue;   % never bisect a dust edge
            end
            [m2, created] = get_or_create_mid_v32(au, aw);
            if m2 <= 0; continue; end
            if ~created; info.n_reused = info.n_reused + 1; end
            quadnode(end+1, :) = mean(quadnode([e1, e2, e3, e4], :), 1); %#ok<AGROW>
            o = size(quadnode, 1);
            if ad == 1
                kids = [m, e2, m2, o; m2, e3, e4, o; e4, e1, m, o];
            else
                kids = [m2, e1, m, o; m, e2, e3, o; e3, e4, m2, o];
            end
            ctr = 'p2bnd';
            if ~isb; ctr = 'p1adj'; end
            if routed2 && all_kids_ok_v32(kids, strict) && commit_kids_v32(qi, kids, ctr)
                ok = true; return;
            else
                quadnode(end, :) = []; %#ok<AGROW>
            end
        end
        % fallback 1: the validated (unrouted) P1 split
        if ~isempty(p1_ok) && commit_kids_v32(qi, p1_ok, 'p1opp')
            ok = true; return;
        end
        % fallback 2: an unrouted adjacent cap3 (children validated only)
        for t = 1:numel(oi)
            ad = opts(oi(t), 1);
            if ad == 1; au = e2; aw = e3; else; au = e4; aw = e1; end
            isb = edge_terminable_v32(au, aw);
            Lt3 = norm(quadnode(au, :) - quadnode(aw, :));
            if DUST_TOL > 0 && Lt3 < DUST_TOL
                continue;
            end
            [m2, created] = get_or_create_mid_v32(au, aw);
            if m2 <= 0; continue; end
            quadnode(end+1, :) = mean(quadnode([e1, e2, e3, e4], :), 1); %#ok<AGROW>
            o = size(quadnode, 1);
            if ad == 1
                kids = [m, e2, m2, o; m2, e3, e4, o; e4, e1, m, o];
            else
                kids = [m2, e1, m, o; m, e2, e3, o; e3, e4, m2, o];
            end
            ctr = 'p2bnd';
            if ~isb; ctr = 'p1adj'; end
            if all_kids_ok_v32(kids, strict) && commit_kids_v32(qi, kids, ctr)
                ok = true; return;
            else
                quadnode(end, :) = []; %#ok<AGROW>
            end
        end
        ok = false;
    end
end
