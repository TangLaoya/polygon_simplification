function [node, tri, info] = remove_short_boundary_edges_v32(node, tri, debug, ratio)
%REMOVE_SHORT_BOUNDARY_EDGES_V32  Collapse extremely short boundary edges.
%
%   V32 rewrite of remove_short_boundary_edges_v31 (compact, no dead code,
%   no scoping bugs, exact-zero boundary deviation). Strategy:
%     * A boundary edge (a,b) is SHORT when
%         (i)  min(Lprev, Lnext) > ratio * L  AND  L < 0.5 * loop median
%              (neighbor loop edges both at least `ratio`x longer), or
%         (ii) L < loop_median / 10  (absolutely tiny w.r.t. its loop;
%              catches adjacent PAIRS of short edges where the neighbor
%              ratio rule cannot fire), loop size >= 5 edges.
%     * Collapse shortest-first. Collapse position X in {A, B, midpoint} is
%       always ON segment [A,B] => boundary polyline deviation is EXACTLY 0.
%     * Safety checks per candidate position:
%         1. Hoppe link condition (common neighbors of a,b == {apex}),
%            guarantees manifold + topology preservation.
%         2. Fold check: all incident triangles keep positive orientation.
%         3. Crossing check: new fan edges (X,v) do not properly cross any
%            nearby live mesh edge (uniform grid + exact predicates).
%     * Among fold-free candidates, pick the one maximizing the worst
%       minimum angle of the incident triangle fan.
%
%   INPUT:
%     node  : N-by-2 vertices
%     tri   : M-by-3 triangles (1-indexed, CCW)
%     debug : verbose flag
%     ratio : short-edge ratio threshold (default 5)
%
%   OUTPUT:
%     node, tri : modified mesh (compacted numbering)
%     info      : n_removed, n_skipped_link, n_skipped_fold,
%                 n_skipped_cross, n_passes, removed_edges,
%                 removed_pos (V32-05: [x1 y1 x2 y2] of every collapsed
%                 short edge, recorded at collapse time so the debug
%                 figure can draw them on the post-removal mesh)

    if nargin < 4 || isempty(ratio); ratio = 5; end
    info = struct('n_removed', 0, 'n_skipped_link', 0, 'n_skipped_fold', 0, ...
                  'n_skipped_cross', 0, 'n_passes', 0, 'removed_edges', [], ...
                  'removed_pos', zeros(0, 4));
    max_passes = 12;

    for pass = 1:max_passes
        loops = find_boundary_loops(node, tri);
        if isempty(loops); break; end

        cand = collect_short_candidates_v32(node, loops, ratio);
        if isempty(cand); break; end
        [~, order] = sort(cand(:, 3), 'ascend');
        cand = cand(order, :);

        % global edge grid for crossing checks (rebuilt once per pass;
        % stores vertex IDS so coordinate moves are reflected live)
        all_edges = build_edge_list_v32(tri);
        grid = build_edge_grid_v32(node, all_edges);

        nnode = size(node, 1);
        alive_v = true(nnode, 1);
        alive_t = true(size(tri, 1), 1);

        n_removed_pass = 0;
        for k = 1:size(cand, 1)
            a = cand(k, 1); b = cand(k, 2);
            if ~alive_v(a) || ~alive_v(b) || a == b; continue; end

            % V32-05: record the collapsed segment COORDINATES before the
            % call (the collapse may move a/b onto the same position).
            seg_pos = [node(a, 1), node(a, 2), node(b, 1), node(b, 2)];
            [reason, node, tri, alive_t, alive_v] = ...
                try_collapse_edge_v32(node, tri, alive_t, alive_v, a, b, grid);
            switch reason
                case 0
                    n_removed_pass = n_removed_pass + 1;
                    info.removed_edges(end+1, :) = [a, b]; %#ok<AGROW>
                    info.removed_pos(end+1, :) = seg_pos;   %#ok<AGROW>
                case 1
                    info.n_skipped_link = info.n_skipped_link + 1;
                case 2
                    info.n_skipped_fold = info.n_skipped_fold + 1;
                case 3
                    info.n_skipped_cross = info.n_skipped_cross + 1;
            end
        end

        % compact mesh: drop dead triangles & unused vertices
        tri = tri(alive_t, :);
        used = false(nnode, 1); used(tri(:)) = true;
        [keep, ~, newid] = find(used);
        map_v = zeros(nnode, 1); map_v(keep) = 1:numel(keep);
        tri = map_v(tri);
        node = node(keep, :);

        info.n_removed = info.n_removed + n_removed_pass;
        info.n_passes = pass;
        if debug
            fprintf('  [short-edge pass %d] collapsed %d (total %d)\n', ...
                pass, n_removed_pass, info.n_removed);
        end
        if n_removed_pass == 0; break; end
    end

    if debug
        fprintf('  [short-edge] done: %d removed in %d passes (link-skip %d, fold-skip %d, cross-skip %d)\n', ...
            info.n_removed, info.n_passes, info.n_skipped_link, ...
            info.n_skipped_fold, info.n_skipped_cross);
    end
end

% =====================================================================
function cand = collect_short_candidates_v32(node, loops, ratio)
%COLLECT_SHORT_CANDIDATES_V32  Scan boundary loops; cand rows [a, b, len].
    cand = zeros(0, 3);
    bbox_scale = max(abs(node(:)));
    if isempty(bbox_scale) || bbox_scale == 0; bbox_scale = 1; end
    micro_len = 1e-11 * bbox_scale;

    for li = 1:numel(loops)
        lp = loops{li};
        L = numel(lp);
        if L < 3; continue; end
        ev = node(lp, :);
        nxt = [ev(2:end, :); ev(1, :)];
        elen = sqrt(sum((nxt - ev).^2, 2));
        med = median(elen);
        for i = 1:L
            li_len = elen(i);
            cond_rel = false;
            if li_len > 0
                lprev = elen(mod(i - 2, L) + 1);
                lnext = elen(mod(i, L) + 1);
                cond_rel = min(lprev, lnext) > ratio * li_len && ...
                           li_len < 0.5 * med;
            end
            % absolute rule: edge tiny w.r.t. loop median (chain-aware);
            % guard loop size so we never shrink a loop below 4 edges
            cond_abs = li_len < med / 10 && L >= 5;
            if cond_rel || cond_abs || li_len < micro_len
                cand(end+1, :) = [lp(i), lp(mod(i, L) + 1), li_len]; %#ok<AGROW>
            end
        end
    end
end

% =====================================================================
function [reason, node, tri, alive_t, alive_v] = ...
    try_collapse_edge_v32(node, tri, alive_t, alive_v, a, b, grid)
%TRY_COLLAPSE_EDGE_V32  Collapse boundary edge (a,b) keeping vertex a and
%   moving it to the best position in {A, B, midpoint}.
%   reason: 0=applied, 1=link fail, 2=fold fail, 3=cross fail

    reason = 0;

    % ---- incident triangles ----
    tids = find(alive_t & (any(tri == a, 2) | any(tri == b, 2)));
    if isempty(tids); reason = 1; return; end

    % ---- the (unique) shared triangle & apex ----
    has_a = any(tri(tids, :) == a, 2);
    has_b = any(tri(tids, :) == b, 2);
    shared_t = tids(has_a & has_b);
    if numel(shared_t) ~= 1; reason = 1; return; end
    t_shared = tri(shared_t(1), :);
    apex = setdiff(setdiff(t_shared, a), b);
    if numel(apex) ~= 1; reason = 1; return; end
    apex = apex(1);

    % ---- Hoppe link condition ----
    ta = tids(has_a);
    va = unique(tri(ta, :)); va = setdiff(va(:)', a);
    vb = unique(tri(tids(has_b), :)); vb = setdiff(vb(:)', b);
    common = intersect(va, vb);
    if ~isequal(common, apex); reason = 1; return; end

    % ---- pick best fold-free position ----
    PA = node(a, :); PB = node(b, :);
    cands_pos = [PA; PB; 0.5 * (PA + PB)];
    best = 0; best_score = -inf;
    for ci = 1:3
        X = cands_pos(ci, :);
        [ok_fold, worst_ang] = fold_check_v32(node, tri, tids, a, b, shared_t(1), X);
        if ok_fold && worst_ang > best_score
            best_score = worst_ang;
            best = ci;
        end
    end
    if best == 0; reason = 2; return; end
    X = cands_pos(best, :);

    % ---- crossing check: new fan edges (X, v), v in link vertices ----
    link_v = unique([va, vb]);
    for ii = 1:numel(link_v)
        v = link_v(ii);
        if ~seg_clear_v32(node, grid, X, node(v, :), a, b)
            reason = 3; return;
        end
    end

    % ---- apply: keep a at X, delete b, drop degenerate triangles ----
    node(a, :) = X;
    alive_v(b) = false;
    for ii = 1:numel(tids)
        ti = tids(ii);
        if ~alive_t(ti); continue; end
        t = tri(ti, :);
        if any(t == b)
            t(t == b) = a;
            tri(ti, :) = t;
            if numel(unique(t)) < 3
                alive_t(ti) = false;
            end
        end
    end
end

% =====================================================================
function [ok, worst_ang] = fold_check_v32(node, tri, tids, a, b, t_shared, X)
%FOLD_CHECK_V32  All incident triangles (except collapsed one) keep positive
%   orientation with a,b replaced by X; returns worst min corner angle.
    ok = true; worst_ang = inf;
    for ii = 1:numel(tids)
        ti = tids(ii);
        if ti == t_shared; continue; end
        t = tri(ti, :);
        p = node(t, :);
        for jj = 1:3
            if t(jj) == a || t(jj) == b
                p(jj, :) = X;
            end
        end
        cr = (p(2,1)-p(1,1)) * (p(3,2)-p(1,2)) - (p(2,2)-p(1,2)) * (p(3,1)-p(1,1));
        if cr <= 0; ok = false; return; end
        ang = tri_min_angle_pts_v32(p);
        worst_ang = min(worst_ang, ang);
    end
end

% =====================================================================
function ma = tri_min_angle_pts_v32(p)
%TRI_MIN_ANGLE_PTS_V32  Minimum interior angle (degrees) of 3 points.
    v1 = p(2,:) - p(1,:); v2 = p(3,:) - p(1,:); v3 = p(3,:) - p(2,:);
    a1 = angle_between_v32(v1, v2);
    a2 = angle_between_v32(-v1, v3);
    a3 = 180 - a1 - a2;
    ma = min([a1, a2, max(a3, 0)]);
end

function ang = angle_between_v32(v1, v2)
    n1 = norm(v1); n2 = norm(v2);
    if n1 < 1e-300 || n2 < 1e-300; ang = 0; return; end
    c = max(-1, min(1, (v1(1)*v2(1) + v1(2)*v2(2)) / (n1 * n2)));
    ang = acosd(c);
end

% =====================================================================
function edges = build_edge_list_v32(tri)
%BUILD_EDGE_LIST_V32  All unique mesh edges (Mx2, sorted vertex ids).
    e = [tri(:, [2 3]); tri(:, [3 1]); tri(:, [1 2])];
    e = sort(e, 2);
    edges = unique(e, 'rows');
end

% =====================================================================
function grid = build_edge_grid_v32(node, edges)
%BUILD_EDGE_GRID_V32  Uniform grid over edge midpoints for proximity query.
%   Buckets store edge IDs sorted by cell; uc (ascending unique cells),
%   starts/counts indexed consistently w.r.t. uc.
    ncell_target = max(1, round(numel(edges) / 4));
    xspan = max(node(:,1)) - min(node(:,1)) + 1e-300;
    yspan = max(node(:,2)) - min(node(:,2)) + 1e-300;
    gx = max(1, round(sqrt(ncell_target * xspan / yspan)));
    gy = max(1, round(ncell_target / gx));
    x0 = min(node(:,1)); y0 = min(node(:,2));

    mid = 0.5 * (node(edges(:,1), :) + node(edges(:,2), :));
    ix = min(gx, max(1, floor((mid(:,1) - x0) / (xspan / gx)) + 1));
    iy = min(gy, max(1, floor((mid(:,2) - y0) / (yspan / gy)) + 1));
    cell_id = (iy - 1) * gx + ix;

    [~, order] = sort(cell_id);
    sorted_cells = cell_id(order);
    [grid.uc, ~, uidx] = unique(sorted_cells);
    grid.counts = accumarray(uidx(:), 1);
    grid.starts = [1; cumsum(grid.counts(1:end-1)) + 1];
    grid.edge_ids = order;
    grid.gx = gx; grid.gy = gy;
    grid.x0 = x0; grid.y0 = y0;
    grid.csx = xspan / gx; grid.csy = yspan / gy;
    grid.edges = edges;
end

% =====================================================================
function ok = seg_clear_v32(node, grid, P, Q, a, b)
%SEG_CLEAR_V32  Segment (P,Q) must not PROPERLY cross any mesh edge in the
%   neighborhood, excluding edges incident to a or b (they are the ones
%   being deformed/removed by the collapse).
    ix1 = max(1, floor((min(P(1), Q(1)) - grid.x0) / grid.csx) + 1 - 1);
    ix2 = min(grid.gx, floor((max(P(1), Q(1)) - grid.x0) / grid.csx) + 1 + 1);
    iy1 = max(1, floor((min(P(2), Q(2)) - grid.y0) / grid.csy) + 1 - 1);
    iy2 = min(grid.gy, floor((max(P(2), Q(2)) - grid.y0) / grid.csy) + 1 + 1);

    for cx = ix1:ix2
        for cy = iy1:iy2
            cid = (cy - 1) * grid.gx + cx;
            idx = find_cell_bucket_v32(grid, cid);
            if idx < 1; continue; end
            for e = grid.starts(idx):(grid.starts(idx) + grid.counts(idx) - 1)
                eid = grid.edge_ids(e);
                ev = grid.edges(eid, :);
                if any(ev == a) || any(ev == b); continue; end
                R = node(ev(1), :); S = node(ev(2), :);
                if segments_properly_cross_v32(P, Q, R, S)
                    ok = false; return;
                end
            end
        end
    end
    ok = true;
end

function idx = find_cell_bucket_v32(grid, cid)
%FIND_CELL_BUCKET_V32  Binary search cid in grid.uc; 0 if absent.
    lo = 1; hi = numel(grid.uc); idx = 0;
    while lo <= hi
        mid = floor((lo + hi) / 2);
        if grid.uc(mid) == cid
            idx = mid; return;
        elseif grid.uc(mid) < cid
            lo = mid + 1;
        else
            hi = mid - 1;
        end
    end
end

% =====================================================================
function ok = segments_properly_cross_v32(P, Q, R, S)
%SEGMENTS_PROPERLY_CROSS_V32  True iff open segments (P,Q),(R,S) cross.
    d1 = orient2d_v32(R, S, P);
    d2 = orient2d_v32(R, S, Q);
    d3 = orient2d_v32(P, Q, R);
    d4 = orient2d_v32(P, Q, S);
    ok = ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ...
         ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
end

function d = orient2d_v32(P, Q, R)
%ORIENT2D_V32  Signed area*2 of triangle PQR (>0 CCW).
    d = (Q(1) - P(1)) * (R(2) - P(2)) - (Q(2) - P(2)) * (R(1) - P(1));
end
