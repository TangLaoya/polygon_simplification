%TEST_TRI2QUAD_V32  Test driver: loads node.txt/tri.txt from the current
%   directory, runs the full V32 pipeline, saves results and prints the
%   acceptance summary.
%
%   Usage (in MATLAB or Octave):
%     test_tri2quad_v32            % blossom 5, quiet
%     test_tri2quad_v32(6, 1)      % blossom 6, debug on

function test_tri2quad_v32(blossom_ver, debug)

    if nargin < 2 || isempty(debug); debug = 0; end
    if nargin < 1 || isempty(blossom_ver); blossom_ver = 5; end

    here = fileparts(mfilename('fullpath'));
    if isempty(here); here = pwd; end
    node = load(fullfile(here, 'node.txt'));
    tri  = load(fullfile(here, 'tri.txt'));

    fprintf('test_tri2quad_v32: %d vtx, %d tri, blossom=%d, debug=%d\n', ...
        size(node,1), size(tri,1), blossom_ver, debug);

    [quadnode, quad, report] = tri2quad_v32(node, tri, blossom_ver, debug);

    fprintf('\n===== ACCEPTANCE SUMMARY =====\n');
    v = report.verify;
    fprintf('1) boundary missing/lost   : %d  %s\n', v.n_missing_boundary, pass_str(v.boundary_preserved));
    fprintf('2) edge intersections      : %d  %s\n', v.n_edge_intersections, pass_str(v.no_intersections));
    fprintf('3) concave/CW quads        : %d/%d  %s\n', v.n_concave_quads, v.n_cw_quads, pass_str(v.no_concave));
    fprintf('3b) collinear corners      : %d  %s\n', v.n_collinear_corners, pass_str(v.n_collinear_corners==0));
    fprintf('3c) reflex-spanning quads  : %d  %s   (both bnd edges of a >180deg corner; convex=%d)\n', v.n_spanning_quads, pass_str(v.n_spanning_quads==0), v.n_spanning_convex);
    fprintf('3d) diag-valence-3 quads   : %d  %s   (interior val3=%d)\n', v.n_doublet_quads, pass_str(v.n_doublet_quads==0), v.n_interior_val3);
    fprintf('3e) triangle-like quads    : %d  %s   (corner >=179 or <=1 deg)\n', v.n_triangle_like, pass_str(v.n_triangle_like==0));
    fprintf('3f) T-junctions            : %d  %s\n', v.n_tjunctions, pass_str(v.n_tjunctions==0));
    fprintf('4) coverage (area err)     : %.3e  %s\n', v.area_rel_error, pass_str(v.coverage_ok));
    fprintf('5) vertex ratio            : %.4f (quads %d)  %s\n', v.vertex_ratio, v.quad_count, pass_str(v.vertex_ratio <= 1.5));
    fprintf('   quality: minAng=%.2f med=%.2f | SJmin=%.3f | #ang<20=%d #ang<30=%d\n', ...
        v.min_angle_min, v.min_angle_median, v.sj_min, v.n_angle_below_20, v.n_angle_below_30);
    fprintf('   max angle = %.2f | quads with a corner >=168: %d (boundary straight-run corners; convex)\n', ...
        v.max_angle_max, v.n_flat168);
    fprintf('   TOTAL PASSED = %d | time = %.2f s\n', v.passed, report.total_time_sec);

    % save results
    fid = fopen(fullfile(here, 'quadnode.txt'), 'w');
    fprintf(fid, '%.17g %.17g\n', quadnode');
    fclose(fid);
    fid = fopen(fullfile(here, 'quad.txt'), 'w');
    fprintf(fid, '%d %d %d %d\n', quad');
    fclose(fid);
    fprintf('Saved quadnode.txt / quad.txt\n');
end

function s = pass_str(tf)
    if tf; s = '[PASS]'; else; s = '[FAIL]'; end
end
