function [quadnode, info] = untangle_v32(quadnode, quad, ref_node, debug)
%UNTANGLE_V32  V32-05 r3: relocate vertices of flat quads (>= 168 deg).
%   A quad with a corner >= FLAT_DEG is "flat" (round-04 issue 2).
%
%   r3 corrects the r1/r2 direction bugs (empirically: moved=176 but
%   flat 176->176, max 179->179):
%     BUG A (interior corner): v was moved TOWARD the opposite corner
%       x, i.e. across the (p,n) diagonal to x's side - convexity
%       broken (rejected) or, for partial steps, h DEcreased and the
%       corner got FLATTER. Correct: v moves to ITS OWN side of
%       line(p,n) (away from x), increasing its height h; the corner
%       angle atan(a/h)+atan(b/h) then decreases.
%     BUG B (frozen corner helper): the movable neighbor moved along
%       -bis (OUT of the corner wedge -> flatter / flip); correct is
%       +bis INTO the wedge, rotating the v->tgt ray toward v->other.
%     BUG C (validation): every incident quad had to satisfy corners
%       in (2,178.5) absolutely, so ANY pre-existing flat incident
%       quad blocked every candidate (fail 423). Correct: per-quad
%       NO-WORSENING bounds w.r.t. the entry state (monotone
%       improvement), absolute caps only for previously-good quads.
%     BUG D: moves counted as "success" without improving the target
%       corner; r3 requires >= 1 deg improvement of the quad's max.
%     BUG E: crossing guard only covered the LAST incident quad's
%       edges; r3 checks all edges at the moved vertex.
%
%   INPUT:  quadnode, quad, ref_node (anchored/frozen set; [] ->
%           only current-boundary vertices frozen), debug flag
%   OUTPUT: moved quadnode + info counters

    if nargin < 4; debug = false; end
    if nargin < 3 || isempty(ref_node); ref_node = []; end
    FLAT_DEG  = 168;      % classification threshold
    TARGET_DEG = 152;     % aim for this angle at the fixed corner
    N_SWEEPS  = 6;
    IMPROVE_DEG = 1.0;    % required drop of the quad's max angle

    t0 = tic;
    nv = size(quadnode, 1);
    nq = size(quad, 1);
    info = struct('n_moved', 0, 'n_fail', 0, 'n_skip_frozen', 0, ...
                  'flat_before', 0, 'flat_after', 0, ...
                  'maxang_before', 0, 'maxang_after', 0, ...
                  'n_over1789_before', 0, 'n_over1789_after', 0, ...
                  'sweeps', {{}});

    % ---------- frozen set: reference rows + current boundary ----------
    frozen = false(nv, 1);
    if ~isempty(ref_node)
        frozen = ismember(quadnode, ref_node, 'rows');
    end

    % vertex -> quads incidence
    v2q = cell(nv, 1);
    for qi2 = 1:nq
        for tt2 = 1:4
            v2q{quad(qi2, tt2)}(end+1) = qi2; %#ok<AGROW>
        end
    end

    % current boundary vertices (1-owner edges)
    Eall = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
    K2 = double(nv) + 2;
    key2 = min(Eall(:,1), Eall(:,2)) * K2 + max(Eall(:,1), Eall(:,2));
    [~, ~, ic2] = unique(key2);
    ecnt2 = accumarray(ic2, 1);
    bkey2 = key2(ecnt2(ic2) == 1);
    frozen(floor(bkey2 / K2)) = true;
    frozen(mod(bkey2, K2)) = true;

    % ---------- entry-state per-quad metrics (monotone reference) ----------
    [ang0, area0, mine0, ori0] = quad_metrics_v32(quadnode, quad);
    qmax = max(ang0, [], 2);
    qmin = min(ang0, [], 2);
    pre_max = qmax; pre_min = qmin;

    info.flat_before = sum(qmax >= FLAT_DEG);
    info.maxang_before = max(qmax);
    info.n_over1789_before = sum(qmax >= 178.9);

    % crossing-guard edge grid (bbox bucketed, built once)
    xeg = build_xeg_grid_v32();

    for sw = 1:N_SWEEPS
        n_mv = 0; n_fl = 0; n_sb = 0; deg_gain = 0;
        % worst-first ordering (>= 178.9 corners are verifier-critical)
        [qsrt, ord] = sort(qmax, 'descend');
        fq = ord(qsrt >= FLAT_DEG);
        for kk = 1:numel(fq)
            qi3 = fq(kk);
            if qmax(qi3) < FLAT_DEG; continue; end   % already fixed
            qv3 = quad(qi3, :);
            angrow = ang_row_v32(quadnode, qv3);
            [th_old, t3] = max(angrow);
            if th_old < FLAT_DEG; continue; end
            v3 = qv3(t3);
            p3 = qv3(mod(t3+2,4)+1);   % prev neighbor of v in ring
            n3 = qv3(mod(t3,4)+1);     % next neighbor of v in ring
            x3 = qv3(mod(t3+1,4)+1);   % opposite corner
            if ~frozen(v3)
                % interior/movable flat corner: move v onto its own
                % side of line(p,n), away from x
                if try_move_flat_v32(v3, p3, n3, x3, qi3, th_old)
                    n_mv = n_mv + 1; info.n_moved = info.n_moved + 1;
                    deg_gain = deg_gain + (th_old - qmax(qi3));
                    continue;
                end
                n_fl = n_fl + 1; info.n_fail = info.n_fail + 1;
            else
                % frozen flat corner: rotate the movable neighbor ray
                % INTO the wedge (v->tgt toward v->other)
                done_h = false;
                for tgt3 = [n3, p3]
                    if frozen(tgt3); continue; end
                    if try_open_frozen_v32(v3, p3 + n3 - tgt3, tgt3, qi3, th_old)
                        n_mv = n_mv + 1; info.n_moved = info.n_moved + 1;
                        deg_gain = deg_gain + (th_old - qmax(qi3));
                        done_h = true; break;
                    end
                end
                if ~done_h
                    n_sb = n_sb + 1; info.n_skip_frozen = info.n_skip_frozen + 1;
                end
            end
        end
        info.sweeps{end+1} = struct('sweep', sw, 'flat', numel(fq), ...
            'moved', n_mv, 'fail', n_fl, 'skip_frozen', n_sb, ...
            'left', sum(qmax >= FLAT_DEG), 'deg_gain', deg_gain); %#ok<AGROW>
        if debug
            fprintf('  [untangle s%d] flat=%d moved=%d (fail %d froz-skip %d) left=%d gain=%.0fdeg | max=%.1f\n', ...
                sw, numel(fq), n_mv, n_fl, n_sb, sum(qmax >= FLAT_DEG), ...
                deg_gain, max(qmax));
        end
        if n_mv == 0; break; end
    end

    info.flat_after = sum(qmax >= FLAT_DEG);
    info.maxang_after = max(qmax);
    info.n_over1789_after = sum(qmax >= 178.9);
    info.time_sec = toc(t0);
    if debug
        fprintf('  [untangle] done: moved=%d flat %d->%d (>=178.9: %d->%d) max %.1f->%.1f | %.1fs\n', ...
            info.n_moved, info.flat_before, info.flat_after, ...
            info.n_over1789_before, info.n_over1789_after, ...
            info.maxang_before, info.maxang_after, info.time_sec);
    end

    % ==================== nested helpers ====================
    % NOTE: all helper locals use *_ prefixes; parent loop vars
    % (qi3, qv3, v3, p3, n3, x3, kk, sw...) must never be assigned
    % inside a nested function.

    function [ang_r, ar_r, me_r, or_r] = quad_metrics_v32(P, Q)
        %QUAD_METRICS_V32  Vectorized per-quad corner angles, area,
        % min edge, orientation sign.
        pa = P(Q(:,1),:); pb = P(Q(:,2),:); pc = P(Q(:,3),:); pd = P(Q(:,4),:);
        e1 = pb - pa; e2 = pc - pb; e3 = pd - pc; e4 = pa - pd;
        % corner t: angle between (prev - v) and (next - v)
        d_1 = -e4; d_2 =  e1;   % corner 1: (pa-pd),(pb-pa) -> use (v->prev),(v->next)
        ang_r = ang_pair_v32(d_1, d_2);
        ang_r = [ang_r, ang_pair_v32(-e1, e2)];
        ang_r = [ang_r, ang_pair_v32(-e2, e3)];
        ang_r = [ang_r, ang_pair_v32(-e3, e4)];
        ar_r = 0.5 * (e1(:,1).*e2(:,2) - e1(:,2).*e2(:,1) + ...
                      e3(:,1).*e4(:,2) - e3(:,2).*e4(:,1));
        ar_r = abs(ar_r);
        or_r = sign(0.5 * (e1(:,1).*e2(:,2) - e1(:,2).*e2(:,1) + ...
                           e3(:,1).*e4(:,2) - e3(:,2).*e4(:,1)));
        me_r = min([sqrt(sum(e1.^2,2)), sqrt(sum(e2.^2,2)), ...
                    sqrt(sum(e3.^2,2)), sqrt(sum(e4.^2,2))], [], 2);
    end

    function a_out = ang_pair_v32(da_, db_)
        na_ = sqrt(sum(da_.^2, 2)); nb_ = sqrt(sum(db_.^2, 2));
        cs_ = sum(da_.*db_, 2) ./ max(na_.*nb_, 1e-300);
        a_out = acosd(max(-1, min(1, cs_)));
        a_out(na_ < 1e-300 | nb_ < 1e-300) = 360;
    end

    function ang_r = ang_row_v32(P, qrow)
        % corner t angle: between (prev - v) and (next - v)
        pa_ = P(qrow(1),:); pb_ = P(qrow(2),:); pc_ = P(qrow(3),:); pd_ = P(qrow(4),:);
        ang_r = [ang_pair_v32(pd_-pa_, pb_-pa_), ang_pair_v32(pa_-pb_, pc_-pb_), ...
                 ang_pair_v32(pb_-pc_, pd_-pc_), ang_pair_v32(pc_-pd_, pa_-pd_)];
    end

    function ok_r = try_move_flat_v32(v4, p4, n4, x4, qi4, th4)
        %TRY_MOVE_FLAT_V32  Move interior flat corner v4 to its OWN side
        %   of line(p4,n4) (away from x4) until the corner is ~TARGET.
        ok_r = false;
        Pv_ = quadnode(v4,:); Pp_ = quadnode(p4,:); Pn_ = quadnode(n4,:);
        Px_ = quadnode(x4,:);
        pn_ = Pn_ - Pp_;
        npn_ = norm(pn_);
        if npn_ < 1e-300; return; end
        % projection of v onto the line and along-line distances
        tproj_ = max(0, min(1, ((Pv_-Pp_)*pn_') / (npn_*npn_)));
        Pproj_ = Pp_ + tproj_ * pn_;
        da_ = norm(Pproj_ - Pp_); db_ = norm(Pn_ - Pproj_);
        u_ = [pn_(2), -pn_(1)] / npn_;
        vs_ = (Pv_ - Pproj_) * u_';
        if vs_ < 0
            u_ = -u_; vs_ = -vs_;
        elseif vs_ == 0
            % v exactly on the line: move to the side away from x
            if (Px_ - Pproj_) * u_' > 0; u_ = -u_; end
        end
        h_cur_ = abs(vs_);
        h_tgt_ = solve_height_v32(da_, db_, h_cur_);
        step_ = h_tgt_ - h_cur_;
        if step_ <= 1e-15; return; end
        cap_ = 0.45 * min_edge_around_v32(v4);
        step_ = min(step_, cap_);
        if step_ <= 1e-15; return; end
        for fr_ = [1.0, 0.55, 0.3, 0.15, 0.07]
            cand_ = Pv_ + fr_ * step_ * u_;
            if vertex_pos_ok_v32(v4, cand_) && improves_quad_v32(qi4, cand_, v4, th4)
                quadnode(v4,:) = cand_;
                refresh_incident_v32(v4);
                ok_r = true; return;
            end
        end
    end

    function h_s = solve_height_v32(a5, b5, h_lo5)
        %SOLVE_HEIGHT_V32  Height h over line(p,n) giving corner angle
        %   TARGET_DEG (bisection; angle is monotone decreasing in h).
        %   v at height h, projection splits (a5,b5): angle between
        %   (p-v) and (n-v): cos = (h^2 - a5*b5)/sqrt((a5^2+h^2)(b5^2+h^2))
        h_s = h_lo5;
        lo5 = h_lo5;
        hi5 = max(0.25 * (a5 + b5), h_lo5 * 1.5);
        for it5 = 1:40
            if ang_h_v32(a5, b5, hi5) <= TARGET_DEG; break; end
            hi5 = hi5 * 2;
            if hi5 > 1e3 * (a5 + b5 + 1); break; end
        end
        if ang_h_v32(a5, b5, hi5) > TARGET_DEG
            h_s = hi5; return;   % unreachable - take the extreme
        end
        for it5 = 1:48
            mid5 = 0.5 * (lo5 + hi5);
            if ang_h_v32(a5, b5, mid5) > TARGET_DEG
                lo5 = mid5;
            else
                hi5 = mid5;
            end
        end
        h_s = 0.5 * (lo5 + hi5);
    end

    function a_h = ang_h_v32(a6, b6, h6)
        cs6 = (h6*h6 - a6*b6) / sqrt((a6*a6 + h6*h6) * (b6*b6 + h6*h6));
        a_h = acosd(max(-1, min(1, cs6)));
    end

    function ok_o = try_open_frozen_v32(v7, other7, tgt7, qi7, th7)
        %TRY_OPEN_FROZEN_V32  Frozen flat corner at v7: move the movable
        %   neighbor tgt7 INTO the corner wedge (+bisector), rotating
        %   the ray v7->tgt7 toward v7->other7 and opening the angle.
        ok_o = false;
        Pv7 = quadnode(v7,:); Pt7 = quadnode(tgt7,:); Po7 = quadnode(other7,:);
        d1_ = Po7 - Pv7; d2_ = Pt7 - Pv7;
        nd1_ = norm(d1_); nd2_ = norm(d2_);
        if nd1_ < 1e-300 || nd2_ < 1e-300; return; end
        bis_ = d1_/nd1_ + d2_/nd2_;
        nb_ = norm(bis_);
        if nb_ < 1e-9
            % nearly antipodal rays: bisector ill-defined; use the
            % perpendicular of (other->tgt) pointing toward the quad
            % interior (the opposite corner x side is unavailable
            % here; fall back to any consistent in-wedge normal)
            ln_ = d2_ - d1_;
            if norm(ln_) < 1e-300; return; end
            bis_ = [-ln_(2), ln_(1)]; nb_ = norm(bis_);
            if nb_ < 1e-300; return; end
        end
        bis_ = bis_ / nb_;
        % rotation needed to reach TARGET_DEG from th7
        phi_ = deg2rad(max(min(th7 - TARGET_DEG, 25), 3));
        sin_half_ = max(sin(deg2rad(th7/2)), 0.35);
        delta_ = nd2_ * phi_ / sin_half_;
        cap7 = 0.35 * min_edge_around_v32(tgt7);
        delta_ = min(delta_, cap7);
        if delta_ <= 1e-15; return; end
        for fr_ = [1.0, 0.55, 0.3, 0.15, 0.07]
            cand_ = Pt7 + fr_ * delta_ * bis_;
            if vertex_pos_ok_v32(tgt7, cand_) && improves_quad_v32(qi7, cand_, tgt7, th7)
                quadnode(tgt7,:) = cand_;
                refresh_incident_v32(tgt7);
                ok_o = true; return;
            end
        end
    end

    function m_e = min_edge_around_v32(v8)
        m_e = inf;
        qs8 = v2q{v8};
        for k8 = 1:numel(qs8)
            qrow8 = quad(qs8(k8), :);
            m_e = min(m_e, norm(quadnode(qrow8(1),:) - quadnode(qrow8(2),:)));
            m_e = min(m_e, norm(quadnode(qrow8(2),:) - quadnode(qrow8(3),:)));
            m_e = min(m_e, norm(quadnode(qrow8(3),:) - quadnode(qrow8(4),:)));
            m_e = min(m_e, norm(quadnode(qrow8(4),:) - quadnode(qrow8(1),:)));
        end
    end

    function ok_v = improves_quad_v32(qi9, cand9, vm9, th9)
        %IMPROVES_QUAD_V32  With vm9 at cand9, quad qi9's max corner
        %   angle must drop by >= IMPROVE_DEG below th9.
        ok_v = false;
        qrow9 = quad(qi9, :);
        Psave9 = quadnode(vm9, :);
        quadnode(vm9, :) = cand9;      % temporary (restored below)
        angr9 = ang_row_v32(quadnode, qrow9);
        quadnode(vm9, :) = Psave9;
        if max(angr9) <= th9 - IMPROVE_DEG
            ok_v = true;
        end
    end

    function refresh_incident_v32(vr)
        %REFRESH_INCIDENT_V32  Recompute qmax/qmin rows of every quad
        %   incident to (just moved) vertex vr.
        qs_r = v2q{vr};
        for kr = 1:numel(qs_r)
            angr_r = ang_row_v32(quadnode, quad(qs_r(kr), :));
            qmax(qs_r(kr)) = max(angr_r);
            qmin(qs_r(kr)) = min(angr_r);
        end
    end

    function ok_p = vertex_pos_ok_v32(v10, cand10)
        %VERTEX_POS_OK_V32  Candidate position for vertex v10:
        %   every incident quad stays convex with its orientation,
        %   within per-quad NO-WORSENING bounds (monotone w.r.t. the
        %   entry state), sane area/edge ratios, and the edges at
        %   v10 (at cand10) cross no nearby mesh edge.
        ok_p = false;
        qs10 = v2q{v10};
        if isempty(qs10); return; end
        for k10 = 1:numel(qs10)
            qrow10 = quad(qs10(k10), :);
            pts10 = quadnode(qrow10, :);
            hit10 = (qrow10 == v10);
            pts10(hit10, :) = repmat(cand10, sum(hit10), 1);
            % orientation + strict convexity (all corner cross > 0)
            sa10 = 0;
            for c10 = 1:4
                sa10 = sa10 + pts10(c10,1)*pts10(mod(c10,4)+1,2) ...
                              - pts10(mod(c10,4)+1,1)*pts10(c10,2);
            end
            if abs(sa10) < 1e-300; return; end
            if sign(sa10) ~= ori0(qs10(k10)); return; end
            for c10 = 1:4
                crn10 = (pts10(c10,1)-pts10(mod(c10+2,4)+1,1)) * ...
                        (pts10(mod(c10,4)+1,2)-pts10(c10,2)) - ...
                        (pts10(c10,2)-pts10(mod(c10+2,4)+1,2)) * ...
                        (pts10(mod(c10,4)+1,1)-pts10(c10,1));
                if crn10 * ori0(qs10(k10)) <= 0; return; end
            end
            % angles within no-worsening bounds
            angs10 = [ang_pair_v32(pts10(4,:)-pts10(1,:), pts10(2,:)-pts10(1,:)); ...
                      ang_pair_v32(pts10(1,:)-pts10(2,:), pts10(3,:)-pts10(2,:)); ...
                      ang_pair_v32(pts10(2,:)-pts10(3,:), pts10(4,:)-pts10(3,:)); ...
                      ang_pair_v32(pts10(3,:)-pts10(4,:), pts10(1,:)-pts10(4,:))];
            lo_b = min(pre_min(qs10(k10)), 2.0) - 0.5;
            if min(angs10) < max(lo_b, 1.0); return; end
            if pre_max(qs10(k10)) >= FLAT_DEG
                hi_b = min(pre_max(qs10(k10)) + 0.5, 179.8);
            else
                hi_b = min(178.5, pre_max(qs10(k10)) + 4.0);
            end
            if max(angs10) > hi_b; return; end
            % area + min-edge sanity vs the entry state
            anew10 = abs(sa10) / 2;
            if anew10 < 0.45 * area0(qs10(k10)) || anew10 > 2.75 * area0(qs10(k10))
                return;
            end
            el10 = [norm(pts10(2,:)-pts10(1,:)), norm(pts10(3,:)-pts10(2,:)), ...
                    norm(pts10(4,:)-pts10(3,:)), norm(pts10(1,:)-pts10(4,:))];
            if min(el10) < 0.3 * mine0(qs10(k10)) || min(el10) < 1e-10
                return;
            end
        end
        % crossing guard: ALL edges (cand10, far) for every incident
        % quad slot of v10, against nearby grid edges (verifier-style
        % relative epsilon; near-touches are not crossings)
        fars10 = [];
        for k10 = 1:numel(qs10)
            qrow10 = quad(qs10(k10), :);
            for s10 = 1:4
                if qrow10(s10) == v10
                    fars10 = [fars10, qrow10(mod(s10,4)+1), qrow10(mod(s10+2,4)+1)]; %#ok<AGROW>
                end
            end
        end
        fars10 = unique(fars10);
        for f10 = fars10(:)'
            if seg_crosses_grid_v32(cand10, quadnode(f10, :), v10, f10)
                return;
            end
        end
        ok_p = true;
    end

    function hit_g = seg_crosses_grid_v32(xg1, xg2, skip1, skip2)
        %SEG_CROSSES_GRID_V32  TRUE if segment (xg1,xg2) properly
        %   crosses a grid edge sharing neither endpoint.
        hit_g = false;
        cx0g = max(0, floor((min(xg1(1),xg2(1)) - xeg.x0) / xeg.csx));
        cx1g = min(xeg.gx - 1, floor((max(xg1(1),xg2(1)) - xeg.x0) / xeg.csx));
        cy0g = max(0, floor((min(xg1(2),xg2(2)) - xeg.y0) / xeg.csy));
        cy1g = min(xeg.gy - 1, floor((max(xg1(2),xg2(2)) - xeg.y0) / xeg.csy));
        for gxg = cx0g:cx1g
            for gyg = cy0g:cy1g
                glist_g = xeg.bmap{gyg * xeg.gx + gxg + 1};
                for gi_g = 1:numel(glist_g)
                    ng_g = xeg.E(glist_g(gi_g), :);
                    if ng_g(1) == skip1 || ng_g(2) == skip1; continue; end
                    if ng_g(1) == skip2 || ng_g(2) == skip2; continue; end
                    qa_g = quadnode(ng_g(1), :); qb_g = quadnode(ng_g(2), :);
                    lRSg = norm(qb_g - qa_g); lPQg = norm(xg2 - xg1);
                    d1g = (xg1(1)-xg2(1))*(qa_g(2)-xg2(2)) - (xg1(2)-xg2(2))*(qa_g(1)-xg2(1));
                    d2g = (xg1(1)-xg2(1))*(qb_g(2)-xg2(2)) - (xg1(2)-xg2(2))*(qb_g(1)-xg2(1));
                    d3g = (qb_g(1)-qa_g(1))*(xg2(2)-qa_g(2)) - (qb_g(2)-qa_g(2))*(xg2(1)-qa_g(1));
                    d4g = (qb_g(1)-qa_g(1))*(xg1(2)-qa_g(2)) - (qb_g(2)-qa_g(2))*(xg1(1)-qa_g(1));
                    e1g = 1e-9 * lPQg * norm(qa_g - xg2);
                    e2g = 1e-9 * lPQg * norm(qb_g - xg2);
                    e3g = 1e-9 * lRSg * norm(xg2 - qa_g);
                    e4g = 1e-9 * lRSg * norm(xg1 - qa_g);
                    s1g = sign_eps_unt_v32(d1g, e1g); s2g = sign_eps_unt_v32(d2g, e2g);
                    s3g = sign_eps_unt_v32(d3g, e3g); s4g = sign_eps_unt_v32(d4g, e4g);
                    if s1g == 0 || s2g == 0 || s3g == 0 || s4g == 0; continue; end
                    if (s1g ~= s2g) && (s3g ~= s4g)
                        hit_g = true; return;
                    end
                end
            end
        end
    end

    function s11 = sign_eps_unt_v32(d11, e11)
        if d11 > e11; s11 = 1;
        elseif d11 < -e11; s11 = -1;
        else; s11 = 0; end
    end

    function g12 = build_xeg_grid_v32()
        %BUILD_XEG_GRID_V32  Edge grid bucketed by every cell an edge
        %   bbox spans (positions move only locally during untangle).
        g12 = struct();
        g12.E = Eall;
        ne12 = size(g12.E, 1);
        gspan12 = max(max(quadnode(:,1)) - min(quadnode(:,1)), ...
                      max(quadnode(:,2)) - min(quadnode(:,2))) * 1.0001 + 1e-300;
        g12.gx = max(8, round(sqrt(ne12))); g12.gy = g12.gx;
        g12.x0 = min(quadnode(:,1)); g12.y0 = min(quadnode(:,2));
        g12.csx = gspan12 / g12.gx; g12.csy = gspan12 / g12.gy;
        g12.bmap = cell(g12.gx * g12.gy, 1);
        for i12 = 1:ne12
            a12 = quadnode(g12.E(i12,1), :); b12 = quadnode(g12.E(i12,2), :);
            cx0_2 = max(0, floor((min(a12(1),b12(1)) - g12.x0) / g12.csx));
            cx1_2 = min(g12.gx - 1, floor((max(a12(1),b12(1)) - g12.x0) / g12.csx));
            cy0_2 = max(0, floor((min(a12(2),b12(2)) - g12.y0) / g12.csy));
            cy1_2 = min(g12.gy - 1, floor((max(a12(2),b12(2)) - g12.y0) / g12.csy));
            for gx12 = cx0_2:cx1_2
                for gy12 = cy0_2:cy1_2
                    g12.bmap{gy12 * g12.gx + gx12 + 1}(end+1) = i12; %#ok<AGROW>
                end
            end
        end
    end
end
