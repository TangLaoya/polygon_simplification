function dbg_plot_boundary_check_v32(quadnode, quad, ref_node, ref_tri, figname)
%DBG_PLOT_BOUNDARY_CHECK_V32  V32-05 debug figure: final mesh + reference
%   boundary overlay; LOST / MISSING reference boundary edges drawn as
%   red bold lines with endpoint markers (v32-01 style). Green = final
%   mesh boundary. Title reports the missing-edge count.

    [nmiss, miss_edges, nv_q] = check_ref_boundary_v32(quadnode, quad, ref_node, ref_tri);
    ti = sprintf('boundary check %s: %d missing ref edge(s) [RED BOLD] | quad bnd vtx %d', ...
        figname, nmiss, nv_q);
    try
        figure('Name', ti, 'NumberTitle', 'off');
        hold on; axis equal; axis off;
        patch('faces', quad, 'vertices', quadnode, ...
              'facecolor', 'none', 'edgecolor', [0.55 0.55 0.55]);
        % final mesh boundary (green) - vectorized (NaN-separated)
        qb = mesh_boundary_edges_v32(quadnode, quad);
        XX = []; YY = [];
        for k = 1:size(qb, 1)
            XX = [XX, quadnode(qb(k,1),1), quadnode(qb(k,2),1), NaN]; %#ok<AGROW>
            YY = [YY, quadnode(qb(k,1),2), quadnode(qb(k,2),2), NaN]; %#ok<AGROW>
        end
        plot(XX, YY, 'g-', 'LineWidth', 1.2);
        % reference boundary (blue thin) - vectorized
        rb = tri_boundary_edges_v32(ref_tri);
        XX = []; YY = [];
        for k = 1:size(rb, 1)
            XX = [XX, ref_node(rb(k,1),1), ref_node(rb(k,2),1), NaN]; %#ok<AGROW>
            YY = [YY, ref_node(rb(k,1),2), ref_node(rb(k,2),2), NaN]; %#ok<AGROW>
        end
        plot(XX, YY, 'b-', 'LineWidth', 1.0);
        % missing edges (red bold + markers)
        for k = 1:size(miss_edges, 1)
            p = ref_node(miss_edges(k,1), :); q = ref_node(miss_edges(k,2), :);
            plot([p(1), q(1)], [p(2), q(2)], 'r-', 'LineWidth', 3.0);
            plot(p(1), p(2), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
            plot(q(1), q(2), 'rs', 'MarkerSize', 8, 'LineWidth', 2);
        end
        title(ti, 'Interpreter', 'none');
        hold off;
        try
            print(gcf, sprintf('dbg_fig_%s.png', figname), '-dpng', '-r110');
        catch
        end
        drawnow;
    catch
    end
end

% ===================== local helpers =====================
function draw_bad_v32(quadnode, quad, ids, color)
    for k = 1:numel(ids)
        q = quad(ids(k), :);
        pts = quadnode(q([1 2 3 4 1]), :);
        patch(pts(:,1), pts(:,2), color, ...
              'EdgeColor', color * 0.6, 'LineWidth', 0.8);
    end
end

function ma = max_quad_ang_v32(P, qv)
    ma = 0;
    for t = 1:4
        v = P(qv(t),:);
        u = P(qv(mod(t+2,4)+1),:);
        w = P(qv(mod(t,4)+1),:);
        a = u - v; b = w - v;
        na = norm(a); nb = norm(b);
        if na < 1e-300 || nb < 1e-300
            ma = 360; return;
        end
        cs = (a(1)*b(1)+a(2)*b(2)) / (na*nb);
        ma = max(ma, acosd(max(-1, min(1, cs))));
    end
end

function qb = mesh_boundary_edges_v32(quadnode, quad)
    nv = size(quadnode, 1);
    E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
    K = double(nv) + 2;
    key = min(E(:,1), E(:,2)) * K + max(E(:,1), E(:,2));
    [skey, ~, ic] = unique(key);
    ecnt = accumarray(ic, 1);
    bmask = (ecnt == 1);
    bk = skey(bmask);
    qb = [floor(bk / K), mod(bk, K)];
end

function rb = tri_boundary_edges_v32(tri)
    E = [tri(:, [1 2]); tri(:, [2 3]); tri(:, [3 1])];
    nv = max(E(:));
    K = double(nv) + 2;
    key = min(E(:,1), E(:,2)) * K + max(E(:,1), E(:,2));
    [skey, ~, ic] = unique(key);
    ecnt = accumarray(ic, 1);
    bmask = (ecnt == 1);
    bk = skey(bmask);
    rb = [floor(bk / K), mod(bk, K)];
end

function [nmiss, miss_edges, nv_q] = check_ref_boundary_v32(quadnode, quad, ref_node, ref_tri)
    % geometric reference check: every reference boundary edge must be
    % covered by a chain of collinear quad-boundary edges (v32-02 rule)
    nmiss = 0; miss_edges = zeros(0, 2);
    rb = tri_boundary_edges_v32(ref_tri);
    qb = mesh_boundary_edges_v32(quadnode, quad);
    nv_q = 0;
    % boundary adjacency of the quad mesh
    nv = size(quadnode, 1);
    adj = cell(nv, 1);
    for k = 1:size(qb, 1)
        adj{qb(k,1)}(end+1) = qb(k,2); %#ok<AGROW>
        adj{qb(k,2)}(end+1) = qb(k,1); %#ok<AGROW>
        nv_q = nv_q + 0;
    end
    % map reference vertices -> quad vertices by exact coordinates
    [tf_r, iq_r] = ismember(ref_node, quadnode, 'rows');
    for k = 1:size(rb, 1)
        a = 0; b = 0;
        if tf_r(rb(k,1)); a = iq_r(rb(k,1)); end
        if tf_r(rb(k,2)); b = iq_r(rb(k,2)); end
        if a == 0 || b == 0
            nmiss = nmiss + 1;
            miss_edges(end+1, :) = [rb(k,1), rb(k,2)]; %#ok<AGROW>
            continue;
        end
        if ~seg_chain_cover_v32(a, b, quadnode, adj)
            nmiss = nmiss + 1;
            miss_edges(end+1, :) = [rb(k,1), rb(k,2)]; %#ok<AGROW>
        end
    end
    % quad boundary vertex count
    bset = false(nv, 1);
    bset(qb(:)) = true;
    nv_q = sum(bset);
end

function tf = seg_chain_cover_v32(a, b, P, adj)
    %SEG_CHAIN_COVER_V32  True iff b is reachable from a along boundary
    %   edges whose vertices all lie ON segment (a,b) (depth 6).
    tf = seg_chain_rec_v32(a, b, P, adj, 0);
end

function tf = seg_chain_rec_v32(a, b, P, adj, depth)
    tf = false;
    if depth > 6; return; end
    A = P(a, :); B = P(b, :);
    AB = B - A; L2 = AB(1)^2 + AB(2)^2;
    if L2 < 1e-300; return; end
    nbrs = adj{a};
    if isempty(nbrs); return; end
    for k = 1:numel(nbrs)
        m = nbrs(k);
        if m == b; tf = true; return; end
        M = P(m, :);
        tp = ((M(1)-A(1))*AB(1) + (M(2)-A(2))*AB(2)) / L2;
        d = abs((M(1)-A(1))*AB(2) - (M(2)-A(2))*AB(1)) / sqrt(L2);
        if tp > 1e-12 && tp < 1 - 1e-12 && d < 1e-9 * sqrt(L2)
            if seg_chain_rec_v32(m, b, P, adj, depth + 1)
                tf = true; return;
            end
        end
    end
end
