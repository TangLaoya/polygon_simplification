function [quadnode, quad, info] = tdust_fix_v32(quadnode, quad, ref_node, debug)
%TDUST_FIX_V32  V32-05 stage 8.96: surgical repair of the residual
%   dust defects that block the verifier (round-05 final pass).
%
%   A) T-DUST NUDGE: every verifier-exact T-junction on this mesh is a
%      degenerate "pocket": vertex v sits BIT-EXACTLY (dist ~ 1e-19) at
%      the midpoint of a short 1-owner boundary edge (a,b), where a,b
%      are a near-duplicate pair and v is a chain-midpoint left behind
%      by a reverted closure. The quads around the pocket are healthy;
%      the ONLY defect is the 1e-9-relative T predicate. Fix: nudge v
%      PERPENDICULAR to (a,b) by dust = 1e-2*|ab| toward the side of
%      v's far (non a/b) neighbors (validated: convexity, angles,
%      no new T, no new crossings).
%
%   D) DUST-SANDWICH PAIR-MERGE: the residual concave quads are dust
%      slivers (true area 1e-10) shaped as "triangle + a corner vertex
%      nearly on the opposite edge", always carrying a DUST edge
%      (< 0.25*median) shared by TWO CONSECUTIVE edges with a partner
%      sliver (the sandwich around the tip vertex). Fix: merge the pair
%      into the single quad of their outer 4-ring (area-conserving,
%      NO new edges - all 4 outer edges pre-exist), delete the interior
%      dust edges, drop the tip vertex, then OPEN any collinear/flat
%      corner of the merged quad by a small validated perpendicular
%      nudge (direct or via a movable ring neighbor). Reverts cleanly
%      if any validation fails.
%
%   B) CONCAVE NUDGE (fallback): push a reflex corner out along the
%      local perpendicular until its corner cross flips sign with
%      margin (works for near-noise concavities only).
%
%   INPUT : quadnode, quad, ref_node (anchored set), debug
%   OUTPUT: repaired quadnode + quad (dead rows compacted), info

    if nargin < 4; debug = false; end
    if nargin < 3 || isempty(ref_node); ref_node = []; end
    t0 = tic;
    nq = size(quad, 1);
    nv = size(quadnode, 1);
    info = struct('n_t_fixed', 0, 'n_t_fail', 0, 'n_c_fixed', 0, ...
                  'n_c_fail', 0, 'n_merge', 0, 'n_merge_revert', 0, ...
                  'n_collapse', 0, 'n_collapse_revert', 0, ...
                  'n_cross_clear', 0, 'n_cross_fail', 0);

    % ---------- frozen (reference) vertices ----------
    frozen = false(nv, 1);
    if ~isempty(ref_node)
        frozen = ismember(quadnode, ref_node, 'rows');
    end

    % ---------- vertex -> quads ----------
    v2q = build_v2q_v32();

    % ---------- A) T-dust nudges ----------
    tpairs = collect_t_pairs_v32();
    if debug
        fprintf('  [tdust] found %d verifier T-pairs\n', size(tpairs, 1));
    end
    for k = 1:size(tpairs, 1)
        v = tpairs(k, 1); a = tpairs(k, 2); b = tpairs(k, 3);
        if ~do_t_nudge_v32(v, a, b)
            info.n_t_fail = info.n_t_fail + 1;
            if debug
                fprintf('  [tdust] T nudge FAILED at vtx %d (edge %d-%d)\n', v, a, b);
            end
        else
            info.n_t_fixed = info.n_t_fixed + 1;
        end
    end

    % ---------- F) crossing-clearance nudges (first: verifier FAIL) ----------
    for rf = 1:2
        n_f = sweep_f_crossings_v32();
        if debug
            fprintf('  [tdust] crossing round %d: cleared=%d | left=%d\n', rf, n_f, size(locate_crossings_v32(), 1));
        end
        if n_f == 0; break; end
    end

    % ---------- rounds: D (merge), E (collapse), B (nudge) ----------
    for rd = 1:3
        n_d = sweep_d_merge_v32(rd == 1);
        n_e = sweep_e_collapse_v32();
        n_b = sweep_b_nudge_v32();
        if debug
            fprintf('  [tdust] round %d: merges=%d collapses=%d concave-nudges=%d | concave now %d\n', ...
                rd, n_d, n_e, n_b, count_concave_v32());
        end
        if n_d == 0 && n_e == 0 && n_b == 0; break; end
    end

    % compact dead quad rows
    alive = any(quad ~= 0, 2);
    if ~all(alive)
        quad = quad(alive, :);
        nq = size(quad, 1);
        v2q = build_v2q_v32(); %#ok<NASGU>
    end

    info.time_sec = toc(t0);
    info.n_concave_left = count_concave_v32();
    if debug
        fprintf('  [tdust] done: T %d (fail %d) merges %d (revert %d) concave-nudge %d left=%d | %.1fs\n', ...
            info.n_t_fixed, info.n_t_fail, info.n_merge, info.n_merge_revert, ...
            info.n_c_fixed, info.n_concave_left, info.time_sec);
    end

    % ==================== nested helpers ====================

    function v2q = build_v2q_v32()
        v2q = cell(nv, 1);
        for qi = 1:nq
            if any(quad(qi, :) == 0); continue; end   % dead row
            for tt = 1:4
                v2q{quad(qi, tt)}(end+1) = qi; %#ok<AGROW>
            end
        end
    end

    function nc = count_concave_v32()
        nc = numel(concave_ids_v32());
    end

    function cq = concave_ids_v32()
        %CONCAVE_IDS_V32  Vectorized ids of quads with mixed corner
        %   cross signs (dead rows excluded).
        alive = any(quad ~= 0, 2);
        ai = find(alive);
        p1 = quadnode(quad(ai,1),:); p2 = quadnode(quad(ai,2),:);
        p3 = quadnode(quad(ai,3),:); p4 = quadnode(quad(ai,4),:);
        e1 = p2 - p1; e2 = p3 - p2; e3 = p4 - p3; e4 = p1 - p4;
        c1 = e4(:,1).*e1(:,2) - e4(:,2).*e1(:,1);   % (p1-p4) x (p2-p1) = e4 x e1
        c2 = e1(:,1).*e2(:,2) - e1(:,2).*e2(:,1);
        c3 = e2(:,1).*e3(:,2) - e2(:,2).*e3(:,1);
        c4 = e3(:,1).*e4(:,2) - e3(:,2).*e4(:,1);
        cr = [c1, c2, c3, c4];
        cq = ai(any(cr < 0, 2) & any(cr > 0, 2));
        cq = cq(:)';
    end

    function tp = collect_t_pairs_v32()
        %COLLECT_T_PAIRS_V32  (v, a, b): v strictly inside edge (a,b),
        %   dist < 1e-9*|ab| (verifier-exact predicate).
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        E = E(any(E ~= 0, 2), :);
        tp = zeros(0, 3);
        for e = 1:size(E, 1)
            a2 = E(e, 1); b2 = E(e, 2);
            A2 = quadnode(a2, :); B2 = quadnode(b2, :);
            AB2 = B2 - A2; L22 = AB2(1)^2 + AB2(2)^2;
            if L22 < 1e-300; continue; end
            xlo = min(A2(1), B2(1)) - 1e-7; xhi = max(A2(1), B2(1)) + 1e-7;
            ylo = min(A2(2), B2(2)) - 1e-7; yhi = max(A2(2), B2(2)) + 1e-7;
            cand = find(quadnode(:,1) >= xlo & quadnode(:,1) <= xhi & ...
                        quadnode(:,2) >= ylo & quadnode(:,2) <= yhi);
            for v2 = cand(:)'
                if v2 == a2 || v2 == b2; continue; end
                AV2 = quadnode(v2, :) - A2;
                tq = (AV2 * AB2') / L22;
                if tq <= 1e-9 || tq >= 1 - 1e-9; continue; end
                d2 = abs(AV2(1)*AB2(2) - AV2(2)*AB2(1)) / sqrt(L22);
                if d2 < 1e-9 * sqrt(L22)
                    tp(end+1, :) = [v2, a2, b2]; %#ok<AGROW>
                end
            end
        end
    end

    function ok = do_t_nudge_v32(v, a, b)
        %DO_T_NUDGE_V32  Perpendicular dust nudge of v off edge (a,b).
        ok = false;
        Pv = quadnode(v, :); Pa = quadnode(a, :); Pb = quadnode(b, :);
        ab = Pb - Pa;
        nab = norm(ab);
        if nab < 1e-300; return; end
        u = [ab(2), -ab(1)] / nab;     % unit normal of (a,b)
        fars = far_neighbors_v32(v, a, b);
        side = 0;
        for w = fars(:)'
            s = (quadnode(w, :) - 0.5*(Pa+Pb)) * u';
            if abs(s) > abs(side); side = s; end
        end
        if side == 0; side = 1; end
        u = u * sign(side);
        delta = 1e-2 * nab;             % dust nudge (1e6x the threshold)
        for fr = [1.0, 0.5, 0.25, 0.125]
            cand = Pv + fr * delta * u;
            if pos_ok_v32(v, cand)
                quadnode(v, :) = cand;
                ok = true; return;
            end
        end
    end

    function nf = sweep_f_crossings_v32()
        %SWEEP_F_CROSSINGS_V32  Clear proper edge crossings by a small
        %   perpendicular nudge of a movable endpoint: v (endpoint of
        %   one crossing edge) moves to the far endpoint's side of the
        %   OTHER edge's line, clearing the straddle. Validated with a
        %   NO-WORSENING bundle (pre-bad quads may stay bad, not worse).
        nf = 0;
        pairs = locate_crossings_v32();
        for p = 1:size(pairs, 1)
            e1a = pairs(p,1); e1b = pairs(p,2);
            e2a = pairs(p,3); e2b = pairs(p,4);
            if try_clear_crossing_v32(e1a, e1b, e2a, e2b) || ...
               try_clear_crossing_v32(e2a, e2b, e1a, e1b)
                nf = nf + 1;
                info.n_cross_clear = info.n_cross_clear + 1;
            else
                info.n_cross_fail = info.n_cross_fail + 1;
                if debug
                    fprintf('  [tdust] crossing UNRESOLVED: %d-%d X %d-%d\n', e1a, e1b, e2a, e2b);
                end
            end
        end
    end

    function ok = try_clear_crossing_v32(ea, eb, oa, ob)
        %TRY_CLEAR_CROSSING_V32  Move a movable endpoint of edge (ea,eb)
        %   across the line of (oa,ob) to its far partner's side.
        ok = false;
        % recheck the pair still crosses (earlier fixes may have
        % changed things)
        if ~pair_crosses_v32(ea, eb, oa, ob); ok = true; return; end
        od = quadnode(ob,:) - quadnode(oa,:);
        nod = norm(od);
        if nod < 1e-300; return; end
        uper = [-od(2), od(1)] / nod;   % left-perp of the other edge
        for vsel = [ea, eb]
            if frozen(vsel); continue; end
            % v's far partner on its own edge
            farp = eb; if vsel == eb; farp = ea; end
            dv = (quadnode(vsel,:) - quadnode(oa,:)) * uper';
            df = (quadnode(farp,:) - quadnode(oa,:)) * uper';
            if abs(df) < 1e-300; continue; end
            % v must currently be on the OPPOSITE side of far (straddle)
            if dv * df >= 0; continue; end
            % displacement to land at 15% of far's distance on far's side
            delta = abs(dv) + max(0.15 * abs(df), 1e-4 * median_edge_len_v32());
            delta = min(delta, 0.5 * median_edge_len_v32());   % sane local scale (min_edge is dust here)
            if delta <= 1e-15; continue; end
            for fr = [1.0, 0.6, 0.35]
                cand = quadnode(vsel,:) + fr * delta * uper * sign(df);
                if pair_crosses_with_cand_v32(ea, eb, oa, ob, vsel, cand)
                    continue;   % still crossing
                end
                if pos_ok_relaxed_v32(vsel, cand)
                    quadnode(vsel,:) = cand;
                    ok = true; return;
                end
            end
        end
    end

    function hit = pair_crosses_v32(ea, eb, oa, ob)
        hit = seg_pair_crosses_v32(quadnode(ea,:), quadnode(eb,:), ...
                                   quadnode(oa,:), quadnode(ob,:));
    end

    function hit = pair_crosses_with_cand_v32(ea, eb, oa, ob, v, cand)
        A = quadnode(ea,:); B = quadnode(eb,:);
        C = quadnode(oa,:); D = quadnode(ob,:);
        if v == ea; A = cand; elseif v == eb; B = cand; end
        if v == oa; C = cand; elseif v == ob; D = cand; end
        hit = seg_pair_crosses_v32(A, B, C, D);
    end

    function hit = seg_pair_crosses_v32(A, B, C, D)
        %SEG_PAIR_CROSSES_V32  Verifier-parity proper crossing test.
        hit = false;
        d1 = (A(1)-B(1))*(C(2)-B(2)) - (A(2)-B(2))*(C(1)-B(1));
        d2 = (A(1)-B(1))*(D(2)-B(2)) - (A(2)-B(2))*(D(1)-B(1));
        d3 = (D(1)-C(1))*(B(2)-C(2)) - (D(2)-C(2))*(B(1)-C(1));
        d4 = (D(1)-C(1))*(A(2)-C(2)) - (D(2)-C(2))*(A(1)-C(1));
        lPQ = norm(B-A); lRS = norm(D-C);
        e1 = 1e-9*lPQ*norm(C-B); e2 = 1e-9*lPQ*norm(D-B);
        e3 = 1e-9*lRS*norm(B-C); e4 = 1e-9*lRS*norm(A-C);
        s1 = sign_e(d1, e1); s2 = sign_e(d2, e2);
        s3 = sign_e(d3, e3); s4 = sign_e(d4, e4);
        if s1 == 0 || s2 == 0 || s3 == 0 || s4 == 0; return; end
        if s1 ~= s2 && s3 ~= s4
            hit = true;
        end
    end

    function pairs = locate_crossings_v32()
        %LOCATE_CROSSINGS_V32  Unique proper-crossing edge pairs
        %   (verifier-parity) via the midpoint grid.
        pairs = zeros(0, 4);
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        E = E(any(E ~= 0, 2), :);
        K = double(size(quadnode,1)) + 2;
        key = min(E(:,1), E(:,2)) * K + max(E(:,1), E(:,2));
        [ukey, iu] = unique(key);
        ue = E(iu, :);
        ne = size(ue, 1);
        P = quadnode;
        span = max(max(P(:,1))-min(P(:,1)), max(P(:,2))-min(P(:,2))) * 1.0001 + 1e-300;
        gx = max(8, round(sqrt(ne))); gy = gx;
        x0 = min(P(:,1)); y0 = min(P(:,2));
        csx = span/gx; csy = span/gy;
        mx = 0.5*(P(ue(:,1),1)+P(ue(:,2),1)); my = 0.5*(P(ue(:,1),2)+P(ue(:,2),2));
        ix = min(gx, max(1, floor((mx-x0)/csx)+1)); iy = min(gy, max(1, floor((my-y0)/csy)+1));
        cid = (iy-1)*gx+ix;
        [~, order] = sort(cid);
        [~, ~, ic] = unique(cid);
        cnts = accumarray(ic(:), 1);
        starts = [1; cumsum(cnts(1:end-1))+1];
        ueS = ue(order,:);
        cu = unique(cid);
        % V32-07 PERF: O(1) cell -> bucket map (the old find(cu==cidq)
        % was an O(#cells) linear scan per (edge,cell): 67k edges x 9
        % cells x ~500 = 300M comparisons = the 137 s tdust sink)
        cellmap = zeros(gx * gy, 1);
        cellmap(cu) = 1:numel(cu);
        for e = 1:ne
            a = ue(e,1); b = ue(e,2);
            A = P(a,:); B = P(b,:);
            cx = floor(((A(1)+B(1))/2 - x0)/csx)+1;
            cy = floor(((A(2)+B(2))/2 - y0)/csy)+1;
            for dx = -1:1
                ccx = cx+dx; if ccx < 1 || ccx > gx; continue; end
                for dy = -1:1
                    ccy = cy+dy; if ccy < 1 || ccy > gy; continue; end
                    bi = cellmap((ccy-1)*gx+ccx);
                    if bi == 0; continue; end
                    for s2 = starts(bi):starts(bi)+cnts(bi)-1
                        c = ueS(s2,1); d = ueS(s2,2);
                        if a==c || a==d || b==c || b==d; continue; end
                        if e > s2; continue; end   % canonical order
                        if seg_pair_crosses_v32(A, B, P(c,:), P(d,:))
                            pairs(end+1, :) = [a, b, c, d]; %#ok<AGROW>
                        end
                    end
                end
            end
        end
    end

    function ok = pos_ok_relaxed_v32(v, cand)
        %POS_OK_RELAXED_V32  No-worsening validation: incident quads
        %   that were previously bad (concave / extreme angles) may stay
        %   bad but not worse; previously-good quads must stay strictly
        %   valid. T-guard and crossing guard as in pos_ok_v32.
        ok = false;
        qs = v2q{v};
        qs = qs(any(quad(qs,:) ~= 0, 2));
        if isempty(qs); return; end
        for k = 1:numel(qs)
            qrow = quad(qs(k), :);
            pts = quadnode(qrow, :);
            hit = (qrow == v);
            pts(hit, :) = repmat(cand, sum(hit), 1);
            sa = sum(pts(:,1) .* pts([2 3 4 1],2) - pts(:,2) .* pts([2 3 4 1],1));
            if abs(sa) < 1e-300; return; end
            scr = corner_crosses_v32(pts, 1:4);
            sang = corner_angles_v32(pts, 1:4);
            % entry-state reference
            qrow_old = quadnode(qrow, :);
            scr0 = corner_crosses_v32(qrow_old, 1:4);
            sang0 = corner_angles_v32(qrow_old, 1:4);
            sa0 = sum(qrow_old(:,1) .* qrow_old([2 3 4 1],2) - qrow_old(:,2) .* qrow_old([2 3 4 1],1));
            if sign(sa) ~= sign(sa0); return; end
            nbad0 = sum(scr0 * sign(sa0) < 0);
            nbad1 = sum(scr * sign(sa) < 0);
            if nbad1 > nbad0; return; end
            if nbad1 == 0
                % previously-or-now convex: require strict validity
                if any(sang <= 1) || any(sang >= 179); return; end
            else
                % pre-bad: angles may not worsen beyond entry + 1 deg
                if max(sang) > max(sang0) + 1 || min(sang) < min(sang0) - 1
                    return;
                end
            end
        end
        % T + crossing guards (identical to pos_ok_v32)
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        E = E(any(E ~= 0, 2), :);
        Aall = quadnode(E(:,1), :); Ball = quadnode(E(:,2), :);
        AV = cand - Aall;
        ABv = Ball - Aall;
        L2v = ABv(:,1).^2 + ABv(:,2).^2;
        L2v(L2v < 1e-300) = inf;
        tq = (AV(:,1).*ABv(:,1) + AV(:,2).*ABv(:,2)) ./ L2v;
        dv = abs(AV(:,1).*ABv(:,2) - AV(:,2).*ABv(:,1)) ./ sqrt(L2v);
        isfar = E(:,1) ~= v & E(:,2) ~= v;
        hit_t = isfar & tq > 1e-9 & tq < 1 - 1e-9 & dv < 1e-9 * sqrt(L2v);
        if any(hit_t); return; end
        fars = far_neighbors_v32(v, 0, 0);
        for w = fars(:)'
            Pw = quadnode(w, :);
            if seg_crosses_any_v32(cand, Pw, v, w); return; end
        end
        ok = true;
    end

    function nmerged = sweep_d_merge_v32(verb)
        %SWEEP_D_MERGE_V32  Pair-merge the dust-sandwich slivers.
        nmerged = 0;
        med_e = median_edge_len_v32();
        for qi = concave_ids_v32()
            qv = quad(qi, :);
            if any(qv == 0); continue; end
            % find the dust edge slot
            for t = 1:4
                u = qv(t); w = qv(mod(t,4)+1);
                if norm(quadnode(u,:) - quadnode(w,:)) < 0.25 * med_e
                    if try_merge_pair_v32(qi, u, w)
                        nmerged = nmerged + 1;
                        info.n_merge = info.n_merge + 1;
                        if verb
                            fprintf('  [tdust] merged sandwich at quad %d (dust edge %d-%d)\n', qi, u, w);
                        end
                    end
                    break;   % one attempt per quad
                end
            end
        end
    end

    function ok = try_merge_pair_v32(q1, du, dw)
        %TRY_MERGE_PAIR_V32  Merge q1 with the other owner of edge
        %   (du,dw) when they share exactly two consecutive edges; the
        %   merged outer 4-ring replaces both (area conserved, no new
        %   edges); flat/collinear corners are opened by nudges.
        ok = false;
        % find the other owner of (du,dw)
        q2 = 0;
        qs = intersect(v2q{du}, v2q{dw});
        for k = 1:numel(qs)
            if qs(k) == q1; continue; end
            if any(quad(qs(k), :) == du) && any(quad(qs(k), :) == dw)
                q2 = qs(k); break;
            end
        end
        if q2 == 0; return; end
        r1 = quad(q1, :); r2 = quad(q2, :);
        % edge sets (sorted vertex pairs, undirected)
        e1 = sort([r1([1 2]); r1([2 3]); r1([3 4]); r1([4 1])], 2);
        e2 = sort([r2([1 2]); r2([2 3]); r2([3 4]); r2([4 1])], 2);
        sh = intersect(e1, e2, 'rows');
        if size(sh, 1) ~= 2; return; end
        % the two shared edges must share exactly one tip vertex
        tip_common = intersect(sh(1,:), sh(2,:));
        if numel(tip_common) ~= 1; return; end
        % outer edges = union minus shared
        eu = [e1; e2];
        keep = true(size(eu,1), 1);
        for k = 1:size(sh, 1)
            keep = keep & ~(eu(:,1) == sh(k,1) & eu(:,2) == sh(k,2));
        end
        eo = eu(keep, :);
        if size(eo, 1) ~= 4; return; end
        % walk the 4-cycle
        ring = walk_cycle_v32(eo);
        if isempty(ring); return; end
        % orientation: match q1's shoelace sign
        ori1 = sign(shoelace_v32(r1));
        if shoelace_v32(ring) * ori1 < 0
            ring = ring([4 3 2 1]);
        end
        % areas
        a1 = 0.5 * abs(shoelace_v32(r1));
        a2 = 0.5 * abs(shoelace_v32(r2));
        am = 0.5 * abs(shoelace_v32(ring));
        if abs(am - (a1 + a2)) > 1e-6 * (a1 + a2) + 1e-300; return; end
        % apply the merge (temporarily)
        quad(q1, :) = ring;
        quad(q2, :) = [0 0 0 0];
        v2q = build_v2q_v32();
        % open flat / collinear / nonconvex corners of the merged quad
        if ~open_bad_corners_v32(q1, med_edge_cache_v32())
            % revert
            quad(q1, :) = r1;
            quad(q2, :) = r2;
            v2q = build_v2q_v32();
            info.n_merge_revert = info.n_merge_revert + 1;
            if debug
                fprintf('  [tdust] merge REVERTED (validation) at quad %d\n', q1);
            end
            return;
        end
        ok = true;
    end

    function ring = walk_cycle_v32(eo)
        %WALK_CYCLE_V32  Extract the 4-ring from 4 undirected edges.
        ring = [];
        adj = cell(size(quadnode,1), 1); %#ok<NASGU>
        % local adjacency over involved vertices only
        involved = unique(eo(:));
        adjm = containers.Map('KeyType', 'double', 'ValueType', 'any');
        for k = 1:size(eo, 1)
            a2 = eo(k,1); b2 = eo(k,2);
            if ~isKey(adjm, a2); adjm(a2) = []; end
            if ~isKey(adjm, b2); adjm(b2) = []; end
            adjm(a2) = [adjm(a2), b2];
            adjm(b2) = [adjm(b2), a2];
        end
        if numel(involved) ~= 4; return; end
        % each vertex must have exactly 2 neighbors
        for v = involved(:)'
            if numel(unique(adjm(v))) ~= 2; return; end
            if numel(adjm(v)) ~= 2; return; end   % no parallel edges
        end
        % walk
        ring = involved(1);
        prev = 0; cur = involved(1);
        for step = 1:4
            nb = adjm(cur);
            nxt = nb(1);
            if nxt == prev; nxt = nb(2); end
            if nxt == cur; return; end
            ring(end+1, 1) = nxt; %#ok<AGROW>
            prev = cur; cur = nxt;
        end
        closed = (ring(5) == ring(1));
        ring = ring(1:4);
        if ~closed || numel(unique(ring)) ~= 4
            ring = [];
        end
    end

    function ok = open_bad_corners_v32(qi, med_e)
        %OPEN_BAD_CORNERS_V32  Ensure the merged quad has 4 convex
        %   corners with angles in (2, 178.5); flat/collinear/reflex
        %   corners are opened by validated dust nudges.
        ok = true;
        for attempt = 1:4
            qv = quad(qi, :);
            cr = corner_crosses_v32(quadnode, qv);
            ori = sign(sum(cr));
            if ori == 0; ok = false; return; end
            ang = corner_angles_v32(quadnode, qv);
            bad_t = 0; bad_kind = 0;
            for t = 1:4
                if cr(t) * ori <= 0; bad_t = t; bad_kind = 1; break; end
                if ang(t) >= 178.5; bad_t = t; bad_kind = 2; break; end
                if ang(t) <= 2; bad_t = t; bad_kind = 3; break; end
            end
            if bad_t == 0; return; end        % all good
            v = qv(bad_t); p = qv(mod(bad_t+2,4)+1); nn = qv(mod(bad_t,4)+1);
            if ~fix_merged_corner_v32(qi, bad_t, v, p, nn, ori, med_e, bad_kind)
                ok = false; return;
            end
        end
        % final recheck
        qv = quad(qi, :);
        cr = corner_crosses_v32(quadnode, qv);
        ori = sign(sum(cr));
        ang = corner_angles_v32(quadnode, qv);
        if any(cr * ori <= 0) || any(ang >= 179) || any(ang <= 1.5)
            ok = false;
        end
    end

    function ok = fix_merged_corner_v32(qi, tt, v, p, nn, ori, med_e, kind)
        %FIX_MERGED_CORNER_V32  Open a flat/reflex corner of the merged
        %   quad by nudging v (or a movable ring neighbor if v frozen).
        ok = false;
        Pp = quadnode(p, :); Pn = quadnode(nn, :);
        pn = Pn - Pp; npn = norm(pn);
        if npn < 1e-300; return; end
        up = [pn(2), -pn(1)] / npn;
        % try direct (v movable) then neighbors
        cands = {};
        if ~frozen(v)
            cands{end+1} = struct('who', v, 'pvp', quadnode(v,:)); %#ok<AGROW>
        end
        for wsel = [nn, p]
            if wsel == v; continue; end
            if frozen(wsel); continue; end
            cands{end+1} = struct('who', wsel, 'pvp', quadnode(wsel,:)); %#ok<AGROW>
        end
        for cidx = 1:numel(cands)
            who = cands{cidx}.who;
            base = quadnode(who, :);
            for sd = [1, -1]
                u2 = up * sd;
                for fr = [0.05, 0.02, 0.01, 5e-3, 2e-3, 1e-3]
                    delta = fr * med_e;
                    cand = base + delta * u2;
                    % the target corner must improve and the quad stay valid
                    if ~merged_corner_ok_v32(qi, tt, who, cand, ori, kind)
                        continue;
                    end
                    if pos_ok_v32(who, cand)
                        quadnode(who, :) = cand;
                        ok = true; return;
                    end
                end
            end
        end
    end

    function ok = merged_corner_ok_v32(qi, tt, who, cand, ori, kind)
        %MERGED_CORNER_OK_V32  With who at cand, corner tt of quad qi is
        %   convex with angle in (2, 178.5) (kind 2: < 178.5;
        %   kind 1/3: strictly convex).
        ok = false;
        qv = quad(qi, :);
        pts = quadnode(qv, :);
        hit = (qv == who);
        pts(hit, :) = repmat(cand, sum(hit), 1);
        cr = corner_crosses_v32(pts, 1:4);
        if any(cr * ori <= 0); return; end
        ang = corner_angles_v32(pts, 1:4);
        if any(ang >= 178.5) || any(ang <= 2); return; end
        if kind == 2
            % the previously-flat corner must have improved
            if ang(tt) >= 178.5; return; end
        end
        ok = true;
    end

    function ncol = sweep_e_collapse_v32()
        %SWEEP_E_COLLAPSE_V32  Dust-edge collapse for leftover concave
        %   quads whose sandwich-merge did not apply (single shared
        %   edge): weld the dust pair (keep,kill), zero the quads that
        %   contain both (must be dust-area), rewire the rest, validate.
        ncol = 0;
        med_e = median_edge_len_v32();
        med_area = median_quad_area_v32();
        for qi = concave_ids_v32()
            qv = quad(qi, :);
            if any(qv == 0); continue; end
            for t = 1:4
                u = qv(t); w = qv(mod(t,4)+1);
                if norm(quadnode(u,:) - quadnode(w,:)) >= 0.25 * med_e
                    continue;
                end
                if try_dust_collapse_v32(u, w, med_area)
                    ncol = ncol + 1;
                    info.n_collapse = info.n_collapse + 1;
                    if debug
                        fprintf('  [tdust] collapsed dust edge %d-%d (quad %d gone)\n', u, w, qi);
                    end
                end
                break;   % one attempt per quad
            end
        end
    end

    function ok = try_dust_collapse_v32(u, w, med_area)
        %TRY_DUST_COLLAPSE_V32  Weld the near-duplicate pair (u,w):
        %   keep one endpoint, kill the other; quads containing BOTH
        %   must be dust-area and are zeroed; the rest are rewired and
        %   validated (convexity, angles, no new T, no new crossings).
        ok = false;
        % choose keep/kill
        if frozen(u) && ~frozen(w)
            kp = u; kl = w;
        elseif frozen(w) && ~frozen(u)
            kp = w; kl = u;
        elseif ~frozen(u) && ~frozen(w)
            if numel(v2q{u}) >= numel(v2q{w}); kp = u; kl = w; else; kp = w; kl = u; end
        else
            return;   % both frozen
        end
        if numel(v2q{kp}) == 0 || numel(v2q{kl}) == 0; return; end
        % distance sanity (must be dust)
        if norm(quadnode(kp,:) - quadnode(kl,:)) > 0.25 * median_edge_len_v32()
            return;
        end
        deaths = intersect(v2q{kp}, v2q{kl});
        % every death quad must be dust-area
        for d = deaths(:)'
            qd_row = quad(d, :);
            ar = 0.5 * abs(sum(quadnode(qd_row,1) .* quadnode(qd_row([2 3 4 1]),2) - ...
                              quadnode(qd_row,2) .* quadnode(qd_row([2 3 4 1]),1)));
            if ar > 1e-3 * med_area
                if debug
                    fprintf('  [tdust] collapse %d-%d REJECTED: quad %d area %.2e not dust\n', u, w, d, ar);
                end
                return;
            end
        end
        rewires = setdiff(v2q{kl}, deaths);
        % save state
        sv = struct();
        sv.deaths = deaths;
        sv.rewires = rewires;
        sv.rows = quad(rewires, :);
        sv.drows = quad(deaths, :);
        % apply tentatively
        for r = rewires(:)'
            for tt = 1:4
                if quad(r, tt) == kl; quad(r, tt) = kp; end
            end
        end
        for d = deaths(:)'
            quad(d, :) = [0 0 0 0];
        end
        v2q = build_v2q_v32();
        % validate: kill's surviving quads at keep's position
        if ~isempty(rewires) && ~pos_ok_v32(kl, quadnode(kp, :))
            % revert
            quad(rewires, :) = sv.rows;
            quad(deaths, :) = sv.drows;
            v2q = build_v2q_v32();
            info.n_collapse_revert = info.n_collapse_revert + 1;
            if debug
                fprintf('  [tdust] collapse %d-%d REVERTED (validation)\n', u, w);
            end
            return;
        end
        % extra: no remaining death-adjacent degenerate rows (duplicate
        % kp twice in a surviving quad)
        for r = rewires(:)'
            qrow = quad(r, :);
            if numel(unique(qrow)) < 4
                quad(rewires, :) = sv.rows;
                quad(deaths, :) = sv.drows;
                v2q = build_v2q_v32();
                info.n_collapse_revert = info.n_collapse_revert + 1;
                return;
            end
        end
        ok = true;
    end

    function ma = median_quad_area_v32()
        alive = any(quad ~= 0, 2);
        ai = find(alive);
        p1 = quadnode(quad(ai,1),:); p2 = quadnode(quad(ai,2),:);
        p3 = quadnode(quad(ai,3),:); p4 = quadnode(quad(ai,4),:);
        ars = 0.5 * abs(p1(:,1).*p2(:,2) - p1(:,2).*p2(:,1) + p2(:,1).*p3(:,2) - p2(:,2).*p3(:,1) + ...
                        p3(:,1).*p4(:,2) - p3(:,2).*p4(:,1) + p4(:,1).*p1(:,2) - p4(:,2).*p1(:,1));
        ars = ars(ars > 0);
        ma = median(ars);
    end

    function nb = sweep_b_nudge_v32()
        %SWEEP_B_NUDGE_V32  Reflex-corner perpendicular nudge fallback.
        % V32-07: this nudge only works for NEAR-NOISE concavities (the
        % reflex corner is a few degrees past 180). Real concavities
        % (pairing leftovers) made it grind: 365 quads x 3 rounds of
        % doomed candidate moves was 138 s in Octave. Depth prefilter:
        % skip corners whose reflex depth exceeds 20 deg-equivalent.
        nb = 0;
        for qi = concave_ids_v32()
            qv = quad(qi, :);
            if any(qv == 0); continue; end
            cr = corner_crosses_v32(quadnode, qv);
            ori = sign(sum(cr));
            fixed_one = false;
            for tt = 1:4
                if cr(tt) * ori > 0; continue; end
                v = qv(tt);
                if frozen(v); continue; end
                p = qv(mod(tt+2,4)+1); nn = qv(mod(tt,4)+1);
                % V32-07 r3: prefilter REMOVED (its sign logic was
                % inverted - it skipped exactly the near-noise
                % concavities the perpendicular nudge fixes). With the
                % strict extraction net only ~2 near-noise concave
                % quads reach this sweep, so the candidate loop is
                % cheap again.
                if do_c_nudge_v32(qi, tt, v, p, nn, ori)
                    fixed_one = true;
                    break;
                end
            end
            if fixed_one
                nb = nb + 1;
                info.n_c_fixed = info.n_c_fixed + 1;
            else
                cr2 = corner_crosses_v32(quadnode, quad(qi,:));
                if any(cr2 < 0) && any(cr2 > 0)
                    info.n_c_fail = info.n_c_fail + 1;
                    if debug
                        fprintf('  [tdust] concave nudge FAILED at quad %d\n', qi);
                    end
                end
            end
        end
    end

    function ok = do_c_nudge_v32(qi, tt, v, p, nn, ori)
        %DO_C_NUDGE_V32  Push reflex corner v out until its corner cross
        %   has the quad's orientation sign with a sine margin >= 1e-3.
        ok = false;
        Pv = quadnode(v, :); Pp = quadnode(p, :); Pn = quadnode(nn, :);
        pn = Pn - Pp; npn = norm(pn);
        if npn < 1e-300; return; end
        up = [pn(2), -pn(1)] / npn;
        a_al = norm(Pv - Pp); b_al = norm(Pn - Pv);
        h_need = 0.25 * min(a_al, b_al) + 1e-12;
        hv = abs((Pv - Pp) * up');
        if frozen(v); return; end
        step0 = min(h_need + hv, 0.45 * min_edge_around_v32(v));
        if step0 <= 1e-15; return; end
        for sd = [1, -1]
            u2 = up * sd;
            for fr = [1.0, 0.5, 0.25, 0.125]
                cand = Pv + fr * step0 * u2;
                [crn_v, marg_ok] = crn_check_v32(qi, tt, cand);
                if crn_v && marg_ok && pos_ok_v32(v, cand)
                    quadnode(v, :) = cand;
                    ok = true; return;
                end
            end
        end
        % neighbor fallback: move p or nn perpendicular
        for wsel = [nn, p]
            w = wsel;
            if w == v || frozen(w); continue; end
            if w == nn
                base = Pv - Pp;
            else
                base = Pn - Pv;
            end
            nbv = norm(base);
            if nbv < 1e-300; continue; end
            lp = [-base(2), base(1)] / nbv;
            crn_cur = corner_crosses_v32(quadnode, quad(qi, :));
            deficit = abs(crn_cur(tt)) + 2e-3 * nbv * norm(Pv - quadnode(w, :));
            dw = min(max(deficit / nbv, 1e-4 * min_edge_around_v32(w)), ...
                     0.35 * min_edge_around_v32(w));
            if dw <= 1e-15; continue; end
            Pw = quadnode(w, :);
            for sd = [1, -1]
                u2 = lp * sd;
                for fr = [1.0, 0.5, 0.25]
                    cand = Pw + fr * dw * u2;
                    [crn_v, marg_ok] = crn_check_v32(qi, tt, 0, w, cand);
                    if crn_v && marg_ok && pos_ok_v32(w, cand)
                        quadnode(w, :) = cand;
                        ok = true; return;
                    end
                end
            end
        end
    end

    function [ok, marg] = crn_check_v32(qi, tt, cand, w, wcand)
        %CRN_CHECK_V32  Corner tt's cross sign + margin with one vertex
        %   moved (v at cand, or neighbor w at wcand).
        ok = false; marg = false;
        qv = quad(qi, :);
        pts = quadnode(qv, :);
        if nargin > 4 && w ~= 0
            hitw = (qv == w);
            pts(hitw, :) = repmat(wcand, sum(hitw), 1);
        else
            pts(tt, :) = cand;
        end
        crn_v = (pts(tt,1)-pts(mod(tt+2,4)+1,1)) * (pts(mod(tt,4)+1,2)-pts(tt,2)) - ...
                (pts(tt,2)-pts(mod(tt+2,4)+1,2)) * (pts(mod(tt,4)+1,1)-pts(tt,1));
        sa = sum(pts(:,1) .* pts([2 3 4 1],2) - pts(:,2) .* pts([2 3 4 1],1));
        if abs(sa) < 1e-300; return; end
        if crn_v * sign(sa) <= 0; return; end
        ok = true;
        m1 = norm(pts(mod(tt+2,4)+1,:) - pts(tt,:));
        m2 = norm(pts(mod(tt,4)+1,:) - pts(tt,:));
        if abs(crn_v) >= 1e-3 * m1 * m2 + 1e-300
            marg = true;
        end
    end

    function m = med_edge_cache_v32()
        m = median_edge_len_v32();
    end

    function m = median_edge_len_v32()
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        E = E(any(E ~= 0, 2), :);
        L = sqrt(sum((quadnode(E(:,1),:) - quadnode(E(:,2),:)).^2, 2));
        m = median(L);
    end

    function f = far_neighbors_v32(v, a, b)
        f = [];
        qs = v2q{v};
        for k = 1:numel(qs)
            qrow = quad(qs(k), :);
            if any(qrow == 0); continue; end
            for s = 1:4
                if qrow(s) == v
                    f = [f, qrow(mod(s,4)+1), qrow(mod(s+2,4)+1)]; %#ok<AGROW>
                end
            end
        end
        f = unique(f);
        f = f(f ~= a & f ~= b);
    end

    function m = min_edge_around_v32(v)
        m = inf;
        qs = v2q{v};
        for k = 1:numel(qs)
            qrow = quad(qs(k), :);
            if any(qrow == 0); continue; end
            m = min(m, norm(quadnode(qrow(1),:) - quadnode(qrow(2),:)));
            m = min(m, norm(quadnode(qrow(2),:) - quadnode(qrow(3),:)));
            m = min(m, norm(quadnode(qrow(3),:) - quadnode(qrow(4),:)));
            m = min(m, norm(quadnode(qrow(4),:) - quadnode(qrow(1),:)));
        end
    end

    function cr = corner_crosses_v32(P, qv)
        cr = zeros(1, 4);
        for t = 1:4
            v1 = P(qv(t),:); v2 = P(qv(mod(t,4)+1),:); v0 = P(qv(mod(t+2,4)+1),:);
            cr(t) = (v1(1)-v0(1))*(v2(2)-v1(2)) - (v1(2)-v0(2))*(v2(1)-v1(1));
        end
    end

    function ang = corner_angles_v32(P, qv)
        ang = zeros(1, 4);
        for t = 1:4
            d1 = P(qv(mod(t+2,4)+1),:) - P(qv(t),:);
            d2 = P(qv(mod(t,4)+1),:) - P(qv(t),:);
            ang(t) = acosd(max(-1, min(1, (d1*d2')/(norm(d1)*norm(d2)))));
        end
    end

    function s = shoelace_v32(qv)
        Pq = quadnode(qv, :);
        s = sum(Pq(:,1) .* Pq([2 3 4 1],2) - Pq(:,2) .* Pq([2 3 4 1],1));
    end

    function ok = pos_ok_v32(v, cand)
        %POS_OK_V32  Full validation bundle for a dust nudge of v:
        %   1. incident quads: orientation kept, strict convexity,
        %      angles in (1, 179);
        %   2. no NEW T: cand not within the verifier threshold of any
        %      edge it is not an endpoint of (vectorized);
        %   3. no new proper crossings of segments (cand, w) for all
        %      far ring neighbors w (vectorized).
        ok = false;
        qs = v2q{v};
        qs = qs(any(quad(qs,:) ~= 0, 2));
        if isempty(qs); return; end
        % --- 1. incident quads ---
        for k = 1:numel(qs)
            qrow = quad(qs(k), :);
            pts = quadnode(qrow, :);
            hit = (qrow == v);
            pts(hit, :) = repmat(cand, sum(hit), 1);
            sa = sum(pts(:,1) .* pts([2 3 4 1],2) - pts(:,2) .* pts([2 3 4 1],1));
            if abs(sa) < 1e-300; return; end
            scr = corner_crosses_v32(pts, 1:4);
            if any(scr * sign(sa) <= 0); return; end
            sang = corner_angles_v32(pts, 1:4);
            if any(sang <= 1) || any(sang >= 179); return; end
        end
        % --- 2. no new T (cand vs all edges, vectorized) ---
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        E = E(any(E ~= 0, 2), :);
        Aall = quadnode(E(:,1), :); Ball = quadnode(E(:,2), :);
        AV = cand - Aall;
        ABv = Ball - Aall;
        L2v = ABv(:,1).^2 + ABv(:,2).^2;
        L2v(L2v < 1e-300) = inf;
        tq = (AV(:,1).*ABv(:,1) + AV(:,2).*ABv(:,2)) ./ L2v;
        dv = abs(AV(:,1).*ABv(:,2) - AV(:,2).*ABv(:,1)) ./ sqrt(L2v);
        isfar = E(:,1) ~= v & E(:,2) ~= v;
        hit_t = isfar & tq > 1e-9 & tq < 1 - 1e-9 & dv < 1e-9 * sqrt(L2v);
        if any(hit_t); return; end
        % --- 3. no new proper crossings (cand, w) vs all edges ---
        fars = far_neighbors_v32(v, 0, 0);
        for w = fars(:)'
            Pw = quadnode(w, :);
            if seg_crosses_any_v32(cand, Pw, v, w); return; end
        end
        ok = true;
    end

    function hit = seg_crosses_any_v32(xg1, xg2, s1, s2)
        %SEG_CROSSES_ANY_V32  Proper crossing of segment (xg1,xg2) vs
        %   all edges sharing neither endpoint (vectorized, relative
        %   epsilon like the verifier: near-touches are not crossings).
        hit = false;
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        E = E(any(E ~= 0, 2), :);
        keep = E(:,1) ~= s1 & E(:,2) ~= s1 & E(:,1) ~= s2 & E(:,2) ~= s2;
        if ~any(keep); return; end
        E = E(keep, :);
        qa = quadnode(E(:,1), :); qb = quadnode(E(:,2), :);
        d1 = (xg1(1)-xg2(1)) .* (qa(:,2)-xg2(2)) - (xg1(2)-xg2(2)) .* (qa(:,1)-xg2(1));
        d2 = (xg1(1)-xg2(1)) .* (qb(:,2)-xg2(2)) - (xg1(2)-xg2(2)) .* (qb(:,1)-xg2(1));
        d3 = (qb(:,1)-qa(:,1)) .* (xg2(2)-qa(:,2)) - (qb(:,2)-qa(:,2)) .* (xg2(1)-qa(:,1));
        d4 = (qb(:,1)-qa(:,1)) .* (xg1(2)-qa(:,2)) - (qb(:,2)-qa(:,2)) .* (xg1(1)-qa(:,1));
        lPQ = norm(xg2 - xg1);
        lRS = sqrt((qb(:,1)-qa(:,1)).^2 + (qb(:,2)-qa(:,2)).^2);
        nqa_x2 = sqrt((qa(:,1)-xg2(1)).^2 + (qa(:,2)-xg2(2)).^2);
        nqb_x2 = sqrt((qb(:,1)-xg2(1)).^2 + (qb(:,2)-xg2(2)).^2);
        nxg1_qa = sqrt((xg1(1)-qa(:,1)).^2 + (xg1(2)-qa(:,2)).^2);
        e1 = 1e-9 * lPQ * nqa_x2;
        e2 = 1e-9 * lPQ * nqb_x2;
        e3 = 1e-9 * lRS .* nqa_x2;
        e4 = 1e-9 * lRS .* nxg1_qa;
        s1v = sign_e(d1, e1); s2v = sign_e(d2, e2);
        s3v = sign_e(d3, e3); s4v = sign_e(d4, e4);
        hit = any(s1v ~= 0 & s2v ~= 0 & s3v ~= 0 & s4v ~= 0 & ...
                  s1v ~= s2v & s3v ~= s4v);
    end

    function s = sign_e(d, e)
        s = zeros(size(d));
        s(d > e) = 1;
        s(d < -e) = -1;
    end
end
