function [quadnode, quad, info] = topology_cleanup_v32(quadnode, quad, debug, ref_node, opts)
%TOPOLOGY_CLEANUP_V32  Post-repair topology optimization (V32-02).
%
%   W) WELD DEBRIS (V32-05, runs FIRST): near-coincident vertex pairs
%      (numerical dust left by degenerate strip debris) are welded; a
%      quad that collapses to a repeated vertex is deleted. Anchored
%      (reference-boundary) vertices keep their exact position.
%
%   C) T-JUNCTION CLOSURE (runs SECOND: hanging nodes make interior
%      edges look 1-owned and pollute boundary detection): a vertex v
%      lying STRICTLY inside a live quad edge (a,b) it is not an
%      endpoint of is hung on that quad — the owner quad is split into
%      (a,v,m,d) + (v,b,c,m) with m = midpoint of the opposite edge
%      (c,d). The new midpoint m may itself hang on the neighbor
%      across (c,d); the sweep rescans and closes those in turn (each
%      edge is split at most once, so chains always terminate).
%      Children are validated strictly convex with corner angles in
%      (1 deg, 179 deg).
%
%   A) UNSPAN REFLEX CORNERS (user rule: adjacent boundary edges whose
%      angle EXCEEDS 180 deg must never be two sides of ONE quad):
%      every quad that contains BOTH boundary edges of a boundary
%      vertex v whose domain angle > 180.5 deg is re-split together
%      with a neighbor quad into a 2-quad hexagon whose new diagonal
%      emanates from v. After the split, v carries an interior edge
%      (boundary valence 3 = regular) and each child contains exactly
%      ONE of the two boundary edges. (Convex sharp corners MAY span —
%      the standard corner quad; the extraction hard tier already
%      rejects concave quads, so this sweep is a safety net.) The operation keeps every other valence
%      unchanged, so the only guards are: a neighbor quad across the
%      removed edge, 6 distinct hexagon vertices, both children
%      convex with corners in (1 deg, 179 deg) and not spanning
%      another corner.
%
%   B) DOUBLET REMOVAL (classic Blossom-Quad cleanup): a quad whose two
%      opposite (diagonal) vertices are BOTH interior vertices of
%      valence 3 is deleted; the two valence-3 vertices merge into one
%      new valence-4 vertex. Candidate positions for the merged
%      vertex: midpoint of the diagonal, then each original vertex,
%      then the patch centroid — first one keeping all 4 neighbor
%      quads convex wins. Guards: all 4 edges of the quad interior
%      with 4 DISTINCT neighbor quads; the two remaining corner
%      vertices keep valence >= 3 (i.e. have >= 4 before); the third-
%      edge vertices of the two merged corners must differ.
%
%   Sweeps repeat C / A / B until a fixpoint. Unused vertices are
%   compacted.
%
%   INPUT:  quadnode (Nx2), quad (Mx4, 1-indexed), debug flag
%   OUTPUT: cleaned mesh + info counters

    if nargin < 3; debug = false; end
    if nargin < 5; opts = struct(); end
    if nargin < 4; ref_node = []; end
    if ~isfield(opts, 'real_bnd'); opts.real_bnd = []; end
    if ~isfield(opts, 'disable'); opts.disable = ''; end
    % V32-05 weld scale: pairs closer than 1e-9*span are numerically
    % the SAME position regardless of the (possibly dust-polluted)
    % incident-edge median - the old criterion `dsrt > 1e-12` rejected
    % 2e-12-separated debris pairs in the ribbon zones (round-04
    % issues 1/2 residue).
    span_topo = max(max(quadnode(:,1)) - min(quadnode(:,1)), ...
                    max(quadnode(:,2)) - min(quadnode(:,2)));
    WELD_FLOOR = 1e-9 * max(span_topo, 1e-300);
    % V32-05 r2 AREA BUDGET: every collapsed quad deletes its (dust)
    % area from the mesh sum. The coverage tolerance is 1e-6 RELATIVE
    % (total area ~1.1e-4 here -> ~1.1e-10 absolute) and smoothing
    % already consumes over half of it, so the weld may delete at most
    % 20%% of the budget in total.
    qa_all = sum_qarea_topo_v32();
    WELD_AREA_BUDGET = 0.2e-6 * max(qa_all, 1e-300);
    weld_area_used = 0;
    t0 = tic;
    info = struct('n_unspanned', 0, 'n_unspan_failed', 0, ...
                  'n_corner_triple', 0, 'n_tj_nudged', 0, ...
                  'n_cf_dup', 0, 'n_cf_degen', 0, 'n_cf_flat', 0, 'n_cf_span', 0, ...
                  'span_ids_round', {{}}, ...
                  'n_doublets_removed', 0, 'n_doublet_rejected', 0, ...
                  'n_tj_closed', 0, 'n_tj_failed', 0, ...
                  'n_welds', 0, 'n_weld_rejected', 0, ...
                  'n_thin_resplit', 0, 'n_thin_failed', 0, ...
                  'n_rounds', 0, 'n_vtx_before', size(quadnode, 1), ...
                  'n_quad_before', size(quad, 1));
    % anchored = vertices with EXACT reference coordinates (boundary
    % must stay bit-exact; welds never move an anchored vertex)
    if ~isempty(ref_node)
        anchored = ismember(quadnode, ref_node, 'rows');
    else
        anchored = false(size(quadnode, 1), 1);
    end

    tj_clean = false;   % unspan/doublet ops create no hanging nodes
    % V32-07 PERF: persistent per-call blocked lists. Rounds 2..6 used
    % to re-attempt every failing unspan/tj/doublet candidate (round-05
    % data: 6488 unspan + 6221 tj failed ATTEMPTS per call = most of
    % the 90 s call). A quad/vertex whose op failed validation stays
    % blocked for the REMAINING rounds of THIS call (the lists reset
    % between the 7.5 / 8.5 / 8.85 calls, where the mesh and smoothing
    % have actually changed).
    blk_unspan = false(size(quad, 1), 1);
    blk_tjv = false(size(quadnode, 1), 1);
    blk_thin = false(size(quad, 1), 1);
    for round_i = 1:6
        if isempty(strfind(opts.disable, 'W'))
            nw = weld_sweep_v32();
        else
            nw = 0;
        end
        if nw > 0; tj_clean = false; end
        if tj_clean
            nc = 0;
        else
            if isempty(strfind(opts.disable, 'C'))
                nc = tjunction_sweep_v32();
            else
                nc = 0;
            end
            if nc == 0; tj_clean = true; end
        end
        ns = unspan_sweep_v32();
        nd = doublet_sweep_v32();
        nt = thin_resplit_sweep_v32();
        info.n_rounds = round_i;
        if debug
            fprintf('  [topo r%d] welds=%d tj-closed=%d unspanned=%d doublets-removed=%d thin-resplit=%d (quads=%d)\n', ...
                round_i, nw, nc, ns, nd, nt, size(quad, 1));
            stck = rebuild_state_v32();
            info.span_after_round(round_i) = count_spanning_topo_v32(stck);
            fprintf('    [topo r%d] spanning-now=%d\n', round_i, ...
                info.span_after_round(round_i));
        end
        if nw == 0 && nc == 0 && ns == 0 && nd == 0 && nt == 0; break; end
    end

    % ---------- compaction of unused vertices ----------
    used = false(size(quadnode, 1), 1);
    used(quad(:)) = true;
    [keep, ~, newid] = find(used);
    if numel(keep) < size(quadnode, 1)
        vmap = zeros(size(quadnode, 1), 1);
        vmap(keep) = 1:numel(keep);
        quad = vmap(quad);
        quadnode = quadnode(keep, :);
    end

    info.n_vtx_after = size(quadnode, 1);
    info.n_quad_after = size(quad, 1);
    info.time_sec = toc(t0);
    if debug
        fprintf('  [topo] done: welds=%d (rej %d) tj=%d (failed %d) unspanned=%d (failed %d) doublets=%d (rejected %d) thin=%d (failed %d) | vtx %d->%d quads %d->%d | %.2fs\n', ...
            info.n_welds, info.n_weld_rejected, ...
            info.n_tj_closed, info.n_tj_failed, ...
            info.n_unspanned, info.n_unspan_failed, ...
            info.n_doublets_removed, info.n_doublet_rejected, ...
            info.n_thin_resplit, info.n_thin_failed, ...
            info.n_vtx_before, info.n_vtx_after, ...
            info.n_quad_before, info.n_quad_after, info.time_sec);
    end

    function nsp = count_spanning_topo_v32(st)
        %COUNT_SPANNING_TOPO_V32  Current spanning-quad count (debug aid).
        nsp = 0;
        nq = size(quad, 1);
        slot_key = [ ...
            ekey_v32(quad(:,1), quad(:,2), st.K), ...
            ekey_v32(quad(:,2), quad(:,3), st.K), ...
            ekey_v32(quad(:,3), quad(:,4), st.K), ...
            ekey_v32(quad(:,4), quad(:,1), st.K)];
        [tf_mem, gid_mem] = ismember(slot_key(:), st.gkey);
        nown_all = [st.nown; 0];
        nown_slot = reshape(nown_all(gid_mem + 1), nq, 4);
        span_corner = [ ...
            nown_slot(:,4) == 1 & nown_slot(:,1) == 1, ...
            nown_slot(:,1) == 1 & nown_slot(:,2) == 1, ...
            nown_slot(:,2) == 1 & nown_slot(:,3) == 1, ...
            nown_slot(:,3) == 1 & nown_slot(:,4) == 1];
        [qi_rows, ci_cols] = find(span_corner);
        for k = 1:numel(qi_rows)
            qi = qi_rows(k); t = ci_cols(k);
            v = quad(qi, t);
            pv = quad(qi, mod(t+2, 4)+1);
            nx = quad(qi, mod(t, 4)+1);
            ga = gid_of_key_topo_v32(st, ekey_v32(pv, v, st.K));
            gb = gid_of_key_topo_v32(st, ekey_v32(v, nx, st.K));
            if ga == 0 || gb == 0; continue; end
            if st.nown(ga) == 1 && st.nown(gb) == 1
                % V32-07: use the true material angle (through the quad
                % side) and the 120-deg user rule (was acosd/>180.5,
                % which could only ever see straight-run corners)
                ang = domain_angle_v32(quadnode, v, pv, nx, quad(qi, :));
                if ang > 120
                    nsp = nsp + 1;   % spanning corner > 120 deg
                    if debug
                        info.span_ids_round{end+1} = [qi, t, v]; %#ok<AGROW>
                    end
                end
            end
        end
    end

    % ==================== sweep W: weld numerical debris ====================
    function nw = weld_sweep_v32()
        %WELD_SWEEP_V32  V32-05: merge near-coincident vertex pairs
        %   (numerical dust from degenerate strip debris); quads that
        %   collapse to a repeated vertex are deleted (their area is
        %   dust, guarded). Anchored vertices keep position+id.
        nw = 0;
        nv = size(quadnode, 1);
        nq = size(quad, 1);
        if nq == 0 || nv == 0; return; end
        % V32-05 fix: other sweeps in this round may have appended
        % vertices; the anchored mask is only valid for the ids it was
        % built with - fresh vertices are NEVER anchored (they are
        % new midpoints, not reference vertices).
        if numel(anchored) < nv
            anchored(numel(anchored)+1:nv) = false; %#ok<AGROW>
        end
        % grid-hash candidate pairs (cell = 1.5e-6)
        cell = 1.5e-6;
        ix = floor(quadnode(:,1) / cell);
        iy = floor(quadnode(:,2) / cell);
        ckey = iy * 2e9 + ix;
        [sck, ordk] = sort(ckey);
        first = [true; diff(sck) ~= 0];
        gid = cumsum(first);
        gstart = [find(first); numel(sck) + 1];
        ng = numel(gstart) - 1;
        cand = zeros(0, 2);
        for g = 1:ng
            members = ordk(gstart(g):gstart(g+1)-1);
            if numel(members) > 1
                for ii = 1:numel(members)-1
                    for jj = ii+1:numel(members)
                        cand(end+1,:) = [members(ii), members(jj)]; %#ok<AGROW>
                    end
                end
            end
            x0 = ix(members(1)); y0 = iy(members(1));
            offs = [1, 2e9, 2e9+1, 2e9-1];
            for oi = 1:4
                dxk = mod(offs(oi), 2e9); dyk = floor(offs(oi) / 2e9);
                if dyk == 0 && dxk == 0; continue; end
                k2 = (y0 + dyk) * 2e9 + (x0 + dxk);
                lo = 1; hi = numel(sck); gg = 0;
                while lo <= hi
                    mid = floor((lo + hi) / 2);
                    if sck(mid) == k2; gg = mid; break;
                    elseif sck(mid) < k2; lo = mid + 1;
                    else; hi = mid - 1;
                    end
                end
                if gg == 0; continue; end
                g2 = gid(gg);
                mem2 = ordk(gstart(g2):gstart(g2+1)-1);
                for a = members(:)'
                    for b = mem2(:)'
                        cand(end+1,:) = [a, b]; %#ok<AGROW>
                    end
                end
            end
        end
        if isempty(cand); return; end
        d = sqrt(sum((quadnode(cand(:,1),:) - quadnode(cand(:,2),:)).^2, 2));
        cand = cand(d < 1e-6, :); d = d(d < 1e-6);
        if isempty(cand); return; end
        % per-vertex incident edge lengths (bucketed, one pass)
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        elen = sqrt(sum((quadnode(E(:,1),:) - quadnode(E(:,2),:)).^2, 2));
        [sv, ov] = sort([E(:,1); E(:,2)]);
        vf = [true; diff(sv) ~= 0];
        vstart = [find(vf); numel(sv) + 1];
        vedge = [elen; elen]; vedge = vedge(ov);
        uqv = sv(vf);
        vgid_of = zeros(nv, 1);
        vgid_of(uqv) = 1:numel(uqv);
        done_w = false(nv, 1);
        [dsrt, dord] = sort(d);
        for kk = 1:numel(d)
            k = dord(kk);
            u = cand(k, 1); v = cand(k, 2);
            if u == v || done_w(u) || done_w(v); continue; end
            gu = vgid_of(u); gv = vgid_of(v);
            if gu == 0 || gv == 0; continue; end
            le = [vedge(vstart(gu):vstart(gu+1)-1); ...
                  vedge(vstart(gv):vstart(gv+1)-1)];
            med = median(le);
            if dsrt(kk) > 0.1 * med && dsrt(kk) > WELD_FLOOR; continue; end
            % ---- choose welding direction ----
            st = rebuild_state_v32();
            bu = st.isb(u); bv = st.isb(v);
            au = anchored(u); av = anchored(v);
            keepu = true;
            if au && ~av
                keepu = true;
            elseif av && ~au
                keepu = false;
            elseif bu || bv
                % boundary-involved but no anchor: ONLY exact duplicates
                % (V32-05 r2: the old 1e-9 tolerance merged genuinely
                % distinct boundary vertices -> 14 lost boundary edges)
                if dsrt(kk) <= 1e-12
                    keepu = sum(vedge(vstart(gu):vstart(gu+1)-1)) <= ...
                            sum(vedge(vstart(gv):vstart(gv+1)-1));
                else
                    info.n_weld_rejected = info.n_weld_rejected + 1;
                    continue;
                end
            else
                keepu = true;
            end
            if ~keepu
                tmp = u; u = v; v = tmp;
            end
            % ---- apply weld: v -> u ----
            quad_bak = quad;
            pos_bak = quadnode(u,:);
            hit = (quad == v);
            rows_hit = any(hit, 2);
            if ~anchored(u)
                quadnode(u,:) = 0.5 * (quadnode(u,:) + quadnode(v,:));
            end
            quad(hit) = u;
            % rows with < 4 distinct vertices collapse -> delete
            del = false(size(quad,1), 1);
            A_old = 0;
            for r = find(rows_hit)'
                if numel(unique(quad(r,:))) < 4
                    del(r) = true;
                    A_old = A_old + qarea_topo_v32(quad_bak(r,:), quadnode);
                end
            end
            quad_new = quad(~del, :);
            % validate: no self-loop, no edge with >2 owners, area dust only
            E2 = [quad_new(:, [1 2]); quad_new(:, [2 3]); ...
                  quad_new(:, [3 4]); quad_new(:, [4 1])];
            bad_shape = any(E2(:,1) == E2(:,2));
            if ~bad_shape
                key2 = min(E2(:,1), E2(:,2)) * (double(nv)+2) + ...
                       max(E2(:,1), E2(:,2));
                key2s = sort(key2);
                [~, ~, ick] = unique(key2s);
                ecnt = accumarray(ick, 1);
                bad_shape = any(ecnt > 2);
            end
            if bad_shape || A_old > 1e-9 || weld_area_used + A_old > WELD_AREA_BUDGET
                quad = quad_bak;
                quadnode(u,:) = pos_bak;
                info.n_weld_rejected = info.n_weld_rejected + 1;
                continue;
            end
            weld_area_used = weld_area_used + A_old;
            quad = quad_new;
            done_w(u) = true; done_w(v) = true;
            nw = nw + 1;
            info.n_welds = info.n_welds + 1;
        end
    end

    % ==================== sweep T: thin-quad hexagon re-split ====================
    function nt = thin_resplit_sweep_v32()
        %THIN_RESPLIT_SWEEP_V32  V32-05: re-split needle quads (min edge
        %   < THIN_ASPECT * max edge AND a corner >= 168 deg) together
        %   with a neighbor across a LONG edge into 2 better quads
        %   (generic hexagon re-split, best diagonal by min child angle).
        THIN_ASPECT = 0.12; ANG_THR = 168;
        nt = 0;
        nq = size(quad, 1);
        if nq == 0; return; end
        st = rebuild_state_v32();
        touched = false(nq, 1);
        if numel(blk_thin) < nq
            blk_thin(end+1:nq) = false; %#ok<AGROW>
        end
        for qi = 1:nq
            if touched(qi); continue; end
            if blk_thin(qi); continue; end
            qv = quad(qi, :);
            el = edge_lens_row_v32(quadnode, qv);
            if min(el) >= THIN_ASPECT * max(el); continue; end
            ang = quad_angles_row_v32(quadnode, qv);
            if max(ang) < ANG_THR; continue; end
            % candidate shared edges: the two LONGEST edges
            [~, ordl] = sort(el, 'descend');
            applied = false;
            for oi = 1:2
                if applied; break; end
                ei = ordl(oi);
                a = qv(ei); b = qv(mod(ei,4)+1);
                ga = gid_of_key_topo_v32(st, ekey_v32(a, b, st.K));
                if ga == 0 || st.nown(ga) ~= 2; continue; end
                [qj, oknb] = other_owner_v32(st, a, b, qi);
                if ~oknb || qj <= 0; continue; end
                if qj > size(quad, 1) || touched(qj); continue; end
                h = hexagon_of_pair_v32(quad(qi,:), quad(qj,:), a, b);
                if isempty(h) || numel(unique(h)) ~= 6; continue; end
                [r1, r2, ok, sc] = best_hex_split_v32(h);
                if ~ok; continue; end
                A_old = qarea_topo_v32(quad(qi,:), quadnode) + ...
                        qarea_topo_v32(quad(qj,:), quadnode);
                A_new = qarea_topo_v32(r1, quadnode) + ...
                        qarea_topo_v32(r2, quadnode);
                if abs(A_new - A_old) > 1e-12 * max(A_old, 1e-300); continue; end
                % children must beat the parents' worst min-angle
                pa_min = min([quad_angles_row_v32(quadnode, quad(qi,:)), ...
                              quad_angles_row_v32(quadnode, quad(qj,:))]);
                if sc <= pa_min + 0.5; continue; end
                quad(qi,:) = orient_ccw_v32(quadnode, r1);
                quad(qj,:) = orient_ccw_v32(quadnode, r2);
                touched(qi) = true; touched(qj) = true;
                applied = true;
                nt = nt + 1;
                info.n_thin_resplit = info.n_thin_resplit + 1;
            end
            if ~applied
                info.n_thin_failed = info.n_thin_failed + 1;
                if qi <= numel(blk_thin); blk_thin(qi) = true; end
            end
        end
    end

    % ==================== sweep A: unspan corners ====================
    function n_fixed = unspan_sweep_v32()
        n_fixed = 0;
        tj_hang_flag = false;   % corner triple splits hang c/d on neighbors
        st = rebuild_state_v32();
        nq = size(quad, 1);
        % V32-07: REAL-boundary flag per quad edge slot (see the
        % count_spanning note). Fallback: the 1-owner heuristic.
        if ~isempty(opts.real_bnd)
            rbs = false(nq, 4);
            for t = 1:4
                u = quad(:, t); w = quad(:, mod(t, 4) + 1);
                pu = quadnode(u, :); pw = quadnode(w, :);
                sw = (pu(:,1) > pw(:,1)) | ...
                     (pu(:,1) == pw(:,1) & pu(:,2) > pw(:,2));
                pA = pu; pB = pw;
                for r = find(sw(:))'
                    pA(r, :) = pw(r, :); pB(r, :) = pu(r, :);
                end
                rbs(:, t) = ismember([pA, pB], opts.real_bnd, 'rows');
            end
            span_corner = [ ...
                rbs(:,4) & rbs(:,1), ...  % corner 1
                rbs(:,1) & rbs(:,2), ...  % corner 2
                rbs(:,2) & rbs(:,3), ...  % corner 3
                rbs(:,3) & rbs(:,4)];     % corner 4
        else
            slot_key = [ ...
                ekey_v32(quad(:,1), quad(:,2), st.K), ...
                ekey_v32(quad(:,2), quad(:,3), st.K), ...
                ekey_v32(quad(:,3), quad(:,4), st.K), ...
                ekey_v32(quad(:,4), quad(:,1), st.K)];
            [tf_mem, gid_mem] = ismember(slot_key(:), st.gkey);
            nown_all = [st.nown; 0];          % gid 0 (absent) -> owner count 0
            nown_slot = reshape(nown_all(gid_mem + 1), nq, 4);
            tf_mem = tf_mem; %#ok<NASGU>
            span_corner = [ ...
                nown_slot(:,4) == 1 & nown_slot(:,1) == 1, ...
                nown_slot(:,1) == 1 & nown_slot(:,2) == 1, ...
                nown_slot(:,2) == 1 & nown_slot(:,3) == 1, ...
                nown_slot(:,3) == 1 & nown_slot(:,4) == 1];
        end
        [qi_rows, ci_cols] = find(span_corner);
        touched = false(nq, 1);
        if numel(blk_unspan) < nq
            blk_unspan(end+1:nq) = false; %#ok<AGROW>
        end
        for k = 1:numel(qi_rows)
            qi = qi_rows(k); t = ci_cols(k);
            v = quad(qi, t);
            if touched(qi); continue; end
            if blk_unspan(qi); continue; end   % failed earlier this call
            % V32-07 CASCADE GUARD: only ANCHORED (bit-exact reference)
            % vertices are un-spanned. The hanging midpoints / nudged
            % T-closures leave overlapping single-owner edges whose
            % vertices look like boundary corners to the 1-owner
            % boundary test; un-spanning those fake corners cascaded
            % into ~3900 extra triple splits (ratio 1.83). Real
            % boundary corners are reference vertices by construction.
            if v > numel(anchored) || ~anchored(v); continue; end
            % domain angle at v between its 2 boundary edges, measured
            % through the quad side (quad lies on the interior side)
            p = quad(qi, mod(t+2, 4)+1);    % prev boundary neighbor
            n = quad(qi, mod(t, 4)+1);      % next boundary neighbor
            ang = domain_angle_v32(quadnode, v, p, n, quad(qi, :));
            % V32-07 (issue 4, user rule): un-span every quad containing
            % both boundary edges of a boundary vertex whose material
            % angle exceeds 120 deg (was 180.5 = reflex only). Sharp
            % convex corners (< 120) keep the standard corner quad.
            if ang <= 120
                continue;   % sharp convex corner: corner quad allowed
            end
            x = quad(qi, mod(t+1, 4)+1);    % vertex opposite v
            % V32-07 (issue 4, decisive template): CORNER TRIPLE SPLIT
            %   (p,v,n,x) -> (p,v,o,c) + (v,n,d,o) + (o,d,x,c) with
            %   o = midpoint of the diagonal (v,x), c = midpoint of
            %   (x,p), d = midpoint of (n,x). v gains the INTERIOR
            %   edge (v,o) -> each child carries ONE boundary edge of
            %   v. NO neighbor merging (the hexagon/fan re-splits fold
            %   the flanking REFLEX boundary vertices' wedges into one
            %   child corner - topologically unfixable at zigzag
            %   corners). c and d hang on the neighbor edges (x,p)/
            %   (n,x) and are closed by the nudge sweeps.
            applied = try_corner_triple_split_v32(qi, v, p, n, x, st);
            if applied
                n_fixed = n_fixed + 1;
                info.n_unspanned = info.n_unspanned + 1;
                info.n_corner_triple = info.n_corner_triple + 1;
                tj_hang_flag = true;   % c/d need the next tj nudge round
                touched(qi) = true;
            end
            % fallback: try removing edge (n,x) [case A] then edge
            % (x,p) [case B] (the classic 2-quad hexagon re-split)
            cands = {[n, x], [x, p]};
            for ci = 1:2
                if applied; break; end
                rem = cands{ci};
                % neighbor across the removed edge
                [qj, oknb] = other_owner_v32(st, rem(1), rem(2), qi);
                if ~oknb; continue; end
                if touched(qj); continue; end
                % (no valence guard: the unspan split keeps every
                % valence except v's, which grows by 1)
                % build hexagon [v, ..., x-opposite-path ..., p]
                h = hexagon_for_corner_v32(quad(qi,:), v, p, n, x, quad(qj,:), rem);
                if isempty(h); continue; end
                % diagonal from v: h positions 1 and 4
                c1 = [h(1), h(2), h(3), h(4)];
                c2 = [h(4), h(5), h(6), h(1)];
                if ~children_ok_v32(c1, st) || ~children_ok_v32(c2, st)
                    continue;
                end
                % apply with LOCAL AREA GUARD: the two children must
                % cover exactly the same region as the two parents
                A_old = qarea_topo_v32(quad(qi,:), quadnode) + ...
                        qarea_topo_v32(quad(qj,:), quadnode);
                r1 = orient_ccw_v32(quadnode, c1);
                r2 = orient_ccw_v32(quadnode, c2);
                A_new = qarea_topo_v32(r1, quadnode) + ...
                        qarea_topo_v32(r2, quadnode);
                if abs(A_new - A_old) > 1e-12 * max(A_old, 1e-300)
                    continue;   % malformed hexagon: skip
                end
                quad(qi, :) = r1;
                quad(qj, :) = r2;
                touched(qi) = true; touched(qj) = true;
                applied = true;
                n_fixed = n_fixed + 1;
                info.n_unspanned = info.n_unspanned + 1;
            end
            if ~applied
                % fallback: 3-quad patch (corner quad + BOTH neighbors)
                % re-split as a center fan (6- or 8-gon). Handles tip
                % configurations where no 2-quad hexagon is valid.
                if try_unspan_fan_v32(st, qi, v, p, n, x)
                    applied = true;
                    n_fixed = n_fixed + 1;
                    info.n_unspanned = info.n_unspanned + 1;
                    % quad rows were appended: keep guard arrays in sync
                    if numel(touched) < size(quad, 1)
                        touched(end+1:size(quad,1)) = false;
                    end
                end
            end
            if ~applied
                info.n_unspan_failed = info.n_unspan_failed + 1;
                if qi <= numel(blk_unspan); blk_unspan(qi) = true; end
            end
        end
        if tj_hang_flag; tj_clean = false; end   % c/d T's -> next round
    end

    function ok = try_corner_triple_split_v32(qi, v, p, n, x, st)
        %TRY_CORNER_TRIPLE_SPLIT_V32  (p,v,n,x) -> 3 quads with the
        %   interior edge (v,o): (p,v,o,c) + (v,n,d,o) + (o,d,x,c),
        %   o on the diagonal (v,x), c on (x,p), d on (n,x). c and d
        %   hang on the two neighbor quads (closed by the nudge
        %   sweeps). Validations: 3 distinct-vertex convex children
        %   with corners in (1,179), exact area (3 children == the
        %   parent quad), no child spanning, clearance of the new
        %   edges against ORIGINAL mesh vertices.
        ok = false;
        Pv = quadnode(v, :); Pn = quadnode(n, :);
        Pp = quadnode(p, :); Px = quadnode(x, :);
        % guard: (x,p) and (n,x) must be INTERIOR edges (2 owners) -
        % c/d hang on the neighbors; if either is a boundary edge the
        % child at p/n would span a second boundary edge
        gx = gid_of_key_topo_v32(st, ekey_v32(x, p, st.K));
        gn = gid_of_key_topo_v32(st, ekey_v32(n, x, st.K));
        if gx == 0 || gn == 0; return; end
        if st.nown(gx) ~= 2 || st.nown(gn) ~= 2; return; end
        % candidate positions: o at 3 positions along the (v,x)
        % diagonal, c/d at the midpoints of their edges
        for fr_o = [0.5, 0.4, 0.6]
            o_pt = Pv + fr_o * (Px - Pv);
            c_pt = 0.5 * (Px + Pp);
            d_pt = 0.5 * (Pn + Px);
            ch1 = [Pp; Pv; o_pt; c_pt];
            ch2 = [Pv; Pn; d_pt; o_pt];
            ch3 = [o_pt; d_pt; Px; c_pt];
            kids = {ch1, ch2, ch3};
            kid_ids = {[p, v, -1, -2], [v, n, -3, -1], [-1, -3, x, -2]};
            all_ok = true;
            for kk = 1:3
                K4 = kids{kk};
                if numel(unique(K4(:,1))) < 1; all_ok = false; break; end
                % convex + corners in (1,179)
                s = 0;
                for t = 1:4
                    s = s + K4(t,1)*K4(mod(t,4)+1,2) - K4(mod(t,4)+1,1)*K4(t,2);
                end
                if s < 0; K4 = K4([1 4 3 2], :); kids{kk} = K4; end
                for t = 1:4
                    v1 = K4(mod(t,4)+1,:) - K4(t,:);
                    v2 = K4(mod(t+1,4)+1,:) - K4(mod(t,4)+1,:);
                    cr = v1(1)*v2(2) - v1(2)*v2(1);
                    n1 = norm(v1); n2 = norm(v2);
                    if n1 < 1e-300 || n2 < 1e-300; all_ok = false; break; end
                    if cr <= 0 || abs(cr)/(n1*n2) < sin(pi/180)
                        all_ok = false; break;
                    end
                end
                if ~all_ok; break; end
            end
            if ~all_ok; continue; end
            % area conservation: 3 children == parent quad
            A_old = abs(qarea_topo_v32(quad(qi,:), quadnode));
            A_new = 0;
            for kk = 1:3
                K4 = kids{kk};
                s = 0;
                for t = 1:4
                    s = s + K4(t,1)*K4(mod(t,4)+1,2) - K4(mod(t,4)+1,1)*K4(t,2);
                end
                A_new = A_new + 0.5 * abs(s);
            end
            if abs(A_new - A_old) > 1e-12 * max(A_old, 1e-300); continue; end
            % APPLY: append o, c, d; rewrite qi; append 2 rows
            nv0 = size(quadnode, 1);
            quadnode(nv0+1, :) = o_pt;   % o
            quadnode(nv0+2, :) = c_pt;   % c
            quadnode(nv0+3, :) = d_pt;   % d
            oid = nv0 + 1; cid = nv0 + 2; did = nv0 + 3;
            % rows CCW: (p,v,o,c), (v,n,d,o), (o,d,x,c)
            r1 = orient_ccw_topo_v32([p, v, oid, cid]);
            r2 = orient_ccw_topo_v32([v, n, did, oid]);
            r3 = orient_ccw_topo_v32([oid, did, x, cid]);
            quad(qi, :) = r1;
            nq_new = size(quad, 1);
            quad(nq_new+1, :) = r2;
            quad(nq_new+2, :) = r3;
            info.n_quad_after = size(quad, 1); %#ok<NASGU>
            ok = true;
            return;
        end
    end

    function r = orient_ccw_topo_v32(qv)
        s = 0;
        for t = 1:4
            s = s + quadnode(qv(t),1)*quadnode(qv(mod(t,4)+1),2) - ...
                    quadnode(qv(mod(t,4)+1),1)*quadnode(qv(t),2);
        end
        if s < 0; r = qv([1 4 3 2]); else; r = qv; end
    end

    function ok = try_unspan_fan_v32(st, qi, v, p, n, x)
        %TRY_UNSPAN_FAN_V32  Re-split the 3-quad patch around the quad
        %   corner opposite v as a CENTER FAN. Patch = corner quad
        %   (p,v,n,x) + neighbors across BOTH interior edges (n,x) and
        %   (x,p). The patch boundary keeps every mesh boundary edge
        %   (in particular (p,v) and (v,n)); the fan gives v an interior
        %   edge to the new center, so each child spans at most one of
        %   v's boundary edges. Guards: 3 distinct quads, a single
        %   simple boundary cycle of 6 or 8 distinct vertices, all fan
        %   children convex with corners in (1 deg, 179 deg) and not
        %   spanning another corner.
        ok = false;
        [qj1, ok1] = other_owner_v32(st, n, x, qi);
        [qj2, ok2] = other_owner_v32(st, x, p, qi);
        if ~ok1 || ~ok2; return; end
        if qj1 == qi || qj2 == qi || qj1 == qj2; return; end
        % stale-state guard: vertex ids created after st was built would
        % overflow st.K and corrupt the key arithmetic — retry next round
        if max(max(quad([qi, qj1, qj2], :))) >= st.K; return; end
        patch = [qi, qj1, qj2];
        % patch edges with multiplicity WITHIN the patch
        E12 = [quad(qi,[1 2]); quad(qi,[2 3]); quad(qi,[3 4]); quad(qi,[4 1]); ...
               quad(qj1,[1 2]); quad(qj1,[2 3]); quad(qj1,[3 4]); quad(qj1,[4 1]); ...
               quad(qj2,[1 2]); quad(qj2,[2 3]); quad(qj2,[3 4]); quad(qj2,[4 1])];
        key12 = min(E12(:,1), E12(:,2)) * st.K + max(E12(:,1), E12(:,2));
        [~, ord12] = sort(key12);
        ks = key12(ord12);
        first12 = [true; diff(ks) ~= 0];
        gid12 = cumsum(first12);            % column group ids
        cnt12 = accumarray(gid12, 1);
        bkey = ks(first12);
        bcnt = cnt12(:);
        bedge_lo = floor(bkey / st.K);
        bedge_hi = mod(bkey, st.K);
        bm = bcnt == 1;                 % patch-boundary edge instances
        blo = bedge_lo(bm); bhi = bedge_hi(bm);
        % boundary adjacency walk from v
        nb_map = cell(size(quadnode, 1), 1);
        for e = 1:numel(blo)
            u1 = blo(e); u2 = bhi(e);
            nb_map{u1} = [nb_map{u1}, u2];
            nb_map{u2} = [nb_map{u2}, u1];
        end
        loop = v; prev = 0; cur = v;
        for step = 1:10
            nxt = 0;
            for w = nb_map{cur}(:)'
                if w ~= prev && w ~= v
                    nxt = w; break;
                end
            end
            % prefer continuing (v closes only at the very end)
            if nxt == 0
                % only v remains -> close if step >= 5
                closed = any(nb_map{cur} == v);
                if closed && step >= 5
                    loop(step+1) = v;       % implicit closure
                    break;
                end
                return;   % dead end
            end
            loop(step+1) = nxt; %#ok<AGROW>
            prev = cur; cur = nxt;
        end
        L = numel(loop) - 1;            % loop = [v h2 ... hL v]
        if L ~= 6 && L ~= 8; return; end
        if numel(unique(loop)) ~= L; return; end   % pinched patch
        % fan children
        h = loop(1:L);
        o_pt = mean(quadnode(h, :), 1);
        kids = zeros(L/2, 4);
        for c = 1:L/2
            i1 = 2*c - 1;
            kids(c, :) = [h(i1), h(mod(i1, L) + 1), h(mod(i1 + 1, L) + 1), -1];
        end
        for c = 1:L/2
            cv = kids(c, :);
            P4 = [quadnode(cv(1:3), :); o_pt];
            if ~quad4_points_convex_topo_v32(P4); return; end
            if child_spans_v32([cv(1:3), size(quadnode, 1) + 1], st); return; end
        end
        % apply with LOCAL AREA GUARD (children must tile the patch)
        A_old = qarea_topo_v32(quad(qi,:), quadnode) + ...
                qarea_topo_v32(quad(qj1,:), quadnode) + ...
                qarea_topo_v32(quad(qj2,:), quadnode);
        quadnode(end+1, :) = o_pt;
        oid = size(quadnode, 1);
        rows_new = zeros(L/2, 4);
        for c = 1:L/2
            row = kids(c, :);
            row(4) = oid;
            rows_new(c, :) = orient_ccw_v32(quadnode, row);
        end
        A_new = 0;
        for c = 1:L/2
            A_new = A_new + qarea_topo_v32(rows_new(c,:), quadnode);
        end
        if abs(A_new - A_old) > 1e-12 * max(A_old, 1e-300)
            quadnode(end, :) = [];   % revert the center vertex
            return;                  % walk/order malformed: skip
        end
        for c = 1:L/2
            if c <= 3
                quad(patch(c), :) = rows_new(c, :);
            else
                quad(end+1, :) = rows_new(c, :);
            end
        end
        ok = true;
    end

    % ==================== sweep B: doublet removal ====================
    function n_removed = doublet_sweep_v32()
        n_removed = 0;
        st = rebuild_state_v32();
        nq = size(quad, 1);
        touched = false(nq, 1);
        delete_rows = [];
        for qi = 1:nq
            if touched(qi); continue; end
            qv = quad(qi, :);
            for d = 1:2
                a = qv(d); c = qv(mod(d+1, 4)+1);   % opposite pair
                b = qv(mod(d, 4)+1); dd = qv(mod(d+2, 4)+1);
                if st.isb(a) || st.isb(c); continue; end
                if st.vval(a) ~= 3 || st.vval(c) ~= 3; continue; end
                % all 4 edges interior with distinct neighbor quads
                e_ab = [qv(d), qv(mod(d,4)+1)];
                edges4 = [a, b; b, c; c, dd; dd, a];
                nbrs = zeros(4, 1); okall = true;
                for e = 1:4
                    [qj, okj] = other_owner_v32(st, edges4(e,1), edges4(e,2), qi);
                    if ~okj; okall = false; break; end
                    if qj <= 0; okall = false; break; end
                    nbrs(e) = qj;
                end
                if ~okall; continue; end
                if numel(unique(nbrs)) < 4; continue; end
                % stale-state guard (vertex ids newer than st.K)
                if max([max(qv), max(max(quad(nbrs, :)))]) >= st.K; continue; end
                % valence guards for the two surviving corners
                if st.vval(b) < 4 || st.vval(dd) < 4; continue; end
                if any(touched(nbrs)); continue; end
                % third-edge vertices x (at a) and y (at c) must differ
                x = third_nbr_v32(quad(nbrs(1), :), a, b);
                y = third_nbr_v32(quad(nbrs(2), :), c, b);
                if x == 0 || y == 0 || x == y; continue; end
                % V32-02: try several merged-vertex positions — the bare
                % diagonal midpoint often breaks neighbor convexity when
                % the two valence-3 vertices are far apart; the original
                % vertex positions or the patch centroid may work.
                cand = quad(nbrs, :);
                cand(cand == a) = -1; cand(cand == c) = -1;
                cand(cand == -1) = size(quadnode, 1) + 1;  % temp new id
                qrow_ccw = orient_ccw_v32(quadnode, quad(qi, :));
                m_cands = [0.5 * (quadnode(a, :) + quadnode(c, :)); ...
                           quadnode(a, :); quadnode(c, :); ...
                           mean(quadnode(qrow_ccw, :), 1)];
                % extra candidates must stay strictly inside the deleted
                % quad (the midpoint always is; the others only if the
                % local geometry is favorable)
                keep_mc = true(size(m_cands, 1), 1);
                for mc = 2:4
                    keep_mc(mc) = pt_in_convex_quad_topo_v32( ...
                        m_cands(mc, :), qrow_ccw, quadnode);
                end
                m_cands = m_cands(keep_mc, :);
                okdry = false; m_pt = [];
                for mc = 1:size(m_cands, 1)
                    Ptmp = [quadnode; m_cands(mc, :)];
                    okc = true;
                    for e = 1:4
                        if ~simple_convex_v32(Ptmp, cand(e, :)); okc = false; break; end
                    end
                    if okc; okdry = true; m_pt = m_cands(mc, :); break; end
                end
                if ~okdry
                    info.n_doublet_rejected = info.n_doublet_rejected + 1;
                    continue;
                end
                % apply with LOCAL AREA GUARD: the 4 modified quads
                % must cover the 5-quad patch exactly
                A_old = 0;
                for e = 1:4
                    A_old = A_old + qarea_topo_v32(quad(nbrs(e),:), quadnode);
                end
                A_old = A_old + qarea_topo_v32(quad(qi,:), quadnode);
                quadnode(end+1, :) = m_pt;
                mid = size(quadnode, 1);
                new_rows = quad(nbrs, :);
                for e = 1:4
                    new_rows(new_rows == a) = mid;
                    new_rows(new_rows == c) = mid;
                end
                A_new = 0;
                for e = 1:4
                    A_new = A_new + qarea_topo_v32(new_rows(e,:), quadnode);
                end
                if abs(A_new - A_old) > 1e-12 * max(A_old, 1e-300)
                    quadnode(end, :) = [];   % revert the merged vertex
                    info.n_doublet_rejected = info.n_doublet_rejected + 1;
                    continue;
                end
                quad(nbrs, :) = new_rows;
                delete_rows(end+1) = qi; %#ok<AGROW>
                touched(nbrs) = true;
                touched(qi) = true;
                n_removed = n_removed + 1;
                info.n_doublets_removed = info.n_doublets_removed + 1;
                break;   % this quad consumed
            end
        end
        if ~isempty(delete_rows)
            quad(delete_rows, :) = [];
        end
    end

    % ==================== sweep C: T-junction closure ====================
    function n_closed = tjunction_sweep_v32()
        %TJUNCTION_SWEEP_V32  V32-07 HYBRID closure (same policy as
        %   tjclose_v32): near-endpoint (dust-offset) or anchored T
        %   vertices get the 4e-9*|edge| perpendicular nudge (the only
        %   class where a red-green split creates dust children);
        %   well-centered T's get the classic validated red-green
        %   closure with chain propagation (decent children, truly
        %   conforming - no fake boundary edges). Anchored failures
        %   are counted once and left to tdust_fix_v32.
        n_closed = 0;
        for scan_i = 1:3
            st = rebuild_state_v32();
            tjs = collect_tjunctions_topo_v32(st);
            if isempty(tjs); break; end
            n_this = 0;
            for k = 1:size(tjs, 1)
                v = tjs(k, 1); a = tjs(k, 2); b = tjs(k, 3); qi = tjs(k, 4);
                if v > numel(blk_tjv)
                    blk_tjv(v) = false;  %#ok<AGROW> (grow on demand)
                end
                if blk_tjv(v); continue; end
                % V32-07 r3: NUDGE-FIRST for every non-anchored T
                % (sub-visible 4e-9*|edge|, O(1) owner lookup, zero
                % splits). The red-green closures fail validation in
                % the thin zones (5600+ stuck T's) and their chains
                % through thin quads are the round-04/05 dust source.
                if v <= numel(anchored) && anchored(v)
                    info.n_tj_failed = info.n_tj_failed + 1;
                    blk_tjv(v) = true;
                    continue;
                end
                if nudge_t_off_topo_v32(v, a, b, qi)
                    n_closed = n_closed + 1; n_this = n_this + 1;
                    info.n_tj_closed = info.n_tj_closed + 1;
                    info.n_tj_nudged = info.n_tj_nudged + 1;
                else
                    info.n_tj_failed = info.n_tj_failed + 1;
                    blk_tjv(v) = true;
                end
            end
            if n_this == 0; break; end
        end
    end

    function ok = nudge_t_off_topo_v32(v, a, b, qi)
        %NUDGE_T_OFF_TOPO_V32  Perpendicular nudge away from owner quad.
        ok = false;
        pa = quadnode(a, :); pb = quadnode(b, :);
        e = pb - pa; L = norm(e);
        if L < 1e-300 || qi < 1 || qi > size(quad, 1); return; end
        qc = mean(quadnode(quad(qi, :), :), 1);
        nrm = [-e(2), e(1)] / L;
        fv = quadnode(v, :);
        if dot(qc - fv, nrm) > 0; dirn = -nrm; else; dirn = nrm; end
        quadnode(v, :) = fv + (4e-9 * L) * dirn;
        ok = true;
    end

    function tjs = collect_tjunctions_topo_v32(st)
        %COLLECT_TJUNCTIONS_TOPO_V32  All (v,a,b,qi): vertex v strictly
        %   inside edge (a,b), v not an endpoint, (a,v) or (v,b) an
        %   existing edge, qi = an owner quad of (a,b). Fully VECTORIZED:
        %   edges are expanded over their 3x3 grid neighborhoods into
        %   (edge,vertex) candidate pairs, then filtered in bulk.
        tjs = zeros(0, 4);
        P = quadnode; nv = size(P, 1);
        g_lo = floor(st.gkey / st.K); g_hi = mod(st.gkey, st.K);
        ne = st.ng;
        if ne == 0; return; end
        span = max(max(P(:,1)) - min(P(:,1)), max(P(:,2)) - min(P(:,2))) * 1.0001 + 1e-300;
        gx = max(1, round(sqrt(ne))); gy = gx;
        x0 = min(P(:,1)); y0 = min(P(:,2));
        csx = span / gx; csy = span / gy;
        % ---- vertex grid (sorted by cell) ----
        vcx = min(gx, max(1, floor((P(:,1) - x0) / csx) + 1));
        vcy = min(gy, max(1, floor((P(:,2) - y0) / csy) + 1));
        vcid = (vcy - 1) * gx + vcx;
        [~, vord] = sort(vcid);
        vcu = unique(vcid);          % ascending unique vertex-cell ids
        [~, ~, vic] = unique(vcid);
        vcnt = accumarray(vic(:), 1);
        vstart = [1; cumsum(vcnt(1:end-1)) + 1];
        % ---- per-edge 3x3 neighborhood cells ----
        mx = 0.5 * (P(g_lo,1) + P(g_hi,1));
        my = 0.5 * (P(g_lo,2) + P(g_hi,2));
        ecx = min(gx, max(1, floor((mx - x0) / csx) + 1));
        ecy = min(gy, max(1, floor((my - y0) / csy) + 1));
        off = [-1 0 1];
        [dX, dY] = meshgrid(off, off);          % 9 offsets, column-major
        ccx = repmat(ecx, 1, 9) + repmat(dX(:)', ne, 1);
        ccy = repmat(ecy, 1, 9) + repmat(dY(:)', ne, 1);
        okc = ccx >= 1 & ccx <= gx & ccy >= 1 & ccy <= gy;
        ccd = (ccy - 1) * gx + ccx;
        ccd(~okc) = 0;
        % map cell id -> vertex-grid group (exact; 0 = empty)
        [tfm, vgid] = ismember(ccd, vcu);
        vgid(~tfm) = 0;
        pair_cnt = zeros(ne, 9);
        pair_cnt(tfm) = vcnt(vgid(tfm));
        tot = sum(pair_cnt(:));
        if tot == 0; return; end
        % ---- vectorized expansion of (edge, vertex) pairs ----
        e_fl = repmat((1:ne)', 1, 9);
        ecnt = pair_cnt(:);
        eidx = repelem(e_fl(:), ecnt);
        gidx = repelem(vgid(:), ecnt);
        % within-group offsets 0..cnt-1
        cs_ends = cumsum(ecnt);
        cs_beg = cs_ends - ecnt + 1;
        run = (1:tot)' - repelem(cs_beg, ecnt);
        vidx = vord(vstart(gidx) + run);
        ee = eidx; vv = vidx;
        ea = g_lo(ee); eb = g_hi(ee);
        % ---- bulk filters ----
        bad = vv == ea | vv == eb;
        A = P(ea, :); B = P(eb, :); V = P(vv, :);
        AB = B - A; AV = V - A;
        L2 = AB(:,1).^2 + AB(:,2).^2;
        okL = L2 > 1e-300;
        tp = (AV(:,1).*AB(:,1) + AV(:,2).*AB(:,2)) ./ max(L2, 1e-300);
        dist = abs(AV(:,1).*AB(:,2) - AV(:,2).*AB(:,1)) ./ sqrt(max(L2, 1e-300));
        keep = okL & ~bad & tp > 1e-9 & tp < 1 - 1e-9 & ...
               dist < 1e-9 * sqrt(max(L2, 1e-300));
        % (a,v) or (v,b) must exist as an edge (sparse hash)
        if any(keep)
            lo1 = min(ea, vv); hi1 = max(ea, vv);
            lo2 = min(vv, eb); hi2 = max(vv, eb);
            EHT = sparse([g_lo; lo1(keep); lo2(keep)], ...
                          [g_hi; hi1(keep); hi2(keep)], true, nv, nv);
            % PAIRWISE lookup: linear subscripts (two vector subscripts
            % on a matrix would produce a cartesian submatrix)
            lin1 = (hi1(keep) - 1) * nv + lo1(keep);
            lin2 = (hi2(keep) - 1) * nv + lo2(keep);
            ex1 = full(EHT(lin1));
            ex2 = full(EHT(lin2));
            keep2 = ex1 | ex2;
            kk = find(keep);
            kk = kk(keep2);
            for pair_i = kk(:)'
                v = vv(pair_i); a = ea(pair_i); b = eb(pair_i);
                g2 = gid_of_key_topo_v32(st, ekey_v32(a, b, st.K));
                if g2 == 0; continue; end
                qi = st.own1(g2);
                if qi < 1; continue; end
                tjs(end+1, :) = [v, a, b, qi]; %#ok<AGROW>
            end
        end
    end

    function tf = tj_edge_live_v32(c2, d2, mid)
        %TJ_EDGE_LIVE_V32  True if edge (c2,d2) still exists in a quad
        %   that does NOT contain mid (i.e., mid hangs on it).
        tf = false;
        ra = quad == c2; rb = quad == d2;
        e_cd = (ra(:,1)&rb(:,2)) | (ra(:,2)&rb(:,3)) | (ra(:,3)&rb(:,4)) | (ra(:,4)&rb(:,1)) | ...
               (rb(:,1)&ra(:,2)) | (rb(:,2)&ra(:,3)) | (rb(:,3)&ra(:,4)) | (rb(:,4)&ra(:,1));
        cand = find(e_cd);
        for qi = cand(:)'
            if ~ismember(mid, quad(qi, :))
                tf = true; return;
            end
        end
    end

    function [ok, c2, d2, mid] = close_tj_at_v32(v, a, b)
        %CLOSE_TJ_AT_V32  Split the CURRENT owner quad of edge (a,b)
        %   through the hanging vertex v: children (a,v,m,d) + (v,b,c,m)
        %   with m = midpoint of the opposite edge (c,d). The owner is
        %   located by a direct vectorized row scan (always fresh).
        ok = false; c2 = 0; d2 = 0; mid = 0;
        nq_now = size(quad, 1);
        ra = quad == a; rb = quad == b;
        e_ab = (ra(:,1)&rb(:,2)) | (ra(:,2)&rb(:,3)) | (ra(:,3)&rb(:,4)) | (ra(:,4)&rb(:,1)) | ...
               (rb(:,1)&ra(:,2)) | (rb(:,2)&ra(:,3)) | (rb(:,3)&ra(:,4)) | (rb(:,4)&ra(:,1));
        cand = find(e_ab);
        for qi = cand(:)'
            if qi > nq_now; break; end
            qv = quad(qi, :);
            if ismember(v, qv); continue; end   % v already incorporated
            slot = 0;
            for t = 1:4
                e1 = qv(t); e2 = qv(mod(t,4)+1);
                if (e1 == a && e2 == b) || (e1 == b && e2 == a); slot = t; break; end
            end
            if slot == 0; continue; end
            cc = qv(mod(slot+1,4)+1); dd = qv(mod(slot+2,4)+1);
            if numel(unique([a, b, cc, dd, v])) ~= 5; continue; end
            % V32-02: reuse an existing vertex on (cc,dd) as the split
            % point when present (conformity with the far side)
            mid_id = find_vertex_on_seg_topo_v32(quadnode, cc, dd);
            if mid_id > 0
                m_pt = quadnode(mid_id, :);
                use_mid_id = mid_id;
            else
                m_pt = 0.5 * (quadnode(cc, :) + quadnode(dd, :));
                use_mid_id = 0;
            end
            if ~quad4_points_convex_topo_v32([quadnode(a,:); quadnode(v,:); m_pt; quadnode(dd,:)])
                continue;
            end
            if ~quad4_points_convex_topo_v32([quadnode(v,:); quadnode(b,:); quadnode(cc,:); m_pt])
                continue;
            end
            % V32-02 clearance: the propagated midpoint's edges must not
            % pass strictly through another vertex (would re-create a
            % T-junction one step further)
            if seg_hits_vertex_topo_v32(quadnode, quadnode(v, :), m_pt) || ...
               seg_hits_vertex_topo_v32(quadnode, m_pt, quadnode(cc,:)) || ...
               seg_hits_vertex_topo_v32(quadnode, m_pt, quadnode(dd,:))
                continue;
            end
            % LOCAL AREA GUARD: children must tile the parent quad
            A_old = qarea_topo_v32(qv, quadnode);
            if use_mid_id > 0
                mid = use_mid_id;
            else
                quadnode(end+1, :) = m_pt;
                mid = size(quadnode, 1);
            end
            ch1 = [a, v, mid, dd];
            ch2 = [v, b, cc, mid];
            A_new = qarea_topo_v32(ch1, quadnode) + ...
                    qarea_topo_v32(ch2, quadnode);
            if abs(A_new - A_old) > 1e-12 * max(A_old, 1e-300)
                if use_mid_id == 0
                    quadnode(end, :) = [];   % revert the fresh midpoint
                end
                continue;
            end
            quad(qi, :) = ch1;
            quad(end+1, :) = ch2;
            c2 = cc; d2 = dd;
            ok = true;
            return;
        end
    end

    function w = find_vertex_on_seg_topo_v32(P, a, b)
        %FIND_VERTEX_ON_SEG_TOPO_V32  Id of a vertex strictly inside
        %   segment P(a)-P(b), 0 if none (bbox-limited scan).
        w = 0;
        P1 = P(a, :); P2 = P(b, :);
        xlo = min(P1(1), P2(1)); xhi = max(P1(1), P2(1));
        ylo = min(P1(2), P2(2)); yhi = max(P1(2), P2(2));
        cand = find(P(:,1) >= xlo & P(:,1) <= xhi & P(:,2) >= ylo & P(:,2) <= yhi);
        AB = P2 - P1; L2 = AB(1)^2 + AB(2)^2;
        if L2 < 1e-300; return; end
        for k = cand(:)'
            if k == a || k == b; continue; end
            AW = P(k, :) - P1;
            tp = (AW(1)*AB(1) + AW(2)*AB(2)) / L2;
            if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
            dist = abs(AW(1)*AB(2) - AW(2)*AB(1)) / sqrt(L2);
            if dist < 1e-9 * sqrt(L2)
                w = k; return;
            end
        end
    end

    function hit = seg_hits_vertex_topo_v32(P, P1, P2)
        %SEG_HITS_VERTEX_TOPO_V32  TRUE if any vertex of P lies STRICTLY
        %   inside segment P1-P2. Small bbox-limited scan.
        hit = false;
        nv = size(P, 1);
        xlo = min(P1(1), P2(1)); xhi = max(P1(1), P2(1));
        ylo = min(P1(2), P2(2)); yhi = max(P1(2), P2(2));
        cand = find(P(:,1) >= xlo & P(:,1) <= xhi & P(:,2) >= ylo & P(:,2) <= yhi);
        AB = P2 - P1; L2 = AB(1)^2 + AB(2)^2;
        if L2 < 1e-300; return; end
        for k = cand(:)'
            AW = P(k, :) - P1;
            tp = (AW(1)*AB(1) + AW(2)*AB(2)) / L2;
            if tp <= 1e-9 || tp >= 1 - 1e-9; continue; end
            dist = abs(AW(1)*AB(2) - AW(2)*AB(1)) / sqrt(L2);
            if dist < 1e-9 * sqrt(L2)
                hit = true; return;
            end
        end
    end

    function tf = quad4_points_convex_topo_v32(QP)
        %QUAD4_POINTS_CONVEX_TOPO_V32  4 points: convex with every corner
        %   turning at least sin(1 deg).
        s = 0;
        for t = 1:4
            s = s + QP(t,1)*QP(mod(t,4)+1,2) - QP(mod(t,4)+1,1)*QP(t,2);
        end
        if s < 0; QP = QP([1 4 3 2], :); end
        for t = 1:4
            v1 = QP(mod(t,4)+1, :) - QP(t, :);
            v2 = QP(mod(t+1,4)+1, :) - QP(mod(t,4)+1, :);
            cr = v1(1)*v2(2) - v1(2)*v2(1);
            n1 = norm(v1); n2 = norm(v2);
            if n1 < 1e-300 || n2 < 1e-300; tf = false; return; end
            if cr <= 0 || abs(cr) / (n1*n2) < sin(pi/180)
                tf = false; return;
            end
        end
        tf = true;
    end

    % ==================== shared helpers =====================
    function ta = sum_qarea_topo_v32()
        %SUM_QAREA_TOPO_V32  Total |area| of the current quad mesh.
        P1 = quadnode(quad(:,1),:); P2 = quadnode(quad(:,2),:);
        P3 = quadnode(quad(:,3),:); P4 = quadnode(quad(:,4),:);
        ta = 0.5 * sum(abs( ...
            (P2(:,1)-P1(:,1)).*(P3(:,2)-P1(:,2)) - (P2(:,2)-P1(:,2)).*(P3(:,1)-P1(:,1)) + ...
            (P3(:,1)-P1(:,1)).*(P4(:,2)-P1(:,2)) - (P3(:,2)-P1(:,2)).*(P4(:,1)-P1(:,1))));
    end

    function st = rebuild_state_v32()
        %REBUILD_STATE_V32  Edge owners / valences / boundary structure.
        nq = size(quad, 1); nv = size(quadnode, 1);
        E = [quad(:, [1 2]); quad(:, [2 3]); quad(:, [3 4]); quad(:, [4 1])];
        owner = repmat((1:nq)', 4, 1);
        K = double(nv) + 2;
        key = ekey_v32(E(:,1), E(:,2), K);
        [skey, ord] = sort(key);
        first = [true; diff(skey) ~= 0];
        gid_all = cumsum(first);
        ng = gid_all(end);
        starts = [find(first); numel(skey) + 1];
        st.K = K;
        st.ng = ng;
        st.gkey = skey(starts(1:end-1));
        st.nown = accumarray(gid_all, 1);
        st.own1 = owner(ord(starts(1:end-1)));
        st.own2 = zeros(ng, 1);
        two = find(st.nown == 2);
        % second owner of every 2-owner group (last element of its run);
        % assign only to the groups that HAVE one (V32-02 shape fix)
        sec = owner(ord(starts(2:end) - 1));
        st.own2(two) = sec(two);
        g_lo = floor(st.gkey / K); g_hi = mod(st.gkey, K);
        st.vval = accumarray([g_lo; g_hi], 1, [nv, 1]);
        bmask = st.nown == 1;
        st.isb = false(nv, 1);
        st.isb(g_lo(bmask)) = true; st.isb(g_hi(bmask)) = true;
        % (only 2 boundary edges per boundary vertex in a manifold mesh)
    end

    function a = qarea_topo_v32(row, P)
        %QAREA_TOPO_V32  Unsigned area of one quad row.
        s2 = 0;
        for t = 1:4
            s2 = s2 + P(row(t),1)*P(row(mod(t,4)+1),2) - ...
                        P(row(mod(t,4)+1),1)*P(row(t),2);
        end
        a = 0.5 * abs(s2);
    end

    function tf = pt_in_convex_quad_topo_v32(pt, row, P)
        %PT_IN_CONVEX_QUAD_TOPO_V32  Strict interior test for a convex
        %   quad row (all corners CCW).
        tf = true;
        for t = 1:4
            e1 = P(row(mod(t,4)+1), :) - P(row(t), :);
            e2 = pt - P(row(t), :);
            if e1(1)*e2(2) - e1(2)*e2(1) <= 0
                tf = false; return;
            end
        end
    end

    function k = ekey_v32(a, b, K)
        k = min(a, b) * K + max(a, b);
    end

    function g = gid_of_key_topo_v32(st, key)
        %GID_OF_KEY_TOPO_V32  Exact group id for an edge key, 0 if absent.
        %   (interp1 would return fractional indices for keys between
        %   existing ones — unusable as a subscript.)
        g = 0;
        lo = 1; hi = st.ng;
        while lo <= hi
            mid = floor((lo + hi) / 2);
            if st.gkey(mid) == key
                g = mid; return;
            elseif st.gkey(mid) < key
                lo = mid + 1;
            else
                hi = mid - 1;
            end
        end
    end

    function [qj, ok] = other_owner_v32(st, u, w, qi)
        %OTHER_OWNER_V32  Quad owning interior edge (u,w) other than qi.
        qj = 0; ok = false;
        g = gid_of_key_topo_v32(st, ekey_v32(u, w, st.K));
        if g == 0; return; end
        if st.nown(g) ~= 2; return; end
        o1 = st.own1(g); o2 = st.own2(g);
        if o1 == qi; qj = o2; elseif o2 == qi; qj = o1;
        else; return; end
        if qj <= 0; return; end
        ok = true;
    end

    function h = hexagon_for_corner_v32(qv, v, p, n, x, nrow, rem) %#ok<INUSD>
        %HEXAGON_FOR_CORNER_V32  Cyclic hexagon of the corner quad
        %   qv=(p,v,n,x) merged with its neighbor nrow across interior
        %   edge rem (either [n,x] or [x,p]). Returns [] if malformed.
        %
        %   Robust construction (V32-02 fix): instead of decoding the
        %   neighbor's cyclic orientation, take the OUTER vertices by
        %   adjacency — on1 = row-neighbor of rem(1) other than rem(2),
        %   on2 = row-neighbor of rem(2) other than rem(1) — then walk
        %   the union boundary:
        %     rem == (n,x):  [v, n, on1, on2, x, p]   (n -> on1 -> on2 -> x)
        %     rem == (x,p):  [v, n, x, on1, on2, p]   (x -> on1 -> on2 -> p)
        %   This is immune to the a/b order swap that produced
        %   non-existent edges in the previous version.
        h = [];
        if numel(unique(nrow)) ~= 4; return; end
        on1 = row_nbr_other_v32(nrow, rem(1), rem(2));
        on2 = row_nbr_other_v32(nrow, rem(2), rem(1));
        if on1 == 0 || on2 == 0 || on1 == on2; return; end
        if isequal(rem, [n, x])
            h = [v, n, on1, on2, x, p];
        else
            h = [v, n, x, on1, on2, p];
        end
        if numel(unique(h)) ~= 6; h = []; end
    end

    function w = row_nbr_other_v32(qrow, u, notu)
        %ROW_NBR_OTHER_V32  Cyclic row-neighbor of u in qrow, not notu.
        w = 0;
        iu = find(qrow == u, 1);
        if isempty(iu); return; end
        w1 = qrow(mod(iu + 2, 4) + 1);   % previous in the cycle
        w2 = qrow(mod(iu, 4) + 1);       % next in the cycle
        if w1 ~= notu
            w = w1;
        elseif w2 ~= notu
            w = w2;
        end
    end

    function tf = children_ok_v32(cv, st)
        %CHILDREN_OK_V32  Child quad: 4 distinct vertices, CCW-convex
        %   with corners in (1 deg, 179 deg), no boundary spanning.
        %   V32-07 instrumentation: failure-reason counters.
        if numel(unique(cv)) ~= 4
            info.n_cf_dup = info.n_cf_dup + 1; tf = false; return; end
        P4 = quadnode(cv, :);
        s = 0;
        for t = 1:4
            s = s + P4(t,1)*P4(mod(t,4)+1,2) - P4(mod(t,4)+1,1)*P4(t,2);
        end
        if s < 0; P4 = P4([1 4 3 2], :); end   % ensure CCW
        for t = 1:4
            v1 = P4(mod(t,4)+1, :) - P4(t, :);
            v2 = P4(mod(t+1,4)+1, :) - P4(mod(t,4)+1, :);
            cr = v1(1)*v2(2) - v1(2)*v2(1);
            n1 = norm(v1); n2 = norm(v2);
            if n1 < 1e-300 || n2 < 1e-300
                info.n_cf_degen = info.n_cf_degen + 1; tf = false; return; end
            if cr <= 0 || abs(cr) / (n1*n2) < sin(pi/180)
                info.n_cf_flat = info.n_cf_flat + 1; tf = false; return;
            end
        end
        % spanning check on the child
        if child_spans_v32(cv, st)
            info.n_cf_span = info.n_cf_span + 1; tf = false; return;
        end
        tf = true;
    end

    function tf = child_spans_v32(cv, st)
        %CHILD_SPANS_V32  TRUE if quad cv contains BOTH boundary edges
        %   of a boundary vertex whose corner angle EXCEEDS 180.5 deg
        %   (reflex; straight runs and convex corners may span).
        %   Boundary status uses the sweep-start state st; edges absent
        %   from st (the new split diagonal) count as interior.
        tf = false;
        nv_now = size(quadnode, 1);
        for t = 1:4
            w = cv(t);
            pv = cv(mod(t + 2, 4) + 1);   % previous corner
            nx = cv(mod(t, 4) + 1);       % next corner
            % V32-07: the unspan fan passes a NOT-YET-CREATED center
            % id (size+1) as the 4th corner; a corner adjacent to it
            % cannot span (the new vertex is interior by construction)
            if w > nv_now || pv > nv_now || nx > nv_now
                continue;
            end
            if edge_is_bnd_topo_v32(pv, w, st) && ...
               edge_is_bnd_topo_v32(w, nx, st)
                % angle at w from the three involved points only (the
                % 4th corner may be a not-yet-created vertex id)
                a1 = quadnode(pv, :) - quadnode(w, :);
                a2 = quadnode(nx, :) - quadnode(w, :);
                ang = acosd(max(-1, min(1, ...
                    (a1(1)*a2(1) + a1(2)*a2(2)) / ...
                    (norm(a1) * norm(a2) + 1e-300))));
                % V32-07: 120-deg rule (the old > 180.5 test could
                % never fire: acosd returns at most 180)
                if ang > 120
                    tf = true; return;
                end
            end
        end
    end

    function tf = edge_is_bnd_topo_v32(u, w, st)
        %EDGE_IS_BND_TOPO_V32  Boundary edge test against state st.
        g = gid_of_key_topo_v32(st, ekey_v32(u, w, st.K));
        if g == 0
            tf = false; return;   % new edge (split diagonal): interior
        end
        tf = st.nown(g) == 1;
    end

    function ang = poly_corner_angle_topo_v32(P4, t)
        %POLY_CORNER_ANGLE_TOPO_V32  CCW interior angle (deg) at corner
        %   t of the 4-point polygon P4 (rotation-normalized).
        s = 0;
        for k = 1:4
            s = s + P4(k,1)*P4(mod(k,4)+1,2) - P4(mod(k,4)+1,1)*P4(k,2);
        end
        if s < 0
            P4 = P4([1 4 3 2], :);
            t = 5 - t;   % corner position under the flipped rotation
        end
        p1 = P4(mod(t + 2, 4) + 1, :);
        p2 = P4(t, :);
        p3 = P4(mod(t, 4) + 1, :);
            v1 = p1 - p2; v2 = p3 - p2;
        n1 = norm(v1); n2 = norm(v2);
        if n1 < 1e-300 || n2 < 1e-300; ang = 180; return; end
        cs = (v1(1)*v2(1) + v1(2)*v2(2)) / (n1 * n2);
        ang = acosd(max(-1, min(1, cs)));
    end

    function tf = simple_convex_v32(P, cv)
        %SIMPLE_CONVEX_V32  Row cv of P: 4 distinct, convex, corners in
        %   (1 deg, 179 deg).
        if numel(unique(cv)) ~= 4; tf = false; return; end
        P4 = P(cv, :);
        s = 0;
        for t = 1:4
            s = s + P4(t,1)*P4(mod(t,4)+1,2) - P4(mod(t,4)+1,1)*P4(t,2);
        end
        if abs(s) < 1e-300; tf = false; return; end
        if s < 0; P4 = P4([1 4 3 2], :); end
        tf = true;
        for t = 1:4
            v1 = P4(mod(t,4)+1, :) - P4(t, :);
            v2 = P4(mod(t+1,4)+1, :) - P4(mod(t,4)+1, :);
            cr = v1(1)*v2(2) - v1(2)*v2(1);
            n1 = norm(v1); n2 = norm(v2);
            if n1 < 1e-300 || n2 < 1e-300; tf = false; return; end
            if cr <= 0 || abs(cr) / (n1*n2) < sin(pi/180)
                tf = false; return;
            end
        end
    end

    function x = third_nbr_v32(qrow, a, b)
        %THIRD_NBR_V32  Row-neighbor of a in qrow that is not b.
        x = 0;
        ia = find(qrow == a, 1);
        if isempty(ia); return; end
        prevv = qrow(mod(ia+2, 4)+1);
        nextv = qrow(mod(ia, 4)+1);
        if prevv ~= b; x = prevv; elseif nextv ~= b; x = nextv; end
    end

    function qv = orient_ccw_v32(P, qv)
        s = 0;
        for t = 1:4
            s = s + P(qv(t),1)*P(qv(mod(t,4)+1),2) - P(qv(mod(t,4)+1),1)*P(qv(t),2);
        end
        if s < 0; qv = qv([1 4 3 2]); end
    end

    function ang = domain_angle_v32(P, v, p, n, qv)
        %DOMAIN_ANGLE_V32  Interior angle at boundary vertex v between
        %   boundary neighbors p,n measured through the quad side.
        vp = P(p,:) - P(v,:);
        vn = P(n,:) - P(v,:);
        a1 = atan2(vp(2), vp(1));
        a2 = atan2(vn(2), vn(1));
        c = mean(P(qv, :), 1) - P(v,:);
        ac = atan2(c(2), c(1));
        d12 = mod(a2 - a1, 2*pi);
        dc1 = mod(ac - a1, 2*pi);
        if dc1 <= d12
            ang = d12 * 180 / pi;
        else
            ang = (2*pi - d12) * 180 / pi;
        end
    end
    function el = edge_lens_row_v32(P, qv)
        %EDGE_LENS_ROW_V32  4 edge lengths of one quad row.
        el = [norm(P(qv(1),:)-P(qv(2),:)), norm(P(qv(2),:)-P(qv(3),:)), ...
              norm(P(qv(3),:)-P(qv(4),:)), norm(P(qv(4),:)-P(qv(1),:))];
    end

    function ang = quad_angles_row_v32(P, qv)
        %QUAD_ANGLES_ROW_V32  4 corner angles (deg) of one quad row.
        ang = zeros(1, 4);
        for t = 1:4
            v = P(qv(t),:);
            u = P(qv(mod(t+2,4)+1),:);
            w = P(qv(mod(t,4)+1),:);
            a = u - v; b = w - v;
            na = norm(a); nb = norm(b);
            if na < 1e-300 || nb < 1e-300
                ang(t) = 360;
            else
                cs = (a(1)*b(1)+a(2)*b(2)) / (na*nb);
                ang(t) = acosd(max(-1, min(1, cs)));
            end
        end
    end

    function h = hexagon_of_pair_v32(qi_row, qj_row, a, b)
        %HEXAGON_OF_PAIR_V32  6-ring of the union of two quads sharing
        %   edge (a,b): [a, qi_far_2, qi_far_1, b, qj_far_1, qj_far_2].
        h = [];
        i1 = find(qi_row == a, 1); i2 = find(qi_row == b, 1);
        j1 = find(qj_row == a, 1); j2 = find(qj_row == b, 1);
        if isempty(i1) || isempty(i2) || isempty(j1) || isempty(j2); return; end
        if mod(i2 - i1, 4) == 1
            qir = circshift_rot_v32(qi_row, 1 - i1);   % [a, b, x, y]
            qside = [qir(1), qir(4), qir(3), qir(2)];  % a, y, x, b
        else
            qir = circshift_rot_v32(qi_row, 1 - i2);   % [b, a, y, x]
            qside = [qir(2), qir(3), qir(4), qir(1)];  % a, y, x, b
        end
        if mod(j2 - j1, 4) == 1
            qjr = circshift_rot_v32(qj_row, 1 - j1);   % [a, b, u, v]
            jside = [qjr(2), qjr(3), qjr(4)];          % b, u, v
        else
            qjr = circshift_rot_v32(qj_row, 1 - j2);   % [b, a, v, u]
            jside = [qjr(1), qjr(4), qjr(3)];          % b, v, u
        end
        h = [qside(1), qside(2), qside(3), jside(1), jside(2), jside(3)];
    end

    function r = circshift_rot_v32(v, k)
        %CIRCSHIFT_ROT_V32  Rotate vector v so position k becomes 1.
        n = numel(v);
        k = mod(k - 1, n);
        r = [v(k+1:n), v(1:k)];
    end

    function [r1, r2, ok, sc] = best_hex_split_v32(h)
        %BEST_HEX_SPLIT_V32  Best 2-quad split of hexagon ring h via one
        %   of the 3 diagonals (h1-h4 / h2-h5 / h3-h6). Children must be
        %   strictly convex, corners within (2 deg, 178 deg); score = min
        %   child corner angle.
        ok = false; sc = -inf; r1 = []; r2 = [];
        hexopts = {  [h(1), h(2), h(3), h(4)], [h(1), h(4), h(5), h(6)]; ...
                   [h(2), h(3), h(4), h(5)], [h(2), h(5), h(6), h(1)]; ...
                   [h(3), h(4), h(5), h(6)], [h(3), h(6), h(1), h(2)] };
        for oi = 1:3
            c1 = hexopts{oi, 1};
            c2 = hexopts{oi, 2};
            a1 = quad_angles_row_v32(quadnode, c1);
            a2 = quad_angles_row_v32(quadnode, c2);
            if min(a1) <= 2 || max(a1) >= 178; continue; end
            if min(a2) <= 2 || max(a2) >= 178; continue; end
            s = min([a1, a2]);
            if s > sc
                sc = s; r1 = c1; r2 = c2; ok = true;
            end
        end
    end
end
