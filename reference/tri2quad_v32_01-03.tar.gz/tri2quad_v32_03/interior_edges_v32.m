function [ti, tj, va, vb, vc, vd] = interior_edges_v32(tri)
%INTERIOR_EDGES_V32  Interior edges of tri mesh with ti<tj (1-based).
%   For each interior edge: endpoints va,vb; apex of ti is vc; apex of tj
%   is vd. Convention matches compute_neighbors_fast: local edge j of
%   triangle i is (tri(i,mod(j,3)+1), tri(i,mod(j+1,3)+1)), apex tri(i,j).
%   The quad formed by merging (ti,tj) is (vc, va, vd, vb) in CCW order.
    nbr = compute_neighbors_fast(tri);
    ntri = size(tri, 1);
    ti = repmat((1:ntri)', 3, 1); ti = ti(:);
    ej = repmat((1:3)', 1, ntri)'; ej = ej(:);
    nb = nbr(sub2ind([ntri, 3], ti, ej));
    mask = nb > 0 & ti < nb;
    ti = ti(mask); ej = ej(mask); tj = nb(mask);
    va = tri(sub2ind([ntri, 3], ti, mod(ej, 3) + 1));
    vb = tri(sub2ind([ntri, 3], ti, mod(ej + 1, 3) + 1));
    vc = tri(sub2ind([ntri, 3], ti, ej));
    rowsT = tri(tj, :);
    notab = ~(rowsT == va | rowsT == vb);
    vd = zeros(size(va));
    for cc = 1:3   % column-major safe extraction (row order preserved)
        sel = notab(:, cc);
        vd(sel) = rowsT(sel, cc);
    end
    vd = vd(:);
end
