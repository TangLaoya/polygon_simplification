function [node, tri, info] = mesh_clean_v32(node, tri, debug)
%MESH_CLEAN_V32  Clean input triangle mesh: dedupe, degenerate removal, CCW.
%
%   Operations (all vectorized, O(N log N)):
%     1. Merge duplicate vertices (exact coordinate match after rounding to
%        a grid of 1e-14 * bbox scale).
%     2. Remove degenerate triangles (repeated vertex indices).
%     3. Remove duplicate triangles (same sorted vertex set).
%     4. Enforce CCW orientation (positive signed area).
%     5. Compact vertex numbering (remove unused vertices).
%
%   INPUT:
%     node : N-by-2 vertex coordinates
%     tri  : M-by-3 triangle connectivity (1-indexed)
%     debug: verbose flag
%
%   OUTPUT:
%     node : cleaned vertex coordinates
%     tri  : cleaned connectivity (1-indexed, CCW)
%     info : struct with counts (n_dup_vtx_merged, n_degenerate_removed,
%             n_dup_tri_removed, n_flipped_orientation, n_unused_vtx_removed)

    info = struct('n_dup_vtx_merged', 0, 'n_degenerate_removed', 0, ...
                  'n_dup_tri_removed', 0, 'n_flipped_orientation', 0, ...
                  'n_unused_vtx_removed', 0);
    nnode0 = size(node, 1);
    ntri0 = size(tri, 1);

    % ---- 1. Merge duplicate vertices (grid-rounded key, 3x3 cell search) ----
    bbox_scale = max(abs(node(:)));
    if isempty(bbox_scale) || ~isfinite(bbox_scale) || bbox_scale == 0
        bbox_scale = 1;
    end
    tol = 1e-12 * bbox_scale;   % exact-duplicate tolerance (near machine eps)
    key = round(node / tol);
    [uniq_key, ~, ic] = unique(key, 'rows');
    % grid rounding can straddle cell borders: also check neighbors is
    % overkill for exact duplicates; unique on rounded key is sufficient.
    node_u = node(ic, :); %#ok<NASGU>  % first occurrence kept below
    % keep FIRST occurrence coordinates for each unique key
    [uf, first_idx] = unique(ic, 'first');
    node_new = node(first_idx, :);
    tri = ic(tri);
    info.n_dup_vtx_merged = nnode0 - size(node_new, 1);
    node = node_new;

    % ---- 2. Remove degenerate triangles ----
    deg = tri(:,1) == tri(:,2) | tri(:,2) == tri(:,3) | tri(:,1) == tri(:,3);
    tri(deg, :) = [];
    info.n_degenerate_removed = sum(deg);

    if isempty(tri)
        if debug; fprintf('  [clean] WARNING: no triangles left\n'); end
        return;
    end

    % ---- 3. Remove duplicate triangles (same sorted vertex set) ----
    tri_sorted = sort(tri, 2);
    [~, uid] = unique(tri_sorted, 'rows', 'stable');
    info.n_dup_tri_removed = size(tri, 1) - numel(uid);
    tri = tri(uid, :);

    % ---- 4. Enforce CCW orientation ----
    p1 = node(tri(:,1), :); p2 = node(tri(:,2), :); p3 = node(tri(:,3), :);
    cr = (p2(:,1)-p1(:,1)).*(p3(:,2)-p1(:,2)) - (p2(:,2)-p1(:,2)).*(p3(:,1)-p1(:,1));
    flip_mask = cr < 0;
    info.n_flipped_orientation = sum(flip_mask);
    if any(flip_mask)
        tmp = tri(flip_mask, 2);
        tri(flip_mask, 2) = tri(flip_mask, 3);
        tri(flip_mask, 3) = tmp;
    end

    % ---- 5. Compact vertex numbering ----
    used = false(size(node,1), 1);
    used(tri(:)) = true;
    [~, remap] = max(cumsum(used)); %#ok<NASGU>
    [used_idx, ~, newid] = find(used);   % newid gives compact ids
    map_v = zeros(size(node,1), 1);
    map_v(used_idx) = 1:numel(used_idx);
    tri = map_v(tri);
    info.n_unused_vtx_removed = size(node,1) - numel(used_idx);
    node = node(used_idx, :);

    if debug
        fprintf('  [clean] vtx %d->%d (dup %d, unused %d), tri %d->%d (degen %d, dup %d), flipped %d\n', ...
            nnode0, size(node,1), info.n_dup_vtx_merged, info.n_unused_vtx_removed, ...
            ntri0, size(tri,1), info.n_degenerate_removed, info.n_dup_tri_removed, ...
            info.n_flipped_orientation);
    end

    % ---- 6. Promote vertices lying strictly ON a boundary edge (V32-02) ----
    % Degenerate inputs can place a mesh vertex exactly on the interior of
    % a boundary edge. Left alone, such a vertex becomes a T-junction of
    % the quad mesh that no validated closure can fix (any split produces
    % ~180-deg corners). Promoting it here — splitting the boundary edge
    % (a,b) at v and its triangle (a,b,x) into (a,v,x) + (v,b,x) — makes
    % v a regular boundary-chain vertex with deviation exactly 0.
    info.n_boundary_promoted = 0;
    for sweep = 1:4
        [node, tri, np] = promote_onedge_vertices_v32(node, tri);
        info.n_boundary_promoted = info.n_boundary_promoted + np;
        if np == 0; break; end
    end
    if debug && info.n_boundary_promoted > 0
        fprintf('  [clean] promoted %d on-edge vertices to boundary chain\n', ...
            info.n_boundary_promoted);
    end
end

% =====================================================================
function [node, tri, n_promoted] = promote_onedge_vertices_v32(node, tri)
%PROMOTE_ONEDGE_VERTICES_V32  One sweep: split every boundary edge that
%   strictly contains another mesh vertex. Vectorized detection (spatial
%   grid), per-hit triangle split. Splits use the vertex's exact
%   coordinates, so coverage and every other vertex are unchanged.
    n_promoted = 0;
    ntri = size(tri, 1);
    nv = size(node, 1);
    nbr = compute_neighbors_fast(tri);
    [I, J] = find(nbr < 0);
    bva = tri(sub2ind([ntri,3], I, mod(J,3)+1));
    bvb = tri(sub2ind([ntri,3], I, mod(J+1,3)+1));
    apex = I;
    ne = numel(bva);
    if ne == 0; return; end
    % grid over boundary-edge midpoints
    span = max(max(node(:,1))-min(node(:,1)), max(node(:,2))-min(node(:,2))) * 1.0001 + 1e-300;
    gx = max(1, round(sqrt(ne))); cs = span / gx;
    x0 = min(node(:,1)); y0 = min(node(:,2));
    mx = 0.5*(node(bva,1)+node(bvb,1)); my = 0.5*(node(bva,2)+node(bvb,2));
    cid = floor((my-y0)/cs)*gx + floor((mx-x0)/cs) + 1;
    [~, ord] = sort(cid); cu = unique(cid);
    [~, ~, icu] = unique(cid); cnts = accumarray(icu(:),1);
    starts = [1; cumsum(cnts(1:end-1))+1];
    e_lo = bva(ord); e_hi = bvb(ord); e_ap = apex(ord);
    % collect (edge-row, vertex) hits
    hits = zeros(0, 2);
    for v = 1:nv
        cx = floor((node(v,1)-x0)/cs)+1; cy = floor((node(v,2)-y0)/cs)+1;
        for dx = -1:1
            for dy = -1:1
                ccx = cx+dx; ccy = cy+dy;
                if ccx < 1 || ccx > gx || ccy < 1 || ccy > gx; continue; end
                cq = (ccy-1)*gx+ccx;
                bi = find(cu == cq, 1);
                if isempty(bi); continue; end
                for s2 = starts(bi):starts(bi)+cnts(bi)-1
                    a = e_lo(s2); b = e_hi(s2);
                    if v == a || v == b; continue; end
                    A = node(a,:); B = node(b,:); V = node(v,:);
                    AB = B - A; AV = V - A;
                    L2 = AB(1)^2 + AB(2)^2;
                    if L2 < 1e-300; continue; end
                    tp = (AV(1)*AB(1)+AV(2)*AB(2)) / L2;
                    dist = abs(AV(1)*AB(2)-AV(2)*AB(1)) / sqrt(L2);
                    if tp > 1e-9 && tp < 1-1e-9 && dist < 1e-9 * sqrt(L2)
                        hits(end+1, :) = [s2, v]; %#ok<AGROW>
                    end
                end
            end
        end
    end
    if isempty(hits); return; end
    % split each hit boundary edge (process far-most t first per edge so
    % earlier splits are not invalidated); multiple vertices on one edge
    % are handled across sweeps
    hit_t = zeros(size(hits,1), 1);
    for k = 1:size(hits,1)
        s2 = hits(k,1); v = hits(k,2);
        a = e_lo(s2); b = e_hi(s2);
        AB = node(b,:) - node(a,:); AV = node(v,:) - node(a,:);
        hit_t(k) = (AV(1)*AB(1)+AV(2)*AB(2)) / (AB(1)^2+AB(2)^2);
    end
    % one split per unique edge (farthest vertex first); at most ONE
    % split per triangle per sweep (two boundary edges of the same
    % triangle containing on-edge vertices are handled across sweeps)
    edge_key = min(e_lo(hits(:,1)), e_hi(hits(:,1))) * double(nv) + ...
               max(e_lo(hits(:,1)), e_hi(hits(:,1)));
    [ue_k, ~, ie] = unique(edge_key);
    pick = zeros(numel(ue_k), 1);
    for k = 1:numel(ue_k)
        idx = find(ie == k);
        [~, im] = max(hit_t(idx));
        pick(k) = idx(im);
    end
    tri_new = zeros(numel(pick) * 2, 3);
    tn = 0;
    used_ap = false(ntri, 1);
    del_ap = false(ntri, 1);
    for k = 1:numel(pick)
        pk = pick(k);
        s2 = hits(pk, 1); v = hits(pk, 2);
        a = e_lo(s2); b = e_hi(s2); x = e_ap(s2);
        if x < 1 || used_ap(x); continue; end
        used_ap(x) = true;
        del_ap(x) = true;
        tn = tn + 1;
        tri_new(2*tn-1, :) = [a, v, x];
        tri_new(2*tn, :) = [v, b, x];
        n_promoted = n_promoted + 1;
    end
    if tn == 0; return; end
    tri = [tri(~del_ap, :); tri_new(1:2*tn, :)];
end
