function [quadnode, moved] = smooth_quad_mesh_v32(quadnode, quad, ...
    n_taubin, debug)
%SMOOTH_QUAD_MESH_V32  Constrained quality smoothing (boundary FIXED).
%
%   Stage 1: Taubin (lambda=0.5, mu=-0.53) — vectorized umbrella updates
%     via a sparse adjacency matrix. Only interior vertices move; ALL
%     boundary vertices (input vertices + on-segment midpoints) are
%     FROZEN, so the domain boundary stays bit-exact. Inversion guard:
%     after each sweep, quads with a non-positive corner cross revert
%     their free vertices (iterates until clean).
%   Stage 2: targeted angle optimization — interior vertices whose
%     incident minimum angle is below 60 deg try candidate positions
%     (umbrella centroid + 8 probes) and keep the best guarded one.
%
%   INPUT:  quadnode, quad, n_taubin (default 20), debug
%   OUTPUT: quadnode, moved (count of vertices relocated in stage 2)

    if nargin < 3 || isempty(n_taubin); n_taubin = 20; end
    if nargin < 4; debug = false; end

    LAM = 0.5; MU = -0.53;
    nnode = size(quadnode, 1);
    nq = size(quad, 1);
    moved = 0;

    fixed = detect_boundary_nodes(quad, quadnode);   % reuse (as-is)
    free_mask = ~fixed;
    free_ids = find(free_mask);

    % sparse umbrella adjacency (row v -> neighbors)
    A = [quad(:,[1 2]); quad(:,[2 3]); quad(:,[3 4]); quad(:,[4 1])];
    nedge = size(A, 1);
    W = sparse(A(:,1), A(:,2), 1, nnode, nnode) + ...
        sparse(A(:,2), A(:,1), 1, nnode, nnode);
    W = spones(W);
    deg = full(sum(W, 2));

    % ---- Stage 1: Taubin sweeps ----
    for it = 1:n_taubin
        lam = LAM; if it > n_taubin / 2; lam = MU; end
        old = quadnode;
        target = full(W * quadnode) ./ max(deg, 1);
        cand = quadnode;
        cand(free_ids, :) = quadnode(free_ids, :) + ...
            lam * (target(free_ids, :) - quadnode(free_ids, :));
        % inversion guard: revert free vertices of bad quads until clean
        for git = 1:8
            badq = bad_quads_mask_v32(cand, quad);
            if ~any(badq); break; end
            bv = unique(quad(badq, :));
            bv = bv(free_mask(bv));
            cand(bv, :) = old(bv, :);
        end
        quadnode = cand;
    end
    if debug
        badq = bad_quads_mask_v32(quadnode, quad);
        fprintf('  [smooth] tauban done (%d iters), bad quads now %d\n', ...
            n_taubin, sum(badq)); 
    end

    % ---- Stage 2: targeted angle optimization ----
    % incident quads per vertex via sparse incidence
    Iqv = repmat((1:nq)', 4, 1);
    Ivq = quad(:);
    Inc = sparse(Ivq, Iqv, true, nnode, nq);

    for sweep = 1:2
        any_move = false;
        % min angle per quad
        ma_q = quad_min_angles_v32(quadnode, quad);
        % vertices to consider: free with an incident quad angle < 60
        cand_v = find(free_mask & any(Inc(:, ma_q < 40), 2));
        for k = 1:numel(cand_v)
            v = cand_v(k);
            qids = find(Inc(v, :));
            cur = quadnode(v, :);
            best = cur;
            best_sc = vertex_min_angle_v32(quadnode, quad, qids, v, cur);
            if best_sc >= 40; continue; end
            nb = find(W(v, :));
            if isempty(nb); continue; end
            c = mean(quadnode(nb, :), 1);
            dref = 0.25 * mean(sqrt(sum((quadnode(nb,:) - repmat(cur, numel(nb), 1)).^2, 2)));
            cands = c;
            for ang = 0:90:270
                cands = [cands; c + dref * [cosd(ang), sind(ang)]]; %#ok<AGROW>
            end
            for ci = 1:size(cands, 1)
                cand = cands(ci, :);
                if ~guard_ok_v32(quadnode, quad, qids, v, cand); continue; end
                sc = vertex_min_angle_v32(quadnode, quad, qids, v, cand);
                if sc > best_sc + 1e-6
                    best_sc = sc; best = cand;
                end
            end
            if ~isequal(best, cur)
                quadnode(v, :) = best;
                moved = moved + 1;
                any_move = true;
            end
        end
        if debug
            fprintf('  [smooth] opt sweep %d: moved=%d\n', sweep, moved);
            
        end
        if ~any_move; break; end
    end
end

% =====================================================================
function badq = bad_quads_mask_v32(P, quad)
%BAD_QUADS_MASK_V32  Quads with any non-positive corner cross OR any
%   corner flatter than ~1 deg (V32-02: keeps smoothing from creating
%   triangle-like quads; frozen flat boundary quads revert nothing).
    p1 = P(quad(:,1), :); p2 = P(quad(:,2), :);
    p3 = P(quad(:,3), :); p4 = P(quad(:,4), :);
    c1 = crossr_v32(p1, p2, p3); c2 = crossr_v32(p2, p3, p4);
    c3 = crossr_v32(p3, p4, p1); c4 = crossr_v32(p4, p1, p2);
    e12 = sqrt(sum((p2-p1).^2, 2)); e23 = sqrt(sum((p3-p2).^2, 2));
    e34 = sqrt(sum((p4-p3).^2, 2)); e41 = sqrt(sum((p1-p4).^2, 2));
    usin = [c1./(e12.*e23), c2./(e23.*e34), c3./(e34.*e41), c4./(e41.*e12)];
    sin1 = sin(pi/180);
    badq = c1 <= 0 | c2 <= 0 | c3 <= 0 | c4 <= 0 | ...
           any(abs(usin) < sin1, 2);
end

function c = crossr_v32(p1, p2, p3)
    c = (p2(:,1)-p1(:,1)).*(p3(:,2)-p2(:,2)) - ...
        (p2(:,2)-p1(:,2)).*(p3(:,1)-p2(:,1));
end

% =====================================================================
function ma = quad_min_angles_v32(P, quad)
%QUAD_MIN_ANGLES_V32  Min corner angle per quad (vectorized), -inf if
%   degenerate corner.
    p1 = P(quad(:,1), :); p2 = P(quad(:,2), :);
    p3 = P(quad(:,3), :); p4 = P(quad(:,4), :);
    a1 = angr_v32(p1, p2, p3); a2 = angr_v32(p2, p3, p4);
    a3 = angr_v32(p3, p4, p1); a4 = angr_v32(p4, p1, p2);
    ma = min([a1, a2, a3, a4], [], 2);
end

function a = angr_v32(pa, pb, pc)
%ANGR_V32  Angle at pb of (pa,pb,pc), vectorized, degrees.
    v1 = pa - pb; v2 = pc - pb;
    n1 = sqrt(v1(:,1).^2 + v1(:,2).^2); n2 = sqrt(v2(:,1).^2 + v2(:,2).^2);
    cs = (v1(:,1).*v2(:,1) + v1(:,2).*v2(:,2)) ./ (n1 .* n2 + 1e-300);
    a = acosd(max(-1, min(1, cs)));
    a(n1 < 1e-300 | n2 < 1e-300) = -inf;
end

% =====================================================================
function ok = guard_ok_v32(P, quad, qids, v, newpos)
%V32-02: additionally reject moves producing corners flatter than 1 deg.
    sin1 = sin(pi/180);
    for k = 1:numel(qids)
        qv = quad(qids(k), :);
        QP = P(qv, :);
        pos_v = find(qv == v);
        QP(pos_v(1), :) = newpos;
        for t = 1:4
            e1 = QP(mod(t,4)+1,:) - QP(t,:);
            e2 = QP(mod(t+1,4)+1,:) - QP(mod(t,4)+1,:);
            cr = e1(1)*e2(2) - e1(2)*e2(1);
            if cr <= 0; ok = false; return; end
            if abs(cr) / (norm(e1) * norm(e2) + 1e-300) < sin1
                ok = false; return;
            end
        end
    end
    ok = true;
end

function sc = vertex_min_angle_v32(P, quad, qids, v, newpos)
    sc = inf;
    for k = 1:numel(qids)
        qv = quad(qids(k), :);
        QP = P(qv, :);
        pos_v = find(qv == v);
        QP(pos_v(1), :) = newpos;
        for t = 1:4
            v1 = QP(t,:) - QP(mod(t,4)+1,:);
            v2 = QP(mod(t+1,4)+1,:) - QP(mod(t,4)+1,:);
            n1 = norm(v1); n2 = norm(v2);
            if n1 < 1e-300 || n2 < 1e-300; sc = -inf; return; end
            cs = (v1(1)*v2(1)+v1(2)*v2(2)) / (n1*n2);
            sc = min(sc, acosd(max(-1, min(1, cs))));
        end
    end
end
