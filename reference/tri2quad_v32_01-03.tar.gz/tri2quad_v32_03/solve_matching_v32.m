function [match, info] = solve_matching_v32(graph, blossom_ver, debug, opts)
%SOLVE_MATCHING_V32  Per-component MWPM with a RELIABLE solver ladder.
%
%   V32-03 (round 03) - fixes the reported blossom-6 failure:
%     "ERROR: Solve failed: Negative delta increase" on comp 7 (4616
%     nodes) followed by an unbounded run on comp 8 (33184 nodes)
%     = the pipeline dead loop (MATLAB system() has NO timeout on
%     Windows, so the hung solver blocked the pipeline forever).
%
%   ROOT CAUSE (reproduced and measured on the real data):
%     * The bundled Blossom VI reference CLI is unreliable on this
%       mesh family: it CRASHES on the 4616-node dual component
%       ("Negative delta increase" - DualUpdater cross-component
%       slack going negative) and RUNS UNBOUNDEDLY on the 33184-node
%       one. Patching that C++ check only shifts the failure mode
%       ("No progress made in either of primal and dual updates").
%     * The SAME components are solved by blossom5_cli in 0.007 s
%       and 0.092 s respectively, with a verified perfect matching.
%
%   FIX - three layers of defense, all inside this file:
%     1. SOLVER LADDER per component, first success wins:
%          ver=6, nc <= gate : cli-6 -> cli-5 -> matlab-augment
%          ver=6, nc >  gate : cli-5 -> matlab-augment  (skip cli-6)
%          ver=5, any size   : cli-5 -> matlab-augment
%                              (cli-6 only if cli-5 is missing)
%       A failed rung hands over to the next rung, so the component
%       that used to degenerate into thousands of SINGLEs is now
%       solved perfectly by the blossom5 rung.
%     2. SIZE GATE: components larger than opts.blossom6_max_nodes
%        (default 3000) never enter cli-6 (its reference
%        implementation is unboundedly slow on large instances).
%     3. WATCHDOG TIMEOUT on every CLI call (opts.cli_timeout_sec,
%        default 240): unix -> GNU coreutils "timeout"; Windows ->
%        "start /b" + done-file polling + "taskkill". No solver can
%        ever block the pipeline again, on any platform.
%     Every CLI result is VALIDATED before acceptance (pair count ==
%     nc/2, pairs form a permutation of all nodes, every pair is an
%     actual component edge) - a partial or garbage matching is
%     rejected and retried on the next rung, never trusted.
%
%   EFFICIENCY (round-03 user requirement): matrix/array operations
%     ONLY - no containers.Map, no contains(), no per-line fscanf.
%     File I/O is vectorized (one fprintf in, one textscan out),
%     validation uses sort / unique / ismember, CLI selection uses a
%     numeric .ver field instead of string matching.
%
%   Components with an odd node count (or where every rung fails)
%   stay unmatched (-1) and are resolved as SINGLEs by the extraction
%   stage - full coverage, no crash, no blocking.
%
%   INPUT:
%     graph       : from build_dual_graph_v32 (edges 0-based)
%     blossom_ver : 5 or 6 (preferred solver; the ladder guarantees
%                   a result either way)
%     debug       : verbose flag
%     opts        : optional struct:
%                     .blossom6_max_nodes (default 3000)
%                     .cli_timeout_sec    (default 240)
%   OUTPUT:
%     match : n_nodes x 1, 0-based partner, -1 = single
%     info  : .n_components, .n_solved, .n_fallback, .n_unmatched,
%             .method, .rung_counts [cli-6 cli-5 matlab], .time_sec

    t0 = tic;
    n = graph.n_nodes;
    E = graph.edges;
    W = graph.weights;
    info = struct('n_components', 0, 'n_solved', 0, 'n_fallback', 0, ...
                  'n_aux_used', 0, 'n_unmatched', 0, 'method', '', ...
                  'time_sec', 0, 'rung_counts', [0 0 0]);

    if nargin < 3 || isempty(debug); debug = false; end
    if nargin < 4 || isempty(opts); opts = struct(); end
    b6_gate = 3000;
    if isfield(opts, 'blossom6_max_nodes'); b6_gate = opts.blossom6_max_nodes; end
    cli_tmo = 240;
    if isfield(opts, 'cli_timeout_sec'); cli_tmo = opts.cli_timeout_sec; end

    % ---------- locate both CLIs once (numeric .ver, no string ops) ----------
    cli_main = find_blossom_cli_v32(blossom_ver);
    if blossom_ver == 5
        cli_alt = find_blossom_cli_v32(6);
    else
        cli_alt = find_blossom_cli_v32(5);
    end
    have_cli5 = (~isempty(cli_main.path) && cli_main.ver == 5) || ...
                (~isempty(cli_alt.path)  && cli_alt.ver == 5);
    have_cli6 = (~isempty(cli_main.path) && cli_main.ver == 6) || ...
                (~isempty(cli_alt.path)  && cli_alt.ver == 6);

    % ---------- union-find components (path-compressing) ----------
    parent = 1:n;
    for k = 1:size(E, 1)
        x = E(k,1) + 1;
        while parent(x) ~= x
            parent(x) = parent(parent(x)); x = parent(x);
        end
        y = E(k,2) + 1;
        while parent(y) ~= y
            parent(y) = parent(parent(y)); y = parent(y);
        end
        if x ~= y; parent(y) = x; end
    end
    root = zeros(n, 1);
    for i = 1:n
        r = i;
        while parent(r) ~= r; r = parent(r); end
        root(i) = r;
    end
    [~, ~, comp_id] = unique(root);
    n_comp = max(comp_id);
    info.n_components = n_comp;

    match = -ones(n, 1);
    n_solved = 0; n_fallback = 0;
    rung_counts = [0 0 0];   % [cli-6  cli-5  matlab] wins

    if debug
        fprintf('  [matching] pref=cli-%d (cli6=%d, cli5=%d) components=%d gate=%d tmo=%ds\n', ...
            blossom_ver, have_cli6, have_cli5, n_comp, b6_gate, cli_tmo);
    end

    for c = 1:n_comp
        nodes_c = find(comp_id == c);
        nc = numel(nodes_c);
        if mod(nc, 2) ~= 0
            n_fallback = n_fallback + 1;
            if debug
                fprintf('    comp %d: ODD (%d nodes) -> fallback\n', c, nc);
            end
            continue;
        end
        lmap = zeros(n, 1); lmap(nodes_c) = 0:nc-1;
        mask = comp_id(E(:,1) + 1) == c;
        sub = E(mask, :);
        subw = W(mask);
        sub(:,1) = lmap(sub(:,1) + 1);
        sub(:,2) = lmap(sub(:,2) + 1);
        if size(sub, 1) == 0
            n_fallback = n_fallback + 1;
            if debug
                fprintf('    comp %d: NO EDGES (%d nodes) -> fallback\n', c, nc);
            end
            continue;
        end

        tc = tic;
        [m_c, rung_used, fail_note] = solve_ladder_v32( ...
            nc, sub, subw, blossom_ver, cli_main, cli_alt, ...
            b6_gate, cli_tmo, debug, c);
        dt = toc(tc);

        if all(m_c >= 0) && rung_used > 0
            match(nodes_c) = nodes_c(m_c + 1) - 1;   % keep 0-based
            n_solved = n_solved + 1;
            rung_counts(rung_used) = rung_counts(rung_used) + 1;
            if debug
                fprintf('    comp %d: %d nodes %s OK (%.2fs)\n', ...
                    c, nc, rung_name_v32(rung_used, blossom_ver), dt);
            end
        else
            n_fallback = n_fallback + 1;
            if debug
                fprintf('    comp %d: %d nodes ALL-RUNGS-FAILED -> fallback (%s)\n', ...
                    c, nc, fail_note);
            end
        end
    end

    info.n_solved = n_solved;
    info.n_fallback = n_fallback;
    info.n_unmatched = sum(match < 0);
    info.rung_counts = rung_counts;
    if rung_counts(1) > 0 && rung_counts(2) > 0
        info.method = 'cli-6+cli-5';
    elseif rung_counts(1) > 0
        info.method = 'cli-6';
    elseif rung_counts(2) > 0
        info.method = 'cli-5';
    else
        info.method = 'matlab';
    end
    info.time_sec = toc(t0);
    if debug
        fprintf('  [matching] solved=%d fallback=%d unmatched=%d (cli6=%d cli5=%d matlab=%d) time=%.2fs\n', ...
            n_solved, n_fallback, info.n_unmatched, ...
            rung_counts(1), rung_counts(2), rung_counts(3), info.time_sec);
    end
end

% =====================================================================
function [m_c, rung_used, fail_note] = solve_ladder_v32( ...
    nc, sub, subw, blossom_ver, cli_main, cli_alt, b6_gate, cli_tmo, debug, comp_id)
%SOLVE_LADDER_V32  Try solver rungs in reliability order until one
%   returns a VALID perfect matching. Rung numbering:
%     1 = cli-6, 2 = cli-5, 3 = bounded MATLAB augmenting.
%   Returns m_c = -ones(nc,1) with fail_note if every rung failed.

    fail_note = '';
    m_c = -ones(nc, 1);
    rung_used = 0;

    cli6 = cli_of_ver_v32(cli_main, cli_alt, 6);
    cli5 = cli_of_ver_v32(cli_main, cli_alt, 5);

    % ---- ordered rung list (built without any string comparison) ----
    ladder = struct('kind', {}, 'cli', {});
    if blossom_ver == 6
        % preferred VI, but only within the size gate (or when V is
        % the only CLI available - the watchdog still bounds it)
        if ~isempty(cli6.path) && (nc <= b6_gate || isempty(cli5.path))
            ladder(end+1) = struct('kind', 1, 'cli', cli6); %#ok<AGROW>
        end
        if ~isempty(cli5.path)
            ladder(end+1) = struct('kind', 2, 'cli', cli5); %#ok<AGROW>
        end
    else
        if ~isempty(cli5.path)
            ladder(end+1) = struct('kind', 2, 'cli', cli5); %#ok<AGROW>
        end
        if ~isempty(cli6.path) && isempty(cli5.path)
            ladder(end+1) = struct('kind', 1, 'cli', cli6); %#ok<AGROW>
        end
    end
    % last resort: bounded pure-MATLAB augmenting matcher (never MEX -
    % an in-process segfault would kill the whole MATLAB session)
    ladder(end+1) = struct('kind', 3, 'cli', ...
        struct('path', '', 'desc', '', 'ver', 0)); %#ok<AGROW>

    % ---- walk the ladder ----
    for r = 1:numel(ladder)
        if ladder(r).kind == 3
            try
                if blossom_ver == 6
                    m_c = blossom6_solve_v30(nc, sub, subw, false, 'matlab');
                else
                    m_c = blossom5_solve_v30(nc, sub, subw, false, 'matlab');
                end
            catch
                m_c = -ones(nc, 1);
            end
            if all(m_c >= 0)
                rung_used = 3;
                return;
            end
            fail_note = 'matlab-augment incomplete';
            continue;
        end
        [m_c, why] = solve_cli_direct_v32(ladder(r).cli, nc, sub, subw, cli_tmo);
        if all(m_c >= 0)
            rung_used = ladder(r).kind;
            return;
        end
        if debug
            fprintf('    comp %d: cli-%d FAIL (%s) -> next rung\n', ...
                comp_id, ladder(r).kind, why);
        end
        fail_note = sprintf('cli-%d: %s', ladder(r).kind, why);
    end
end

% =====================================================================
function cli = cli_of_ver_v32(cli_main, cli_alt, ver)
%CLI_OF_VER_V32  Pick the CLI struct for version 5 or 6 by NUMERIC
%   .ver field (no contains/strcmp on descriptor strings - round-03
%   efficiency + Octave compatibility requirement).
    if cli_main.ver == ver && ~isempty(cli_main.path)
        cli = cli_main;
    elseif cli_alt.ver == ver && ~isempty(cli_alt.path)
        cli = cli_alt;
    else
        cli = struct('path', '', 'desc', sprintf('cli-%d', ver), 'ver', ver);
    end
end

% =====================================================================
function [m, why] = solve_cli_direct_v32(cli, nc, sub, subw, tmo)
%SOLVE_CLI_DIRECT_V32  One CLI call under the watchdog with vectorized
%   I/O and FULL output validation. m stays -1 (and why explains) on
%   any failure - the ladder then tries the next rung.
    m = -ones(nc, 1);
    why = '';
    tmp_in = [tempname '.txt'];
    tmp_out = [tempname '.match'];
    tmp_log = [tmp_in '.log'];

    fid = fopen(tmp_in, 'w');
    if fid < 0
        why = 'cannot write temp input';
        return;
    end
    fprintf(fid, '%d %d\n', nc, size(sub, 1));
    % one vectorized fprintf: rows of [i j w]
    fprintf(fid, '%d %d %.15g\n', [sub(:,1)'; sub(:,2)'; round(subw(:)')]);
    fclose(fid);

    [ok, reason] = run_cli_watchdog_v32(cli.path, tmp_in, tmp_out, tmp_log, tmo);
    if ~ok
        why = reason;
        clean_tmp_v32(tmp_in); clean_tmp_v32(tmp_out); clean_tmp_v32(tmp_log);
        return;
    end

    % ---- parse + validate (vectorized) ----
    fid = fopen(tmp_out, 'r');
    if fid < 0
        why = 'no output file';
        clean_tmp_v32(tmp_in);
        return;
    end
    C = textscan(fid, '%d %d', 'HeaderLines', 1);
    fclose(fid);
    clean_tmp_v32(tmp_in); clean_tmp_v32(tmp_out); clean_tmp_v32(tmp_log);
    pi_ = C{1}; pj = C{2};
    if numel(pi_) ~= nc / 2
        why = sprintf('pair count %d != nc/2', numel(pi_));
        return;
    end
    % pairs must be a permutation of 0..nc-1 (perfect, no self/dup)
    allv = double([pi_; pj]);
    if ~isequal(sort(allv), (0:nc-1)')
        why = 'pairs are not a permutation';
        return;
    end
    % every reported pair must be an actual component edge
    a = double(sub(:,1)); b = double(sub(:,2));
    ekey = unique(min(a, b) * nc + max(a, b));
    pkey = min(double(pi_), double(pj)) * nc + max(double(pi_), double(pj));
    if any(~ismember(pkey, ekey))
        why = 'matched pair is not an edge';
        return;
    end

    m(pi_ + 1) = pj;
    m(pj + 1) = pi_;
end

% =====================================================================
function [ok, reason] = run_cli_watchdog_v32(cli_path, tmp_in, tmp_out, tmp_log, tmo)
%RUN_CLI_WATCHDOG_V32  Run a blossom CLI with a HARD timeout on any
%   platform, so a slow or hung solver can never block the pipeline.
%     unix    : GNU coreutils "timeout <tmo> ..." (exit 124 on expiry)
%     windows : async "start /b" + temp .bat + done-file polling +
%               "taskkill /f /im" on expiry (system() alone has NO
%               timeout on Windows - that was the round-03 dead loop)
%   The caller validates the output file contents regardless of the
%   exit code, so a killed or failing process cannot sneak a partial
%   result through.
    reason = '';
    if isunix
        cmd = sprintf('timeout %d "%s" "%s" "%s" 0 2> "%s"', ...
            tmo, cli_path, tmp_in, tmp_out, tmp_log);
        try
            status = system(cmd);
        catch
            status = -1;
        end
        if status == 0
            ok = true;
            return;
        end
        if status == 124
            reason = sprintf('watchdog timeout (%ds)', tmo);
        else
            reason = first_log_line_v32(tmp_log);
            if isempty(reason)
                reason = sprintf('exit status %d', status);
            end
        end
        ok = false;
        return
    end

    % ---- Windows watchdog ----
    done_f = [tmp_in '.done'];
    bat_f  = [tmp_in '.bat'];
    fid = fopen(bat_f, 'w');
    if fid < 0
        ok = false;
        reason = 'cannot write watchdog .bat';
        return;
    end
    % .bat: run the CLI synchronously INSIDE the async cmd, then write
    % the exit code to the done-file (per-line %errorlevel% is
    % evaluated at execution time, which is what we need)
    fprintf(fid, '@echo off\r\n');
    fprintf(fid, '"%s" "%s" "%s" 0 > "%s" 2>&1\r\n', ...
        cli_path, tmp_in, tmp_out, tmp_log);
    fprintf(fid, 'echo %%errorlevel%% > "%s"\r\n', done_f);
    fclose(fid);

    system(sprintf('start /b "" "%s"', bat_f));   % async, no window
    t0 = tic;
    while ~exist(done_f, 'file') && toc(t0) < tmo
        pause(0.25);
    end
    if exist(done_f, 'file')
        ok = true;     % process ended; output validated by the caller
        reason = '';
    else
        ok = false;    % watchdog expired -> kill the solver
        [~, exe_name] = fileparts(cli_path);
        system(sprintf('taskkill /f /im "%s.exe" > NUL 2>&1', exe_name));
        reason = sprintf('watchdog timeout (%ds), solver killed', tmo);
    end
    clean_tmp_v32(bat_f);
    clean_tmp_v32(done_f);
end

% =====================================================================
function s = first_log_line_v32(log_f)
%FIRST_LOG_LINE_V32  First non-empty line of a CLI stderr log,
%   truncated to 90 chars (failure diagnostics only).
    s = '';
    try
        if exist(log_f, 'file') ~= 2; return; end
        fid = fopen(log_f, 'r');
        if fid < 0; return; end
        raw = fread(fid, '*char')';
        fclose(fid);
        raw = strtrim(raw);
        if isempty(raw); return; end
        k = find(raw == char(10), 1);
        if ~isempty(k); raw = raw(1:k-1); end
        if numel(raw) > 90; raw = [raw(1:90) '...']; end
        s = strtrim(raw);
    catch
        s = '';
    end
end

% =====================================================================
function clean_tmp_v32(fn)
%CLEAN_TMP_V32  Best-effort temp file removal (never throws).
    try
        if exist(fn, 'file'); delete(fn); end
    catch
    end
end

% =====================================================================
function cli = find_blossom_cli_v32(blossom_ver)
%FIND_BLOSSOM_CLI_V32  Locate a blossom CLI executable.
%   Search order: which() -> pwd -> pwd/blossom5_src|blossom6_src.
%   The returned struct carries a numeric .ver field so later
%   selection needs no string operations at all.
    if ispc; ext = '.exe'; else; ext = ''; end
    if blossom_ver == 5; base = 'blossom5_cli'; dirn = 'blossom5_src';
    else;             base = 'blossom6_cli'; dirn = 'blossom6_src';
    end
    cand = {};
    w = which(base);
    if ~isempty(w); cand{end+1} = w; end %#ok<AGROW>
    cand{end+1} = fullfile(pwd, [base ext]); %#ok<AGROW>
    cand{end+1} = fullfile(pwd, dirn, [base ext]); %#ok<AGROW>
    cli = struct('path', '', 'desc', sprintf('cli-%d', blossom_ver), ...
                 'ver', blossom_ver);
    for i = 1:numel(cand)
        if exist(cand{i}, 'file') == 2 || exist(cand{i}, 'file') == 3
            cli.path = cand{i};
            return;
        end
    end
    cli.desc = sprintf('cli-%d-missing', blossom_ver);
end

% =====================================================================
function s = rung_name_v32(rung, blossom_ver)
%RUNG_NAME_V32  Human-readable solver name for logging.
    switch rung
        case 1
            s = 'cli-6';
        case 2
            s = 'cli-5';
        case 3
            if blossom_ver == 6
                s = 'matlab-augment(b6)';
            else
                s = 'matlab-augment(b5)';
            end
        otherwise
            s = '?';
    end
end
