function [tri, info] = optimize_tri_mesh_v32(node, tri, debug)
%OPTIMIZE_TRI_MESH_V32  Improve triangle mesh for quad-pairing quality.
%
%   Two operations per pass (interior edges only; boundary untouched):
%     A. DELAUNAY flip — exact in-circle predicate: for interior edge
%        shared by CCW triangles (a,b,c),(b,a,d), flip (a,b)->(c,d) when
%        d lies strictly inside the circumcircle of (a,b,c).
%     B. MAX-MIN-ANGLE (quad-friendly) flip — flip when the two new
%        triangles have strictly better minimum corner angle than the two
%        old ones (drives triangles toward right-isosceles, ideal for
%        pairing into squares; cf. Blossom-Quad L-infinity strategy).
%   Convexity guard on the flip quad; CCW preserved; vectorized scan per
%   pass with per-flip re-validation.
%
%   INPUT/OUTPUT: standard mesh arguments (tri modified, node unchanged)

    info = struct('n_delaunay_flips', 0, 'n_quad_flips', 0, 'n_passes', 0);
    max_passes = 8;

    for pass = 1:max_passes
        n_del = delaunay_pass_v32(node, tri);
        n_quad = maxmin_pass_v32(node, tri);
        info.n_delaunay_flips = info.n_delaunay_flips + n_del;
        info.n_quad_flips = info.n_quad_flips + n_quad;
        info.n_passes = pass;
        if debug
            fprintf('  [tri-opt pass %d] delaunay=%d quad-friendly=%d\n', ...
                pass, n_del, n_quad);
        end
        if n_del + n_quad == 0; break; end
    end
end

% =====================================================================
function [ti, tj, va, vb, vc, vd] = interior_edge_list_v32(tri)
%INTERIOR_EDGE_LIST_V32  All interior edges with (ti<tj), endpoints and
%   apexes. Returns column vectors; nbr(i,j) edge j of tri i is
%   (tri(i,mod(j,3)+1), tri(i,mod(j+1,3)+1)), apex is tri(i,j).
    nbr = compute_neighbors_fast(tri);
    ntri = size(tri, 1);
    ti = repmat((1:ntri)', 3, 1);
    ej = repmat((1:3)', 1, ntri)';
    ti = ti(:); ej = ej(:);
    idx = sub2ind([ntri, 3], ti, ej);
    nb = nbr(idx);                       % neighbor triangle across local edge ej
    mask = nb > 0 & ti < nb;
    ti = ti(mask); ej = ej(mask); tj = nb(mask);
    va = tri(sub2ind([ntri, 3], ti, mod(ej, 3) + 1));
    vb = tri(sub2ind([ntri, 3], ti, mod(ej + 1, 3) + 1));
    vc = tri(sub2ind([ntri, 3], ti, ej));
    % vd = element of tri(tj,:) not in {va,vb} (vectorized)
    rowsT = tri(tj, :);
    notab = ~(rowsT == va | rowsT == vb);
    vd = zeros(size(va));
    for cc = 1:3   % column-major safe extraction (row order preserved)
        sel = notab(:, cc);
        vd(sel) = rowsT(sel, cc);
    end
    vd = vd(:);
end

% =====================================================================
function n_flip = delaunay_pass_v32(node, tri)
%DELAUNAY_PASS_V32  One pass of exact in-circle Delaunay flips.
    [ti, tj, va, vb, vc, vd] = interior_edge_list_v32(tri);
    n_flip = 0;
    if isempty(ti); return; end

    inside = incircle_rel_v32(node, va, vb, vc, vd);
    cand = find(inside);
    for k = cand(:)'
        if ~edge_still_valid_v32(tri, ti(k), tj(k), va(k), vb(k)); continue; end
        if ~quad_convex_ccw_v32(node, va(k), vb(k), vc(k), vd(k)); continue; end
        apply_flip_v32(tri, ti(k), tj(k), va(k), vb(k), vc(k), vd(k));
        n_flip = n_flip + 1;
    end
end

% =====================================================================
function n_flip = maxmin_pass_v32(node, tri)
%MAXMIN_PASS_V32  One pass of max-min-angle (quad-friendly) flips.
    [ti, tj, va, vb, vc, vd] = interior_edge_list_v32(tri);
    n_flip = 0;
    if isempty(ti); return; end

    ang_old = min(tri_min_angle_v32v(node, va, vb, vc), ...
                  tri_min_angle_v32v(node, vb, va, vd));
    ang_new = min(tri_min_angle_v32v(node, vc, vd, va), ...
                  tri_min_angle_v32v(node, vd, vc, vb));
    convex = quad_convex_ccw_v32(node, va, vb, vc, vd);
    cand = find((ang_new > ang_old + 0.05) & convex);
    for k = cand(:)'
        if ~edge_still_valid_v32(tri, ti(k), tj(k), va(k), vb(k)); continue; end
        if ~quad_convex_ccw_v32(node, va(k), vb(k), vc(k), vd(k)); continue; end
        apply_flip_v32(tri, ti(k), tj(k), va(k), vb(k), vc(k), vd(k));
        n_flip = n_flip + 1;
    end
end

% =====================================================================
function ok = edge_still_valid_v32(tri, t1, t2, va, vb)
%EDGE_STILL_VALID_V32  t1,t2 exist and still share edge (va,vb).
    if t1 > size(tri,1) || t2 > size(tri,1); ok = false; return; end
    r1 = tri(t1, :); r2 = tri(t2, :);
    ok = any(r1 == va) && any(r1 == vb) && any(r2 == va) && any(r2 == vb) && ...
         sum(ismember(r1, r2)) == 2;
end

% =====================================================================
function apply_flip_v32(tri, t1, t2, a, b, c, d)
%APPLY_FLIP_V32  Replace shared edge (a,b) of t1,t2 by (c,d).
%   Quad polygon (c,a,d,b) is CCW-convex (guarded by caller).
%   New triangles: (c,a,d) and (c,d,b) — both CCW.
    tri(t1, :) = [c, a, d];
    tri(t2, :) = [c, d, b];
end

% =====================================================================
function inside = incircle_ccw_v32(node, a, b, c, d)
%INCIRCLE_CCW_V32  Vectorized in-circle test: d strictly inside the
%   circumcircle of CCW triangle (a,b,c). Since the mesh is CCW and
%   (a,b,c) is a cyclic rotation of tri i, (a,b,c) is always CCW here,
%   so the test reduces to det > 0.
    ax = node(a,1) - node(d,1);  ay = node(a,2) - node(d,2);
    bx = node(b,1) - node(d,1);  by = node(b,2) - node(d,2);
    cx = node(c,1) - node(d,1);  cy = node(c,2) - node(d,2);
    aa = ax.*ax + ay.*ay;  bb = bx.*bx + by.*by;  cc = cx.*cx + cy.*cy;
    det = ax.*(by.*cc - bb.*cy) - ay.*(bx.*cc - bb.*cx) + ...
          aa.*(bx.*cy - by.*cx);
    inside = det > 0;
end

% =====================================================================
function ok = quad_convex_ccw_v32(node, a, b, c, d)
%QUAD_CONVEX_Ccw_V32  Quad polygon (c,a,d,b) strictly convex (vectorized).
    p1 = node(c, :); p2 = node(a, :); p3 = node(d, :); p4 = node(b, :);
    cr1 = cross_rows_v32(p1, p2, p3);
    cr2 = cross_rows_v32(p2, p3, p4);
    cr3 = cross_rows_v32(p3, p4, p1);
    cr4 = cross_rows_v32(p4, p1, p2);
    ok = cr1 > 0 & cr2 > 0 & cr3 > 0 & cr4 > 0;
end

function cr = cross_rows_v32(p1, p2, p3)
%CROSS_ROWS_V32  Row-wise cross (p2-p1)x(p3-p2).
    cr = (p2(:,1)-p1(:,1)).*(p3(:,2)-p2(:,2)) - ...
         (p2(:,2)-p1(:,2)).*(p3(:,1)-p2(:,1));
end

% =====================================================================
function ma = tri_min_angle_v32v(node, v1, v2, v3)
%TRI_MIN_ANGLE_V32V  Vectorized min corner angle (deg) of triangles.
    p1 = node(v1,:); p2 = node(v2,:); p3 = node(v3,:);
    a1 = angle_rows_v32(p2-p1, p3-p1);
    a2 = angle_rows_v32(p1-p2, p3-p2);
    % third angle via cosine law to stay vectorized
    e1 = p2 - p1; e2 = p3 - p1; e3 = p3 - p2;
    l1 = sqrt(sum(e1.^2, 2)); l2 = sqrt(sum(e2.^2, 2)); l3 = sqrt(sum(e3.^2, 2));
    cos3 = (l1.^2 + l2.^2 - l3.^2) ./ (2 * l1 .* l2 + 1e-300);
    a3 = acosd(max(-1, min(1, cos3)));
    ma = min([a1; a2; a3]);
end

function ang = angle_rows_v32(u, v)
    nu = sqrt(sum(u.^2, 2)); nv = sqrt(sum(v.^2, 2));
    cs = (u(:,1).*v(:,1) + u(:,2).*v(:,2)) ./ (nu .* nv + 1e-300);
    ang = acosd(max(-1, min(1, cs)));
end

% =====================================================================
function inside = incircle_rel_v32(node, a, b, c, d)
%INCIRCLE_REL_V32  In-circle test with RELATIVE tolerance to avoid
%   oscillating flips on (near-)cocircular configurations: normalized
%   determinant must exceed 1e-9.
    ax = node(a,1) - node(d,1);  ay = node(a,2) - node(d,2);
    bx = node(b,1) - node(d,1);  by = node(b,2) - node(d,2);
    cx = node(c,1) - node(d,1);  cy = node(c,2) - node(d,2);
    aa = ax.*ax + ay.*ay;  bb = bx.*bx + by.*by;  cc = cx.*cx + cy.*cy;
    det = ax.*(by.*cc - bb.*cy) - ay.*(bx.*cc - bb.*cx) + ...
          aa.*(bx.*cy - by.*cx);
    % scale: product of the 4 flip-quad side lengths
    lab = sqrt(aa); lcd = sqrt(bb); lbd = sqrt(cc);
    lac = sqrt((node(a,1)-node(c,1)).^2 + (node(a,2)-node(c,2)).^2);
    lcb = sqrt((node(c,1)-node(b,1)).^2 + (node(c,2)-node(b,2)).^2);
    scale = (lab .* lcb .* lcd .* lbd);
    inside = det > 1e-9 .* max(scale, 1e-300);
end
