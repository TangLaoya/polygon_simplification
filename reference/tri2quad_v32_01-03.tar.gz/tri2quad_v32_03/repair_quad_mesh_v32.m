function [quadnode, quad, info] = repair_quad_mesh_v32(quadnode, quad, debug)
% (the center-split fallback appends one quad per application)
%REPAIR_QUAD_MESH_V32  Safe topological repair of concave / inverted /
%   near-degenerate quads via 2-quad diagonal swaps (topology preserving).
%
%   For each bad quad (one reflex corner or fully CW), take the quad pair
%   formed with the neighbor across the edge OPPOSITE the reflex corner.
%   The pair forms a hexagon; try all 3 diagonals; apply the one that
%   maximizes the pair minimum corner angle (strict improvement, both
%   children strictly convex). Boundary edges are never broken: only the
%   shared interior edge of the pair changes.

    if nargin < 3; debug = false; end
    info = struct('n_swaps', 0, 'n_passes', 0, 'n_remaining_bad', 0);

    nq = size(quad, 1);
    locked = false(nq, 1);   % persistent across passes (no ping-pong)
    for pass = 1:6
        % guard arrays stay in sync with quad rows appended by the
        % center-split fallback (V32-02 robustness fix)
        if numel(locked) < size(quad, 1)
            locked(end+1:size(quad,1)) = false;
        end
        [bad_idx, bad_kind] = find_bad_quads_v32(quadnode, quad);
        if isempty(bad_idx); break; end
        n_swapped = 0;
        used = locked;
        nq = size(quad, 1);   % rows may grow (center-split) — rebuild per pass
        % edge-owner lookup (rebuilt per pass, vectorized keys)
        A = [quad(:,[2 3]); quad(:,[3 4]); quad(:,[4 1]); quad(:,[1 2])];
        owner = repmat((1:nq)', 4, 1);
        K = max(max(quad)) + 2;
        ekey = min(A(:,1), A(:,2)) * K + max(A(:,1), A(:,2));
        [skey, sord] = sort(ekey);
        for bi = 1:numel(bad_idx)
            qi = bad_idx(bi);
            if used(qi); continue; end
            pv = problem_vertex_v32(quadnode, quad, qi, bad_kind(bi));
            if pv < 1; continue; end
            qv = quad(qi, :);
            pos_pv = find(qv == pv, 1);
            if isempty(pos_pv); continue; end
            % try the edge OPPOSITE the problem vertex first, then the
            % two edges ADJACENT to it (3 neighbor options total)
            opp = mod(pos_pv + 1, 4) + 1;
            adj1 = pos_pv;                        % edge (pv_prev, pv)?? use cyclic
            adj2 = mod(pos_pv, 4) + 1;            % edge (pv, pv_next)
            slots = [opp, adj1, adj2];
            ok = false;
            for si = 1:3
                e1 = qv(slots(si)); e2 = qv(mod(slots(si), 4) + 1);
                qj = lookup_owner_v32(min(e1,e2), max(e1,e2), skey, sord, owner, K, qi);
                if qj < 1 || used(qj) || locked(qj); continue; end
                ok = try_hexagon_resplit_v32(quadnode, quad, qi, qj, e1, e2);
                if ~ok
                    [ok, quadnode, quad] = try_hexagon_center_split_v32(quadnode, quad, qi, qj, e1, e2);
                end
                if ok
                    used(qi) = true; used(qj) = true;
                    locked(qi) = true; locked(qj) = true;
                    n_swapped = n_swapped + 1;
                    break;
                end
            end
        end
        info.n_swaps = info.n_swaps + n_swapped;
        info.n_passes = pass;
        if debug
            fprintf('  [repair pass %d] bad=%d swapped=%d\n', pass, numel(bad_idx), n_swapped);
            
        end
        if n_swapped == 0; break; end
    end

    [bad_idx, ~] = find_bad_quads_v32(quadnode, quad);
    info.n_remaining_bad = numel(bad_idx);
    if debug
        fprintf('  [repair] done: swaps=%d remaining-bad=%d\n', info.n_swaps, info.n_remaining_bad);
        
    end
end

% =====================================================================
function [bad_idx, bad_kind] = find_bad_quads_v32(quadnode, quad)
%FIND_BAD_QUADS_V32  Quads with a reflex (>=180) or inverted corner.
    p1 = quadnode(quad(:,1), :); p2 = quadnode(quad(:,2), :);
    p3 = quadnode(quad(:,3), :); p4 = quadnode(quad(:,4), :);
    c1 = crossr_v32(p1, p2, p3); c2 = crossr_v32(p2, p3, p4);
    c3 = crossr_v32(p3, p4, p1); c4 = crossr_v32(p4, p1, p2);
    cr = [c1, c2, c3, c4];
    concave = any(cr <= 0, 2) & any(cr > 0, 2);
    inverted = all(cr <= 0, 2);
    bad_idx = find(concave | inverted); bad_idx = bad_idx(:);
    bad_kind = ones(numel(bad_idx), 1);
    bad_kind(inverted(bad_idx)) = 2;
end

% =====================================================================
function pv = problem_vertex_v32(quadnode, quad, qi, kind)
%PROBLEM_VERTEX_V32  Vertex at the worst corner of quad qi.
    qv = quad(qi, :);
    p1 = quadnode(qv(1), :); p2 = quadnode(qv(2), :);
    p3 = quadnode(qv(3), :); p4 = quadnode(qv(4), :);
    cr = [cross_pt_v32(p1,p2,p3), cross_pt_v32(p2,p3,p4), ...
          cross_pt_v32(p3,p4,p1), cross_pt_v32(p4,p1,p2)];
    if kind == 2
        [~, w] = min(cr);
    else
        w = find(cr <= 0, 1);
        if isempty(w); w = 1; end
    end
    pv = qv(w);
end

% =====================================================================
function qj = lookup_owner_v32(lo, hi, skey, sord, owner, K, exclude_q)
%LOOKUP_OWNER_V32  Quad owning edge (lo,hi), excluding exclude_q.
    want = lo * K + hi;
    lo_i = 1; hi_i = numel(skey); hits = [];
    while lo_i <= hi_i
        mid = floor((lo_i + hi_i) / 2);
        if skey(mid) == want
            hits = mid;
            % scan duplicates
            k = mid - 1;
            while k >= 1 && skey(k) == want; hits = [hits, k]; k = k - 1; end
            k = mid + 1;
            while k <= numel(skey) && skey(k) == want; hits = [hits, k]; k = k + 1; end
            break;
        elseif skey(mid) < want
            lo_i = mid + 1;
        else
            hi_i = mid - 1;
        end
    end
    qj = -1;
    for h = hits(:)'
        cand = owner(sord(h));
        if cand ~= exclude_q
            qj = cand; return;
        end
    end
end

% =====================================================================
function ok = try_hexagon_resplit_v32(quadnode, quad, qi, qj, e1, e2)
%TRY_HEXAGON_RESPLIT_V32  3-diagonal re-split of the hexagon formed by
%   quads qi,qj sharing edge (e1,e2). Apply best strictly-improving one.
    ok = false;
    a = quad(qi, :); b = quad(qj, :);
    [x1a, ok1] = outer_nbr_v32(a, e1, e2);
    [x2a, ok2] = outer_nbr_v32(a, e2, e1);
    [x1b, ok3] = outer_nbr_v32(b, e1, e2);
    [x2b, ok4] = outer_nbr_v32(b, e2, e1);
    if ~(ok1 && ok2 && ok3 && ok4); return; end
    hexv = [x1a, e1, x1b, x2b, e2, x2a];
    if numel(unique(hexv)) ~= 6; return; end
    d1 = [hexv(1), hexv(4)];
    d2 = [hexv(2), hexv(5)];
    d3 = [hexv(3), hexv(6)];
    diag_list = {d1, d2, d3};
    cur_bad = pair_bad_corners_v32(quadnode, quad(qi,:), quad(qj,:));
    best_score = pair_min_angle_v32(quadnode, quad(qi,:), quad(qj,:));
    best_bad = cur_bad;
    best_q1 = []; best_q2 = [];
    for d = 1:3
        dg = diag_list{d};
        [s1, s2] = hex_sides_v32(hexv, dg);
        if isempty(s1); continue; end
        if ~is_convex4_v32(quadnode(s1,:)) || ~is_convex4_v32(quadnode(s2,:))
            continue;
        end
        sc = pair_min_angle_v32(quadnode, s1, s2);
        nb_bad = pair_bad_corners_v32(quadnode, s1, s2);   % = 0 (convex)
        % accept if strictly fewer bad corners, or same-but-better angle
        if nb_bad < best_bad || (nb_bad == best_bad && sc > best_score + 1e-9)
            best_score = sc; best_bad = nb_bad; best_q1 = s1; best_q2 = s2;
        end
    end
    if isempty(best_q1); return; end
    quad(qi, :) = orient_ccw_v32(quadnode, best_q1);
    quad(qj, :) = orient_ccw_v32(quadnode, best_q2);
    ok = true;
end

% =====================================================================
function [x, ok] = outer_nbr_v32(qv, v, other)
%OUTER_NBR_V32  Neighbor of vertex v in quad qv that is not `other`.
    x = 0; ok = false;
    for t = 1:4
        e1 = qv(t); e2 = qv(mod(t,4)+1);
        if e1 == v && e2 ~= other; x = e2; ok = true; return; end
        if e2 == v && e1 ~= other; x = e1; ok = true; return; end
    end
end

% =====================================================================
function [s1, s2] = hex_sides_v32(h, dg)
%HEX_SIDES_V32  Two 4-vertex sides of hexagon h split by diagonal dg
%   (empty if dg endpoints are not opposite vertices).
    s1 = []; s2 = [];
    p1 = find(h == dg(1), 1); p2 = find(h == dg(2), 1);
    if isempty(p1) || isempty(p2); return; end
    if p1 > p2; tmp = p1; p1 = p2; p2 = tmp; end
    if p2 - p1 ~= 3; return; end
    s1 = [h(p1), h(p1+1), h(p1+2), h(p1+3)];
    s2 = [h(p2), h(mod(p2,6)+1), h(mod(p2+1,6)+1), h(p1)];
end

% =====================================================================
function sc = pair_min_angle_v32(P, q1, q2)
    sc = min(min_angle4_v32(P(q1,:)), min_angle4_v32(P(q2,:)));
end

function tf = is_convex4_v32(QP)
    tf = true;
    for t = 1:4
        c = cross_pt_v32(QP(t,:), QP(mod(t,4)+1,:), QP(mod(t+1,4)+1,:));
        if c <= 0; tf = false; return; end
    end
end

function ma = min_angle4_v32(QP)
    ma = inf;
    for t = 1:4
        v1 = QP(t,:) - QP(mod(t,4)+1,:);
        v2 = QP(mod(t+1,4)+1,:) - QP(mod(t,4)+1,:);
        n1 = norm(v1); n2 = norm(v2);
        if n1 < 1e-300 || n2 < 1e-300; ma = -inf; return; end
        cs = (v1(1)*v2(1)+v1(2)*v2(2)) / (n1*n2);
        ma = min(ma, acosd(max(-1, min(1, cs))));
    end
end

function c = crossr_v32(p1, p2, p3)
    c = (p2(:,1)-p1(:,1)).*(p3(:,2)-p2(:,2)) - ...
        (p2(:,2)-p1(:,2)).*(p3(:,1)-p2(:,1));
end

function c = cross_pt_v32(p1, p2, p3)
    c = (p2(1)-p1(1))*(p3(2)-p2(2)) - (p2(2)-p1(2))*(p3(1)-p2(1));
end

% =====================================================================
function qv = orient_ccw_v32(P, qv)
    s = 0;
    for t = 1:4
        s = s + P(qv(t),1)*P(qv(mod(t,4)+1),2) - P(qv(mod(t,4)+1),1)*P(qv(t),2);
    end
    if s < 0; qv = qv([1 4 3 2]); end
end

% =====================================================================
function n = pair_bad_corners_v32(P, q1, q2)
%PAIR_BAD_CORNERS_V32  Count of non-positive corners in the two quads.
    n = count_bad_v32(P, q1) + count_bad_v32(P, q2);
end

function n = count_bad_v32(P, qv)
    n = 0;
    for t = 1:4
        c = cross_pt_v32(P(qv(t),:), P(qv(mod(t,4)+1),:), P(qv(mod(t+1,4)+1),:));
        if c <= 0; n = n + 1; end
    end
end

% =====================================================================
function [ok, quadnode, quad] = try_hexagon_center_split_v32(quadnode, quad, qi, qj, e1, e2)
%TRY_HEXAGON_CENTER_SPLIT_V32  Last-resort: merge quads qi,qj into their
%   hexagon and re-split into 3 quads through a new center vertex o.
%   Children: (h1,h2,h3,o),(h3,h4,h5,o),(h5,h6,h1,o). Accepted only if
%   all three are non-bowtie with strictly positive corner crosses.
    ok = false;
    a = quad(qi, :); b = quad(qj, :);
    [x1a, ok1] = outer_nbr_v32(a, e1, e2);
    [x2a, ok2] = outer_nbr_v32(a, e2, e1);
    [x1b, ok3] = outer_nbr_v32(b, e1, e2);
    [x2b, ok4] = outer_nbr_v32(b, e2, e1);
    if ~(ok1 && ok2 && ok3 && ok4); return; end
    h = [x1a, e1, x1b, x2b, e2, x2a];
    if numel(unique(h)) ~= 6; return; end
    o = mean(quadnode(h, :), 1);
    c1 = [h(1), h(2), h(3), -1];   % -1 = new center (placeholder)
    % evaluate children with o
    T1 = [quadnode(h(1:3),:); o];
    T2 = [quadnode(h(3:5),:); o];
    T3 = [quadnode(h(5:6),:); quadnode(h(1),:); o];
    if ~all_pos_corners_v32(T1) || ~all_pos_corners_v32(T2) || ~all_pos_corners_v32(T3)
        return;
    end
    % apply: reuse qi row, append two rows
    quadnode(end+1, :) = o;
    oid = size(quadnode, 1);
    quad(qi, :) = [h(1), h(2), h(3), oid];
    quad(qj, :) = [h(3), h(4), h(5), oid];
    quad(end+1, :) = [h(5), h(6), h(1), oid];
    ok = true;
end

function tf = all_pos_corners_v32(QP)
    tf = true;
    for t = 1:4
        c = cross_pt_v32(QP(t,:), QP(mod(t,4)+1,:), QP(mod(t+1,4)+1,:));
        if c <= 0; tf = false; return; end
    end
end
