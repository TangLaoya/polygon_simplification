function [node, tri, info] = fix_boundary_parity_v32(node, tri, debug)
%FIX_BOUNDARY_PARITY_V32  Make every closed boundary loop have an EVEN
%   number of edges by splitting exactly one edge of each odd loop.
%
%   Parity theorem (Blossom-Quad, Remacle et al. IJNME 2012; Ramaswami et
%   al. CCCG 1997): a triangulated region admits an all-quad mesh by pure
%   triangle-pair merging  <=>  every boundary loop has an even number of
%   edges (since 3T = 2*Eint + Ebnd  =>  T == Ebnd mod 2 per component).
%
%   Split rule: among the 25% LONGEST edges of the odd loop, pick the one
%   whose midpoint-split maximizes the minimum angle of the two resulting
%   triangles. The new midpoint lies exactly ON the segment, so the
%   boundary geometry is 100% preserved (only one extra collinear vertex).
%
%   INPUT:
%     node, tri : triangle mesh (1-indexed, CCW)
%     debug     : verbose flag
%
%   OUTPUT:
%     node, tri : mesh with all boundary loops even
%     info      : n_odd_loops, n_splits, split_edges (k x 2)

    info = struct('n_odd_loops', 0, 'n_splits', 0, 'split_edges', []);
    loops = find_boundary_loops(node, tri);

    for li = 1:numel(loops)
        lp = loops{li};
        L = numel(lp);
        if mod(L, 2) == 0; continue; end   % already even
        if L < 3; continue; end
        info.n_odd_loops = info.n_odd_loops + 1;

        % candidate edges: the longest 25% of the loop (min 1)
        ev = node(lp, :);
        nxt = [ev(2:end, :); ev(1, :)];
        elen = sqrt(sum((nxt - ev).^2, 2));
        thr = max(prctile_v32(elen, 75), 0);
        cand_idx = find(elen >= thr);
        if isempty(cand_idx); cand_idx = find(elen == max(elen)); end

        % find adjacent triangle for each candidate edge
        best_i = 0; best_score = -inf;
        for ii = 1:numel(cand_idx)
            i = cand_idx(ii);
            va = lp(i); vb = lp(mod(i, L) + 1);
            tid = find_triangle_with_edge_v32(tri, va, vb);
            if tid < 1; continue; end
            t = tri(tid, :);
            vop = setdiff(t, [va, vb]);
            if numel(vop) ~= 1; continue; end
            vop = vop(1);
            M = 0.5 * (node(va, :) + node(vb, :));
            a1 = tri_min_angle_pts_v32p([node(va,:); M; node(vop,:)]);
            a2 = tri_min_angle_pts_v32p([node(vop,:); M; node(vb,:)]);
            score = min(a1, a2);
            if score > best_score
                best_score = score;
                best_i = i;
            end
        end
        if best_i == 0
            % extremely defensive fallback: split the longest edge
            [~, best_i] = max(elen);
        end

        va = lp(best_i); vb = lp(mod(best_i, L) + 1);
        tid = find_triangle_with_edge_v32(tri, va, vb);
        if tid < 1
            if debug
                fprintf('  [parity] WARNING: loop %d edge (%d,%d) has no triangle; skipped\n', ...
                    li, va, vb);
            end
            continue;
        end
        vop = setdiff(tri(tid, :), [va, vb]);
        if numel(vop) ~= 1; continue; end
        vop = vop(1);

        % insert midpoint vertex and split triangle tid into two
        M = 0.5 * (node(va, :) + node(vb, :));
        node(end+1, :) = M;
        vm = size(node, 1);
        % keep CCW orientation of the two children
        tri(tid, :) = [va, vm, vop];
        tri(end+1, :) = [vm, vb, vop];
        info.n_splits = info.n_splits + 1;
        info.split_edges(end+1, :) = [va, vb]; %#ok<AGROW>
    end

    if debug
        fprintf('  [parity] odd loops=%d, splits=%d (+%d vtx, +%d tri)\n', ...
            info.n_odd_loops, info.n_splits, info.n_splits, info.n_splits);
    end
end

% =====================================================================
function p = prctile_v32(x, pct)
%PRCTILE_V32  Simple percentile (linear interpolation, like MATLAB).
    x = sort(x(:));
    n = numel(x);
    if n == 0; p = NaN; return; end
    if n == 1; p = x(1); return; end
    r = 1 + (pct / 100) * (n - 1);
    r0 = floor(r); r1 = ceil(r);
    if r0 < 1; r0 = 1; end
    if r1 > n; r1 = n; end
    if r0 == r1
        p = x(r0);
    else
        p = x(r0) + (r - r0) * (x(r1) - x(r0));
    end
end

% =====================================================================
function tid = find_triangle_with_edge_v32(tri, va, vb)
%FIND_TRIANGLE_WITH_EDGE_V32  First triangle containing both va and vb.
    tid = find(any(tri == va, 2) & any(tri == vb, 2), 1);
    if isempty(tid); tid = 0; end
end

% =====================================================================
function ma = tri_min_angle_v32(node, vids)
%TRI_MIN_ANGLE_V32  Min angle (deg) of triangle given 3 vertex ids.
    ma = tri_min_angle_pts_v32p(node(vids, :));
end

function ma = tri_min_angle_pts_v32p(p)
    v1 = p(2,:) - p(1,:); v2 = p(3,:) - p(1,:); v3 = p(3,:) - p(2,:);
    a1 = ang2_v32(v1, v2);
    a2 = ang2_v32(-v1, v3);
    a3 = 180 - a1 - a2;
    ma = min([a1, a2, max(a3, 0)]);
end

function ang = ang2_v32(v1, v2)
    n1 = norm(v1); n2 = norm(v2);
    if n1 < 1e-300 || n2 < 1e-300; ang = 0; return; end
    c = max(-1, min(1, (v1(1)*v2(1) + v1(2)*v2(2)) / (n1 * n2)));
    ang = acosd(c);
end
