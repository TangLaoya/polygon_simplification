function [quadnode, quad, n_merged] = merge_duplicate_vertices_v30(quadnode, quad, nnode_orig)
%MERGE_DUPLICATE_VERTICES_V30  Merge vertices at the same (x,y) location.
%   When two adjacent ghost triangles both use centroid_split_full, each
%   creates its OWN midpoint on the shared edge (same location, different
%   vertex ids) => non-manifold edges / isolated triangles. This function
%   merges such duplicates. Boundary vertices (id <= nnode_orig) are
%   preferred as canonical reference.

    n_merged = 0;
    nqn = size(quadnode, 1);
    if nqn == 0; return; end

    crange = range(quadnode(:));
    if crange < 1e-15; crange = 1; end
    tol = 1e-8 * crange;

    grid = round(quadnode / tol);
    [uniq_grid, ~, grid_ic] = unique(grid, 'rows');

    rep = (1:nqn)';
    for c = 1:size(uniq_grid, 1)
        members = find(grid_ic == c);
        if length(members) < 2; continue; end
        canon = members(1);
        for m = 1:length(members)
            if members(m) <= nnode_orig
                canon = members(m); break;
            end
        end
        for m = 1:length(members)
            mv = members(m);
            if mv == canon; continue; end
            if norm(quadnode(mv,:) - quadnode(canon,:)) > 3 * tol; continue; end
            rep(mv) = canon;
            n_merged = n_merged + 1;
        end
    end

    if n_merged == 0; return; end

    for qi = 1:size(quad, 1)
        q = quad(qi, :);
        for j = 1:4
            if q(j) > 0 && q(j) <= nqn
                quad(qi, j) = rep(q(j));
            end
        end
    end
end
