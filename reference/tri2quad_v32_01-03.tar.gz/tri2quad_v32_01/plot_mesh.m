function plot_mesh(n, e, tit)
%PLOT_MESH Quick mesh visualization helper.
%   plot_mesh(n, e, tit) draws the mesh defined by nodes `n` and
%   elements `e` (triangle: 3 cols, quad: 4 cols) with the given title.
%
%   REUSED FROM ORIGINAL tri2quad.m WITHOUT MODIFICATION.

    figure;
    hold on; axis equal;
    patch('faces', e, 'vertices', n, ...
          'facecolor', 'none', 'edgecolor', 'k');
    title(tit);
    hold off;
end
