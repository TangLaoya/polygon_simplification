node=load('E:\company\EDA\huawei\quadmesh\test1\test1.xmlSignal$L3_node.txt');
tri=load('E:\company\EDA\huawei\quadmesh\test1\test1.xmlSignal$L3_tri.txt');
nnode=size(node,1)
ntri=size(tri,1)
debug=1;
if debug==1
    figure,hold on;axis equal;patch('faces',tri,'vertices',node,'facecolor','none','edgecolor','k');title('stage 1--input mesh')
end
if 0
crossfield = 1;
jaal = 2;
tic
[quadnode, quad] = tri2quad(node, tri, crossfield, debug);
toc
nquad=size(quad,1)
nnode=size(quadnode,1)
if debug==0
    figure,hold on;axis equal;patch('faces',quad(1:nquad,:),'vertices',quadnode,'facecolor','none','edgecolor','k');title('stage 2--after quadmesh')
end
end

% python=1;
% if python
%     node_python=load('quadnode_python.txt');
%     quad_python=load('quad_python.txt');
%     figure,hold on;axis equal;patch('faces',quad_python,'vertices',node_python,'facecolor','none','edgecolor','k');title('Python result')
% end
tic
blossom=6;
[quadnode, quad, report] = tri2quad_v31(node, tri,blossom, debug);
toc
nquad=size(quad,1)
nnode=size(quadnode,1)
if debug==1
    figure,hold on;axis equal;patch('faces',quad(1:nquad,:),'vertices',quadnode,'facecolor','r','edgecolor','k');title('stage 2--after quadmesh')
    save('quadnode.txt','quadnode','-ascii');
    save('quad.txt','quad','-ascii');
end
