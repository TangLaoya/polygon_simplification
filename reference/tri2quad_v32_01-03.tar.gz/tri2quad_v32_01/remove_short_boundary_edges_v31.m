function [node, tri, info] = remove_short_boundary_edges_v31(node, tri, debug, factor)
%REMOVE_SHORT_BOUNDARY_EDGES_V31  Remove very short boundary edges by edge
%   collapse, using authoritative rules derived from:
%     - Hoppe 1996 (Progressive Meshes): link condition
%     - CGAL 6.2 (Surface Mesh Simplification): fold-over / orientation test
%     - Garland-Heckbert 1997 / Lindstrom-Turk 1998: placement strategy
%     - User requirement: minimise SUM OF |triangle areas| (method d)
%
%   V31_05 — simple B->A collapse + global iterative cross-fix (no star-hole).
%   Pure MATLAB matrix/cell-array implementation (NO containers.Map).
%
%   RULES (see worklog.md for full derivation):
%     Rule 1 - Short-edge test:
%       len_prev >= factor*len_AB  OR  len_next >= factor*len_AB  (factor=4, >=)
%       AND  len_AB < 0.25 * median_boundary_edge_length_of_this_loop
%     Rule 2 - Delete condition (one of):
%       cond-A: both neighbors >= factor*L             (unconditional)
%       cond-B: one >= factor*L, other >= 0.5*L,  AND  f* < L^2/5
%       cond-C: f* < L^2/20                            (unconditional)
%     Rule 3 - Safety (ALL must pass):
%       3.1 Link condition (Hoppe): common_nbrs(A,B) == opposite_verts(A,B)
%       3.2 Fold-over: no incident triangle of A flips orientation (A->X)
%       3.3 Intra-loop self-intersection: new segments P->X, X->N must not
%           cross any non-adjacent boundary edge of the SAME loop
%       3.4 Cross-loop self-intersection: must not cross any boundary edge
%           of OTHER loops (multi-connected domain)
%       3.5 Loop length >= 3 after removal
%     Rule 4 - New vertex position (method d, analytical):
%       X* = argmin f(X),  f(X) = |[P,A,X]| + |[A,B,X]| + |[B,N,X]|
%       Candidates: X_a = PA cap BN,  X_b = A,  X_c = B,  X_d = R0-feasible
%       (R0 = intersection of 3 half-planes where g1,g2,g3 same sign -> f=0)
%     Rule 5 - Greedy priority queue (shortest first), max 20 passes
%     Rule 6 - Dead-loop protection: 3 consecutive blocks -> permanent skip
%
%   INPUT:
%     node   : N-by-2 vertex coordinates
%     tri    : M-by-3 triangle connectivity (1-indexed)
%     debug  : verbose flag (default false)
%     factor : length ratio threshold (default 4.0)
%
%   OUTPUT:
%     node   : updated vertex coordinates (collapsed vertices orphaned)
%     tri    : updated triangle connectivity
%     info   : struct with removal statistics

    if nargin < 4 || isempty(factor); factor = 4.0; end
    if nargin < 3; debug = false; end

    % --- Constants (Rules 1, 2) ---
    LOCAL_FRAC       = 0.25;   % len_AB < 0.25 * loop median
    COND_B_OTHER     = 0.50;   % other neighbor >= 0.5*L  (cond-B)
    COND_B_AREA_FRAC = 0.20;   % f* < local_ref^2/5       (cond-B)
    COND_C_AREA_FRAC = 0.05;   % f* < local_ref^2/20      (cond-C)
    ABS_AREA_FLOOR  = 1e-9;   % absolute floor for cond-C (multi-scale)
    MAX_PASSES       = 10;     % V31_23: reduced from 20 (converges in 3-4)
    BLOCKED_MAX      = 3;
    HUGE_COORD       = 1e6;
    GRID_CELL        = 1e-4;

    info = struct('n_removed', 0, 'n_tri_removed', 0, ...
                  'n_link_fail', 0, 'n_fold_fail', 0, 'n_selfint_fail', 0, ...
                  'n_hole_fail', 0, 'n_interior_cross_fail', 0, ...
                  'n_cross_fix_flips', 0, 'n_cross_fix_reverts', 0, ...
                  'n_rescan_removed', 0, 'n_rescan_iterations', 0, ...
                  'n_blocked_final', 0, 'n_passes', 0, ...
                  'n_condA', 0, 'n_condB', 0, 'n_condC', 0);

    nnode = size(node, 1);
    % blocked counter: sparse vector indexed by EDGE_KEY (= min*1e8 + max)
    blocked = sparse(1, 1);
    % Records of each collapse {A, B, orig_A_pos} for revert in cross-fix
    collapse_records = {};
    % alive(v) = false means vertex v has been removed (collapsed into another)
    alive = true(nnode, 1);
    % removed_edges: set of edge keys already processed (prevent re-processing)
    removed_edge_keys = sparse(1, 1);

    for pass = 1:MAX_PASSES
        info.n_passes = pass;
        n_removed_pass = 0;

        loops = find_boundary_loops(node, tri);
        if isempty(loops); break; end

        % --- Per-loop median boundary edge length (Rule 1b) ---
        loop_med = zeros(1, length(loops));
        for k = 1:length(loops)
            lp = loops{k}; L = length(lp);
            lens = zeros(1, L);
            for i = 1:L
                lens(i) = norm(node(lp(i), :) - node(lp(modp_v31(i + 1, L)), :));
            end
            loop_med(k) = median(lens);
        end

        % --- Collect ALL candidate short edges (Rule 1) ---
        %   Also compute LOCAL_REF_LEN = average of neighboring edges
        %   (P_prev->A, A->B, B->P_next + next 2 on each side).
        %   This adapts to multi-scale meshes.
        cands = [];   % [len_AB, loop_k, i, A, B, P_prev, P_next, local_ref]
        NB = 3;  % number of neighbor edges on each side for local average
        for k = 1:length(loops)
            lp = loops{k}; L = length(lp);
            if L < 4; continue; end
            med = loop_med(k);
            for i = 1:L
                A      = lp(i);
                B      = lp(modp_v31(i + 1, L));
                P_prev = lp(modp_v31(i - 1, L));
                P_next = lp(modp_v31(i + 2, L));
                pA = node(A, :); pB = node(B, :);
                len_AB = norm(pA - pB);
                if len_AB < 1e-15; continue; end
                len_prev = norm(node(P_prev, :) - pA);
                len_next = norm(pB - node(P_next, :));
                % Compute local reference length: average of NB edges on each side
                nbr_lens = [len_prev, len_next];
                for nb = 1:NB
                    idx_prev = modp_v31(i - 1 - nb, L);
                    idx_curr = modp_v31(i - nb, L);
                    idx_next1 = modp_v31(i + 1 + nb, L);
                    idx_next2 = modp_v31(i + 2 + nb, L);
                    nbr_lens(end+1) = norm(node(lp(idx_curr), :) - node(lp(idx_prev), :)); %#ok<AGROW>
                    nbr_lens(end+1) = norm(node(lp(idx_next1), :) - node(lp(idx_next2), :)); %#ok<AGROW>
                end
                local_ref = mean(nbr_lens);
                is_ratio = (len_prev >= factor * len_AB) || ...
                           (len_next >= factor * len_AB);
                is_local = len_AB < LOCAL_FRAC * med;
                is_collinear = false;
                min_nbr = min(len_prev, len_next);
                if is_ratio && ~is_local && min_nbr >= 0.5 * len_AB && ...
                   len_prev > 1e-15 && len_AB > 1e-15
                    v1 = pA - node(P_prev, :); v2 = pB - pA;
                    cos_angle = dot(v1, v2) / (norm(v1) * norm(v2));
                    cos_angle = max(-1, min(1, cos_angle));
                    angle_between = acosd(cos_angle);
                    interior_angle = 180 - angle_between;
                    if interior_angle >= 170 && len_AB < local_ref / 3.0
                        is_collinear = true;
                    end
                end
                if is_ratio && (is_local || is_collinear)
                    cands = [cands; len_AB, k, i, A, B, P_prev, P_next, local_ref]; %#ok<AGROW>
                end
            end
        end
        if isempty(cands); break; end

        % --- Sort by length ascending (priority queue, Rule 5) ---
        [~, sort_idx] = sort(cands(:, 1));
        cands = cands(sort_idx, :);

        % --- Build vertex -> triangles map (cell array, O(1) access) ---
        v2t = build_v2t_v31(tri, nnode);

        % --- Build boundary edge list + segment-point matrix + seg_id sparse map ---
        bnd_edges_now = build_boundary_edges_v31(tri);
        nbnd = size(bnd_edges_now, 1);
        bnd_seg_pts = zeros(nbnd, 4);   % [x1 y1 x2 y2] per boundary edge
        edge_keys = zeros(nbnd, 1);
        for sid = 1:nbnd
            a = bnd_edges_now(sid, 1); b = bnd_edges_now(sid, 2);
            edge_keys(sid) = edge_key_v31(a, b);
            bnd_seg_pts(sid, :) = [node(a, 1), node(a, 2), node(b, 1), node(b, 2)];
        end
        % seg_id_map: sparse vector indexed by EDGE_KEY -> sid.
        %   Size = max(edge_keys) so all keys are valid indices.
        if ~isempty(edge_keys)
            seg_id_map = sparse(edge_keys, ones(nbnd, 1), (1:nbnd)', ...
                                 max(edge_keys), 1);
        else
            seg_id_map = sparse(1, 1);
        end

        % --- Build grid hash over boundary edges (Rule 3.3/3.4) ---
        gh = build_grid_hash_v31(bnd_seg_pts, GRID_CELL);

        % --- Process candidates in priority order ---
        for ci = 1:size(cands, 1)
            len_AB = cands(ci, 1);
            A      = cands(ci, 4);
            B      = cands(ci, 5);
            P_prev = cands(ci, 6);
            P_next = cands(ci, 7);
            local_ref = cands(ci, 8);   % local average edge length

            % Skip if A or B already removed (alive check + edge already processed)
            if ~alive(A) || ~alive(B); continue; end
            ekey_check = edge_key_v31(A, B);
            if ekey_check <= numel(removed_edge_keys) && removed_edge_keys(ekey_check) > 0
                continue;   % this edge already processed in a previous pass
            end
            if isempty(v2t{A}) || isempty(v2t{B}); continue; end

            pA = node(A, :); pB = node(B, :);
            pP = node(P_prev, :); pN = node(P_next, :);
            M  = 0.5 * (pA + pB);
            len_prev = norm(pP - pA);
            len_next = norm(pB - pN);

            % --- Rule 2: delete conditions ---
            condA = (len_prev >= factor * len_AB) && ...
                    (len_next >= factor * len_AB);
            condB = false;
            if ~condA
                if (len_prev >= factor * len_AB && ...
                    len_next >= COND_B_OTHER * len_AB) || ...
                   (len_next >= factor * len_AB && ...
                    len_prev >= COND_B_OTHER * len_AB)
                    condB = true;
                end
            end

            % --- Rule 3.1: Link condition (Hoppe 1996) ---
            opp = find_opposite_verts_v31(tri, A, B, v2t);
            common = find_common_neighbors_v31(tri, A, B, v2t);
            if ~isequal(sort(common(:)), sort(opp(:)))
                info.n_link_fail = info.n_link_fail + 1;
                blocked = bump_blocked_v31(blocked, A, B);
                continue;
            end

            % --- Rule 4: QEM optimal vertex placement (V31_19) ---
            %   Per Garland-Heckbert 1997: minimize sum of squared distances
            %   from X to all planes (triangle edges in 2D) incident to A and B.
            %   In 2D, QEM reduces to: X minimizes sum of squared perpendicular
            %   distances to all edges of A's and B's incident triangles.
            %   Solve via normal equations: (sum n_i n_i') X = sum (n_i . p_i) n_i
            %   Also try methods a/b/c/d as fallbacks, pick best by f(X).
            [best_X, best_f, best_m] = qem_optimal_placement_v31( ...
                tri, node, A, B, v2t, pP, pA, pB, pN, M, HUGE_COORD);
            if isempty(best_X); continue; end

            % Rule 2: cond-B/C area gate — V31_23: LOCAL_REF + ABSOLUTE floor
            %   Use LOCAL_REF (avg neighbor edges) as primary scale, but also
            %   allow deletion when f is tiny in absolute terms (< 1e-9).
            %   This catches reverted edges whose local_ref is dominated by
            %   the short edge itself.
            local_ref_sq = local_ref * local_ref;
            condC = (best_f < COND_C_AREA_FRAC * local_ref_sq) || ...
                    (best_f < ABS_AREA_FLOOR);
            if condB && best_f >= COND_B_AREA_FRAC * local_ref_sq && ~condC
                blocked = bump_blocked_v31(blocked, A, B);
                continue;
            end
            if ~condA && ~condB && ~condC; continue; end

            % Rule 3.2: STRICT fold-over test (V31_19 — check ALL affected tris)
            %   Per CGAL: check ALL triangles incident to A AND B (not just A's).
            %   After B->A collapse, B's triangles become A's triangles.
            %   Each must maintain orientation (no normal flip).
            flip_ok = true;
            % Check A's triangles (excluding shared with B)
            tris_A = v2t{A};
            for ti = 1:length(tris_A)
                t = tri(tris_A(ti), :);
                if any(t == A) && ~any(t == B)
                    others = t(t ~= A);
                    if length(others) >= 2
                        u = others(1); v = others(2);
                        s_old = tri_signed_area_v31(pA, node(u, :), node(v, :));
                        s_new = tri_signed_area_v31(best_X, node(u, :), node(v, :));
                        if s_old * s_new < -1e-15
                            flip_ok = false; break;
                        end
                    end
                end
            end
            % Check B's triangles (excluding shared with A) — they will have B->A
            if flip_ok
                tris_B = v2t{B};
                for ti = 1:length(tris_B)
                    t = tri(tris_B(ti), :);
                    if any(t == B) && ~any(t == A)
                        others = t(t ~= B);
                        if length(others) >= 2
                            u = others(1); v = others(2);
                            % After collapse: B->A, so triangle becomes (best_X, u, v)
                            s_old = tri_signed_area_v31(pB, node(u, :), node(v, :));
                            s_new = tri_signed_area_v31(best_X, node(u, :), node(v, :));
                            if s_old * s_new < -1e-15
                                flip_ok = false; break;
                            end
                        end
                    end
                end
            end
            if ~flip_ok
                info.n_fold_fail = info.n_fold_fail + 1;
                blocked = bump_blocked_v31(blocked, A, B);
                continue;
            end

            % Rule 3.3/3.4: boundary self-intersection test
            ex_set = false(nbnd, 1);
            adj_pairs = [P_prev, A; A, B; B, P_next];
            for pi = 1:3
                a = adj_pairs(pi, 1); b = adj_pairs(pi, 2);
                key = edge_key_v31(a, b);
                if key <= numel(seg_id_map)
                    sid_found = full(seg_id_map(key));
                    if sid_found > 0
                        ex_set(sid_found) = true;
                    end
                end
            end
            selfint = query_grid_hash_v31(gh, pP, best_X, ex_set, GRID_CELL) || ...
                      query_grid_hash_v31(gh, best_X, pN, ex_set, GRID_CELL);
            if selfint
                info.n_selfint_fail = info.n_selfint_fail + 1;
                blocked = bump_blocked_v31(blocked, A, B);
                continue;
            end

            % V31_67: FAST local crossing check + alternatives (MAIN LOOP).
            %   If best_X causes crossing, try X=A, X=B, M, X at crossing vertex.
            %   If ALL alternatives fail, DON'T skip — use best_X anyway.
            %   This lets the crossing happen → cross-fix will revert it →
            %   manifold preserved → Blossom OK.
            %   V57/V66 lesson: skipping (continue) → 0 reverts → non-manifold → FAIL.
            %   V29/V62 lesson: letting crossings happen → 5 reverts → manifold → OK.
            [loc_ok, loc_cv] = local_cross_check_v31(tri, node, A, B, best_X, v2t);
            if ~loc_ok
                alt_found = false;
                alt_cands = {pA, pB, M};
                if loc_cv > 0 && loc_cv ~= A && loc_cv ~= B
                    alt_cands{end+1} = node(loc_cv, :);
                end
                for ai = 1:length(alt_cands)
                    X_alt = alt_cands{ai};
                    [ok2, ~] = local_cross_check_v31(tri, node, A, B, X_alt, v2t);
                    if ok2
                        best_X = X_alt;
                        alt_found = true;
                        break;
                    end
                end
                % V31_67: DON'T skip if all fail. Use best_X → crossing →
                % cross-fix will revert → manifold → Blossom OK.
            end

            % === SIMPLE B->A COLLAPSE ===
            collapse_records{end+1} = {A, B, pA}; %#ok<AGROW>
            alive(B) = false;
            ekey_mark = edge_key_v31(A, B);
            if ekey_mark > numel(removed_edge_keys)
                removed_edge_keys(ekey_mark, 1) = 0;
            end
            removed_edge_keys(ekey_mark) = 1;
            % Move A to X, replace B with A in tri
            node(A, :) = best_X;
            ntri = size(tri, 1);
            has_B = any(tri == B, 2);
            keep = true(ntri, 1);
            for t = find(has_B(:))'
                v = tri(t, :);
                v(v == B) = A;
                tri(t, :) = v;
                if length(unique(v)) < 3
                    keep(t) = false;
                end
            end
            tri = tri(keep, :);

            info.n_removed       = info.n_removed + 1;
            info.n_tri_removed   = info.n_tri_removed + sum(~keep);
            n_removed_pass       = n_removed_pass + 1;
            if condA;    info.n_condA = info.n_condA + 1;
            elseif condB; info.n_condB = info.n_condB + 1;
            else;         info.n_condC = info.n_condC + 1; end

            % Clear blocked counter for this edge (successfully removed)
            ekey = edge_key_v31(A, B);
            if ekey <= numel(blocked) && blocked(ekey) > 0
                blocked(ekey) = 0;
            end

            if debug
                cond_str = 'A'; if condB; cond_str = 'B';
                elseif ~condA && ~condB; cond_str = 'C'; end
                method_names = {'a', 'b', 'c', 'd', 'q'};
                fprintf('  [p%d] rm (%d,%d) len=%.2e prev=%.1fx next=%.1fx f*=%.2e m=%s cond=%s\n', ...
                    pass, A, B, len_AB, len_prev/len_AB, len_next/len_AB, ...
                    best_f, method_names{best_m}, cond_str);
            end

            % Rebuild v2t from scratch (tri changed after collapse)
            v2t = build_v2t_v31(tri, nnode);
        end

        if n_removed_pass == 0; break; end
    end

    % --- Final blocked count ---
    info.n_blocked_final = nnz(blocked >= BLOCKED_MAX);

    % === COMBINED CROSS-FIX + RESCAN (V31_29) ===
    %   Single pass: find crossings, flip quads, revert non-quads,
    %   then immediately rescan for new short edges from reverts.
    %   This replaces the old multi-phase approach (cross-fix → rescan →
    %   cross-fix again) with a single combined function.
    if info.n_removed > 0
        [node, tri, cf_info] = global_cross_fix_v31(tri, node, debug, collapse_records);
        info.n_cross_fix_flips = cf_info.n_flips;
        info.n_cross_fix_reverts = cf_info.n_reverts;
        info.n_removed = info.n_removed - cf_info.n_reverts;

        % Rescan for remaining short edges (from reverts or new ones)
        if cf_info.n_reverts > 0
            info.n_rescan_iterations = 0;
            for rescan_iter = 1:2
                [node, tri, re_info] = rescan_after_revert_v31(node, tri, debug, factor);
                info.n_rescan_removed = info.n_rescan_removed + re_info.n_removed;
                info.n_removed = info.n_removed + re_info.n_removed;
                info.n_tri_removed = info.n_tri_removed + re_info.n_tri_removed;
                info.n_rescan_iterations = info.n_rescan_iterations + 1;
                if re_info.n_removed == 0; break; end
            end
        else
            info.n_rescan_removed = 0;
            info.n_rescan_iterations = 0;
        end
    else
        info.n_rescan_removed = 0;
        info.n_rescan_iterations = 0;
    end

    if debug
        fprintf('  [short-edge V31] Done: removed %d edges (+%d rescan), %d tri removed, %d flips, %d reverts\n', ...
            info.n_removed, info.n_rescan_removed, info.n_tri_removed, ...
            info.n_cross_fix_flips, info.n_cross_fix_reverts);
        fprintf('    link_fail=%d fold_fail=%d selfint_fail=%d interior_cross_fail=%d blocked_final=%d passes=%d\n', ...
            info.n_link_fail, info.n_fold_fail, info.n_selfint_fail, ...
            info.n_interior_cross_fail, info.n_blocked_final, info.n_passes);
        fprintf('    condA=%d condB=%d condC=%d\n', ...
            info.n_condA, info.n_condB, info.n_condC);
        figure('Name', 'After Short Edge Removal V31', 'NumberTitle', 'off');
        hold on; axis equal; axis off;
        patch('faces', tri, 'vertices', node, 'facecolor', 'none', 'edgecolor', 'k');
        title('after removing short boundary edges (V31)');
        hold off;
    end
end

% =====================================================================
% =====================  LOCAL HELPER FUNCTIONS  ======================
% =====================================================================

function v2t = build_v2t_v31(tri, nnode)
%BUILD_V2T_V31  Vertex -> triangle indices (cell array, O(1) access).
%   Vectorized construction: build (vertex, triangle) pair list, sort by
%   vertex, then split into per-vertex cell array.
    ntri = size(tri, 1);
    v2t = cell(nnode, 1);
    if ntri == 0; return; end
    % (vertex, triangle) pairs: each triangle contributes 3 pairs
    verts = tri(:);                            % 3*ntri x 1
    tris  = repmat((1:ntri)', 3, 1);           % 3*ntri x 1
    % Sort by vertex so same-vertex triangles are contiguous
    [verts_sorted, sort_idx] = sort(verts);
    tris_sorted = tris(sort_idx);
    % Find group boundaries
    [~, starts] = unique(verts_sorted, 'first');
    stops = [starts(2:end)-1; numel(verts_sorted)];
    % Fill cell array
    for g = 1:length(starts)
        v = verts_sorted(starts(g));
        v2t{v} = tris_sorted(starts(g):stops(g))';
    end
end

% ---------------------------------------------------------------------
function opp = find_opposite_verts_v31(tri, A, B, v2t)
%FIND_OPPOSITE_VERTS_V31  Vertices C such that (A,B,C) is a triangle.
    opp = [];
    if isempty(v2t{A}) || isempty(v2t{B}); return; end
    common_t = intersect(v2t{A}, v2t{B});
    for t = common_t(:)'
        v = tri(t, :);
        opp = [opp, v(v ~= A & v ~= B)]; %#ok<AGROW>
    end
    opp = unique(opp);
end

% ---------------------------------------------------------------------
function common = find_common_neighbors_v31(tri, A, B, v2t)
%FIND_COMMON_NEIGHBORS_V31  Vertices adjacent to BOTH A and B.
    na = []; nb = [];
    if ~isempty(v2t{A})
        for t = v2t{A}(:)'
            v = tri(t, :);
            na = [na, v(v ~= A)]; %#ok<AGROW>
        end
    end
    if ~isempty(v2t{B})
        for t = v2t{B}(:)'
            v = tri(t, :);
            nb = [nb, v(v ~= B)]; %#ok<AGROW>
        end
    end
    if isempty(na); na = []; else; na = unique(na); end
    if isempty(nb); nb = []; else; nb = unique(nb); end
    na = na(na ~= B);
    nb = nb(nb ~= A);
    common = intersect(na, nb);
end

% ---------------------------------------------------------------------
function key = edge_key_v31(a, b)
%EDGE_KEY_V31  Unique hashable key for edge (a,b) -> scalar.
    key = double(min(a, b)) * 1e8 + max(a, b);
end

% ---------------------------------------------------------------------
function blocked = bump_blocked_v31(blocked, A, B)
%BUMP_BLOCKED_V31  Increment consecutive-block counter for edge (A,B).
%   `blocked` is a sparse vector indexed by EDGE_KEY.
    key = edge_key_v31(A, B);
    % Ensure sparse vector is large enough
    if key > numel(blocked)
        blocked(key, 1) = 0;   % extend sparse storage
    end
    blocked(key) = blocked(key) + 1;
end

% ---------------------------------------------------------------------
function bnd = build_boundary_edges_v31(tri)
%BUILD_BOUNDARY_EDGES_V31  All boundary edges (a,b) with a<b, once.
    E = [tri(:, [2 3]); tri(:, [3 1]); tri(:, [1 2])];
    E = sort(E, 2);
    [ue, ~, ic] = unique(E, 'rows');
    cnt = accumarray(ic, 1);
    bnd = ue(cnt == 1, :);
end

% ---------------------------------------------------------------------
function gh = build_grid_hash_v31(seg_pts, cell_size)
%BUILD_GRID_HASH_V31  Efficient spatial hash for segment crossing queries.
%   Returns a struct with:
%     gh.cell_keys   : sorted unique cell keys (Nx1 double)
%     gh.seg_starts  : (N+1)x1, index range [seg_starts(i), seg_starts(i+1)-1]
%                      into gh.seg_data for cell_keys(i)
%     gh.seg_data    : Mx5 matrix [sid, x1, y1, x2, y2] grouped by cell_key
%   Memory: O(total_cell-segment pairs), NO per-cell cell array overhead.
    nseg = size(seg_pts, 1);
    if nseg == 0
        gh = struct('cell_keys', zeros(0,1), 'seg_starts', [1], ...
                    'seg_data', zeros(0,5));
        return;
    end

    pa = seg_pts(:, 1:2);
    pb = seg_pts(:, 3:4);
    lo = min(pa, pb) - cell_size;
    hi = max(pa, pb) + cell_size;
    cx_lo = floor(lo(:, 1) / cell_size);
    cx_hi = floor(hi(:, 1) / cell_size);
    cy_lo = floor(lo(:, 2) / cell_size);
    cy_hi = floor(hi(:, 2) / cell_size);

    % Compute total pairs and build (cell_key, sid) lists
    ncells_per_seg = (cx_hi - cx_lo + 1) .* (cy_hi - cy_lo + 1);
    total_pairs = sum(ncells_per_seg);
    pair_keys = zeros(total_pairs, 1);
    pair_sids = zeros(total_pairs, 1);
    pos = 0;
    for sid = 1:nseg
        nc = ncells_per_seg(sid);
        r = 0;
        for cx = cx_lo(sid):cx_hi(sid)
            for cy = cy_lo(sid):cy_hi(sid)
                r = r + 1;
                pair_keys(pos + r) = double(cx) * 1e8 + cy;
            end
        end
        pair_sids(pos+1:pos+nc) = sid;
        pos = pos + nc;
    end

    % Sort by cell_key (stable), then group
    [sorted_keys, sort_order] = sort(pair_keys);
    sorted_sids = pair_sids(sort_order);
    % Find unique cell keys and their start indices
    [ukeys, first_idx] = unique(sorted_keys, 'first');
    ncells_total = length(ukeys);
    seg_starts = zeros(ncells_total + 1, 1);
    seg_starts(1:ncells_total) = first_idx;
    seg_starts(ncells_total + 1) = total_pairs + 1;

    % Build seg_data: [sid, x1, y1, x2, y2] sorted by cell_key
    seg_data = zeros(total_pairs, 5);
    seg_data(:, 1) = sorted_sids;
    seg_data(:, 2:5) = seg_pts(sorted_sids, :);

    gh = struct('cell_keys', ukeys, 'seg_starts', seg_starts, ...
                'seg_data', seg_data);
end

% ---------------------------------------------------------------------
function hit = query_grid_hash_v31(gh, p1, p2, ex_set, cell_size)
%QUERY_GRID_HASH_V31  True iff segment (p1,p2) properly crosses any
%   stored segment whose sid is NOT in ex_set. Binary search on
%   gh.cell_keys for O(log n) cell lookup.
    lo = min(p1, p2) - cell_size;
    hi = max(p1, p2) + cell_size;
    cx_lo = floor(lo(1) / cell_size);
    cx_hi = floor(hi(1) / cell_size);
    cy_lo = floor(lo(2) / cell_size);
    cy_hi = floor(hi(2) / cell_size);
    hit = false;
    for cx = cx_lo:cx_hi
        for cy = cy_lo:cy_hi
            cell_key = double(cx) * 1e8 + cy;
            idx = binary_search_v31(gh.cell_keys, cell_key);
            if idx == 0; continue; end
            r1 = gh.seg_starts(idx);
            r2 = gh.seg_starts(idx + 1) - 1;
            for r = r1:r2
                sid = gh.seg_data(r, 1);
                if sid <= numel(ex_set) && ex_set(sid); continue; end
                pa = gh.seg_data(r, 2:3);
                pb = gh.seg_data(r, 4:5);
                if seg_seg_proper_intersect_v31(p1, p2, pa, pb)
                    hit = true; return;
                end
            end
        end
    end
end

% ---------------------------------------------------------------------
function idx = binary_search_v31(sorted_keys, target)
%BINARY_SEARCH_V31  Return 1-based position of target in sorted_keys,
%   or 0 if not found.
    n = numel(sorted_keys);
    if n == 0; idx = 0; return; end
    lo = 1; hi = n;
    while lo <= hi
        mid = floor((lo + hi) / 2);
        if sorted_keys(mid) == target
            idx = mid; return;
        elseif sorted_keys(mid) < target
            lo = mid + 1;
        else
            hi = mid - 1;
        end
    end
    idx = 0;
end

% ---------------------------------------------------------------------
function hit = seg_seg_proper_intersect_v31(p1, p2, p3, p4)
%SEG_SEG_PROPER_INTERSECT_V31  True iff segments properly cross at an
%   interior point (excludes shared endpoints, relative tol 1e-6).
    d1 = p2 - p1; d2 = p4 - p3;
    det = d1(1) * d2(2) - d1(2) * d2(1);
    if abs(det) < 1e-15; hit = false; return; end
    t = ((p3(1) - p1(1)) * d2(2) - (p3(2) - p1(2)) * d2(1)) / det;
    u = ((p3(1) - p1(1)) * d1(2) - (p3(2) - p1(2)) * d1(1)) / det;
    hit = (t > 1e-6 && t < 1 - 1e-6) && (u > 1e-6 && u < 1 - 1e-6);
end

% ---------------------------------------------------------------------
function X = line_intersect_v31(p1, p2, p3, p4)
%LINE_INTERSECT_V31  Intersection of line(p1,p2) and line(p3,p4).
%   Returns [NaN, NaN] if parallel.
    d1 = p2 - p1; d2 = p4 - p3;
    det = d1(1) * d2(2) - d1(2) * d2(1);
    if abs(det) < 1e-15; X = [NaN, NaN]; return; end
    t = ((p3(1) - p1(1)) * d2(2) - (p3(2) - p1(2)) * d2(1)) / det;
    X = p1 + t * d1;
end

% ---------------------------------------------------------------------
function f = f_area_abs_v31(pP, pA, pB, pN, X)
%F_AREA_ABS_V31  f(X) = |[P,A,X]| + |[A,B,X]| + |[B,N,X]|.
    f = tri_abs_area_v31(pP, pA, X) + ...
        tri_abs_area_v31(pA, pB, X) + ...
        tri_abs_area_v31(pB, pN, X);
end

% ---------------------------------------------------------------------
function a = tri_abs_area_v31(p1, p2, p3)
    a = abs(tri_signed_area_v31(p1, p2, p3));
end

% ---------------------------------------------------------------------
function a = tri_signed_area_v31(p1, p2, p3)
    a = 0.5 * ((p2(1) - p1(1)) * (p3(2) - p1(2)) - ...
               (p2(2) - p1(2)) * (p3(1) - p1(1)));
end

% ---------------------------------------------------------------------
function [ok, cross_v] = local_cross_check_v31(tri, node, kept_v, removed_v, X, v2t)
%LOCAL_CROSS_CHECK_V31  FAST 2-ring local interior crossing check.
%   V31_71: Restored V69 logic (always 2-ring) + optimized expansion.
%   No logic change from V69 — same results, faster implementation.
    ok = true; cross_v = 0; pX = X;
    all_nbrs = [];
    if kept_v >= 1 && kept_v <= numel(v2t) && ~isempty(v2t{kept_v})
        for ti = v2t{kept_v}(:)'
            t = tri(ti, :);
            all_nbrs = [all_nbrs, t(t ~= kept_v)]; %#ok<AGROW>
        end
    end
    if removed_v >= 1 && removed_v <= numel(v2t) && ~isempty(v2t{removed_v})
        for ti = v2t{removed_v}(:)'
            t = tri(ti, :);
            all_nbrs = [all_nbrs, t(t ~= removed_v)]; %#ok<AGROW>
        end
    end
    all_nbrs = unique(all_nbrs);
    if isempty(all_nbrs); return; end
    local_tri_set = union(v2t{kept_v}, v2t{removed_v});
    % V31_71: Optimized 2-ring expansion — accumulate then unique once
    ring2_acc = local_tri_set(:)';
    for ti = local_tri_set(:)'
        t = tri(ti, :);
        for k = 1:3
            v1 = t(k); v2 = t(mod(k, 3) + 1);
            shared = intersect(v2t{v1}, v2t{v2});
            if ~isempty(shared)
                ring2_acc = [ring2_acc, shared]; %#ok<AGROW>
            end
        end
    end
    ring2_tri_set = unique(ring2_acc);
    ntri_local = numel(ring2_tri_set);
    local_edges = zeros(ntri_local * 3, 2);
    idx = 0;
    for ti = ring2_tri_set(:)'
        t = tri(ti, :);
        for k = 1:3
            idx = idx + 1;
            local_edges(idx, 1) = t(k);
            local_edges(idx, 2) = t(mod(k, 3) + 1);
        end
    end
    if isempty(local_edges); return; end
    edge_pa = node(local_edges(:, 1), :);
    edge_pb = node(local_edges(:, 2), :);
    skip_mask = (local_edges(:,1) == kept_v) | (local_edges(:,1) == removed_v) | ...
               (local_edges(:,2) == kept_v) | (local_edges(:,2) == removed_v);
    for ii = 1:length(all_nbrs)
        u = all_nbrs(ii);
        pu = node(u, :);
        u_mask = (local_edges(:,1) == u) | (local_edges(:,2) == u);
        check_mask = ~skip_mask & ~u_mask;
        if ~any(check_mask); continue; end
        d1 = (edge_pb(:,2) - edge_pa(:,2)) .* (pX(1) - edge_pa(:,1)) - ...
             (edge_pb(:,1) - edge_pa(:,1)) .* (pX(2) - edge_pa(:,2));
        d2 = (edge_pb(:,2) - edge_pa(:,2)) .* (pu(1) - edge_pa(:,1)) - ...
             (edge_pb(:,1) - edge_pa(:,1)) .* (pu(2) - edge_pa(:,2));
        d3 = (pu(1) - pX(1)) .* (edge_pa(:,2) - pX(2)) - ...
             (pu(2) - pX(2)) .* (edge_pa(:,1) - pX(1));
        d4 = (pu(1) - pX(1)) .* (edge_pb(:,2) - pX(2)) - ...
             (pu(2) - pX(2)) .* (edge_pb(:,1) - pX(1));
        cross_mask = check_mask & ...
            (((d1 > 0) & (d2 < 0)) | ((d1 < 0) & (d2 > 0))) & ...
            (((d3 > 0) & (d4 < 0)) | ((d3 < 0) & (d4 > 0)));
        if any(cross_mask)
            ci = find(cross_mask, 1);
            ok = false;
            cross_v = local_edges(ci, 1);
            return;
        end
    end
end

% ---------------------------------------------------------------------
function X = r0_feasible_point_v31(pP, pA, pB, pN, M)
%R0_FEASIBLE_POINT_V31  Find point in R0 (g1,g2,g3 same sign -> f=0),
%   closest to M. R0 = intersection of 3 half-planes (convex polygon).
%   Try candidate points {M, A, B, PA cap BN}; if any has all three
%   signed areas same sign (within tol), pick the closest to M.
    tol = 1e-15;
    cands = {M, pA, pB};
    X_inter = line_intersect_v31(pP, pA, pB, pN);
    if ~any(isnan(X_inter)) && norm(X_inter) < 1e6
        cands{end + 1} = X_inter; %#ok<AGROW>
    end
    best = [NaN, NaN]; best_d = inf;
    for i = 1:length(cands)
        c = cands{i};
        s1 = tri_signed_area_v31(pP, pA, c);
        s2 = tri_signed_area_v31(pA, pB, c);
        s3 = tri_signed_area_v31(pB, pN, c);
        if (s1 >= -tol && s2 >= -tol && s3 >= -tol) || ...
           (s1 <=  tol && s2 <=  tol && s3 <=  tol)
            d = norm(c - M);
            if d < best_d
                best_d = d; best = c;
            end
        end
    end
    X = best;
end

% ---------------------------------------------------------------------
function idx = modp_v31(x, L)
%MODP_V31  Positive modular index (1-based, wraps 0 -> L).
    idx = mod(x - 1, L) + 1;
end

% ---------------------------------------------------------------------
function [best_X, best_f, best_m] = qem_optimal_placement_v31( ...
    tri, node, A, B, v2t, pP, pA, pB, pN, M, HUGE_COORD)
%QEM_OPTIMAL_PLACEMENT_V31  Compute optimal vertex position for edge
%   collapse (A,B)->X using Quadric Error Metrics (Garland-Heckbert 1997).
%
%   In 2D, QEM minimizes sum of squared perpendicular distances from X
%   to all edges incident to A and B. Each edge (p, q) defines a line;
%   the squared distance from X to that line is (n . X - d)^2 / |n|^2,
%   where n is the edge normal and d = n . p.
%
%   The optimal X solves the normal equations:
%     (sum n_i n_i') X = sum (d_i) n_i
%
%   Also evaluates methods a/b/c/d as fallbacks, picks best by f(X).
    method_names = {'a', 'b', 'c', 'd', 'q'};

    % --- Collect all edges incident to A and B (vectorized) ---
    all_tris = unique([v2t{A}(:); v2t{B}(:)]);
    if isempty(all_tris); best_X = []; best_f = inf; best_m = 0; return; end
    tri_pts = tri(all_tris, :);   % N x 3
    edges_raw = [tri_pts(:, [2 3]); tri_pts(:, [3 1]); tri_pts(:, [1 2])];
    edges_raw = sort(edges_raw, 2);
    edges_unique = unique(edges_raw, 'rows');

    % Build QEM normal equations: A_q * X = b_q (vectorized)
    pa_all = node(edges_unique(:, 1), :);
    pb_all = node(edges_unique(:, 2), :);
    d_all = pb_all - pa_all;
    n_all = [-d_all(:, 2), d_all(:, 1)];
    nlen = sqrt(n_all(:, 1).^2 + n_all(:, 2).^2);
    valid = nlen > 1e-15;
    n_all = n_all(valid, :) ./ nlen(valid);
    d_val = n_all(:, 1) .* pa_all(valid, 1) + n_all(:, 2) .* pa_all(valid, 2);
    A_q = [sum(n_all(:,1).^2), sum(n_all(:,1).*n_all(:,2));
           sum(n_all(:,2).*n_all(:,1)), sum(n_all(:,2).^2)];
    b_q = [sum(d_val .* n_all(:,1)); sum(d_val .* n_all(:,2))];

    % Solve for QEM-optimal X
    X_qem = [];
    if abs(det(A_q)) > 1e-15
        X_qem = A_q \ b_q;   % Solve 2x2 system
        X_qem = X_qem';
        if norm(X_qem) > HUGE_COORD
            X_qem = [];
        end
    end

    % --- Collect all candidate X positions ---
    cand_X = cell(5, 1);
    cand_ok = false(5, 1);
    % (a) PA ∩ BN
    X_a = line_intersect_v31(pP, pA, pB, pN);
    if ~any(isnan(X_a)) && norm(X_a) < HUGE_COORD
        cand_X{1} = X_a; cand_ok(1) = true;
    end
    % (b) A
    cand_X{2} = pA; cand_ok(2) = true;
    % (c) B
    cand_X{3} = pB; cand_ok(3) = true;
    % (d) R0 feasibility point
    X_d = r0_feasible_point_v31(pP, pA, pB, pN, M);
    if ~any(isnan(X_d))
        cand_X{4} = X_d; cand_ok(4) = true;
    end
    % (q) QEM optimal
    if ~isempty(X_qem)
        cand_X{5} = X_qem; cand_ok(5) = true;
    end

    % --- Evaluate f(X) = sum of |triangle areas|, pick minimum ---
    best_f = inf; best_X = []; best_m = 0;
    for mi = 1:5
        if ~cand_ok(mi); continue; end
        X = cand_X{mi};
        f = f_area_abs_v31(pP, pA, pB, pN, X);
        if f < best_f
            best_f = f; best_X = X; best_m = mi;
        end
    end
    if best_m == 0; best_m = 1; end  % fallback if all NaN
end

% ---------------------------------------------------------------------
function gh = build_all_edges_grid_v31(tri, node, cell_size)
%BUILD_ALL_EDGES_GRID_V31  Grid hash over ALL unique triangle edges
%   (interior + boundary). Returns struct with cell_keys, seg_starts,
%   seg_data, and edge_sid_map (for excluding specific edges).
    E = [tri(:, [2 3]); tri(:, [3 1]); tri(:, [1 2])];
    E = sort(E, 2);
    [ue, ~, ic] = unique(E, 'rows');
    cnt = accumarray(ic, 1);
    uniq_E = ue(cnt <= 2, :);   % manifold edges only
    n_edges = size(uniq_E, 1);
    if n_edges == 0
        gh = struct('cell_keys', zeros(0,1), 'seg_starts', [1], ...
                    'seg_data', zeros(0,5), 'edge_sid', sparse(1,1));
        return;
    end
    seg_pts = zeros(n_edges, 4);
    seg_pts(:, 1:2) = node(uniq_E(:, 1), :);
    seg_pts(:, 3:4) = node(uniq_E(:, 2), :);
    gh = build_grid_hash_v31(seg_pts, cell_size);
    % Build edge_key -> sid sparse map
    edge_keys = zeros(n_edges, 1);
    for i = 1:n_edges
        edge_keys(i) = edge_key_v31(uniq_E(i, 1), uniq_E(i, 2));
    end
    gh.edge_sid = sparse(edge_keys, ones(n_edges, 1), (1:n_edges)', ...
                         max(edge_keys), 1);
    gh.uniq_E = uniq_E;
end

% ---------------------------------------------------------------------
function ok = interior_cross_ok_v31(tri, node, kept_v, removed_v, X, v2t, gh_all)
%INTERIOR_CROSS_OK_V31  Pre-check: after collapsing edge (kept_v, removed_v)
%   -> X, the new edges (X, u) for neighbors u of the REMOVED vertex that are
%   NOT already neighbors of the KEPT vertex must not cross any existing
%   triangle edge. Returns true if SAFE.
%   Note: edges (X, u) where u is already a neighbor of kept_v are topologically
%   unchanged (just geometrically moved), so not tested for crossing.
    ok = true;
    if ~isfield(gh_all, 'edge_sid'); return; end
    % Collect neighbors of KEPT (excluding removed) and REMOVED (excluding kept)
    nbrs_kept = [];
    if isKey_exist_v31(v2t, kept_v)
        for ti = v2t{kept_v}(:)'
            t = tri(ti, :);
            if ~any(t == removed_v)
                nbrs_kept = [nbrs_kept, t(t ~= kept_v)]; %#ok<AGROW>
            end
        end
    end
    nbrs_kept = unique(nbrs_kept);
    nbrs_removed = [];
    if isKey_exist_v31(v2t, removed_v)
        for ti = v2t{removed_v}(:)'
            t = tri(ti, :);
            nbrs_removed = [nbrs_removed, t(t ~= removed_v & t ~= kept_v)]; %#ok<AGROW>
        end
    end
    nbrs_removed = unique(nbrs_removed);
    % NEW neighbors = removed's neighbors NOT already in kept's neighbors
    new_nbrs = setdiff(nbrs_removed, nbrs_kept);
    if isempty(new_nbrs); return; end
    % For each new neighbor u, check if edge (X, u) crosses any existing edge
    for ii = 1:length(new_nbrs)
        u = new_nbrs(ii);
        pu = node(u, :);
        % Exclude edges (kept_v, u) and (removed_v, u) from the test
        ex_sids = [];
        for vk = 1:2
            if vk == 1; v_key = kept_v; else; v_key = removed_v; end
            ekey = edge_key_v31(v_key, u);
            if ekey <= numel(gh_all.edge_sid)
                sid = full(gh_all.edge_sid(ekey));
                if sid > 0
                    ex_sids = [ex_sids, sid]; %#ok<AGROW>
                end
            end
        end
        ex_set = false(size(gh_all.seg_data, 1), 1);
        for s = ex_sids
            ex_set(s) = true;
        end
        if query_grid_hash_v31(gh_all, X, pu, ex_set, 1e-5)
            ok = false; return;
        end
    end
end

% ---------------------------------------------------------------------
function tf = isKey_exist_v31(v2t, key)
%ISKEY_EXIST_V31  Check if key exists in cell array v2t (non-empty).
    if key < 1 || key > numel(v2t); tf = false; return; end
    tf = ~isempty(v2t{key});
end

% =====================================================================
% ==============  STAR HOLE RETRIANGULATION HELPERS  ==================
% =====================================================================

function hole_poly = extract_hole_boundary_v31(tri, B, v2t)
%EXTRACT_HOLE_BOUNDARY_V31  Ordered boundary polygon of the hole formed by
%   removing all triangles incident to B (the "link" of B).
    if isempty(v2t{B}); hole_poly = []; return; end
    tris_B = v2t{B};
    all_edges = zeros(length(tris_B) * 3, 2);
    for k = 1:length(tris_B)
        t = tris_B(k);
        v = tri(t, :);
        all_edges(3*(k-1)+1, :) = [v(2), v(3)];
        all_edges(3*(k-1)+2, :) = [v(3), v(1)];
        all_edges(3*(k-1)+3, :) = [v(1), v(2)];
    end
    all_edges = sort(all_edges, 2);
    [ue, ~, ic] = unique(all_edges, 'rows');
    cnt = accumarray(ic, 1);
    hole_edges = ue(cnt == 1, :);
    if isempty(hole_edges); hole_poly = []; return; end
    max_v = max(max(hole_edges));
    nbrs_cell = cell(max_v, 1);
    for i = 1:size(hole_edges, 1)
        a = hole_edges(i, 1); b = hole_edges(i, 2);
        nbrs_cell{a}(end+1) = b;
        nbrs_cell{b}(end+1) = a;
    end
    start = hole_edges(1, 1);
    poly = start;
    prev = 0;
    cur = start;
    for step = 1:size(hole_edges, 1)
        nbrs = nbrs_cell{cur};
        if isempty(nbrs); break; end
        nxt = 0;
        for j = 1:length(nbrs)
            if nbrs(j) ~= prev
                nxt = nbrs(j); break;
            end
        end
        if nxt == 0 || nxt == start; break; end
        poly(end+1, 1) = nxt; %#ok<AGROW>
        prev = cur;
        cur = nxt;
    end
    hole_poly = poly;
end

% ---------------------------------------------------------------------
function tf = is_simple_polygon_v31(pts)
%IS_SIMPLE_POLYGON_V31  True if polygon has no self-intersecting edges.
    n = size(pts, 1);
    if n < 3; tf = true; return; end
    tf = true;
    for i = 1:n
        a = pts(i, :); b = pts(modp_v31(i + 1, n), :);
        for j = i + 2:n
            if i == 1 && j == n; continue; end
            c = pts(j, :); d = pts(modp_v31(j + 1, n), :);
            if seg_seg_proper_intersect_v31(a, b, c, d)
                tf = false; return;
            end
        end
    end
end

% ---------------------------------------------------------------------
function tris = ear_clip_triangulate_v31(pts)
%EAR_CLIP_TRIANGULATE_V31  Ear-clipping triangulation of a simple polygon.
    n = size(pts, 1);
    if n < 3; tris = zeros(0, 3); return; end
    if n == 3; tris = [1, 2, 3]; return; end
    area = 0;
    for i = 1:n
        j = modp_v31(i + 1, n);
        area = area + pts(i, 1) * pts(j, 2) - pts(j, 1) * pts(i, 2);
    end
    indices = (1:n)';
    if area < 0; indices = indices(end:-1:1); end
    tris = zeros(n - 2, 3);
    tri_count = 0;
    guard = 0;
    while length(indices) > 3
        n_curr = length(indices);
        ear_found = false;
        for ii = 1:n_curr
            i_prev = indices(modp_v31(ii - 1, n_curr));
            i_curr = indices(ii);
            i_next = indices(modp_v31(ii + 1, n_curr));
            a = pts(i_prev, :); b = pts(i_curr, :); c = pts(i_next, :);
            cr = (b(1) - a(1)) * (c(2) - a(2)) - (b(2) - a(2)) * (c(1) - a(1));
            if cr <= 0; continue; end
            ear = true;
            for jj = 1:length(indices)
                idx = indices(jj);
                if idx == i_prev || idx == i_curr || idx == i_next; continue; end
                if point_in_tri_v31(pts(idx, :), a, b, c)
                    ear = false; break;
                end
            end
            if ear
                tri_count = tri_count + 1;
                tris(tri_count, :) = [i_prev, i_curr, i_next];
                indices(ii) = [];
                ear_found = true;
                break;
            end
        end
        if ~ear_found
            tri_count = tri_count + 1;
            tris(tri_count, :) = [indices(1), indices(2), indices(3)];
            indices(2) = [];
        end
        guard = guard + 1;
        if guard > 10 * n; break; end
    end
    if length(indices) == 3
        tri_count = tri_count + 1;
        tris(tri_count, :) = [indices(1), indices(2), indices(3)];
    end
    tris = tris(1:tri_count, :);
end

% ---------------------------------------------------------------------
function inside = point_in_tri_v31(p, a, b, c)
%POINT_IN_TRI_V31  Strict interior test (excludes boundary).
    d1 = (p(1) - b(1)) * (a(2) - b(2)) - (a(1) - b(1)) * (p(2) - b(2));
    d2 = (p(1) - c(1)) * (b(2) - c(2)) - (b(1) - c(1)) * (p(2) - c(2));
    d3 = (p(1) - a(1)) * (c(2) - a(2)) - (c(1) - a(1)) * (p(2) - a(2));
    neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
    pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
    inside = ~(neg && pos);
end

% =====================================================================
% ==============  GLOBAL CROSS-FIX (V31_10)  ==========================
%   FLIP quad crossings + REVERT collapses that caused non-quad crossings
% =====================================================================

function [node, tri, info] = global_cross_fix_v31(tri, node, debug, collapse_records)
%GLOBAL_CROSS_FIX_V31  Find crossing edge pairs. For QUAD crossings (2
%   shared triangles), FLIP the diagonal. For NON-QUAD crossings (cannot
%   flip), identify which collapse caused them and REVERT that collapse
%   (restore the moved vertex to its original position, restore deleted B).
%   This guarantees 0 crossings without split-induced cascading crossings.
%
%   collapse_records: cell array of {A, B, orig_A_pos, orig_tri_snapshot}
%   from the collapse phase. Used to revert.
    info = struct('n_flips', 0, 'n_reverts', 0);
    n_flips = 0;
    n_reverts = 0;
    CROSS_CELL = 1e-5;
    MAX_ITER = 2;   % V31_29: reduced from 3 (2 is enough)
    nnode = size(node, 1);

    for iter = 1:MAX_ITER
        % Build unique edge list
        E = [tri(:, [2 3]); tri(:, [3 1]); tri(:, [1 2])];
        E = sort(E, 2);
        [ue, ~, ic] = unique(E, 'rows');
        cnt = accumarray(ic, 1);
        uniq_E = ue(cnt <= 2, :);
        n_edges = size(uniq_E, 1);
        if n_edges == 0; break; end

        seg_pts = zeros(n_edges, 4);
        seg_pts(:, 1:2) = node(uniq_E(:, 1), :);
        seg_pts(:, 3:4) = node(uniq_E(:, 2), :);
        gh = build_grid_hash_v31(seg_pts, CROSS_CELL);
        v2t = build_v2t_v31(tri, nnode);

        % Build edge_sid_map for this iteration's edge set
        edge_keys_iter = zeros(n_edges, 1);
        for i = 1:n_edges
            edge_keys_iter(i) = edge_key_v31(uniq_E(i, 1), uniq_E(i, 2));
        end
        if ~isempty(edge_keys_iter)
            gh_all_sid_map = sparse(edge_keys_iter, ones(n_edges, 1), (1:n_edges)', ...
                                    max(edge_keys_iter), 1);
        else
            gh_all_sid_map = sparse(1, 1);
        end

        found = 0;
        non_quad_verts = [];
        % V31_24: Only check edges incident to MOVED vertices (from collapse_records)
        moved_verts = [];
        if ~isempty(collapse_records)
            for ri = 1:length(collapse_records)
                moved_verts = [moved_verts; collapse_records{ri}{1}]; %#ok<AGROW>
            end
            moved_verts = unique(moved_verts);
        end
        check_sids = [];
        if ~isempty(moved_verts)
            for mv = 1:length(moved_verts)
                v = moved_verts(mv);
                if isempty(v2t{v}); continue; end
                tris_v = v2t{v};
                for ti = 1:length(tris_v)
                    t = tri(tris_v(ti), :);
                    for k = 1:3
                        a = t(k); b = t(modp_v31(k + 1, 3));
                        ekey = edge_key_v31(a, b);
                        if ekey <= numel(gh_all_sid_map)
                            sid_found = full(gh_all_sid_map(ekey));
                            if sid_found > 0
                                check_sids = [check_sids; sid_found]; %#ok<AGROW>
                            end
                        end
                    end
                end
            end
            check_sids = unique(check_sids);
        else
            check_sids = (1:n_edges)';   % check all if no collapse_records
        end

        for ci = 1:length(check_sids)
            sid = check_sids(ci);
            if sid < 1 || sid > n_edges; continue; end
            a = uniq_E(sid, 1); b = uniq_E(sid, 2);
            p1 = node(a, :); p2 = node(b, :);
            cand_sids = query_grid_hash_sids_v31(gh, p1, p2, CROSS_CELL);
            for hs = 1:length(cand_sids)
                sid2 = cand_sids(hs);
                if sid2 == sid; continue; end
                c = uniq_E(sid2, 1); d = uniq_E(sid2, 2);
                if a == c || a == d || b == c || b == d; continue; end
                p3 = node(c, :); p4 = node(d, :);
                if seg_seg_proper_intersect_v31(p1, p2, p3, p4)
                    ta = intersect(v2t{a}, v2t{b});
                    tc = []; td_ = [];
                    for t = ta(:)'
                        v = tri(t, :);
                        if any(v == c); tc = [tc, t]; end
                        if any(v == d); td_ = [td_, t]; end
                    end
                    if length(tc) == 1 && length(td_) == 1
                        tri(tc(1), :) = [a, c, d];
                        tri(td_(1), :) = [b, d, c];
                        n_flips = n_flips + 1;
                        found = found + 1;
                        v2t = build_v2t_v31(tri, nnode);
                        if debug
                            fprintf('    [cross-fix] flipped (%d,%d)x(%d,%d)\n', a, b, c, d);
                        end
                    else
                        non_quad_verts = [non_quad_verts; a; b; c; d]; %#ok<AGROW>
                    end
                    break;
                end
            end
        end
        if debug
            fprintf('  [cross-fix iter %d] flips=%d, non-quad_verts=%d\n', ...
                iter, found, length(non_quad_verts));
        end
        if found == 0 && isempty(non_quad_verts); break; end
        if ~isempty(non_quad_verts) && ~isempty(collapse_records)
            % Revert collapses whose A vertex is in non_quad_verts.
            % Only if we have collapse_records (skip for post-rescan fix
            % where records are empty — just leave non-quad crossings).
            revert_A = unique(non_quad_verts);
            for ri = 1:length(collapse_records)
                rec = collapse_records{ri};
                A_rec = rec{1};
                if ismember(A_rec, revert_A)
                    B_rec = rec{2};
                    orig_A_pos = rec{3};
                    % V31_24: FULL revert — restore A position AND undo B->A remap
                    % Restore A to original position
                    node(A_rec, :) = orig_A_pos;
                    % Undo B->A remap: replace A_rec with B_rec in triangles
                    % that originally had B_rec (now have A_rec from collapse)
                    ntri_now = size(tri, 1);
                    for t = 1:ntri_now
                        v = tri(t, :);
                        if any(v == A_rec)
                            % Check if this triangle originally had B_rec
                            % (it was remapped from B_rec to A_rec during collapse)
                            % Heuristic: if triangle has A_rec AND was created by
                            % the collapse (contains neighbors of B_rec), unmap.
                            % Simple approach: replace one occurrence of A_rec
                            % with B_rec if triangle has 2 A_rec entries
                            % (degenerate from collapse). Skip for now —
                            % position restore alone usually removes crossing.
                        end
                    end
                    n_reverts = n_reverts + 1;
                    if debug
                        fprintf('    [cross-fix] reverted collapse of (%d,%d)\n', A_rec, B_rec);
                    end
                end
            end
        end
        if found == 0 && isempty(non_quad_verts); break; end
    end
    info.n_flips = n_flips;
    info.n_reverts = n_reverts;
end

% ---------------------------------------------------------------------
function sids = query_grid_hash_sids_v31(gh, p1, p2, cell_size)
%QUERY_GRID_HASH_SIDS_V31  Return ALL segment ids whose bounding box
%   overlaps the query segment. Uses gh struct (cell_keys + seg_starts).
    lo = min(p1, p2) - cell_size;
    hi = max(p1, p2) + cell_size;
    cx_lo = floor(lo(1) / cell_size);
    cx_hi = floor(hi(1) / cell_size);
    cy_lo = floor(lo(2) / cell_size);
    cy_hi = floor(hi(2) / cell_size);
    sids = [];
    for cx = cx_lo:cx_hi
        for cy = cy_lo:cy_hi
            cell_key = double(cx) * 1e8 + cy;
            idx = binary_search_v31(gh.cell_keys, cell_key);
            if idx == 0; continue; end
            r1 = gh.seg_starts(idx);
            r2 = gh.seg_starts(idx + 1) - 1;
            for r = r1:r2
                sids = [sids, gh.seg_data(r, 1)]; %#ok<AGROW>
            end
        end
    end
    sids = unique(sids);
end

% ---------------------------------------------------------------------
function [node, tri, info, rescan_records] = rescan_short_edges_v31(node, tri, debug, factor)
%RESCAN_SHORT_EDGES_V31  After cross-fix reverts, re-scan boundary for
%   remaining/new short edges. Uses BIDIRECTIONAL collapse (try both
%   keep-A and keep-B) with relaxed conditions. For each candidate:
%   try all X (a,b,c,d) in both directions, pick first that passes
%   fold + boundary self-int + interior cross precheck.
%   Returns rescan_records {kept_v, removed_v, orig_kept_pos} for revert.
    info = struct('n_removed', 0, 'n_tri_removed', 0);
    rescan_records = {};
    LOCAL_FRAC = 0.25;
    COND_B_OTHER = 0.5;
    COND_C_AREA = 0.10;   % relaxed (was 0.05)
    COND_B_AREA = 0.50;   % relaxed (was 0.20)
    GRID_CELL = 1e-4;
    CROSS_CELL = 1e-5;
    MAX_PASSES = 5;
    nnode = size(node, 1);

    for pass = 1:MAX_PASSES
        n_removed_pass = 0;
        loops = find_boundary_loops(node, tri);
        if isempty(loops); break; end

        loop_med = zeros(1, length(loops));
        for k = 1:length(loops)
            lp = loops{k}; L = length(lp);
            lens = zeros(1, L);
            for i = 1:L
                lens(i) = norm(node(lp(i), :) - node(lp(modp_v31(i + 1, L)), :));
            end
            loop_med(k) = median(lens);
        end

        cands = [];
        for k = 1:length(loops)
            lp = loops{k}; L = length(lp);
            if L < 4; continue; end
            med = loop_med(k);
            for i = 1:L
                A = lp(i); B = lp(modp_v31(i + 1, L));
                P_prev = lp(modp_v31(i - 1, L));
                P_next = lp(modp_v31(i + 2, L));
                pA = node(A, :); pB = node(B, :);
                len_AB = norm(pA - pB);
                if len_AB < 1e-15; continue; end
                len_prev = norm(node(P_prev, :) - pA);
                len_next = norm(pB - node(P_next, :));
                if ((len_prev >= factor * len_AB) || (len_next >= factor * len_AB)) && ...
                   len_AB < LOCAL_FRAC * med
                    cands = [cands; len_AB, k, i, A, B, P_prev, P_next]; %#ok<AGROW>
                end
            end
        end
        if isempty(cands); break; end
        [~, sort_idx] = sort(cands(:, 1));
        cands = cands(sort_idx, :);

        v2t = build_v2t_v31(tri, nnode);
        bnd_edges = build_boundary_edges_v31(tri);
        nbnd = size(bnd_edges, 1);
        bnd_seg_pts = zeros(nbnd, 4);
        bnd_edge_keys = zeros(nbnd, 1);
        for sid = 1:nbnd
            a = bnd_edges(sid, 1); b = bnd_edges(sid, 2);
            bnd_edge_keys(sid) = edge_key_v31(a, b);
            bnd_seg_pts(sid, :) = [node(a, 1), node(a, 2), node(b, 1), node(b, 2)];
        end
        gh_bnd = build_grid_hash_v31(bnd_seg_pts, GRID_CELL);
        % Build seg_id_map (sparse) for boundary edges
        if ~isempty(bnd_edge_keys)
            seg_id_map = sparse(bnd_edge_keys, ones(nbnd, 1), (1:nbnd)', ...
                                max(bnd_edge_keys), 1);
        else
            seg_id_map = sparse(1, 1);
        end
        gh_all = build_all_edges_grid_v31(tri, node, CROSS_CELL);

        for ci = 1:size(cands, 1)
            len_AB = cands(ci, 1);
            A = cands(ci, 4); B = cands(ci, 5);
            P_prev = cands(ci, 6); P_next = cands(ci, 7);
            if isempty(v2t{A}) || isempty(v2t{B}); continue; end

            pA = node(A, :); pB = node(B, :);
            pP = node(P_prev, :); pN = node(P_next, :);
            M = 0.5 * (pA + pB);

            % Candidates X (a,b,c,d)
            cand_X = cell(4, 1);
            cand_ok = false(4, 1);
            X_a = line_intersect_v31(pP, pA, pB, pN);
            if ~any(isnan(X_a)) && norm(X_a) < 1e6
                cand_X{1} = X_a; cand_ok(1) = true;
            end
            cand_X{2} = pA; cand_ok(2) = true;
            cand_X{3} = pB; cand_ok(3) = true;
            X_d = r0_feasible_point_v31(pP, pA, pB, pN, M);
            if ~any(isnan(X_d)); cand_X{4} = X_d; cand_ok(4) = true; end

            best_X = []; best_keep_A = true;
            for mi = 1:4
                if ~cand_ok(mi); continue; end
                X = cand_X{mi};
                % Try both directions
                for dir = 1:2
                    if dir == 1; keep_A = true; else; keep_A = false; end
                    if keep_A; kept_v = A; removed_v = B; kept_pos = pA;
                    else; kept_v = B; removed_v = A; kept_pos = pB; end

                    % Fold test
                    flip_ok = true;
                    tris_k = v2t{kept_v};
                    for ti = 1:length(tris_k)
                        t = tri(tris_k(ti), :);
                        if any(t == kept_v) && ~any(t == removed_v)
                            others = t(t ~= kept_v);
                            if length(others) >= 2
                                u = others(1); v = others(2);
                                s_old = tri_signed_area_v31(kept_pos, node(u, :), node(v, :));
                                s_new = tri_signed_area_v31(X, node(u, :), node(v, :));
                                if s_old * s_new < -1e-15; flip_ok = false; break; end
                            end
                        end
                    end
                    if ~flip_ok; continue; end

                    % Boundary self-int (exclude 3 adjacent edges)
                    ex_set = false(nbnd, 1);
                    adj_pairs = [P_prev, A; A, B; B, P_next];
                    for pi = 1:3
                        a = adj_pairs(pi, 1); b = adj_pairs(pi, 2);
                        key = edge_key_v31(a, b);
                        if key <= numel(seg_id_map)
                            sid_found = full(seg_id_map(key));
                            if sid_found > 0
                                ex_set(sid_found) = true;
                            end
                        end
                    end
                    selfint = query_grid_hash_v31(gh_bnd, pP, X, ex_set, GRID_CELL) || ...
                              query_grid_hash_v31(gh_bnd, X, pN, ex_set, GRID_CELL);
                    if selfint; continue; end

                    % Interior cross precheck (new edges only)
                    if ~interior_cross_ok_v31(tri, node, kept_v, removed_v, X, v2t, gh_all)
                        continue;
                    end

                    best_X = X; best_keep_A = keep_A; break;
                end
                if ~isempty(best_X); break; end
            end
            if isempty(best_X); continue; end

            % Apply collapse + record for revert
            if best_keep_A
                rescan_records{end+1} = {A, B, pA}; %#ok<AGROW>
                node(A, :) = best_X; removed_v = B; kept_v = A;
            else
                rescan_records{end+1} = {B, A, pB}; %#ok<AGROW>
                node(B, :) = best_X; removed_v = A; kept_v = B;
            end
            ntri = size(tri, 1);
            has_r = any(tri == removed_v, 2);
            keep = true(ntri, 1);
            for t = find(has_r(:))'
                v = tri(t, :);
                v(v == removed_v) = kept_v;
                tri(t, :) = v;
                if length(unique(v)) < 3; keep(t) = false; end
            end
            tri = tri(keep, :);
            info.n_removed = info.n_removed + 1;
            info.n_tri_removed = info.n_tri_removed + sum(~keep);
            n_removed_pass = n_removed_pass + 1;
            v2t = build_v2t_v31(tri, nnode);
            gh_all = build_all_edges_grid_v31(tri, node, CROSS_CELL);
            if debug
                dir_str = 'B->A'; if ~best_keep_A; dir_str = 'A->B'; end
                fprintf('  [rescan p%d] rm (%d,%d) len=%.2e dir=%s\n', ...
                    pass, A, B, len_AB, dir_str);
            end
        end
        if n_removed_pass == 0; break; end
    end
end

% ---------------------------------------------------------------------
function [node, tri, info] = rescan_after_revert_v31(node, tri, debug, factor)
%RESCAN_AFTER_REVERT_V31  After cross-fix reverts, re-scan boundary for
%   remaining short edges. Uses simple B->A collapse with local_ref
%   threshold. Only checks edges near REVERTED vertices (fast).
    info = struct('n_removed', 0, 'n_tri_removed', 0);
    LOCAL_FRAC = 0.25;
    COND_B_OTHER = 0.50;
    COND_B_AREA_FRAC = 0.20;
    COND_C_AREA_FRAC = 0.05;
    GRID_CELL = 1e-4;
    nnode = size(node, 1);

    loops = find_boundary_loops(node, tri);
    if isempty(loops); return; end

    % Build per-loop median + local_ref for ALL edges (same as main loop)
    cands = [];
    NB = 3;
    for k = 1:length(loops)
        lp = loops{k}; L = length(lp);
        if L < 4; continue; end
        lens = zeros(1, L);
        for i = 1:L
            lens(i) = norm(node(lp(i), :) - node(lp(modp_v31(i + 1, L)), :));
        end
        med = median(lens);
        for i = 1:L
            A = lp(i); B = lp(modp_v31(i + 1, L));
            P_prev = lp(modp_v31(i - 1, L));
            P_next = lp(modp_v31(i + 2, L));
            pA = node(A, :); pB = node(B, :);
            len_AB = norm(pA - pB);
            if len_AB < 1e-15; continue; end
            len_prev = norm(node(P_prev, :) - pA);
            len_next = norm(pB - node(P_next, :));
            nbr_lens = [len_prev, len_next];
            for nb = 1:NB
                idx_prev = modp_v31(i - 1 - nb, L);
                idx_curr = modp_v31(i - nb, L);
                idx_next1 = modp_v31(i + 1 + nb, L);
                idx_next2 = modp_v31(i + 2 + nb, L);
                nbr_lens(end+1) = norm(node(lp(idx_curr), :) - node(lp(idx_prev), :)); %#ok<AGROW>
                nbr_lens(end+1) = norm(node(lp(idx_next1), :) - node(lp(idx_next2), :)); %#ok<AGROW>
            end
            local_ref = mean(nbr_lens);
            is_ratio_r = (len_prev >= factor * len_AB) || (len_next >= factor * len_AB);
            is_local_r = len_AB < LOCAL_FRAC * med;
            is_collinear_r = false;
            min_nbr_r = min(len_prev, len_next);
            if is_ratio_r && ~is_local_r && min_nbr_r >= 0.5 * len_AB && ...
               len_prev > 1e-15 && len_AB > 1e-15
                v1r = pA - node(P_prev, :); v2r = pB - pA;
                cosr = dot(v1r, v2r) / (norm(v1r) * norm(v2r));
                cosr = max(-1, min(1, cosr));
                interior_r = 180 - acosd(cosr);
                if interior_r >= 170 && len_AB < local_ref / 3.0
                    is_collinear_r = true;
                end
            end
            if is_ratio_r && (is_local_r || is_collinear_r)
                cands = [cands; len_AB, A, B, P_prev, P_next, local_ref]; %#ok<AGROW>
            end
        end
    end
    if isempty(cands); return; end
    [~, sort_idx] = sort(cands(:, 1));
    cands = cands(sort_idx, :);

    v2t = build_v2t_v31(tri, nnode);
    bnd_edges = build_boundary_edges_v31(tri);
    nbnd = size(bnd_edges, 1);
    bnd_seg_pts = zeros(nbnd, 4);
    bnd_edge_keys = zeros(nbnd, 1);
    for sid = 1:nbnd
        a = bnd_edges(sid, 1); b = bnd_edges(sid, 2);
        bnd_edge_keys(sid) = edge_key_v31(a, b);
        bnd_seg_pts(sid, :) = [node(a, 1), node(a, 2), node(b, 1), node(b, 2)];
    end
    gh_bnd = build_grid_hash_v31(bnd_seg_pts, GRID_CELL);
    if ~isempty(bnd_edge_keys)
        seg_id_map = sparse(bnd_edge_keys, ones(nbnd, 1), (1:nbnd)', ...
                            max(bnd_edge_keys), 1);
    else
        seg_id_map = sparse(1, 1);
    end

    alive = true(nnode, 1);
    for ci = 1:size(cands, 1)
        len_AB = cands(ci, 1);
        A = cands(ci, 2); B = cands(ci, 3);
        P_prev = cands(ci, 4); P_next = cands(ci, 5);
        local_ref = cands(ci, 6);
        if ~alive(A) || ~alive(B); continue; end
        if isempty(v2t{A}) || isempty(v2t{B}); continue; end

        pA = node(A, :); pB = node(B, :);
        pP = node(P_prev, :); pN = node(P_next, :);
        M = 0.5 * (pA + pB);
        len_prev = norm(pP - pA);
        len_next = norm(pB - pN);
        condA = (len_prev >= factor * len_AB) && (len_next >= factor * len_AB);
        condB = false;
        if ~condA
            if (len_prev >= factor * len_AB && len_next >= COND_B_OTHER * len_AB) || ...
               (len_next >= factor * len_AB && len_prev >= COND_B_OTHER * len_AB)
                condB = true;
            end
        end
        opp = find_opposite_verts_v31(tri, A, B, v2t);
        common = find_common_neighbors_v31(tri, A, B, v2t);
        if ~isequal(sort(common(:)), sort(opp(:))); continue; end

        % QEM + a/b/c/d candidates
        [best_X, best_f, ~] = qem_optimal_placement_v31( ...
            tri, node, A, B, v2t, pP, pA, pB, pN, M, 1e6);
        if isempty(best_X); continue; end

        local_ref_sq = local_ref * local_ref;
        condC = (best_f < COND_C_AREA_FRAC * local_ref_sq) || (best_f < ABS_AREA_FLOOR);
        if condB && best_f >= COND_B_AREA_FRAC * local_ref_sq && ~condC; continue; end
        if ~condA && ~condB && ~condC; continue; end

        % Fold-over test (A + B triangles)
        flip_ok = true;
        tris_A = v2t{A};
        for ti = 1:length(tris_A)
            t = tri(tris_A(ti), :);
            if any(t == A) && ~any(t == B)
                others = t(t ~= A);
                if length(others) >= 2
                    u = others(1); v = others(2);
                    s_old = tri_signed_area_v31(pA, node(u, :), node(v, :));
                    s_new = tri_signed_area_v31(best_X, node(u, :), node(v, :));
                    if s_old * s_new < -1e-15; flip_ok = false; break; end
                end
            end
        end
        if flip_ok
            tris_B = v2t{B};
            for ti = 1:length(tris_B)
                t = tri(tris_B(ti), :);
                if any(t == B) && ~any(t == A)
                    others = t(t ~= B);
                    if length(others) >= 2
                        u = others(1); v = others(2);
                        s_old = tri_signed_area_v31(pB, node(u, :), node(v, :));
                        s_new = tri_signed_area_v31(best_X, node(u, :), node(v, :));
                        if s_old * s_new < -1e-15; flip_ok = false; break; end
                    end
                end
            end
        end
        if ~flip_ok; continue; end

        % Boundary self-int
        ex_set = false(nbnd, 1);
        adj_pairs = [P_prev, A; A, B; B, P_next];
        for pi = 1:3
            a = adj_pairs(pi, 1); b = adj_pairs(pi, 2);
            key = edge_key_v31(a, b);
            if key <= numel(seg_id_map)
                sid_found = full(seg_id_map(key));
                if sid_found > 0; ex_set(sid_found) = true; end
            end
        end
        selfint = query_grid_hash_v31(gh_bnd, pP, best_X, ex_set, GRID_CELL) || ...
                  query_grid_hash_v31(gh_bnd, best_X, pN, ex_set, GRID_CELL);
        if selfint; continue; end

        % V31_66: local crossing check + alternatives (rescan)
        [loc_ok, loc_cv] = local_cross_check_v31(tri, node, A, B, best_X, v2t);
        if ~loc_ok
            alt_found = false;
            alt_cands = {pA, pB, M};
            if loc_cv > 0 && loc_cv ~= A && loc_cv ~= B
                alt_cands{end+1} = node(loc_cv, :);
            end
            for ai = 1:length(alt_cands)
                [ok2, ~] = local_cross_check_v31(tri, node, A, B, alt_cands{ai}, v2t);
                if ok2
                    best_X = alt_cands{ai};
                    alt_found = true; break;
                end
            end
            if ~alt_found; continue; end
        end

        % Apply collapse
        alive(B) = false;
        node(A, :) = best_X;
        ntri = size(tri, 1);
        has_B = any(tri == B, 2);
        keep = true(ntri, 1);
        for t = find(has_B(:))'
            v = tri(t, :);
            v(v == B) = A;
            tri(t, :) = v;
            if length(unique(v)) < 3; keep(t) = false; end
        end
        tri = tri(keep, :);
        info.n_removed = info.n_removed + 1;
        info.n_tri_removed = info.n_tri_removed + sum(~keep);
        v2t = build_v2t_v31(tri, nnode);
        if debug
            fprintf('  [rescan-revert] rm (%d,%d) len=%.2e\n', A, B, len_AB);
        end
    end
end
