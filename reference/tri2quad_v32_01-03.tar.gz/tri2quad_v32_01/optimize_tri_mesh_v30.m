function [tri, info] = optimize_tri_mesh_v30(tri, node, nbr, debug)
%OPTIMIZE_TRI_MESH_V30  Triangle mesh optimization: Delaunay + quad-friendly flips.
%
%   V30: Reuses v27's optimize_tri_mesh_v2 algorithm. Kept as a separate
%   file so callers can identify which functions need to be in the
%   current directory. Logic is identical to v27 (Delaunay then quad-friendly).
%
%   Phase 1: Delaunay edge flips (maximize minimum angle)
%   Phase 2: Quad-friendly edge flips (minimize quad shape cost)

    info = struct('n_delaunay_flips', 0, 'n_quad_flips', 0, 'n_passes', 0);
    ntri = size(tri, 1);

    for pass = 1:10
        info.n_passes = pass;
        n_del_flips = 0;
        n_quad_flips = 0;
        nbr = compute_neighbors_fast(tri);

        for i = 1:ntri
            for j = 1:3
                k = nbr(i, j);
                if k < 0 || k <= i; continue; end

                a = tri(i, mod(j, 3) + 1);
                b = tri(i, mod(j + 1, 3) + 1);
                c = tri(i, j);
                d = 0;
                for jj = 1:3
                    v = tri(k, jj);
                    if v ~= a && v ~= b
                        d = v; break;
                    end
                end
                if d == 0; continue; end

                % Delaunay flip
                pA = node(a, :); pB = node(b, :); pC = node(c, :); pD = node(d, :);
                ang_C = angle_at_vertex_v30(pC, pA, pB);
                ang_D = angle_at_vertex_v30(pD, pA, pB);

                if ang_C + ang_D > 180.0 + 0.01
                    for pos = 1:3
                        if tri(i, pos) == b; tri(i, pos) = d; break; end
                    end
                    for pos = 1:3
                        if tri(k, pos) == a; tri(k, pos) = c; break; end
                    end
                    n_del_flips = n_del_flips + 1;
                    nbr(i, j) = -1;
                    continue;
                end

                % Quad-friendly flip
                cost_current = quad_shape_cost_4pts_v30(node, a, b, c, d);
                cost_flipped = quad_shape_cost_4pts_v30(node, c, d, a, b);

                if cost_flipped < cost_current - 0.1
                    for pos = 1:3
                        if tri(i, pos) == b; tri(i, pos) = d; break; end
                    end
                    for pos = 1:3
                        if tri(k, pos) == a; tri(k, pos) = c; break; end
                    end
                    n_quad_flips = n_quad_flips + 1;
                    nbr(i, j) = -1;
                end
            end
        end

        info.n_delaunay_flips = info.n_delaunay_flips + n_del_flips;
        info.n_quad_flips = info.n_quad_flips + n_quad_flips;

        if n_del_flips == 0 && n_quad_flips == 0; break; end
    end
end

% =====================================================================
function ang = angle_at_vertex_v30(p_vertex, p_a, p_b)
    v_a = p_a - p_vertex;
    v_b = p_b - p_vertex;
    na = norm(v_a); nb = norm(v_b);
    if na < 1e-15 || nb < 1e-15
        ang = 0; return;
    end
    cos_ang = max(-1, min(1, dot(v_a, v_b) / (na * nb)));
    ang = acosd(cos_ang);
end

% =====================================================================
function cost = quad_shape_cost_4pts_v30(node, v1, v2, v3, v4)
%QUAD_SHAPE_COST_4PTS_V30  Compute quad shape cost for vertices v1,v2,v3,v4.
    verts = [v1, v2, v3, v4];
    pts = node(verts, :);
    c = mean(pts, 1);
    ang = atan2(pts(:, 2) - c(2), pts(:, 1) - c(1));
    [~, sidx] = sort(ang);
    pts = pts(sidx, :);

    angles = zeros(4, 1);
    for k = 1:4
        p1 = pts(k, :);
        p2 = pts(mod(k, 4) + 1, :);
        p3 = pts(mod(k + 1, 4) + 1, :);
        v_in = p1 - p2; v_out = p3 - p2;
        na = norm(v_in); nb = norm(v_out);
        if na < 1e-15 || nb < 1e-15
            angles(k) = 0;
        else
            cos_a = max(-1, min(1, dot(v_in, v_out) / (na * nb)));
            angles(k) = acosd(cos_a);
        end
    end

    cost = sum((angles - 90) .^ 2);

    for k = 1:4
        p1 = pts(k, :);
        p2 = pts(mod(k, 4) + 1, :);
        p3 = pts(mod(k + 1, 4) + 1, :);
        cr = (p2(1)-p1(1))*(p3(2)-p2(2)) - (p2(2)-p1(2))*(p3(1)-p2(1));
        if cr <= 0
            cost = cost + 50000;   % V30: huge penalty for concave
        end
    end
end
