%node=load('E:\company\EDA\huawei\quadmesh\test1\test1.xmlSignal$L3_node.txt');
%tri=load('E:\company\EDA\huawei\quadmesh\test1\test1.xmlSignal$L3_tri.txt');
% cutbyarea(4.1e-3,5.0e-3,-5.2e-3,-4.4e-3,node,tri,'eddytri');
% cutbyarea(4.1e-3,5.0e-3,-5.2e-3,-4.4e-3,quadnode,quad,'eddyquad');
% cutbyarea(3e-4,8e-4,-6.0e-3,-5.6e-3,node,tri,'breaktri');
% cutbyarea(3e-4,8e-4,-6.0e-3,-5.6e-3,quadnode,quad,'breakquad');
% cutbyarea(-2.8e-3,-2.5e-3,-7.3e-3,-7.0e-3,node,tri,'flattri');
% cutbyarea(-2.8e-3,-2.5e-3,-7.3e-3,-7.0e-3,quadnode,quad,'flatquad');
% 
% cutbyarea(-3.9e-3,-3.5e-3,-4.15e-3,-3.85e-3,node,tri,'onedgetri');
% cutbyarea(-3.9e-3,-3.5e-3,-4.15e-3,-3.85e-3,quadnode,quad,'onedgequad');
% 
% cutbyarea(1.5e-3,1.7e-3,-2.75e-3,-2.6e-3,quadnode,quad,'badquad');
% cutbyarea(2.66e-3,2.74e-3,-2.94e-3,-2.87e-3,quadnode,quad,'badquad1');
% cutbyarea(2.6e-3,2.74e-3,-3.1e-3,-2.95e-3,quadnode,quad,'badquad2');
cutbyarea(2.22e-3,2.38e-3,-2.72e-3,-2.62e-3,node,tri,'badtri1');
% cutbyarea(-5.32e-3,-5.26e-3,-2.74e-3,-2.64e-3,node,tri,'badtri2');
% cutbyarea(-5.12e-3,-5.02e-3,-2.81e-3,-2.72e-3,node,tri,'badtri3');


function cutbyarea(x0,x9,y0,y9,node,ele,prefix)
f=find(node(:,1)>x0 & node(:,1)<x9 & node(:,2)>y0 & node(:,2)<y9);
nodet=[f node(f,:)];
idx=zeros(size(node,1),1);
idx(f)=1;
ft = find(sum(idx(ele), 2) == size(ele,2));
tele=ele(ft,:);
savedata(nodet,tele,[prefix '.txt']);

end

function savedata(a,b,filename)
fid=fopen(filename,'wt');
fprintf(fid,"%d %e %e\n",a');
if(size(b,2)==3)
    fprintf(fid,"%d %d %d\n",b');
else
    fprintf(fid,"%d %d %d %d\n",b');
end

fclose(fid);
end
