function debug_plot_vertex_forces_v30(quadnode, quad, nnode_orig)
%DEBUG_PLOT_VERTEX_FORCES_V30  V30-DEBUG: plot the quad mesh, highlight bad
%   quads (red fill), and mark movable interior vertices (red circles +
%   blue arrows showing gradient direction). Called at Stage 5b (debug=1).
%
%   V30-FIX: uses SCALED JACOBIAN (Knupp 2001) for accurate bad-quad
%   detection. sj < 0.3 = bad (concave sj<0, or min angle < ~17°).
%   This avoids marking thin-but-convex quads (sj > 0.3) as "bad".
%   Only marks INTERIOR vertices (skips boundary vertices — they can't move).

    nq = size(quad, 1);
    nqn = size(quadnode, 1);

    [edge_arr, ~, ~] = build_edge_array_local(quad);
    is_bnd_vtx = compute_bnd_vtx_local(edge_arr, nqn);
    vtx_quads = cell(nqn, 1);
    nbrs_map = cell(nqn, 1);
    for qi = 1:nq
        q = quad(qi, :);
        if any(q == 0); continue; end
        for j = 1:4
            v = q(j);
            if v > 0 && v <= nqn
                vtx_quads{v}(end+1) = qi; %#ok<AGROW>
            end
        end
    end
    for ei = 1:size(edge_arr, 1)
        a = edge_arr(ei, 1); b = edge_arr(ei, 2);
        nbrs_map{a}(end+1) = b; %#ok<AGROW>
        nbrs_map{b}(end+1) = a; %#ok<AGROW>
    end

    % Find movable interior vertices + their gradient forces
    move_from = [];
    move_to = [];
    for v = (nnode_orig+1):nqn
        if v > nqn; break; end
        if is_bnd_vtx(v); continue; end
        incident = vtx_quads{v};
        k = length(incident);
        if k < 2; continue; end
        q_vals = zeros(k, 1);
        prev_v = zeros(k, 1); next_v = zeros(k, 1);
        valid_mask = true(k, 1);
        for i = 1:k
            qi = incident(i);
            if qi > size(quad, 1); valid_mask(i) = false; continue; end
            qk = quad(qi, :);
            if any(qk == 0); valid_mask(i) = false; continue; end
            pts = quadnode(qk, :);
            q_vals(i) = scaled_jacobian_local(pts);
            pos_idx = find(qk == v, 1);
            next_v(i) = qk(mod(pos_idx, 4) + 1);
            prev_v(i) = qk(mod(pos_idx - 2, 4) + 1);
        end
        if ~any(valid_mask); continue; end
        q_valid = q_vals(valid_mask);
        old_min_q = min(q_valid);
        if old_min_q > 0.3; continue; end

        old_pos = quadnode(v, :);
        F = [0, 0];
        for i = 1:k
            if ~valid_mask(i); continue; end
            pv = quadnode(prev_v(i), :);
            nv = quadnode(next_v(i), :);
            a = nv - old_pos; b = pv - old_pos;
            na = norm(a); nb = norm(b);
            if na < 1e-15 || nb < 1e-15; continue; end
            D = na * nb;
            cross_val = a(1)*b(2) - a(2)*b(1);
            sj_i = cross_val / D;
            dcross_dv = [nv(2) - pv(2), pv(1) - nv(1)];
            grad_i = dcross_dv / D + sj_i * (a/na^2 + b/nb^2);
            F = F + grad_i;
        end
        f_len = norm(F);
        if f_len < 1e-12; continue; end
        nbrs = nbrs_map{v};
        if isempty(nbrs); continue; end
        min_d = min(sqrt(sum((quadnode(nbrs,:) - old_pos).^2, 2)));
        if min_d < 1e-15; continue; end
        step = 0.3 * min_d;
        F_dir = F / f_len * step;
        move_from(end+1, :) = old_pos; %#ok<AGROW>
        move_to(end+1, :) = old_pos + F_dir; %#ok<AGROW>
    end

    figure('Name', 'V30 Debug', 'NumberTitle', 'off');
    hold on; axis equal; axis off;
    patch('faces', quad, 'vertices', quadnode, 'facecolor', [0.92 0.92 0.92], 'edgecolor', [0.5 0.5 0.5]);

    % Highlight BAD quads (scaled Jacobian < 0.3) in red
    n_bad = 0;
    for qi = 1:nq
        q = quad(qi, :);
        if any(q == 0); continue; end
        if length(unique(q)) < 4
            n_bad = n_bad + 1;
            patch(quadnode(q([1:4, 1]), 1), quadnode(q([1:4, 1]), 2), 'r', ...
                'FaceColor', [1 0.6 0.6], 'EdgeColor', 'r', 'LineWidth', 1.5);
            continue;
        end
        pts = quadnode(q, :);
        sj = scaled_jacobian_local(pts);
        if sj < 0.3
            n_bad = n_bad + 1;
            patch(quadnode(q([1:4, 1]), 1), quadnode(q([1:4, 1]), 2), 'r', ...
                'FaceColor', [1 0.6 0.6], 'EdgeColor', 'r', 'LineWidth', 1.5);
        end
    end

    % Mark movable interior vertices (red circles + blue arrows)
    for i = 1:size(move_from, 1)
        p0 = move_from(i, :);
        p1 = move_to(i, :);
        plot(p0(1), p0(2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
        plot([p0(1), p1(1)], [p0(2), p1(2)], 'b-', 'LineWidth', 2);
        dir = p1 - p0; dn = norm(dir);
        if dn > 1e-15
            dir = dir / dn;
            perp = [-dir(2), dir(1)];
            ah = 0.2 * dn;
            plot([p1(1), p1(1) - ah*dir(1) + ah*perp(1)], ...
                 [p1(2), p1(2) - ah*dir(2) + ah*perp(2)], 'b-', 'LineWidth', 2);
            plot([p1(1), p1(1) - ah*dir(1) - ah*perp(1)], ...
                 [p1(2), p1(2) - ah*dir(2) - ah*perp(2)], 'b-', 'LineWidth', 2);
        end
    end
    title(sprintf('V30 Debug: %d bad quads (red), %d movable interior vertices (red circles + blue arrows)', ...
        n_bad, size(move_from, 1)));
    hold off;
    fprintf('  [debug-plot] %d bad quads (sj<0.3, red). %d movable interior vertices (red circles + blue arrows).\n', ...
        n_bad, size(move_from, 1));
end

% =====================================================================
function [edge_arr, edge_quad_list, edge_keys] = build_edge_array_local(quad)
    nq = size(quad, 1);
    all_edges = zeros(nq * 4, 3);
    ec = 0;
    for qi = 1:nq
        q = quad(qi, :);
        if any(q == 0); continue; end
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if v1 > 0 && v2 > 0 && v1 ~= v2
                ec = ec + 1;
                all_edges(ec, :) = [min(v1, v2), max(v1, v2), qi];
            end
        end
    end
    all_edges = sortrows(all_edges(1:ec, :), [1, 2]);
    edge_arr = zeros(ec, 2);
    edge_quad_list = cell(ec, 1);
    n_unique = 0;
    i = 1;
    while i <= ec
        n_unique = n_unique + 1;
        edge_arr(n_unique, :) = all_edges(i, 1:2);
        qids = all_edges(i, 3);
        while i < ec && all_edges(i+1, 1) == all_edges(i, 1) && ...
                       all_edges(i+1, 2) == all_edges(i, 2)
            i = i + 1;
            qids = [qids, all_edges(i, 3)]; %#ok<AGROW>
        end
        edge_quad_list{n_unique} = qids;
        i = i + 1;
    end
    edge_arr = edge_arr(1:n_unique, :);
    edge_quad_list = edge_quad_list(1:n_unique);
    edge_keys = edge_arr(:, 1) * 1e9 + edge_arr(:, 2);
end

% =====================================================================
function is_bnd = compute_bnd_vtx_local(edge_arr, nqn)
    is_bnd = false(nqn, 1);
    if size(edge_arr, 1) == 0; return; end
    [ue, ~, ic] = unique(edge_arr, 'rows');
    cnt = accumarray(ic, 1);
    for i = 1:size(ue, 1)
        if cnt(i) == 1
            is_bnd(ue(i, 1)) = true;
            is_bnd(ue(i, 2)) = true;
        end
    end
end

% =====================================================================
function sj = scaled_jacobian_local(pts)
    sj = 1;
    for j = 1:4
        pc = pts(j, :);
        pa = pts(mod(j, 4) + 1, :);
        pb = pts(mod(j - 2, 4) + 1, :);
        ea = pa - pc; eb = pb - pc;
        na = norm(ea); nb = norm(eb);
        if na < 1e-15 || nb < 1e-15
            sj = 0; return;
        end
        cross_val = ea(1)*eb(2) - ea(2)*eb(1);
        sj_c = cross_val / (na * nb);
        if sj_c < sj; sj = sj_c; end
    end
end
