function nbr = compute_neighbors_fast(tri)
%COMPUTE_NEIGHBORS_FAST Vectorized triangle adjacency computation.
%   nbr = compute_neighbors_fast(tri) returns an N-by-3 array where
%   nbr(i,j) is the index of the triangle sharing edge j of triangle i,
%   or -1 if the edge is on the boundary.
%
%   Edge j of triangle i is opposite vertex j, i.e.:
%     j=1 : edge (v2,v3)
%     j=2 : edge (v3,v1)
%     j=3 : edge (v1,v2)
%
%   REUSED FROM ORIGINAL tri2quad.m WITHOUT MODIFICATION.
%   Vectorized O(N log N) implementation using sortrows.

    ntri = size(tri, 1);
    v1 = tri(:, 1); v2 = tri(:, 2); v3 = tri(:, 3);

    % Build edge list: (min_vertex, max_vertex, local_edge_id, tri_id)
    e1 = [min(v2,v3), max(v2,v3), ones(ntri,1), (1:ntri)'];
    e2 = [min(v3,v1), max(v3,v1), 2*ones(ntri,1), (1:ntri)'];
    e3 = [min(v1,v2), max(v1,v2), 3*ones(ntri,1), (1:ntri)'];

    col = [e1; e2; e3];
    col = sortrows(col);   % identical edges become adjacent

    nbr = -ones(ntri, 3);
    for i = 1:3*ntri-1
        if col(i,1)==col(i+1,1) && col(i,2)==col(i+1,2)
            s1 = col(i,3);   t1 = col(i,4);
            s2 = col(i+1,3); t2 = col(i+1,4);
            nbr(t1, s1) = t2;
            nbr(t2, s2) = t1;
        end
    end
end
