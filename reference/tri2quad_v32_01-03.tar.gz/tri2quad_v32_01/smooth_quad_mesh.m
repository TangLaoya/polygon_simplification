function [quadnode, moved] = smooth_quad_mesh(quadnode, quad, fixed, iters)
%SMOOTH_QUAD_MESH Constrained Laplacian smoothing that preserves quad
%   validity (no sign flips / no inversions) at every step.
%
%   [quadnode, moved] = smooth_quad_mesh(quadnode, quad, fixed, iters)
%     quadnode : Nx2 node coordinates (modified in place)
%     quad     : Mx4 quad connectivity (1-based)
%     fixed    : Nx1 logical, true = node is held fixed
%     iters    : number of outer iterations
%     moved    : true if any node moved in the last iteration
%
%   Algorithm:
%     * Pre-computes per-node neighbor lists and per-node quad lists.
%     * Each iteration computes a target Laplacian position, then tries
%       to move there in up to 3 decreasing steps (1.0, 0.5, 0.25) of
%       the (bounded) displacement.  A move is accepted only if it does
%       NOT change the orientation (sign of signed area) of any quad
%       incident on the node.  This guarantees no quad becomes concave
%       or inverted as a side-effect of smoothing (Requirement #5, #6).
%
%   REUSED FROM ORIGINAL tri2quad.m WITHOUT MODIFICATION.
%   (High-release Laplacian with pure sign check.)
%   Listed here as a standalone file so the new pipeline can call it
%   directly without re-defining it inside the main file.

    nqn = size(quadnode, 1);

    % --- Pre-compute per-node quad list & position-in-quad -----------
    max_quads_per_node = 8;
    node_quads     = zeros(nqn, max_quads_per_node);
    node_quad_pos  = zeros(nqn, max_quads_per_node);
    node_quad_cnt  = zeros(nqn, 1);

    % --- Pre-compute per-node neighbor (graph) list -----------------
    max_nbs_per_node = 8;
    node_nbs    = zeros(nqn, max_nbs_per_node);
    node_nb_cnt = zeros(nqn, 1);

    for i = 1:size(quad, 1)
        q = quad(i, :);
        for j = 1:4
            v = q(j);
            cnt = node_quad_cnt(v) + 1;
            if cnt <= max_quads_per_node
                node_quads(v, cnt)    = i;
                node_quad_pos(v, cnt) = j;
                node_quad_cnt(v)      = cnt;
            end

            v2 = q(mod(j, 4) + 1);
            nbc = node_nb_cnt(v) + 1;
            if nbc <= max_nbs_per_node
                node_nbs(v, nbc) = v2;
                node_nb_cnt(v)  = nbc;
            end
        end
    end

    moved = false;
    for iter = 1:iters
        moved = false;

        % Vectorized Laplacian target = mean of graph neighbors
        nb_pos_sum = zeros(nqn, 2);
        for j = 1:max_nbs_per_node
            valid = node_nbs(:, j) > 0;
            idx   = node_nbs(valid, j);
            nb_pos_sum(valid, :) = nb_pos_sum(valid, :) + quadnode(idx, :);
        end
        valid_nodes = node_nb_cnt > 0;
        new_pos = zeros(nqn, 2);
        new_pos(valid_nodes, :) = nb_pos_sum(valid_nodes, :) ./ node_nb_cnt(valid_nodes);

        % Min distance to any neighbor (used to bound the move)
        min_d_arr = inf(nqn, 1);
        for i = 1:nqn
            if node_nb_cnt(i) > 0
                nbrs = node_nbs(i, 1:node_nb_cnt(i), :);
                d = sqrt(sum((quadnode(nbrs, :) - quadnode(i, :)).^2, 2));
                min_d_arr(i) = min(d);
            end
        end

        % Try to move each non-fixed interior node
        for i = 1:nqn
            if fixed(i);                 continue; end
            if node_quad_cnt(i) == 0;     continue; end
            if node_nb_cnt(i)  < 3;       continue; end

            old_pos  = quadnode(i, :);
            move_vec = new_pos(i, :) - old_pos;
            move_len = norm(move_vec);
            if move_len == 0; continue; end

            min_d = min_d_arr(i);
            if move_len > 0.4 * min_d
                move_vec = move_vec * (0.4 * min_d / move_len);
            end

            % Decreasing step sizes (high-release strategy)
            alphas = [1.0, 0.5, 0.25];
            for a = 1:length(alphas)
                alpha = alphas(a);
                test_pos = old_pos + alpha * move_vec;
                valid = true;

                % Verify no sign flip in any incident quad
                for k = 1:node_quad_cnt(i)
                    qi  = node_quads(i, k);
                    q   = quad(qi, :);
                    pos = node_quad_pos(i, k);

                    p1 = quadnode(q(1), :); p2 = quadnode(q(2), :);
                    p3 = quadnode(q(3), :); p4 = quadnode(q(4), :);

                    % Original signed areas (split quad into 2 triangles)
                    A1_o = (p2(1)-p1(1))*(p3(2)-p1(2)) - (p2(2)-p1(2))*(p3(1)-p1(1));
                    A2_o = (p3(1)-p1(1))*(p4(2)-p1(2)) - (p3(2)-p1(2))*(p4(1)-p1(1));

                    if     pos == 1; p1 = test_pos;
                    elseif pos == 2; p2 = test_pos;
                    elseif pos == 3; p3 = test_pos;
                    else;            p4 = test_pos; end

                    A1_n = (p2(1)-p1(1))*(p3(2)-p1(2)) - (p2(2)-p1(2))*(p3(1)-p1(1));
                    A2_n = (p3(1)-p1(1))*(p4(2)-p1(2)) - (p3(2)-p1(2))*(p4(1)-p1(1));

                    if (A1_o >  1e-9 && A1_n <  1e-9) || ...
                       (A1_o < -1e-9 && A1_n > -1e-9) || ...
                       (A2_o >  1e-9 && A2_n <  1e-9) || ...
                       (A2_o < -1e-9 && A2_n > -1e-9)
                        valid = false; break;
                    end
                end

                if valid
                    quadnode(i, :) = test_pos;
                    moved = true;
                    break;
                end
            end
        end
        if ~moved; break; end
    end
end
