% test_tri2quad_v31.m
%   Test driver for V31: short-edge removal + Blossom-Quad pipeline.
%   Load real data, run pipeline, save result + verification report.

clear; clc;
node = load('node.txt');
tri  = load('tri.txt');
if size(tri,2) == 1
    tri = reshape(tri, [], 3);
end
fprintf('Input: %d vtx, %d tri\n', size(node,1), size(tri,1));

debug = 1;

% --- Stage 0: plot input mesh ---
if debug
    figure('Name','Stage 0 -- input mesh','NumberTitle','off');
    hold on; axis equal; axis off;
    patch('faces', tri, 'vertices', node, 'facecolor', 'none', 'edgecolor', 'k');
    title('stage 0 -- input mesh'); hold off;
end

% --- Run V31 pipeline ---
blossom = 6;
par = 0;  % 0=single-thread no split, 1=parallel
tic;
[quadnode, quad, report] = tri2quad_v31(node, tri, blossom, par, debug);
toc;

fprintf('\n=== RESULT ===\n');
fprintf('quad: %d elements, %d vertices (orig %d, ratio %.3f)\n', ...
    size(quad,1), size(quadnode,1), size(node,1), ...
    size(quadnode,1) / size(node,1));

if debug
    figure('Name','Stage 2 -- after quadmesh V31','NumberTitle','off');
    hold on; axis equal; axis off;
    patch('faces', quad, 'vertices', quadnode, 'facecolor', 'r', 'edgecolor', 'k');
    title('stage 2 -- after quadmesh V31'); hold off;
    save('quadnode_v31.txt','quadnode','-ascii');
    save('quad_v31.txt','quad','-ascii');
end
