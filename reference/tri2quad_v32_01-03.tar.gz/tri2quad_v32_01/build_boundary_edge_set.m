function boundary_edge_set = build_boundary_edge_set(node, tri)
%BUILD_BOUNDARY_EDGE_SET Build a sparse logical map identifying all
%   boundary edges of the triangle mesh.
%
%   boundary_edge_set = build_boundary_edge_set(node, tri)
%     Returns a sparse NxN logical matrix where
%     boundary_edge_set(min(a,b), max(a,b)) = true if edge (a,b) is
%     a boundary edge (appears in exactly ONE triangle).
%
%   Used by build_quad_topology_boundary_aware to prevent midpoint
%   insertion on boundary edges (Requirement #1).

    nnode = size(node, 1);
    E = [tri(:,[2 3]); tri(:,[3 1]); tri(:,[1 2])];
    E = sort(E, 2);
    [ue, ~, ic] = unique(E, 'rows');
    cnt = accumarray(ic, 1);
    bnd_edges = ue(cnt == 1, :);

    boundary_edge_set = sparse(nnode, nnode);
    for i = 1:size(bnd_edges, 1)
        a = bnd_edges(i, 1);
        b = bnd_edges(i, 2);
        boundary_edge_set(a, b) = true;
    end
end
