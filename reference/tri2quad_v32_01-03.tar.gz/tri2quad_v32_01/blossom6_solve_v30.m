function [match, info] = blossom6_solve_v30(node_count, edges, weights, debug, method_pref)
%BLOSSOM6_SOLVE_V28  Solve MWPM using Blossom VI (V28 robust version).
%
%   [match, info] = blossom6_solve_v30(node_count, edges, weights, debug, method_pref)
%
%   V28 IMPROVEMENTS over v27 blossom6_solve:
%     1. WEIGHT SANITIZATION (CRITICAL FIX): All weights clamped to
%        [1, 2*10^9] (positive integers). Negative/zero weights cause
%        Blossom VI's "InitGreedyIncreaseVars: smallest_slack < 0" error.
%        The error occurs when:
%          - Aux edges (HUGE_W) are added between disconnected components,
%            creating huge weight asymmetry between adjacent edges.
%          - Weights can be zero (init asymmetry between vertices whose
%            min incident weight differs).
%        V28 fix: per-component dispatch (no aux edges) + clamp to [1, 2e9].
%     2. PER-COMPONENT DISPATCH: If the graph is disconnected, solve each
%        component separately (no aux edges, no balancer needed if each
%        component has even size).
%     3. ROBUST MATLAB FALLBACK: Bounded BFS (no infinite loops).
%        Hard cap on outer loop (50) and BFS iterations (2n).
%
%   Tries methods in this order (unless method_pref overrides):
%     1. CLI (blossom6_cli) - SAFE: runs in subprocess, MATLAB never crashes
%     2. MEX (blossom6_mex) - FAST: but segfaults crash MATLAB
%     3. MATLAB fallback - suboptimal but always works
%
%   INPUTS:
%     node_count : scalar positive even integer
%     edges      : E-by-2 matrix, 0-indexed node IDs in [0, node_count-1]
%     weights    : E-by-1 vector of edge costs (will be sanitized to [1, 2e9])
%     debug      : (optional) verbose flag, default false
%     method_pref: (optional) 'cli' | 'mex' | 'auto' | 'matlab', default 'auto'
%
%   OUTPUT:
%     match : node_count-by-1 vector. match[i] = partner of i (0-indexed).
%             -1 means unmatched (should not happen with ghost-ghost edges).
%     info  : struct with .method, .n_pairs, .cost, .time_sec

    if nargin < 4; debug = false; end
    if nargin < 5; method_pref = 'auto'; end
    t_start = tic;
    info = struct();

    % -------- Validate inputs --------
    if node_count <= 0 || node_count ~= floor(node_count)
        error('blossom6_solve_v30:invalidNodeCount', ...
              'node_count must be positive integer, got %g', node_count);
    end
    if mod(node_count, 2) ~= 0
        error('blossom6_solve_v30:oddNodeCount', ...
              'node_count must be even, got %d', node_count);
    end
    if size(edges, 2) ~= 2
        error('blossom6_solve_v30:invalidEdges', 'edges must be E-by-2');
    end
    E = size(edges, 1);
    if numel(weights) ~= E
        error('blossom6_solve_v30:invalidWeights', ...
              'weights must have %d entries, got %d', E, numel(weights));
    end
    weights = weights(:);
    edges = double(edges);
    weights = double(weights);

    % -------- V28: Weight sanitization --------
    % CRITICAL FIX for "InitGreedyIncreaseVars: smallest_slack < 0":
    % Blossom VI multiplies double weights by 1000 and rounds to int.
    % The error occurs when adjacent edges have VERY different weights
    % (e.g., 1 vs 1e8), causing asymmetric dual variable updates that
    % leave some slacks negative.
    % Fix: clamp to [1, 2*10^9 / 1000 = 2*10^6] to keep scaled weights
    % in a moderate range. Actually, Blossom VI scales by 1000, so the
    % effective int range is [1000, 2*10^9]. Even with HUGE_W, slacks
    % stay non-negative because per-component dispatch avoids aux edges.
    INT_MAX = 2 * 1e9;   % Blossom VI uses int (likely 32-bit); stay below 2.1e9
    weights = max(weights, 1);
    weights = min(weights, INT_MAX);
    weights = round(weights);

    % -------- V31_26: Single solve (Blossom VI handles multi-component) --------
    %   Previous V28 per-component dispatch adds overhead (split + multiple CLI
    %   calls + merge). Blossom VI CLI handles disconnected graphs natively.
    [match, info] = solve_single_b6(node_count, edges, weights, debug, method_pref);
    info.time_sec = toc(t_start);
end

% =====================================================================
function [match, info] = solve_single_b6(node_count, edges, weights, debug, method_pref)
%SOLVE_SINGLE_B6  Solve MWPM for a single connected component (Blossom VI).

    t_start = tic;
    info = struct();

    cli_path_found = ~isempty(find_cli_path_b6());
    mex_available = exist('blossom6_mex', 'file') == 3;

    if strcmp(method_pref, 'cli')
        use_method = 'cli';
        if ~cli_path_found
            error('blossom6_solve_v30:cliNotFound', ...
                'blossom6_cli not found. Run compile_blossom6.m');
        end
    elseif strcmp(method_pref, 'mex')
        use_method = 'mex';
        if ~mex_available
            warning('blossom6_solve_v30:mexNotFound', ...
                'blossom6_mex not found, falling back to auto');
            use_method = 'auto';
        end
    elseif strcmp(method_pref, 'matlab')
        use_method = 'matlab';
    else  % 'auto'
        if cli_path_found
            use_method = 'cli';
        elseif mex_available
            use_method = 'mex';
        else
            use_method = 'matlab';
        end
    end

    if debug
        fprintf('    [blossom6-v28] method=%s (cli=%d, mex=%d, pref=%s)\n', ...
            use_method, cli_path_found, mex_available, method_pref);
    end

    switch use_method
        case 'cli'
            [match, ok] = solve_via_cli_b6(node_count, edges, weights, debug);
            if ~ok
                if debug; fprintf('    [blossom6-v28] CLI failed, trying MATLAB fallback\n'); end
                match = blossom6_matlab_fallback_v30(node_count, edges, weights, debug);
                info.method = 'matlab_fallback';
            else
                info.method = 'cli';
            end
        case 'mex'
            [match, ok] = solve_via_mex_b6(node_count, edges, weights, debug);
            if ~ok
                if debug; fprintf('    [blossom6-v28] MEX failed, trying CLI\n'); end
                if cli_path_found
                    [match, ok2] = solve_via_cli_b6(node_count, edges, weights, debug);
                    if ~ok2
                        match = blossom6_matlab_fallback_v30(node_count, edges, weights, debug);
                        info.method = 'matlab_fallback';
                    else
                        info.method = 'cli_fallback';
                    end
                else
                    match = blossom6_matlab_fallback_v30(node_count, edges, weights, debug);
                    info.method = 'matlab_fallback';
                end
            else
                info.method = 'mex';
            end
        case 'matlab'
            match = blossom6_matlab_fallback_v30(node_count, edges, weights, debug);
            info.method = 'matlab';
    end

    % Compute cost
    cost = 0;
    n_pairs = 0;
    seen = false(node_count, 1);
    ew_map = containers.Map('KeyType', 'double', 'ValueType', 'any');
    for k = 1:size(edges, 1)
        a = edges(k, 1); b = edges(k, 2);
        key = aux_key_b6(a, b);
        if ~isKey(ew_map, key); ew_map(key) = weights(k); end
    end
    for i = 1:node_count
        if seen(i); continue; end
        j = match(i);
        if j < 0; continue; end
        ji = j + 1;
        if ji > 0 && ji <= node_count
            seen(i) = true;
            seen(ji) = true;
            key = aux_key_b6(i-1, j-1);
            if isKey(ew_map, key)
                cost = cost + ew_map(key);
                n_pairs = n_pairs + 1;
            end
        end
    end
    info.n_pairs = n_pairs;
    info.cost = cost;
    info.time_sec = toc(t_start);

    if debug
        fprintf('    [blossom6-v28] method=%s, pairs=%d, cost=%.4g, time=%.3fs\n', ...
            info.method, n_pairs, cost, info.time_sec);
    end
end

% =====================================================================
function cli_path = find_cli_path_b6()
%FIND_CLI_PATH_B6  Locate the blossom6_cli executable.
    cli_path = '';
    p = which('blossom6_cli');
    if ~isempty(p); cli_path = p; return; end
    ext = '';
    if ispc; ext = '.exe'; end
    base_dir = fileparts(mfilename('fullpath'));
    candidates = {
        fullfile(pwd, ['blossom6_cli' ext]), ...
        fullfile(pwd, 'blossom6_src', ['blossom6_cli' ext]), ...
        fullfile(base_dir, ['blossom6_cli' ext]), ...
        fullfile(base_dir, 'blossom6_src', ['blossom6_cli' ext])
    };
    for i = 1:length(candidates)
        if exist(candidates{i}, 'file') == 2
            cli_path = candidates{i};
            return;
        end
    end
end

% =====================================================================
function [match, ok] = solve_via_cli_b6(node_count, edges, weights, debug)
%SOLVE_VIA_CLI_B6  Solve via standalone CLI executable (crash-safe).
    cli_path = find_cli_path_b6();
    if isempty(cli_path)
        match = -ones(node_count, 1);
        ok = false;
        if debug; fprintf('    [blossom6-v28] blossom6_cli not found\n'); end
        return;
    end

    tmp_in = [tempname '.txt'];
    tmp_out = [tempname '.match'];
    E = size(edges, 1);
    fid = fopen(tmp_in, 'w');
    if fid < 0
        match = -ones(node_count, 1); ok = false; return;
    end
    fprintf(fid, '%d %d\n', node_count, E);
    for k = 1:E
        fprintf(fid, '%d %d %.15g\n', edges(k,1), edges(k,2), weights(k));
    end
    fclose(fid);

    % V28 FIX: ALWAYS pass '0' to CLI to suppress noisy Blossom VI internal
    % verbose output (y_v dual variables printed per node — 33000+ lines for
    % the largest component, takes hours to print).
    %
    % To enable deep CLI debugging (output to file, not console), change
    % dbg_flag to '1' and capture output:
    %   dbg_flag = '1';
    %   cmd = sprintf('"%s" "%s" "%s" %s > blossom6_verbose.log 2>&1', ...
    %                 cli_path, tmp_in, tmp_out, dbg_flag);
    dbg_flag = '0';
    cmd = sprintf('"%s" "%s" "%s" %s', cli_path, tmp_in, tmp_out, dbg_flag);
    timeout_secs = 300;
    if isunix
        cmd = sprintf('timeout %d %s', timeout_secs, cmd);
    end

    try
        status = system(cmd);
    catch
        status = -1;
    end

    if debug; fprintf('    [blossom6-v28] CLI exit code: %d\n', status); end

    match = -ones(node_count, 1);
    ok = false;
    if status ~= 0
        crash_log = fullfile(pwd, 'blossom6_cli_crash.log');
        if exist(crash_log, 'file')
            f = fopen(crash_log, 'r');
            if f >= 0
                msg = fread(f, '*char')';
                fclose(f);
                if debug
                    fprintf('    [blossom6-v28] CLI crash log:\n%s\n', msg);
                end
            end
            delete(crash_log);
        end
        if exist(tmp_in, 'file'); delete(tmp_in); end
        if exist(tmp_out, 'file'); delete(tmp_out); end
        return;
    end

    fid = fopen(tmp_out, 'r');
    if fid < 0
        if exist(tmp_in, 'file'); delete(tmp_in); end
        return;
    end

    header = fscanf(fid, '%d %d', 2);
    if length(header) < 2 || header(1) ~= node_count
        fclose(fid);
        if exist(tmp_in, 'file'); delete(tmp_in); end
        if exist(tmp_out, 'file'); delete(tmp_out); end
        return;
    end

    pair_count = header(2);
    for k = 1:pair_count
        line = fscanf(fid, '%d %d', 2);
        if length(line) < 2; break; end
        i = line(1) + 1;
        j = line(2) + 1;
        if i >= 1 && i <= node_count && j >= 1 && j <= node_count
            match(i) = j - 1;
            match(j) = i - 1;
        end
    end
    fclose(fid);
    if exist(tmp_in, 'file'); delete(tmp_in); end
    if exist(tmp_out, 'file'); delete(tmp_out); end
    ok = true;
end

% =====================================================================
function [match, ok] = solve_via_mex_b6(node_count, edges, weights, debug)
%SOLVE_VIA_MEX_B6  Solve via MEX (fast, but can crash MATLAB on segfault).
    match = -ones(node_count, 1);
    ok = false;
    dbg_val = 0;
    if debug; dbg_val = 1; end
    try
        match = blossom6_mex(double(node_count), edges, weights, double(dbg_val));
        ok = true;
    catch ME
        if debug
            fprintf('    [blossom6-v28] MEX error: %s\n', ME.message);
        end
    end
end

% =====================================================================
function key = aux_key_b6(a, b)
    if a > b; tmp = a; a = b; b = tmp; end
    key = a * 1e9 + b;
end

% =====================================================================
function [comp_id, n_comp] = find_components_v30(n, edges)
%FIND_COMPONENTS_V28  Union-Find connected components.
%   V28: uses iterative find_root (no nested function) for MATLAB parser safety.
    parent = (1:n)';
    for k = 1:size(edges, 1)
        a = edges(k, 1) + 1;
        b = edges(k, 2) + 1;
        if a < 1 || a > n || b < 1 || b > n; continue; end
        % Inline find_root for a
        ra = a;
        while parent(ra) ~= ra
            parent(ra) = parent(parent(ra));
            ra = parent(ra);
        end
        % Inline find_root for b
        rb = b;
        while parent(rb) ~= rb
            parent(rb) = parent(parent(rb));
            rb = parent(rb);
        end
        if ra ~= rb
            parent(rb) = ra;
        end
    end
    comp_id_raw = zeros(n, 1);
    for i = 1:n
        r = i;
        while parent(r) ~= r
            parent(r) = parent(parent(r));
            r = parent(r);
        end
        comp_id_raw(i) = r;
    end
    [~, ~, comp_idx] = unique(comp_id_raw);
    comp_id = comp_idx;
    n_comp = max(comp_id);
end

% =====================================================================
function match = blossom6_matlab_fallback_v30(node_count, edges, weights, debug)
%BLOSSOM6_MATLAB_FALLBACK_V28  Pure-MATLAB greedy + bounded BFS augmenting.
%   V28: BOUNDED iterations (no infinite loops).

    E = size(edges, 1);
    [~, sort_idx] = sort(weights);
    edges_sorted = edges(sort_idx, :);

    match = -ones(node_count, 1);

    % --- Greedy pass ---
    for k = 1:E
        a = edges_sorted(k, 1) + 1;
        b = edges_sorted(k, 2) + 1;
        if match(a) < 0 && match(b) < 0
            match(a) = b - 1;
            match(b) = a - 1;
        end
    end

    % --- Build adjacency list (vectorized) ---
    deg = zeros(node_count, 1);
    for k = 1:E
        deg(edges(k, 1) + 1) = deg(edges(k, 1) + 1) + 1;
        deg(edges(k, 2) + 1) = deg(edges(k, 2) + 1) + 1;
    end
    adj_ptr = cumsum([0; deg(1:end-1)]);
    adj_list = zeros(sum(deg), 1);
    deg_cur = zeros(node_count, 1);
    for k = 1:E
        u = edges(k, 1) + 1;
        v = edges(k, 2) + 1;
        adj_list(adj_ptr(u) + deg_cur(u) + 1) = v;
        deg_cur(u) = deg_cur(u) + 1;
        adj_list(adj_ptr(v) + deg_cur(v) + 1) = u;
        deg_cur(v) = deg_cur(v) + 1;
    end

    % --- Bounded BFS augmenting path ---
    MAX_OUTER = 50;
    MAX_BFS = 2 * node_count;

    for outer = 1:MAX_OUTER
        unmatched = find(match < 0);
        if isempty(unmatched); break; end
        any_augmented = false;
        for ui = 1:length(unmatched)
            u = unmatched(ui);
            if match(u) >= 0; continue; end
            [path, found] = bfs_augment_bounded_v30( ...
                u, adj_list, adj_ptr, deg, match, node_count, MAX_BFS);
            if found && length(path) >= 2
                for k = 1:2:length(path)-1
                    a = path(k); b = path(k+1);
                    match(a) = b - 1;
                    match(b) = a - 1;
                end
                any_augmented = true;
            end
        end
        if ~any_augmented; break; end
    end

    if debug
        n_unmatched = sum(match < 0);
        fprintf('    [blossom6-v28-fallback] unmatched after fallback: %d\n', n_unmatched);
    end
end

% =====================================================================
function [path, found] = bfs_augment_bounded_v30( ...
    start, adj_list, adj_ptr, deg, match, n, max_iter)
%BFS_AUGMENT_BOUNDED_V28  Bounded BFS for augmenting path.

    visited = false(n, 1);
    visited(start) = true;
    queue = zeros(n, 1);
    parent = zeros(n, 1);
    q_head = 1; q_tail = 1;
    queue(1) = start;
    path = [];
    found = false;

    iter_count = 0;
    while q_head <= q_tail && iter_count < max_iter
        iter_count = iter_count + 1;
        u = queue(q_head); q_head = q_head + 1;

        d = deg(u);
        if d == 0; continue; end
        nbrs = adj_list(adj_ptr(u)+1 : adj_ptr(u)+d);
        for k = 1:length(nbrs)
            v = nbrs(k);
            if visited(v); continue; end
            if match(v) < 0
                path = v;
                cur = u;
                while cur ~= 0 && cur ~= start
                    path = [cur, path]; %#ok<AGROW>
                    cur = parent(cur);
                end
                if cur == start
                    path = [start, path]; %#ok<AGROW>
                end
                found = true;
                return;
            end
            w = match(v) + 1;
            visited(v) = true;
            visited(w) = true;
            parent(w) = u;
            q_tail = q_tail + 1;
            if q_tail <= n; queue(q_tail) = w; end
        end
    end
end
