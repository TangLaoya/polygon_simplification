function [quadnode, quad, info] = topology_cleanup_v30(quadnode, quad, nnode_orig, debug)
%TOPOLOGY_CLEANUP_V30  Topology optimization: collapse valence-2 collinear
%   interior vertices, swap diagonals to reduce valence>5.
%
%   V30 SAFETY:
%     - Boundary vertices (vertex id <= nnode_orig) are NEVER removed.
%     - Each collapse verified for convexity + non-bowtie before applying.
%     - Edge swaps verify convexity + min-angle improvement.
%
%   Based on:
%     - "CleanUp: Improving Quadrilateral Finite Element Meshes" (Kinney)
%     - "Jaal: Engineering a high quality all-quadrilateral mesh generator"

    info = struct('collapsed', 0, 'swapped', 0, 'passes', 0);
    nqn = size(quadnode, 1);

    if debug
        fprintf('    [topo-v29] Starting topology cleanup (%d vtx, %d quads)\n', ...
            nqn, size(quad, 1));
    end

    for pass = 1:5
        info.passes = pass;
        n_collapsed_before = info.collapsed;
        n_swapped_before = info.swapped;

        % --- Edge collapse pass ---
        [quadnode, quad, n_coll] = edge_collapse_pass_v30(quadnode, quad, nnode_orig);
        info.collapsed = info.collapsed + n_coll;

        % --- Diagonal swap pass (only if there are valence>5 interior vertices) ---
        [quadnode, quad, n_swapped] = diagonal_swap_pass_v30(quadnode, quad, nnode_orig);
        info.swapped = info.swapped + n_swapped;

        if n_coll == 0 && n_swapped == 0
            break;
        end
    end

    if debug
        fprintf('    [topo-v29] Done: collapsed=%d, swapped=%d, passes=%d\n', ...
            info.collapsed, info.swapped, info.passes);
    end
end

% =====================================================================
function [quadnode, quad, n_collapsed] = edge_collapse_pass_v30(quadnode, quad, nnode_orig)
%EDGE_COLLAPSE_PASS_V30  Remove valence-2 collinear INTERIOR vertices.
%   V30: NEVER collapse a boundary vertex (id <= nnode_orig).

    nqn = size(quadnode, 1);
    nq = size(quad, 1);
    n_collapsed = 0;

    % Build vertex -> quads incidence
    vtx_quads = cell(nqn, 1);
    for qi = 1:nq
        q = quad(qi, :);
        if all(q == 0); continue; end
        for j = 1:4
            v = q(j);
            if v > 0 && v <= nqn
                vtx_quads{v}(end+1) = qi; %#ok<AGROW>
            end
        end
    end

    % Build unique edges and valences
    edges_all = zeros(nq * 4, 2);
    ec = 0;
    for qi = 1:nq
        q = quad(qi, :);
        if all(q == 0); continue; end
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if v1 > 0 && v2 > 0 && v1 ~= v2
                ec = ec + 1;
                edges_all(ec, :) = [min(v1, v2), max(v1, v2)];
            end
        end
    end
    [ue, ~, ic] = unique(edges_all(1:ec, :), 'rows');
    edge_count = accumarray(ic, 1);
    vtx_valence = zeros(nqn, 1);
    for i = 1:size(ue, 1)
        vtx_valence(ue(i, 1)) = vtx_valence(ue(i, 1)) + 1;
        vtx_valence(ue(i, 2)) = vtx_valence(ue(i, 2)) + 1;
    end

    for v = 1:nqn
        % V30: NEVER remove original boundary vertices
        if v <= nnode_orig; continue; end
        if vtx_valence(v) ~= 2; continue; end

        qs = unique(vtx_quads{v});
        if length(qs) ~= 2; continue; end

        q1 = quad(qs(1), :);
        q2 = quad(qs(2), :);
        if all(q1 == 0) || all(q2 == 0); continue; end

        nbrs_v = [];
        for i = 1:size(ue, 1)
            if ue(i, 1) == v; nbrs_v(end+1) = ue(i, 2); %#ok<AGROW>
            elseif ue(i, 2) == v; nbrs_v(end+1) = ue(i, 1); %#ok<AGROW>
            end
            if length(nbrs_v) == 2; break; end
        end
        if length(nbrs_v) ~= 2; continue; end
        n1 = nbrs_v(1); n2 = nbrs_v(2);

        % Check collinearity
        p = quadnode(v, :);
        p1 = quadnode(n1, :);
        p2 = quadnode(n2, :);
        ab = p2 - p1; ap = p - p1;
        len2 = ab(1)^2 + ab(2)^2;
        if len2 < 1e-18; continue; end
        cross = ab(1)*ap(2) - ab(2)*ap(1);
        if abs(cross) > 1e-9 * sqrt(len2); continue; end
        t = (ab(1)*ap(1) + ab(2)*ap(2)) / len2;
        if t < 0.01 || t > 0.99; continue; end

        % Merge q1 + q2 into 1 quad: vertices of q1 + q2 minus v
        all_verts = [q1, q2];
        all_verts = all_verts(all_verts ~= v);
        all_verts = unique(all_verts);
        if length(all_verts) ~= 4; continue; end

        % Sort CCW around centroid
        pts = quadnode(all_verts, :);
        c = mean(pts, 1);
        ang = atan2(pts(:, 2) - c(2), pts(:, 1) - c(1));
        [~, sidx] = sort(ang);
        new_q = all_verts(sidx);

        % Verify convexity
        if ~is_convex_pts_tc(quadnode(new_q, :)); continue; end
        % Verify non-bowtie
        if is_bowtie_pts_tc(quadnode(new_q, :)); continue; end

        % Apply
        quad(qs(1), :) = new_q;
        quad(qs(2), :) = [0 0 0 0];
        vtx_quads{v} = [];
        vtx_valence(v) = 0;
        n_collapsed = n_collapsed + 1;
    end

    % Remove empty quads
    valid = any(quad ~= 0, 2);
    quad = quad(valid, :);
end

% =====================================================================
function [quadnode, quad, n_swapped] = diagonal_swap_pass_v30(quadnode, quad, nnode_orig)
%DIAGONAL_SWAP_PASS_V30  Swap edges to reduce valence>5 interior vertices.
%   V30: NEVER swap if it would affect boundary vertices.

    nqn = size(quadnode, 1);
    n_swapped = 0;
    valences = compute_valences_tc(quad, quadnode);

    % Build vertex -> quads and edge -> quads incidence
    vtx_quads = cell(nqn, 1);
    edge_quads = containers.Map('KeyType', 'double', 'ValueType', 'any');
    for qi = 1:size(quad, 1)
        q = quad(qi, :);
        if all(q == 0); continue; end
        for j = 1:4
            v = q(j);
            if v > 0 && v <= nqn
                vtx_quads{v}(end+1) = qi; %#ok<AGROW>
            end
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if v1 > 0 && v2 > 0 && v1 ~= v2
                key = min(v1, v2) * 1e9 + max(v1, v2);
                if ~isKey(edge_quads, key); edge_quads(key) = []; end
                edge_quads(key) = [edge_quads(key), qi];
            end
        end
    end

    for v = 1:nqn
        % V30: NEVER touch original boundary vertices
        if v <= nnode_orig; continue; end
        if valences(v) <= 5; continue; end

        adj_quads = unique(vtx_quads{v});
        if length(adj_quads) < 2; continue; end

        swapped_this_v = false;
        for qi1_idx = 1:length(adj_quads)
            if swapped_this_v; break; end
            qi1 = adj_quads(qi1_idx);
            q1 = quad(qi1, :);
            if all(q1 == 0); continue; end

            for j = 1:4
                if swapped_this_v; break; end
                v1 = q1(j); v2 = q1(mod(j, 4) + 1);
                if v1 ~= v && v2 ~= v; continue; end
                key = min(v1, v2) * 1e9 + max(v1, v2);
                if ~isKey(edge_quads, key); continue; end
                eqs = edge_quads(key);
                qi2 = 0;
                for q_idx = 1:length(eqs)
                    if eqs(q_idx) ~= qi1 && ~all(quad(eqs(q_idx), :) == 0)
                        qi2 = eqs(q_idx); break;
                    end
                end
                if qi2 == 0; continue; end
                q2 = quad(qi2, :);
                if all(q2 == 0); continue; end

                hex_verts = unique([q1, q2]);
                if length(hex_verts) ~= 6; continue; end

                pts = quadnode(hex_verts, :);
                c = mean(pts, 1);
                ang = atan2(pts(:, 2) - c(2), pts(:, 1) - c(1));
                [~, sidx] = sort(ang);
                hex = hex_verts(sidx);

                pos1 = find(hex == v1, 1);
                pos2 = find(hex == v2, 1);
                if isempty(pos1) || isempty(pos2); continue; end
                diff = mod(pos1 - pos2, 6);
                if diff ~= 1 && diff ~= 5; continue; end

                p = pos1 - 1;
                opp_a = hex(mod(p + 3, 6) + 1);
                opp_b = hex(mod(p + 4, 6) + 1);

                if edge_exists_tc(quad, opp_a, opp_b); continue; end

                if opp_a > length(valences) || opp_b > length(valences); continue; end
                if valences(opp_a) >= 5 || valences(opp_b) >= 5; continue; end
                % V30: do not touch original boundary vertices
                if opp_a <= nnode_orig || opp_b <= nnode_orig; continue; end

                new_q1 = [hex(mod(p+1,6)+1), hex(mod(p+2,6)+1), ...
                          hex(mod(p+3,6)+1), hex(mod(p+4,6)+1)];
                new_q2 = [hex(mod(p+4,6)+1), hex(mod(p+5,6)+1), ...
                          hex(mod(p,6)+1), hex(mod(p+3,6)+1)];

                if length(unique(new_q1)) ~= 4 || length(unique(new_q2)) ~= 4; continue; end

                % Verify convexity
                if ~is_convex_pts_tc(quadnode(new_q1, :)) || ~is_convex_pts_tc(quadnode(new_q2, :))
                    continue;
                end
                % Verify non-bowtie
                if is_bowtie_pts_tc(quadnode(new_q1, :)) || is_bowtie_pts_tc(quadnode(new_q2, :))
                    continue;
                end

                % Check min angle improvement
                old_min = min(min_angle_pts_tc(quadnode(q1, :)), min_angle_pts_tc(quadnode(q2, :)));
                new_min = min(min_angle_pts_tc(quadnode(new_q1, :)), min_angle_pts_tc(quadnode(new_q2, :)));
                if new_min < old_min - 10; continue; end

                % Apply swap
                quad(qi1, :) = new_q1;
                quad(qi2, :) = new_q2;
                valences(v) = valences(v) - 1;
                valences(opp_a) = valences(opp_a) + 1;
                valences(opp_b) = valences(opp_b) + 1;
                old_key = min(v1, v2) * 1e9 + max(v1, v2);
                edge_quads(old_key) = [];
                new_key = min(opp_a, opp_b) * 1e9 + max(opp_a, opp_b);
                if ~isKey(edge_quads, new_key); edge_quads(new_key) = []; end
                edge_quads(new_key) = [edge_quads(new_key), qi1, qi2];
                n_swapped = n_swapped + 1;
                swapped_this_v = true;
            end
        end
    end
end

% =====================================================================
function cvx = is_convex_pts_tc(pts)
    cvx = true;
    for j = 1:4
        p1 = pts(j, :);
        p2 = pts(mod(j, 4) + 1, :);
        p3 = pts(mod(j + 1, 4) + 1, :);
        cr = (p2(1)-p1(1))*(p3(2)-p2(2)) - (p2(2)-p1(2))*(p3(1)-p2(1));
        if cr <= 1e-9
            cvx = false; return;
        end
    end
end

% =====================================================================
function bt = is_bowtie_pts_tc(pts)
%IS_BOWTIE_PTS_TC  Check if 4 points form a bowtie (self-intersecting).
%   V30: inline ccw computation (no nested function) for MATLAB parser safety.
    bt = (ccw_tc(pts(1,:), pts(3,:), pts(4,:)) ~= ccw_tc(pts(2,:), pts(3,:), pts(4,:))) && ...
         (ccw_tc(pts(1,:), pts(2,:), pts(3,:)) ~= ccw_tc(pts(1,:), pts(2,:), pts(4,:)));
end

% =====================================================================
function tf = ccw_tc(A, B, C)
%CCW_TC  Counter-clockwise test for points A, B, C (topology_cleanup_v30).
    tf = (C(2)-A(2)) * (B(1)-A(1)) > (B(2)-A(2)) * (C(1)-A(1));
end

% =====================================================================
function ma = min_angle_pts_tc(pts)
    ma = inf;
    for j = 1:4
        p1 = pts(j, :);
        p2 = pts(mod(j, 4) + 1, :);
        p3 = pts(mod(j + 1, 4) + 1, :);
        v_in = p1 - p2; v_out = p3 - p2;
        cos_a = dot(v_in, v_out) / (norm(v_in)*norm(v_out) + 1e-12);
        a = acosd(max(-1, min(1, cos_a)));
        if a > 180; a = 360 - a; end
        ma = min(ma, a);
    end
end

% =====================================================================
function exists = edge_exists_tc(quad, a, b)
    exists = false;
    for qi = 1:size(quad, 1)
        q = quad(qi, :);
        if all(q == 0); continue; end
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if (v1 == a && v2 == b) || (v1 == b && v2 == a)
                exists = true; return;
            end
        end
    end
end

% =====================================================================
function valences = compute_valences_tc(quad, quadnode)
    nqn = size(quadnode, 1);
    edges = zeros(size(quad, 1) * 4, 2);
    ec = 0;
    for qi = 1:size(quad, 1)
        q = quad(qi, :);
        if all(q == 0); continue; end
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if v1 > 0 && v2 > 0 && v1 ~= v2
                ec = ec + 1;
                edges(ec, :) = [min(v1, v2), max(v1, v2)];
            end
        end
    end
    edges = edges(1:ec, :);
    [ue, ~, ~] = unique(edges, 'rows');
    valences = zeros(nqn, 1);
    for i = 1:size(ue, 1)
        valences(ue(i, 1)) = valences(ue(i, 1)) + 1;
        valences(ue(i, 2)) = valences(ue(i, 2)) + 1;
    end
end
