function loops = find_boundary_loops(node, tri)
%FIND_BOUNDARY_LOOPS Extract closed boundary loops from a triangle mesh.
%   loops = find_boundary_loops(node, tri) returns a cell array of
%   boundary loops.  Each loop is an L-by-1 column vector of vertex
%   indices listed in walking order (so consecutive vertices share a
%   boundary edge, and the last wraps back to the first).
%
%   Algorithm:
%     1. Build every triangle edge as (min, max).
%     2. Edges appearing exactly once are boundary edges.
%     3. Build a per-vertex link list of boundary neighbours and walk
%        each connected cycle by repeatedly moving to the next
%        boundary neighbour that has not been visited yet.
%
%   Works for multiply connected domains (Requirement #3):
%     - The outer boundary and every interior hole produce one loop.
%     - Isolated single boundary edges (degenerate input) are returned
%       as length-2 "loops" and will be ignored by the parity step.

    nnode = size(node, 1);
    ntri  = size(tri, 1);

    % --- 1. Build all edges and pick boundary edges ----------------
    E = [tri(:,[2 3]); tri(:,[3 1]); tri(:,[1 2])];
    E = sort(E, 2);                          % (min, max) per row
    [ue, ~, ic] = unique(E, 'rows');
    cnt = accumarray(ic, 1);
    bnd_edges = ue(cnt == 1, :);             % boundary edges

    nbnd = size(bnd_edges, 1);
    if nbnd == 0
        loops = {};
        return;
    end

    % --- 2. Per-vertex boundary neighbour lists ---------------------
    bnbr = cell(nnode, 1);
    for i = 1:nbnd
        a = bnd_edges(i, 1);
        b = bnd_edges(i, 2);
        bnbr{a}(end+1) = b;
        bnbr{b}(end+1) = a;
    end

    visited_edge = false(nbnd, 1);

    % Quick lookup: edge id by (a,b)
    % Use a sparse map for O(1) edge id lookup
    max_id = max(max(bnd_edges));
    edge_id = sparse(bnd_edges(:,1), bnd_edges(:,2), (1:nbnd)', max_id, max_id);

    % --- 3. Walk cycles --------------------------------------------
    loops = {};
    visited_v = false(nnode, 1);

    for seed = 1:nbnd
        if visited_edge(seed); continue; end

        a0 = bnd_edges(seed, 1);
        b0 = bnd_edges(seed, 2);
        visited_edge(seed) = true;

        loop = [a0; b0];
        visited_v(a0) = true;
        % Don't mark b0 visited yet, so we can come back to a0

        cur = b0;
        prev = a0;
        while true
            % Pick next boundary neighbour that is not `prev`
            nbrs = bnbr{cur};
            nxt = 0;
            for k = 1:length(nbrs)
                if nbrs(k) ~= prev
                    nxt = nbrs(k); break;
                end
            end
            if nxt == 0
                break;                       % dead-end (degenerate)
            end

            % Mark edge (cur, nxt) visited
            lo = min(cur, nxt); hi = max(cur, nxt);
            eid = full(edge_id(lo, hi));
            if eid == 0 || visited_edge(eid)
                break;                       % already walked -> cycle closed
            end
            visited_edge(eid) = true;

            if nxt == a0
                break;                       % loop closed
            end

            loop(end+1, 1) = nxt;
            prev = cur;
            cur  = nxt;
        end

        loops{end+1} = loop;
    end
end
