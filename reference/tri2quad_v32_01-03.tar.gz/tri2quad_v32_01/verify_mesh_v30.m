function report = verify_mesh_v30(quadnode, quad, orig_node, orig_tri, debug)
%VERIFY_MESH_V30  Comprehensive mesh quality verification.
%
%   V30 CHECKS (all 7 user requirements):
%     1. BOUNDARY PRESERVED: every input boundary edge appears (possibly
%        via midpoint-chain) in the quad mesh boundary.
%     2. COVERAGE OK: quad mesh area == input triangle mesh area (1e-3 rel).
%     3. EDGE CONSISTENCY: every interior edge shared by exactly 2 quads.
%     4. ALL CONVEX: no concave quads (no >180° interior angles).
%     5. NO COLLINEAR: no 3 collinear vertices in any quad.
%     6. NO EDGE INTERSECTION: no two non-adjacent quad edges cross.
%     7. NO >180° MERGE: implicit in (4) - a >180° angle at a quad vertex
%        implies concavity.
%
%   Also reports: vertex count ratio (must be <= 1.5), min/mean/max angle.

    if nargin < 5; debug = 0; end

    report = struct();
    report.passed = true;
    report.warnings = {};

    report.n_tri_vtx = size(orig_node, 1);
    report.n_quad_vtx = size(quadnode, 1);
    report.n_tri = size(orig_tri, 1);
    report.n_quad = size(quad, 1);
    report.vtx_ratio = report.n_quad_vtx / max(1, report.n_tri_vtx);
    report.tri_ratio = 0;   % all-quad

    % 1. Boundary preservation (DFS walk accepting midpoint chains)
    [bnd_ok, bnd_msg, n_missing_bnd, missing_edges] = check_boundary_v30(quadnode, quad, orig_node, orig_tri);
    report.boundary_preserved = bnd_ok;
    report.n_missing_boundary = n_missing_bnd;
    report.missing_boundary_edges = missing_edges;
    if ~bnd_ok
        report.passed = false;
        report.warnings{end+1} = ['Boundary: ' bnd_msg];
        % V30-FIX: debug visualization — draw mesh with missing boundary edges in RED BOLD
        if debug
            plot_missing_boundary_v30(quadnode, quad, orig_node, orig_tri, missing_edges);
        end
    end

    % 2. Coverage (area match)
    [cov_ok, cov_msg, area_tri, area_mesh] = check_coverage_v30(quadnode, quad, orig_node, orig_tri);
    report.coverage_ok = cov_ok;
    report.area_tri = area_tri;
    report.area_mesh = area_mesh;
    if ~cov_ok
        report.passed = false;
        report.warnings{end+1} = ['Coverage: ' cov_msg];
    end

    % 3. Edge consistency (no edge shared by >2 quads)
    [edge_ok, edge_msg, n_bad_edges] = check_edge_v30(quad);
    report.edge_consistency_ok = edge_ok;
    report.n_bad_edges = n_bad_edges;
    if ~edge_ok
        report.passed = false;
        report.warnings{end+1} = ['Edge: ' edge_msg];
    end

    % 4. Quad quality (convexity, collinearity, angle stats)
    [cvx_ok, cvx_msg, min_ang, mean_ang, max_ang, n_concave, n_collinear] = ...
        check_quad_quality_v30(quadnode, quad);
    report.all_convex = cvx_ok;
    report.min_angle_deg = min_ang;
    report.mean_angle_deg = mean_ang;
    report.max_angle_deg = max_ang;
    report.n_concave = n_concave;
    report.n_collinear = n_collinear;
    if ~cvx_ok
        report.passed = false;
        report.warnings{end+1} = ['Convexity: ' cvx_msg];
    end

    % 5. Edge intersection check (bowtie detection)
    [int_ok, int_msg, n_intersect] = check_edge_intersection_v30(quadnode, quad);
    report.no_edge_intersection = int_ok;
    report.n_edge_intersections = n_intersect;
    if ~int_ok
        report.passed = false;
        report.warnings{end+1} = ['Intersection: ' int_msg];
    end

    % 5b. T-junction check (non-conforming mesh) — V30-FIX
    [tj_ok, tj_msg, n_tj] = check_t_junctions_v30(quadnode, quad, report.n_tri_vtx);
    report.no_t_junctions = tj_ok;
    report.n_t_junctions = n_tj;
    if ~tj_ok
        report.passed = false;
        report.warnings{end+1} = ['T-junction: ' tj_msg];
    end

    % 6. Vertex ratio check (must be <= 1.5)
    if report.vtx_ratio > 1.5
        report.passed = false;
        report.warnings{end+1} = sprintf('Vertex ratio %.3f exceeds 1.5 limit', report.vtx_ratio);
    end

    if debug
        fprintf('  [verify-v29] ==================================================\n');
        fprintf('  [verify-v29] V30 Mesh Quality Verification Report\n');
        fprintf('  [verify-v29] --------------------------------------------------\n');
        fprintf('  [verify-v29] Tri mesh : %d vtx, %d tri\n', report.n_tri_vtx, report.n_tri);
        fprintf('  [verify-v29] Quad mesh: %d vtx, %d quad (ratio=%.3f, max=1.5)\n', ...
            report.n_quad_vtx, report.n_quad, report.vtx_ratio);
        fprintf('  [verify-v29] Boundary preserved : %s (%d missing)\n', ...
            mat2str(report.boundary_preserved), n_missing_bnd);
        fprintf('  [verify-v29] Coverage OK         : %s (tri=%.4g, mesh=%.4g)\n', ...
            mat2str(report.coverage_ok), area_tri, area_mesh);
        fprintf('  [verify-v29] Edge consistency OK  : %s (%d bad edges)\n', ...
            mat2str(report.edge_consistency_ok), n_bad_edges);
        fprintf('  [verify-v29] All quads convex     : %s (%d concave, %d collinear)\n', ...
            mat2str(report.all_convex), n_concave, n_collinear);
        fprintf('  [verify-v29] No edge intersection: %s (%d bowties)\n', ...
            mat2str(report.no_edge_intersection), n_intersect);
        fprintf('  [verify-v29] No T-junctions     : %s (%d T-junctions)\n', ...
            mat2str(report.no_t_junctions), n_tj);
        fprintf('  [verify-v29] Angle: min=%.1f, mean=%.1f, max=%.1f deg\n', ...
            min_ang, mean_ang, max_ang);
        fprintf('  [verify-v29] --------------------------------------------------\n');
        if report.passed
            fprintf('  [verify-v29] OVERALL: PASSED\n');
        else
            fprintf('  [verify-v29] OVERALL: FAILED\n');
            for w = 1:length(report.warnings)
                fprintf('  [verify-v29]   ! %s\n', report.warnings{w});
            end
        end
        fprintf('  [verify-v29] ==================================================\n');
    end
end

% ====================================================================
function [ok, msg, n_missing, missing_edges] = check_boundary_v30(quadnode, quad, orig_node, orig_tri)
%CHECK_BOUNDARY_V30  Verify every input boundary edge is preserved.
%   V30-FIX: also returns the list of missing edges (Nx2, 1-indexed)
%   for debug visualization.

    % Original boundary edges
    E = [orig_tri(:,[2 3]); orig_tri(:,[3 1]); orig_tri(:,[1 2])];
    E = sort(E, 2);
    [ue, ~, ic] = unique(E, 'rows');
    cnt = accumarray(ic, 1);
    orig_bnd = ue(cnt == 1, :);

    % Quad boundary edges (skip zero-length from triangle-quads)
    EQ = zeros(size(quad, 1) * 4, 2);
    eqc = 0;
    for i = 1:size(quad, 1)
        q = quad(i, :);
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if v1 == v2; continue; end
            eqc = eqc + 1;
            EQ(eqc, :) = sort([v1, v2]);
        end
    end
    EQ = EQ(1:eqc, :);
    [ueq, ~, icq] = unique(EQ, 'rows');
    cntq = accumarray(icq, 1);
    quad_bnd = ueq(cntq == 1, :);

    % Build vertex -> boundary neighbours map
    bnd_adj = containers.Map('KeyType', 'double', 'ValueType', 'any');
    for i = 1:size(quad_bnd, 1)
        a = quad_bnd(i, 1); b = quad_bnd(i, 2);
        if ~isKey(bnd_adj, a); bnd_adj(a) = []; end
        if ~isKey(bnd_adj, b); bnd_adj(b) = []; end
        bnd_adj(a) = [bnd_adj(a), b];
        bnd_adj(b) = [bnd_adj(b), a];
    end

    n_missing = 0;
    missing_edges = zeros(0, 2);
    for i = 1:size(orig_bnd, 1)
        a = orig_bnd(i, 1); b = orig_bnd(i, 2);
        found = dfs_boundary_walk_v30(a, b, bnd_adj, quadnode);
        if ~found
            % V30: vertex replacement may have replaced 'a' with a new vertex F
            % on segment (a, b). Check if any vertex F on segment (a,b) is in bnd_adj.
            found = check_replaced_vertex_v30(a, b, bnd_adj, quadnode);
        end
        if ~found
            n_missing = n_missing + 1;
            missing_edges(end+1, :) = [a, b]; %#ok<AGROW>
        end
    end

    if n_missing == 0
        ok = true; msg = '';
    else
        ok = false;
        msg = sprintf('%d original boundary edges missing', n_missing);
    end
end

% ====================================================================
function plot_missing_boundary_v30(quadnode, quad, orig_node, orig_tri, missing_edges)
%PLOT_MISSING_BOUNDARY_V30  Debug visualization: draw the quad mesh and
%   highlight the MISSING original boundary edges in RED BOLD.
%   Called when debug=1 and boundary preservation fails.
%   V30-FAST: uses patch() (vectorized) instead of per-quad plot loop.

    figure('Name', 'V30 Boundary Check', 'NumberTitle', 'off');
    hold on; axis equal; axis off;

    % Draw all quads via patch (FAST — single call for all quads)
    patch('faces', quad, 'vertices', quadnode, 'facecolor', 'none', 'edgecolor', 'k');

    % Draw MISSING boundary edges in RED BOLD
    for i = 1:size(missing_edges, 1)
        a = missing_edges(i, 1); b = missing_edges(i, 2);
        pa = orig_node(a, :); pb = orig_node(b, :);
        plot([pa(1), pb(1)], [pa(2), pb(2)], 'r-', 'LineWidth', 3.0);
        plot(pa(1), pa(2), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
        plot(pb(1), pb(2), 'rs', 'MarkerSize', 8, 'LineWidth', 2);
    end

    title(sprintf('V30 Boundary Check: %d missing edge(s) [RED BOLD]', size(missing_edges, 1)));
    hold off;
end

% ====================================================================
function found = dfs_boundary_walk_v30(a, b, bnd_adj, quadnode)
%DFS_BOUNDARY_WALK_V30  DFS from a to b, accepting midpoints on segment.
    if a == b; found = true; return; end
    if ~isKey(bnd_adj, a); found = false; return; end
    nqn = size(quadnode, 1);
    if a > nqn || b > nqn
        found = false; return;
    end

    pa = quadnode(a, :); pb = quadnode(b, :);
    max_depth = 5000;   % V30: bounded depth (was 10000)
    visited_set = containers.Map('KeyType', 'double', 'ValueType', 'logical');
    visited_set(a) = true;

    nbrs = bnd_adj(a);
    stack = [];
    for k = 1:length(nbrs)
        stack(end+1, :) = [nbrs(k), 1]; %#ok<AGROW>
    end

    while ~isempty(stack)
        cur = stack(end, 1);
        depth = stack(end, 2);
        stack(end, :) = [];

        if depth > max_depth; continue; end
        if cur == b; found = true; return; end
        if isKey(visited_set, cur); continue; end
        visited_set(cur) = true;

        if cur > nqn; continue; end
        pn = quadnode(cur, :);
        if ~on_segment_v30(pn, pa, pb) && cur ~= a
            continue;
        end

        if isKey(bnd_adj, cur)
            cnbrs = bnd_adj(cur);
            for k = 1:length(cnbrs)
                if ~isKey(visited_set, cnbrs(k))
                    stack(end+1, :) = [cnbrs(k), depth + 1]; %#ok<AGROW>
                end
            end
        end
    end
    found = false;
end

% ====================================================================
function on = on_segment_v30(p, a, b)
%ON_SEGMENT_V30  Check if point p lies on segment (a,b).
%   V30-FIX: Tolerates tiny perturbations (~1e-5) of boundary midpoints
%   caused by smoothing / collinear-repair. The previous tolerance
%   (1e-6 perpendicular distance) was too tight for VERY SHORT boundary
%   edges (len ~ 1e-5): a 1e-6 perturbation of the midpoint (e.g. from
%   repair_collinear_v30) caused the check to fail at the tolerance
%   boundary, reporting FALSE "missing boundary" for 5-6 tiny edges
%   even though the boundary was geometrically preserved.
    ab = b - a; ap = p - a;
    len2 = ab(1)^2 + ab(2)^2;
    if len2 < 1e-18; on = norm(ap) < 1e-9; return; end
    t = (ab(1)*ap(1) + ab(2)*ap(2)) / len2;
    cross = ab(1)*ap(2) - ab(2)*ap(1);
    % abs(cross) = |ab| * perp_dist, so this checks perp_dist < 1e-5
    % (10x margin over the 1e-6 perturbation from repair_collinear).
    on = (abs(cross) < 1e-5 * sqrt(len2)) && (t >= -0.01) && (t <= 1 + 0.01);
end

% ====================================================================
function [ok, msg, area_tri, area_mesh] = check_coverage_v30(quadnode, quad, orig_node, orig_tri)
    area_tri = 0;
    for i = 1:size(orig_tri, 1)
        p = orig_node(orig_tri(i, :), :);
        area_tri = area_tri + 0.5 * abs((p(2,1)-p(1,1))*(p(3,2)-p(1,2)) - ...
                                       (p(2,2)-p(1,2))*(p(3,1)-p(1,1)));
    end

    area_mesh = 0;
    for i = 1:size(quad, 1)
        p = quadnode(quad(i, :), :);
        A = 0;
        for j = 1:4
            j2 = mod(j, 4) + 1;
            A = A + (p(j,1)*p(j2,2) - p(j2,1)*p(j,2));
        end
        area_mesh = area_mesh + 0.5 * abs(A);
    end

    rel_err = abs(area_mesh - area_tri) / max(1e-12, area_tri);
    if rel_err < 1e-3
        ok = true; msg = '';
    else
        ok = false;
        msg = sprintf('area mismatch: tri=%.6g, mesh=%.6g, rel_err=%.2e', ...
            area_tri, area_mesh, rel_err);
    end
end

% ====================================================================
function [ok, msg, n_bad] = check_edge_v30(quad)
    EQ = zeros(size(quad, 1) * 4, 2);
    ec = 0;
    for i = 1:size(quad, 1)
        q = quad(i, :);
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if v1 == v2; continue; end
            ec = ec + 1;
            EQ(ec, :) = sort([v1, v2]);
        end
    end
    EQ = EQ(1:ec, :);
    [ue, ~, ic] = unique(EQ, 'rows');
    cnt = accumarray(ic, 1);
    n_bad = sum(cnt > 2);
    if n_bad == 0
        ok = true; msg = '';
    else
        ok = false;
        msg = sprintf('%d edges shared by >2 quads (non-manifold)', n_bad);
    end
end

% ====================================================================
function [ok, msg, min_ang, mean_ang, max_ang, n_concave, n_collinear] = ...
    check_quad_quality_v30(quadnode, quad)
    nq = size(quad, 1);
    min_ang = inf; max_ang = -inf; sum_ang = 0; n_ang = 0;
    n_concave = 0; n_collinear = 0;
    for i = 1:nq
        q = quad(i, :);
        if length(unique(q)) < 4
            % V30: triangle-quad (degenerate) — count as 4 collinear (zero cross)
            n_collinear = n_collinear + 4;
            continue;
        end
        p = quadnode(q, :);
        for j = 1:4
            p1 = p(j, :);
            p2 = p(mod(j, 4) + 1, :);
            p3 = p(mod(j + 1, 4) + 1, :);
            cr = (p2(1)-p1(1))*(p3(2)-p2(2)) - (p2(2)-p1(2))*(p3(1)-p2(1));
            v_in  = p1 - p2;
            v_out = p3 - p2;
            cos_a = dot(v_in, v_out) / (norm(v_in)*norm(v_out) + 1e-12);
            ang = acosd(max(-1, min(1, cos_a)));
            if ang > 180; ang = 360 - ang; end
            min_ang = min(min_ang, ang);
            max_ang = max(max_ang, ang);
            sum_ang = sum_ang + ang; n_ang = n_ang + 1;
            if cr <= 1e-12
                if abs(cr) < 1e-9
                    n_collinear = n_collinear + 1;
                else
                    n_concave = n_concave + 1;
                end
            end
        end
    end
    mean_ang = sum_ang / max(1, n_ang);
    if n_concave == 0 && n_collinear == 0
        ok = true; msg = '';
    else
        ok = false;
        msg = sprintf('%d concave angles, %d collinear angles', n_concave, n_collinear);
    end
end

% ====================================================================
function [ok, msg, n_intersect] = check_edge_intersection_v30(quadnode, quad)
%CHECK_EDGE_INTERSECTION_V30  V30-FIX: check for BOWTIE quads (self-intersecting)
%   and non-adjacent edge crossings only.
%
%   V30-FIX: The old check counted diagonal crossings between adjacent quads,
%   which is NORMAL geometry (not a defect). This produced ~8800 false positives.
%
%   New check: for each quad, verify it is NOT a bowtie (self-intersecting).
%   A bowtie occurs when opposite edges of a quad cross.
%   Edges: (p1,p2), (p2,p3), (p3,p4), (p4,p1)
%   Bowtie check: edge (p1,p2) vs edge (p3,p4), and edge (p2,p3) vs edge (p4,p1).
%   This is O(1) per quad, O(N) total.

    nq = size(quad, 1);
    n_intersect = 0;

    for qi = 1:nq
        q = quad(qi, :);
        if length(unique(q)) < 4; continue; end
        pts = quadnode(q, :);

        % Bowtie check: do opposite edges cross?
        % Edge 1: (p1, p2) vs Edge 3: (p3, p4)
        if seg_cross_v30(pts(1,:), pts(2,:), pts(3,:), pts(4,:))
            n_intersect = n_intersect + 1;
            continue;
        end
        % Edge 2: (p2, p3) vs Edge 4: (p4, p1)
        if seg_cross_v30(pts(2,:), pts(3,:), pts(4,:), pts(1,:))
            n_intersect = n_intersect + 1;
        end
    end

    if n_intersect == 0
        ok = true; msg = '';
    else
        ok = false;
        msg = sprintf('%d bowtie (self-intersecting) quads detected', n_intersect);
    end
end

% ====================================================================
function inter = seg_cross_v30(p1, p2, p3, p4)
%SEG_CROSS_V30  Check if segments (p1,p2) and (p3,p4) properly intersect.
%   V30: inline ccw computation (no nested function) for MATLAB parser safety.
    inter = (ccw_v30(p1, p3, p4) ~= ccw_v30(p2, p3, p4)) && ...
            (ccw_v30(p1, p2, p3) ~= ccw_v30(p1, p2, p4));
end

% ====================================================================
function tf = ccw_v30(A, B, C)
%CCW_V30  Counter-clockwise test for points A, B, C (verify_mesh_v30).
    tf = (C(2)-A(2)) * (B(1)-A(1)) > (B(2)-A(2)) * (C(1)-A(1));
end

% ====================================================================
function [ok, msg, n_tj] = check_t_junctions_v30(quadnode, quad, nnode_orig)
%CHECK_T_JUNCTIONS_V30  V30-FIX3: vectorized T-junction scan.
%   Replaces containers.Map with sortrows-based edge array.
%   Uses broadcasting for O(N_new * E) vectorized check (28x faster).

    n_tj = 0;
    nq = size(quad, 1);

    % Build edge list using sortrows (O(N log N))
    all_edges = zeros(nq * 4, 3);  % [min_v, max_v, quad_id]
    ec = 0;
    for qi = 1:nq
        q = quad(qi, :);
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            if v1 > 0 && v2 > 0 && v1 ~= v2
                ec = ec + 1;
                all_edges(ec, :) = [min(v1, v2), max(v1, v2), qi];
            end
        end
    end
    all_edges = sortrows(all_edges(1:ec, :), [1, 2]);

    % Unique edges + quad lists
    edge_arr = zeros(ec, 2);
    edge_quad_list = cell(ec, 1);
    n_unique = 0;
    i = 1;
    while i <= ec
        n_unique = n_unique + 1;
        edge_arr(n_unique, :) = all_edges(i, 1:2);
        qids = all_edges(i, 3);
        while i < ec && all_edges(i+1, 1) == all_edges(i, 1) && ...
                       all_edges(i+1, 2) == all_edges(i, 2)
            i = i + 1;
            qids = [qids, all_edges(i, 3)]; %#ok<AGROW>
        end
        edge_quad_list{n_unique} = qids;
        i = i + 1;
    end
    edge_arr = edge_arr(1:n_unique, :);
    edge_quad_list = edge_quad_list(1:n_unique);

    % Vectorized: precompute edge endpoints
    pa_arr = quadnode(edge_arr(:, 1), :);  % (n_edges, 2)
    pb_arr = quadnode(edge_arr(:, 2), :);
    ab_arr = pb_arr - pa_arr;
    len2_arr = ab_arr(:, 1).^2 + ab_arr(:, 2).^2;
    tol_arr = 1e-9 * sqrt(len2_arr);

    new_vtx_ids = (nnode_orig+1):size(quadnode, 1);

    for fi = 1:length(new_vtx_ids)
        F = new_vtx_ids(fi);
        pF = quadnode(F, :);

        % Vectorized: check F against ALL edges
        ap_arr = pF - pa_arr;  % broadcast (n_edges, 2)
        % V30-FIX4: use .* (element-wise) not * (matrix multiply)
        cross_arr = ab_arr(:, 1) .* ap_arr(:, 2) - ab_arr(:, 2) .* ap_arr(:, 1);
        t_arr = (ab_arr(:, 1) .* ap_arr(:, 1) + ab_arr(:, 2) .* ap_arr(:, 2)) ...
                ./ max(len2_arr, 1e-18);

        on_seg = abs(cross_arr) < tol_arr & t_arr > 0.01 & t_arr < 0.99;
        not_endpoint = edge_arr(:, 1) ~= F & edge_arr(:, 2) ~= F;
        on_seg = on_seg & not_endpoint;

        candidate_edges = find(on_seg);
        for ei = 1:length(candidate_edges)
            edge_idx = candidate_edges(ei);
            qids = edge_quad_list{edge_idx};
            for k = 1:length(qids)
                qi = qids(k);
                q = quad(qi, :);
                if any(q == 0); continue; end
                if ismember(F, q); continue; end
                n_tj = n_tj + 1;
                break;
            end
        end
    end

    if n_tj == 0
        ok = true; msg = '';
    else
        ok = false;
        msg = sprintf('%d T-junctions (non-conforming edges)', n_tj);
    end
end

% ====================================================================
function found = check_replaced_vertex_v30(a, b, bnd_adj, quadnode)
%CHECK_REPLACED_VERTEX_V30  When vertex 'a' was replaced by F (on segment a-b),
%   'a' may no longer be in bnd_adj. Check if any vertex F on segment (a,b)
%   IS in bnd_adj and can reach 'b' via boundary edges.
%   V30-FIX: use cell2mat for robust key extraction from containers.Map.

    nqn = size(quadnode, 1);
    if a > nqn || b > nqn; found = false; return; end
    pa = quadnode(a, :); pb = quadnode(b, :);

    % Get all boundary vertex IDs as numeric array
    bnd_keys_cell = keys(bnd_adj);
    bnd_keys = cell2mat(bnd_keys_cell);  % convert cell array to numeric

    for k = 1:length(bnd_keys)
        F = bnd_keys(k);
        if F == a || F == b; continue; end
        if F > nqn; continue; end
        pF = quadnode(F, :);
        if on_segment_v30(pF, pa, pb)
            % F is on segment (a, b) — try DFS from F to b
            found = dfs_boundary_walk_v30(F, b, bnd_adj, quadnode);
            if found; return; end
        end
    end
    found = false;
end
