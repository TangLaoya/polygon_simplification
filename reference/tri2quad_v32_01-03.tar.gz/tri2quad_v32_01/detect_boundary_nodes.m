function fixed = detect_boundary_nodes(quad, quadnode)
%DETECT_BOUNDARY_NODES Mark mesh nodes that lie on the boundary.
%   fixed = detect_boundary_nodes(quad, quadnode) returns a logical
%   column vector. fixed(i) = true if node i lies on a boundary edge
%   (an edge shared by only one quad). Such nodes must be held fixed
%   during smoothing to preserve the boundary (Requirement #1).
%
%   REUSED FROM ORIGINAL tri2quad.m WITHOUT MODIFICATION.

    nqn = size(quadnode, 1);
    fixed = false(nqn, 1);

    % Build all quad edges as (min, max) pairs
    nquad = size(quad, 1);
    quad_edges_mat = zeros(nquad * 4, 2);
    for i = 1:nquad
        q = quad(i, :);
        for j = 1:4
            v1 = q(j); v2 = q(mod(j, 4) + 1);
            quad_edges_mat((i-1)*4 + j, :) = [min(v1, v2), max(v1, v2)];
        end
    end

    % Count occurrences of each unique edge
    [~, ~, ic] = unique(quad_edges_mat, 'rows');
    uc = accumarray(ic, 1);

    % Edges that appear exactly once are boundary edges
    for i = 1:size(quad_edges_mat, 1)
        if uc(ic(i)) == 1
            fixed(quad_edges_mat(i, 1)) = true;
            fixed(quad_edges_mat(i, 2)) = true;
        end
    end
end
