/**
 * blossom6_cli.cpp - Standalone CLI for Blossom VI (minimum weight perfect matching)
 *
 * Based on Blossom VI by the paper authors.
 * Source: https://github.com/niklasboshuizen/blossom-vi
 *
 * Usage:
 *   blossom6_cli <input_file> <output_file> [debug]
 *
 * Input format (same as blossom5_cli):
 *   Line 1: <node_count> <edge_count>
 *   Lines 2..E+1: <node_i> <node_j> <weight>
 *
 * Output format:
 *   Line 1: <node_count> <pair_count>
 *   Lines 2..pair_count+1: <node_i> <node_j>
 *
 * NOTE: Blossom VI uses INTEGER weights (int64_t).
 *       We multiply double weights by 1000 and round to int.
 *
 * Compile (Linux):
 *   g++ -std=c++20 -O2 -o blossom6_cli blossom6_cli.cpp MWPMSolver.cpp DualUpdater.cpp -I.
 *
 * Compile (Windows with MSVC):
 *   cl /std:c++20 /EHsc /O2 blossom6_cli.cpp MWPMSolver.cpp DualUpdater.cpp /Fe:blossom6_cli.exe
 *
 * Requirements:
 *   - C++20 compiler
 *   - Boost headers (libboost-dev)
 */

#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <tuple>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <string>
#include <csignal>
#include "MWPMSolver.h"

static int g_debug = 0;

static void signal_handler(int sig) {
    FILE* fp = fopen("blossom6_cli_crash.log", "w");
    if (fp) {
        fprintf(fp, "CRASH: signal %d\n", sig);
        fclose(fp);
    }
    _exit(5);
}

int main(int argc, char* argv[]) {
    signal(SIGSEGV, signal_handler);
    signal(SIGABRT, signal_handler);
    signal(SIGFPE, signal_handler);

    if (argc < 3) {
        fprintf(stderr, "Usage: %s <input_file> <output_file> [debug]\n", argv[0]);
        return 1;
    }
    const char* input_file = argv[1];
    const char* output_file = argv[2];
    if (argc >= 4) g_debug = atoi(argv[3]);

    if (g_debug) fprintf(stderr, "[cli] Reading input: %s\n", input_file);

    FILE* fin = fopen(input_file, "r");
    if (!fin) {
        fprintf(stderr, "ERROR: cannot open input file: %s\n", input_file);
        return 2;
    }

    int node_count, edge_count;
    if (fscanf(fin, "%d %d", &node_count, &edge_count) != 2) {
        fprintf(stderr, "ERROR: cannot read header\n");
        fclose(fin);
        return 2;
    }
    if (node_count <= 0 || node_count % 2 != 0) {
        fprintf(stderr, "ERROR: node_count must be positive even, got %d\n", node_count);
        fclose(fin);
        return 3;
    }
    if (g_debug) fprintf(stderr, "[cli] node_count=%d, edge_count=%d\n", node_count, edge_count);

    // Read edges and convert to integer weights
    std::vector<std::tuple<int, int, int>> edges;
    edges.reserve(edge_count);
    double weight_scale = 1000.0;  // scale double to int

    for (int k = 0; k < edge_count; k++) {
        int ni, nj;
        double dw;
        if (fscanf(fin, "%d %d %lf", &ni, &nj, &dw) != 3) {
            fprintf(stderr, "ERROR: cannot read edge %d\n", k+1);
            fclose(fin);
            return 2;
        }
        if (ni < 0 || ni >= node_count || nj < 0 || nj >= node_count) {
            fprintf(stderr, "ERROR: edge %d (%d, %d) out of range\n", k+1, ni, nj);
            fclose(fin);
            return 3;
        }
        if (ni == nj) {
            fprintf(stderr, "ERROR: edge %d is self-loop\n", k+1);
            fclose(fin);
            return 3;
        }
        // Convert to integer (multiply by scale, round, ensure positive)
        int64_t iw = (int64_t)llround(dw * weight_scale);
        if (iw < 0) iw = 0;
        // Clamp to int range
        if (iw > 2000000000) iw = 2000000000;
        edges.emplace_back(ni, nj, (int)iw);
    }
    fclose(fin);
    if (g_debug) fprintf(stderr, "[cli] Read %d edges OK\n", edge_count);

    // Create solver
    SolverParameters params;
    params.verbose = (g_debug > 0);
    params.print_statistics = (g_debug > 0);

    if (g_debug) fprintf(stderr, "[cli] Creating MWPMSolver...\n");
    MWPMSolver solver(edges, params);

    // Solve
    if (g_debug) fprintf(stderr, "[cli] Calling FindMinPerfectMatching()...\n");
    try {
        solver.FindMinPerfectMatching();
    } catch (const std::exception& e) {
        fprintf(stderr, "ERROR: Solve failed: %s\n", e.what());
        return 4;
    } catch (...) {
        fprintf(stderr, "ERROR: Solve failed (unknown)\n");
        return 4;
    }
    if (g_debug) fprintf(stderr, "[cli] Solve completed\n");

    // Extract matching
    const auto& matching = solver.Matching();
    if (g_debug) fprintf(stderr, "[cli] Found %zu pairs\n", matching.size());

    // Write output
    FILE* fout = fopen(output_file, "w");
    if (!fout) {
        fprintf(stderr, "ERROR: cannot open output file: %s\n", output_file);
        return 2;
    }
    fprintf(fout, "%d %zu\n", node_count, matching.size());
    for (const auto& p : matching) {
        fprintf(fout, "%d %d\n", p.first, p.second);
    }
    fclose(fout);

    if (g_debug) fprintf(stderr, "[cli] Done: %zu pairs written\n", matching.size());
    return 0;
}
