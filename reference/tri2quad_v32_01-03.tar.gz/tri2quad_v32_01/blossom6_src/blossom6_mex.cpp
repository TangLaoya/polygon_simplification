/**
 * blossom6_mex.cpp - MEX wrapper for Blossom VI (minimum weight perfect matching)
 *
 * Uses Blossom VI library (C++20, requires Boost headers).
 *
 * Usage:
 *   match = blossom6_mex(node_count, edge_list, weights, [debug])
 *
 * Input:
 *   node_count : scalar positive even integer
 *   edge_list  : E-by-2 matrix, 0-indexed
 *   weights    : E-by-1 vector (double, will be scaled to int)
 *   debug      : (optional) 0 or 1
 *
 * Output:
 *   match : node_count-by-1 vector, match[i] = partner of i (0-indexed)
 *
 * Compile:
 *   mex -largeArrayDims -O CXXFLAGS='$CXXFLAGS -std:c++20' ...
 *       blossom6_mex.cpp MWPMSolver.cpp DualUpdater.cpp -I.
 *
 * Requirements:
 *   - C++20 compiler
 *   - Boost headers (libboost-dev)
 *   - MATLAB R2020b or later (for C++20 support in MEX)
 */

#include "mex.h"
#include <vector>
#include <tuple>
#include <cstdint>
#include <cmath>
#include <cstdio>
#include "MWPMSolver.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs < 3 || nrhs > 4) {
        mexErrMsgIdAndTxt("blossom6_mex:invalidInput",
            "Usage: match = blossom6_mex(node_count, edge_list, weights, [debug])");
    }

    int g_debug = 0;
    if (nrhs >= 4) {
        g_debug = (int)mxGetScalar(prhs[3]);
    }

    // Read node_count
    if (!mxIsScalar(prhs[0]) || !mxIsDouble(prhs[0])) {
        mexErrMsgIdAndTxt("blossom6_mex:invalidNodeCount",
            "node_count must be scalar double");
    }
    double nc_d = mxGetScalar(prhs[0]);
    if (nc_d <= 0 || nc_d != floor(nc_d)) {
        mexErrMsgIdAndTxt("blossom6_mex:invalidNodeCount",
            "node_count must be positive integer");
    }
    int node_count = (int)nc_d;
    if (node_count % 2 != 0) {
        mexErrMsgIdAndTxt("blossom6_mex:oddNodeCount",
            "node_count must be even, got %d", node_count);
    }

    // Read edge_list
    if (!mxIsDouble(prhs[1])) {
        mexErrMsgIdAndTxt("blossom6_mex:invalidEdgeList",
            "edge_list must be double matrix");
    }
    mwSize E = mxGetM(prhs[1]);
    mwSize Ecols = mxGetN(prhs[1]);
    if (Ecols != 2) {
        mexErrMsgIdAndTxt("blossom6_mex:invalidEdgeList",
            "edge_list must be E-by-2");
    }
    if (E == 0) {
        mexErrMsgIdAndTxt("blossom6_mex:emptyEdgeList", "edge_list is empty");
    }
    const double *edge_data = mxGetPr(prhs[1]);

    // Read weights
    if (!mxIsDouble(prhs[2])) {
        mexErrMsgIdAndTxt("blossom6_mex:invalidWeights", "weights must be double");
    }
    const double *weight_data = mxGetPr(prhs[2]);

    if (g_debug) {
        mexPrintf("[blossom6_mex] node_count=%d, E=%d\n", node_count, (int)E);
        mexEvalString("drawnow;");
    }

    // Convert to integer edges
    // Scale: multiply double weights by 1000 and round to int
    std::vector<std::tuple<int, int, int>> edges;
    edges.reserve(E);
    double weight_scale = 1000.0;

    for (mwSize i = 0; i < E; i++) {
        double di = edge_data[i];
        double dj = edge_data[i + E];
        double dw = weight_data[i];

        if (di != floor(di) || dj != floor(dj)) {
            mexErrMsgIdAndTxt("blossom6_mex:nonIntegerEdge",
                "edge %d has non-integer nodes", (int)i+1);
        }
        int ni = (int)di;
        int nj = (int)dj;
        if (ni < 0 || ni >= node_count || nj < 0 || nj >= node_count) {
            mexErrMsgIdAndTxt("blossom6_mex:edgeOutOfRange",
                "edge %d (%d, %d) out of range", (int)i+1, ni, nj);
        }
        if (ni == nj) {
            mexErrMsgIdAndTxt("blossom6_mex:selfLoop",
                "edge %d is self-loop", (int)i+1);
        }
        if (mxIsNaN(dw)) {
            mexErrMsgIdAndTxt("blossom6_mex:nanWeight",
                "edge %d has NaN weight", (int)i+1);
        }

        int64_t iw = (int64_t)llround(dw * weight_scale);
        if (iw < 0) iw = 0;
        if (iw > 2000000000) iw = 2000000000;
        edges.emplace_back(ni, nj, (int)iw);
    }

    if (g_debug) {
        mexPrintf("[blossom6_mex] Creating solver...\n");
        mexEvalString("drawnow;");
    }

    // Create solver and solve
    SolverParameters params;
    params.verbose = (g_debug > 0);
    params.print_statistics = false;

    MWPMSolver solver(edges, params);

    if (g_debug) {
        mexPrintf("[blossom6_mex] Solving...\n");
        mexEvalString("drawnow;");
    }

    try {
        solver.FindMinPerfectMatching();
    } catch (const std::exception& e) {
        mexErrMsgIdAndTxt("blossom6_mex:solveFailed",
            "Solve failed: %s", e.what());
    } catch (...) {
        mexErrMsgIdAndTxt("blossom6_mex:solveFailed",
            "Solve failed (unknown exception)");
    }

    // Extract matching
    const auto& matching = solver.Matching();

    if (g_debug) {
        mexPrintf("[blossom6_mex] Found %zu pairs\n", matching.size());
        mexEvalString("drawnow;");
    }

    // Build match array (node_count x 1)
    plhs[0] = mxCreateDoubleMatrix((mwSize)node_count, 1, mxREAL);
    double *out = mxGetPr(plhs[0]);
    for (int i = 0; i < node_count; i++) out[i] = -1;

    for (const auto& p : matching) {
        int i = p.first;
        int j = p.second;
        if (i >= 0 && i < node_count && j >= 0 && j < node_count) {
            out[i] = (double)j;
            out[j] = (double)i;
        }
    }

    if (g_debug) {
        int matched = 0;
        for (int i = 0; i < node_count; i++) {
            if (out[i] >= 0) matched++;
        }
        mexPrintf("[blossom6_mex] Matched %d/%d nodes\n", matched, node_count);
        mexEvalString("drawnow;");
    }
}
