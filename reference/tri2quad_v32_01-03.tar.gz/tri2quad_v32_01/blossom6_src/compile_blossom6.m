function compile_blossom6(debug)
%COMPILE_BLOSSOM6  Compile Blossom VI MEX + CLI (V28: Boost-aware).
%
%   compile_blossom6()        - release build
%   compile_blossom6(true)    - debug build
%
%   V28 IMPROVEMENTS:
%     - AUTO-DETECT BOOST: searches common Windows/Linux boost install paths.
%     - USER-CONFIGURABLE: set boost_path variable below to your boost root.
%     - Injects -I<boost_path> into both MEX and CLI compile flags.
%
%   Requires: C++20 compiler, Boost headers (libboost-dev on Linux,
%     D:\local\boost_1_77_0 on Windows per user setup).
%
%   Compiles:
%     1. blossom6_mex.<mexext>  - MEX (fast, in-process)
%     2. blossom6_cli<.exe>     - CLI (safe, subprocess)

    if nargin < 1; debug = false; end

    fprintf('=== Compiling Blossom VI (MEX + CLI) [V28 Boost-aware] ===\n');
    fprintf('MATLAB: %s, Platform: %s\n', version, computer);

    src_dir = fileparts(mfilename('fullpath'));
    if isempty(src_dir); src_dir = pwd; end
    cd(src_dir);
    fprintf('Source dir: %s\n', src_dir);

    % ===== USER-CONFIGURABLE BOOST PATH =====
    % Set this to your Boost installation root (the folder containing
    % boost/container/, boost/property_tree/, etc.).
    % Examples:
    %   Windows: 'D:\local\boost_1_77_0'
    %   Linux:   '/usr/include'  (boost is usually in /usr/include/boost)
    %   Mac:     '/opt/homebrew/include'
    boost_path = '';  % <-- EDIT THIS if auto-detect fails

    if isempty(boost_path)
        boost_path = auto_detect_boost();
    end

    if isempty(boost_path)
        fprintf('  Boost: NOT FOUND. Edit boost_path in compile_blossom6.m.\n');
        fprintf('  Compilation will likely fail with boost/container/small_vector.hpp not found.\n');
    else
        fprintf('  Boost path: %s\n', boost_path);
    end

    % Build the -I flag string
    if ~isempty(boost_path)
        boost_inc = sprintf('-I%s', boost_path);
    else
        boost_inc = '';
    end

    % Check source files exist
    src_files = {'blossom6_mex.cpp', 'blossom6_cli.cpp', 'MWPMSolver.cpp', ...
                 'MWPMSolver.h', 'DualUpdater.cpp', 'DualUpdater.h'};
    for i = 1:length(src_files)
        if ~exist(fullfile(src_dir, src_files{i}), 'file')
            error('Missing: %s', src_files{i});
        end
    end

    % -------- 1. Compile MEX --------
    fprintf('\n--- Compiling MEX (blossom6_mex) ---\n');
    if ispc
        std_flag = 'COMPFLAGS=$COMPFLAGS /std:c++20 /EHsc';
    else
        std_flag = 'CXXFLAGS=$CXXFLAGS -std=c++20 -fexceptions';
    end

    mex_opts = {'-largeArrayDims', '-O', std_flag};
    if ~isempty(boost_inc); mex_opts = [{boost_inc}, mex_opts]; end  % V28
    if debug; mex_opts = [{'-g'}; mex_opts]; end

    mex_args = [mex_opts, {'blossom6_mex.cpp', 'MWPMSolver.cpp', 'DualUpdater.cpp'}];
    fprintf('Command: mex %s\n', strjoin(mex_args, ' '));

    mex_ok = false;
    try
        mex(mex_args{:});
        fprintf('  MEX OK: blossom6_mex.%s\n', mexext);
        mex_ok = true;
    catch ME
        fprintf('  MEX FAILED: %s\n', ME.message);
        fprintf('  (CLI will still be compiled)\n');
    end

    % -------- 2. Compile CLI --------
    fprintf('\n--- Compiling CLI (blossom6_cli) ---\n');
    cli_src = 'blossom6_cli.cpp MWPMSolver.cpp DualUpdater.cpp';

    if ispc
        [cl_path, vcvars_path] = find_msvc_v6();
        if ~isempty(vcvars_path)
            fprintf('  Found MSVC: %s\n', vcvars_path);
            if debug
                cli_flags = '/std:c++20 /EHsc /Od /Zi /DNDEBUG';
            else
                cli_flags = '/std:c++20 /EHsc /O2 /DNDEBUG';
            end
            % V28: prepend boost -I flag
            if ~isempty(boost_inc)
                cli_flags = sprintf('%s %s', boost_inc, cli_flags);
            end
            bat_file = fullfile(tempdir, 'compile_blossom6_cli.bat');
            fid = fopen(bat_file, 'w');
            fprintf(fid, '@echo off\n');
            fprintf(fid, 'call "%s"\n', vcvars_path);
            fprintf(fid, 'cd /d "%s"\n', src_dir);
            fprintf(fid, 'cl %s /Fe:blossom6_cli.exe %s\n', cli_flags, cli_src);
            fprintf(fid, 'del blossom6_cli.obj MWPMSolver.obj DualUpdater.obj 2>nul\n');
            fclose(fid);
            status = system(bat_file);
            delete(bat_file);
        else
            fprintf('  MSVC not found. Skipping CLI.\n');
            status = 1;
        end
    else
        if debug
            cli_flags = '-std=c++20 -g -O0 -DNDEBUG';
        else
            cli_flags = '-std=c++20 -O3 -DNDEBUG';
        end
        % V28: prepend boost -I flag
        if ~isempty(boost_inc)
            cli_flags = sprintf('%s %s', boost_inc, cli_flags);
        end
        cmd = sprintf('g++ %s -o blossom6_cli %s -I.', cli_flags, cli_src);
        fprintf('Command: %s\n', cmd);
        status = system(cmd);
    end

    cli_ok = (status == 0 && exist('blossom6_cli', 'file') == 2);
    if cli_ok
        fprintf('  CLI OK: blossom6_cli\n');
    else
        fprintf('  CLI FAILED (status %d)\n', status);
    end

    % -------- Summary --------
    fprintf('\n=== Summary ===\n');
    fprintf('  MEX:  %s\n', ternary(mex_ok, 'OK', 'FAILED'));
    fprintf('  CLI:  %s\n', ternary(cli_ok, 'OK', 'FAILED'));
end

% =====================================================================
function boost_path = auto_detect_boost()
%AUTO_DETECT_BOOST  Search common boost installation locations.
    boost_path = '';

    if ispc
        % Windows: search D:\local\, C:\local\, C:\boost\, etc.
        candidates = {
            'D:\local\boost_1_77_0', ...
            'D:\local\boost_1_78_0', ...
            'D:\local\boost_1_79_0', ...
            'D:\local\boost_1_80_0', ...
            'D:\local\boost_1_81_0', ...
            'D:\local\boost_1_82_0', ...
            'C:\local\boost_1_77_0', ...
            'C:\boost', ...
            'C:\Program Files\boost', ...
            'C:\Program Files (x86)\boost'
        };
        for i = 1:length(candidates)
            if exist(fullfile(candidates{i}, 'boost', 'container', 'small_vector.hpp'), 'file')
                boost_path = candidates{i};
                return;
            end
        end
    else
        % Linux/Mac: search common include paths
        candidates = {
            '/usr/include', ...
            '/usr/local/include', ...
            '/opt/homebrew/include', ...
            '/opt/local/include', ...
            '/opt/boost/include', ...
            '/home/y/include', ...
            getenv('BOOST_ROOT')
        };
        for i = 1:length(candidates)
            if isempty(candidates{i}); continue; end
            if exist(fullfile(candidates{i}, 'boost', 'container', 'small_vector.hpp'), 'file')
                boost_path = candidates{i};
                return;
            end
        end
    end
end

% =====================================================================
function [cl_path, vcvars_path] = find_msvc_v6()
    cl_path = '';
    vcvars_path = '';
    try
        config = mex.getCompilerConfigurations('C++', 'Active');
        if ~isempty(config)
            cl_path = config.CompilerPath;
            if ~isempty(cl_path)
                p = cl_path;
                for k = 1:10
                    candidate = fullfile(p, 'Auxiliary', 'Build', 'vcvars64.bat');
                    if exist(candidate, 'file')
                        vcvars_path = candidate;
                        return;
                    end
                    p_new = fileparts(p);
                    if strcmp(p_new, p); break; end
                    p = p_new;
                end
            end
        end
    catch
    end
    if isempty(vcvars_path)
        candidates = {
            'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat', ...
            'C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat', ...
            'C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat', ...
            'C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat', ...
            'C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat', ...
            'C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvars64.bat', ...
            'C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvars64.bat', ...
            'C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
        };
        for i = 1:length(candidates)
            if exist(candidates{i}, 'file')
                vcvars_path = candidates{i};
                return;
            end
        end
    end
end

% =====================================================================
function s = ternary(cond, a, b)
    if cond; s = a; else; s = b; end
end
