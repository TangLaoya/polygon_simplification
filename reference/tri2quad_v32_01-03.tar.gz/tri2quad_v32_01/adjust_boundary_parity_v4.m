function [node, tri, info] = adjust_boundary_parity_v4( ...
    node, tri, debug, opts)
%ADJUST_BOUNDARY_PARITY_V4 Enhanced version of adjust_boundary_parity.
%
%   [node, tri, info] = adjust_boundary_parity_v4(node, tri, debug, opts)
%
%   Improvements over v3:
%     1. For ODD loops: pick the boundary edge whose SPLIT causes the
%        least geometric distortion.  Use the edge whose adjacent
%        triangle has the BEST aspect ratio after splitting, instead
%        of always picking the longest edge.
%     2. Try multiple candidate edges (up to 5) and pick the one whose
%        adjacent triangle has the largest minimum angle after split.
%     3. For very small loops (L < 6, mostly hole trim loops), DO NOT
%        force parity -- instead leave them odd and let the matching
%        stage deal with the resulting single unmatched triangle on
%        that loop.  This avoids creating a degenerate skinny triangle
%        on a tiny loop.  (We then collapse that orphan into a quad
%        later via local operations.)  Controlled by opts.min_loop_size.
%
%   Inputs:
%     node, tri : input mesh (modified in place)
%     debug     : verbose flag
%     opts      : struct with fields (or use defaults)
%       .min_loop_size   : don't force parity on loops smaller than
%                          this (default 6).  Set to 0 to force all.
%       .max_candidates  : how many candidate edges to evaluate per
%                          odd loop (default 5)
%
%   Output info struct:
%     .num_odd_loops, .num_added_vtx, .num_added_tri, .num_skipped_small

    if nargin < 3; debug = 0; end
    if nargin < 4 || isempty(opts)
        opts = struct();
    end
    if ~isfield(opts, 'min_loop_size');  opts.min_loop_size  = 6; end
    if ~isfield(opts, 'max_candidates'); opts.max_candidates = 5; end

    info.num_odd_loops      = 0;
    info.num_added_vtx      = 0;
    info.num_added_tri      = 0;
    info.num_skipped_small  = 0;

    loops = find_boundary_loops(node, tri);
    if debug
        fprintf('  [parity] found %d boundary loop(s)\n', length(loops));
    end

    for k = 1:length(loops)
        L = length(loops{k});

        if mod(L, 2) == 0
            continue;   % v9: suppress verbose "even, ok" output
        end

        % ODD loop
        info.num_odd_loops = info.num_odd_loops + 1;

        % --- Skip very small odd loops (orphan strategy) ------------
        if L < opts.min_loop_size
            info.num_skipped_small = info.num_skipped_small + 1;
            if debug
                fprintf('  [parity] loop %d: %d edges (ODD, small -> skip)\n', k, L);
            end
            continue;
        end

        % --- Pick best edge to split (by post-split triangle quality) -
        loop = loops{k};

        % Build candidate list: the longest `max_candidates` edges
        edge_lens = zeros(L, 1);
        for i = 1:L
            a = loop(i);
            b = loop(mod(i, L) + 1);
            edge_lens(i) = norm(node(a,:) - node(b,:));
        end
        [~, sort_idx] = sort(edge_lens, 'descend');
        n_cand = min(opts.max_candidates, L);
        cand_idx = sort_idx(1:n_cand);

        best_score = -inf;
        best_i = cand_idx(1);
        for ci = 1:n_cand
            i = cand_idx(ci);
            a = loop(i);
            b = loop(mod(i, L) + 1);
            % Find adjacent triangle
            ntri = size(tri, 1);
            target_tri = 0;
            for t = 1:ntri
                v = tri(t,:);
                if any(v == a) && any(v == b)
                    target_tri = t; break;
                end
            end
            if target_tri == 0; continue; end

            % Compute min angle of the two resulting triangles if we
            % split edge (a, b) with midpoint m.
            v_tri = tri(target_tri, :);
            opp = v_tri(v_tri ~= a & v_tri ~= b);
            opp = opp(1);
            pa = node(a,:); pb = node(b,:); po = node(opp,:);
            pm = 0.5 * (pa + pb);

            % Two new triangles: (a, m, opp) and (m, b, opp) or
            % (b, m, opp) and (m, a, opp) depending on orientation.
            % Compute min angle of each.
            ma1 = min_angle_tri(pa, pm, po);
            ma2 = min_angle_tri(pm, pb, po);
            score = min(ma1, ma2);

            if score > best_score
                best_score = score;
                best_i = i;
            end
        end

        % Apply the split
        a = loop(best_i);
        b = loop(mod(best_i, L) + 1);
        mid_pt  = 0.5 * (node(a,:) + node(b,:));
        mid_id  = size(node, 1) + 1;
        node(end+1, :) = mid_pt;
        info.num_added_vtx = info.num_added_vtx + 1;

        % Find adjacent triangle (again, after possible node changes)
        ntri = size(tri, 1);
        target_tri = 0;
        for t = 1:ntri
            v = tri(t,:);
            if any(v == a) && any(v == b)
                target_tri = t; break;
            end
        end
        if target_tri == 0; continue; end

        v_tri = tri(target_tri, :);
        opp = v_tri(v_tri ~= a & v_tri ~= b);
        opp = opp(1);
        ia = find(v_tri == a, 1);
        ib = find(v_tri == b, 1);
        if mod(ib - ia, 3) == 1
            new_t1 = [a, mid_id, opp];
            new_t2 = [mid_id, b, opp];
        else
            new_t1 = [b, mid_id, opp];
            new_t2 = [mid_id, a, opp];
        end
        tri(target_tri, :) = new_t1;
        tri(end+1, :)       = new_t2;
        info.num_added_tri  = info.num_added_tri + 1;

        if debug
            fprintf('  [parity] loop %d: %d edges (ODD) -> split edge (%d,%d) -> new vtx %d, score=%.1f deg\n', ...
                k, L, a, b, mid_id, best_score);
        end
    end
end

% ====================================================================
function a = min_angle_tri(p1, p2, p3)
%MIN_ANGLE_TRI Minimum interior angle (degrees) of a triangle.
%   Uses the standard cosine formula at each vertex:
%     angle at p1 = angle between vectors (p2-p1) and (p3-p1)
%     angle at p2 = angle between vectors (p1-p2) and (p3-p2)
%     angle at p3 = angle between vectors (p1-p3) and (p2-p3)
    a1 = angle_at_vertex(p1, p2, p3);
    a2 = angle_at_vertex(p2, p1, p3);
    a3 = angle_at_vertex(p3, p1, p2);
    a = min([a1, a2, a3]);
end

function ang = angle_at_vertex(p_vertex, p_a, p_b)
%ANGLE_AT_VERTEX Interior angle at p_vertex between rays to p_a and p_b.
    v_a = p_a - p_vertex;
    v_b = p_b - p_vertex;
    na = norm(v_a); nb = norm(v_b);
    if na < 1e-15 || nb < 1e-15
        ang = 0; return;
    end
    cos_ang = dot(v_a, v_b) / (na * nb);
    cos_ang = max(-1, min(1, cos_ang));
    ang = acosd(cos_ang);
end
