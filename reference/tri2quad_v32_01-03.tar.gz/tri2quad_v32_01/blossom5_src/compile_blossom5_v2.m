function compile_blossom5_v2(debug)
%COMPILE_BLOSSOM5_V2  Compile Blossom V MEX + CLI for Win10/MATLAB2023b.
%
%   compile_blossom5_v2()        - release build (default)
%   compile_blossom5_v2(true)   - debug build
%
%   Compiles TWO binaries:
%     1. blossom5_mex_v2.<mexext>  - MEX (fast, but segfault crashes MATLAB)
%     2. blossom5_cli.<exe>         - CLI (safe, runs in subprocess)

    if nargin < 1; debug = false; end

    fprintf('=== Compiling Blossom V (MEX + CLI) ===\n');
    fprintf('MATLAB: %s, Platform: %s, Build: %s\n', ...
        version, computer, ternary(debug, 'DEBUG', 'RELEASE'));

    src_dir = fileparts(mfilename('fullpath'));
    if isempty(src_dir); src_dir = pwd; end
    cd(src_dir);
    fprintf('Source dir: %s\n', src_dir);

    % -------- Source files (shared by MEX and CLI) --------
    blossom_core = { ...
        'PMinterface.cpp', 'PMinit.cpp', 'PMmain.cpp', ...
        'PMduals.cpp', 'PMexpand.cpp', 'PMshrink.cpp', ...
        'PMrepair.cpp', 'misc.cpp', 'MinCost/MinCost.cpp' ...
    };

    % Check all files exist
    all_files = [{'blossom5_mex_v2.cpp', 'blossom5_cli.cpp'}, blossom_core];
    missing = {};
    for i = 1:length(all_files)
        f = all_files{i};
        if ~exist(fullfile(src_dir, f), 'file')
            missing{end+1} = f; %#ok<AGROW>
        end
    end
    if ~isempty(missing)
        fprintf('Missing files:\n');
        for i = 1:length(missing); fprintf('  %s\n', missing{i}); end
        error('Missing source files');
    end

    % -------- 1. Compile MEX --------
    fprintf('\n--- Compiling MEX (blossom5_mex_v2) ---\n');
    mex_opts = {'-largeArrayDims'};
    if debug
        mex_opts = [mex_opts, {'-g'}];
    else
        mex_opts = [mex_opts, {'-O'}];
    end
    if ispc
        mex_opts = [mex_opts, {'COMPFLAGS=$COMPFLAGS /std:c++17 /EHsc /DNDEBUG'}];
    else
        mex_opts = [mex_opts, {'CXXFLAGS=$CXXFLAGS -std=c++17 -fexceptions -DNDEBUG'}];
    end

    mex_args = {};
    for i = 1:length(mex_opts)
        mex_args{end+1} = mex_opts{i}; %#ok<AGROW>
    end
    mex_args{end+1} = 'blossom5_mex_v2.cpp'; %#ok<AGROW>
    for i = 1:length(blossom_core)
        mex_args{end+1} = blossom_core{i}; %#ok<AGROW>
    end

    fprintf('Command: mex %s\n', strjoin(mex_args, ' '));
    mex_ok = false;
    try
        mex(mex_args{:});
        fprintf('  MEX OK: blossom5_mex_v2.%s\n', mexext);
        mex_ok = true;
    catch ME
        fprintf('  MEX FAILED: %s\n', ME.message);
    end

    % -------- 2. Compile CLI --------
    fprintf('\n--- Compiling CLI (blossom5_cli) ---\n');
    cli_src_list = [{'blossom5_cli.cpp'}, blossom_core];
    cli_src_str = strjoin(cli_src_list, ' ');

    if ispc
        % Windows: find MSVC compiler via MATLAB's mex configuration
        [cl_path, vcvars_path] = find_msvc_compiler();
        if isempty(cl_path) && isempty(vcvars_path)
            fprintf('  MSVC not found via mex config. Searching common paths...\n');
            vcvars_path = find_vcvars_common();
        end

        if debug
            cli_flags = '/std:c++17 /EHsc /Od /Zi /DNDEBUG /DPERFECT_MATCHING_DOUBLE';
        else
            cli_flags = '/std:c++17 /EHsc /O2 /DNDEBUG /DPERFECT_MATCHING_DOUBLE';
        end

        if ~isempty(vcvars_path)
            fprintf('  Found MSVC: %s\n', vcvars_path);
            bat_file = fullfile(tempdir, 'compile_blossom_cli.bat');
            fid = fopen(bat_file, 'w');
            fprintf(fid, '@echo off\n');
            fprintf(fid, 'call "%s"\n', vcvars_path);
            fprintf(fid, 'cd /d "%s"\n', src_dir);
            fprintf(fid, 'cl %s /Fe:blossom5_cli.exe %s\n', cli_flags, cli_src_str);
            fprintf(fid, 'del blossom5_cli.obj 2>nul\n');
            fprintf(fid, 'del *.obj 2>nul\n');
            fclose(fid);
            status = system(bat_file);
            delete(bat_file);
        elseif ~isempty(cl_path)
            cl_dir = fileparts(cl_path);
            cmd = sprintf('cd /d "%s" && "%s\\cl" %s /Fe:blossom5_cli.exe %s', ...
                src_dir, cl_dir, cli_flags, cli_src_str);
            status = system(cmd);
        else
            fprintf('  MSVC not found. Skipping CLI.\n');
            fprintf('  To compile manually, open "x64 Native Tools Command Prompt":\n');
            fprintf('    cd %s\n', src_dir);
            fprintf('    cl %s /Fe:blossom5_cli.exe %s\n', cli_flags, cli_src_str);
            status = 1;
        end
    else
        % Linux/macOS: use g++/clang++
        if debug
            cli_flags = '-std=c++17 -g -O0 -DNDEBUG -DPERFECT_MATCHING_DOUBLE';
        else
            cli_flags = '-std=c++17 -O3 -DNDEBUG -DPERFECT_MATCHING_DOUBLE';
        end
        cmd = sprintf('g++ %s -o blossom5_cli %s', cli_flags, cli_src_str);
        fprintf('Command: %s\n', cmd);
        status = system(cmd);
        if status ~= 0
            fprintf('  g++ failed, trying clang++...\n');
            cmd = sprintf('clang++ %s -o blossom5_cli %s', cli_flags, cli_src_str);
            status = system(cmd);
        end
    end

    cli_ok = (status == 0 && exist('blossom5_cli', 'file') == 2);
    if cli_ok
        fprintf('  CLI OK: blossom5_cli\n');
    else
        fprintf('  CLI FAILED (status %d)\n', status);
    end

    % -------- Summary --------
    fprintf('\n=== Compilation Summary ===\n');
    fprintf('  MEX:  %s\n', ternary(mex_ok, 'OK', 'FAILED'));
    fprintf('  CLI:  %s\n', ternary(cli_ok, 'OK', 'FAILED'));
    if cli_ok && mex_ok
        fprintf('\nBoth compiled. blossom5_solve.m uses CLI by default (safe).\n');
    elseif cli_ok
        fprintf('\nOnly CLI compiled. Safe operation (no crash risk).\n');
    elseif mex_ok
        fprintf('\nOnly MEX compiled. WARNING: may crash MATLAB if Blossom V segfaults.\n');
    else
        fprintf('\nNeither compiled. Using MATLAB fallback (suboptimal).\n');
    end
end

% =====================================================================
function [cl_path, vcvars_path] = find_msvc_compiler()
% Find MSVC compiler via MATLAB's mex configuration.
    cl_path = '';
    vcvars_path = '';

    try
        % Get the active C++ compiler configuration
        config = mex.getCompilerConfigurations('C++', 'Active');
        if ~isempty(config)
            % config.CompilerPath contains the path to cl.exe
            cl_path = config.CompilerPath;
            % Derive vcvars64.bat from cl.exe path
            % cl.exe is usually at: <VS>\VC\Tools\MSVC\<ver>\bin\Hostx64\x64\cl.exe
            % vcvars64.bat is at:  <VS>\VC\Auxiliary\Build\vcvars64.bat
            if ~isempty(cl_path)
                % Walk up to find the VC root (containing 'Auxiliary')
                p = cl_path;
                for k = 1:10
                    candidate = fullfile(p, 'Auxiliary', 'Build', 'vcvars64.bat');
                    if exist(candidate, 'file')
                        vcvars_path = candidate;
                        return;
                    end
                    p_new = fileparts(p);
                    if strcmp(p_new, p); break; end
                    p = p_new;
                end
            end
        end
    catch
        % Ignore errors, fall through to common path search
    end
end

% =====================================================================
function vcvars = find_vcvars_common()
% Search common Visual Studio installation paths for vcvars64.bat.
    vcvars = '';
    candidates = { ...
        'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files (x86)\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files (x86)\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat', ...
        'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
    };
    for i = 1:length(candidates)
        if exist(candidates{i}, 'file')
            vcvars = candidates{i};
            return;
        end
    end
end

% =====================================================================
function s = ternary(cond, a, b)
    if cond; s = a; else; s = b; end
end
