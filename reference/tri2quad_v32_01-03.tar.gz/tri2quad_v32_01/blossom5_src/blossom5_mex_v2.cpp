/**
 * blossom5_mex_v2.cpp - Robust MEX wrapper for Blossom V (Kolmogorov 2009)
 *
 * v2 FIXES OVER ORIGINAL:
 *   1. Win64 POINTER_TYPE: use uintptr_t (8 bytes) instead of unsigned long (4 bytes on Win64)
 *   2. exit(1) → throw std::runtime_error (caught by try/catch, no MATLAB crash)
 *   3. AddEdge validation: _j>=node_num (was _j>node_num, a typo)
 *   4. Graph connectivity pre-check (Blossom V crashes on disconnected graphs)
 *   5. Isolated node detection (Blossom V requires every node to have ≥1 edge)
 *   6. Debug output with mexPrintf + drawnow flush (when debug=1)
 *
 * v3 ADDITIONAL FIXES (after crash diagnosis):
 *   7. Optional 4th argument: debug flag (0=quiet, 1=verbose)
 *   8. Pre-flight degree statistics (detect potential matching issues)
 *   9. Try/catch around ALL Blossom V API calls with detailed error messages
 *  10. Post-solve verification (check matching is valid before returning)
 *
 * USAGE:
 *   match = blossom5_mex_v2(node_count, edge_list, weights)
 *   match = blossom5_mex_v2(node_count, edge_list, weights, debug)
 *
 *   debug = 1 enables extensive progress output (use mexEvalString to flush)
 *
 * CRASH SAFETY:
 *   This MEX catches all C++ exceptions. However, segfaults/assert failures
 *   CANNOT be caught by try/catch and WILL crash MATLAB.
 *   For crash-safe operation, use blossom5_cli (standalone executable)
 *   via blossom5_solve.m with method='cli'.
 */

#include "mex.h"
#include <vector>
#include <string>
#include <algorithm>
#include <memory>
#include <cmath>
#include <cstdio>
#include "PerfectMatching.h"

// Debug helper: print and flush to MATLAB console immediately
static int g_debug = 0;
#define DBG_PRINT(...) do { \
    if (g_debug) { \
        mexPrintf(__VA_ARGS__); \
        mexEvalString("drawnow;"); \
    } \
} while(0)

// =====================================================================
class UnionFind {
public:
    std::vector<int> parent;
    explicit UnionFind(int n) : parent(n) {
        for (int i = 0; i < n; i++) parent[i] = i;
    }
    int find(int x) {
        while (parent[x] != x) {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        return x;
    }
    void unite(int x, int y) {
        int rx = find(x), ry = find(y);
        if (rx != ry) parent[ry] = rx;
    }
};

// =====================================================================
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    // -------- 1. Parse arguments --------
    bool has_debug = (nrhs >= 4);
    if (has_debug) {
        g_debug = (int)mxGetScalar(prhs[3]);
    }
    if (nrhs < 3 || nrhs > 4) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidInput",
            "Usage: match = blossom5_mex_v2(node_count, edge_list, weights, [debug])");
    }
    if (nlhs > 1) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidOutput", "At most one output");
    }

    DBG_PRINT("[blossom5_mex_v2] Starting (debug=%d)\n", g_debug);

    // -------- 2. Read & validate node_count --------
    if (!mxIsScalar(prhs[0]) || !mxIsDouble(prhs[0])) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidNodeCount",
            "node_count must be a scalar double");
    }
    double nc_d = mxGetScalar(prhs[0]);
    if (nc_d <= 0 || nc_d != floor(nc_d)) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidNodeCount",
            "node_count must be a positive integer, got %g", nc_d);
    }
    int node_count = (int)nc_d;
    if (node_count % 2 != 0) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:oddNodeCount",
            "node_count must be even, got %d", node_count);
    }
    DBG_PRINT("[blossom5_mex_v2] node_count = %d\n", node_count);

    // -------- 3. Read & validate edge_list --------
    if (!mxIsDouble(prhs[1])) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidEdgeList",
            "edge_list must be a double matrix");
    }
    mwSize E = mxGetM(prhs[1]);
    mwSize Ecols = mxGetN(prhs[1]);
    if (Ecols != 2) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidEdgeList",
            "edge_list must be E-by-2, got %d-by-%d", (int)E, (int)Ecols);
    }
    if (E == 0) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:emptyEdgeList", "edge_list is empty");
    }
    const double *edge_data = mxGetPr(prhs[1]);
    DBG_PRINT("[blossom5_mex_v2] edge_list: %d edges\n", (int)E);

    // -------- 4. Read & validate weights --------
    if (!mxIsDouble(prhs[2])) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidWeights", "weights must be double");
    }
    mwSize wM = mxGetM(prhs[2]), wN = mxGetN(prhs[2]);
    if (!((wM == E && wN == 1) || (wM == 1 && wN == E))) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:invalidWeights",
            "weights must be E-by-1, got %d-by-%d (expected %d)", (int)wM, (int)wN, (int)E);
    }
    const double *weight_data = mxGetPr(prhs[2]);

    // -------- 5. Pre-validate edges --------
    DBG_PRINT("[blossom5_mex_v2] Step 5: validating edges...\n");
    std::vector<int> ei_arr(E), ej_arr(E);
    std::vector<double> w_arr(E);
    bool has_nan = false;
    for (mwSize i = 0; i < E; i++) {
        double di = edge_data[i];
        double dj = edge_data[i + E];
        double dw = weight_data[i];
        if (di != floor(di) || dj != floor(dj)) {
            mexErrMsgIdAndTxt("blossom5_mex_v2:nonIntegerEdge",
                "edge %d has non-integer nodes (%g, %g)", (int)i+1, di, dj);
        }
        int ni = (int)di, nj = (int)dj;
        if (ni < 0 || ni >= node_count || nj < 0 || nj >= node_count) {
            mexErrMsgIdAndTxt("blossom5_mex_v2:edgeOutOfRange",
                "edge %d (%d, %d) out of range [0, %d)", (int)i+1, ni, nj, node_count);
        }
        if (ni == nj) {
            mexErrMsgIdAndTxt("blossom5_mex_v2:selfLoop",
                "edge %d (%d, %d) is a self-loop", (int)i+1, ni, nj);
        }
        if (mxIsNaN(dw)) has_nan = true;
        ei_arr[i] = ni;
        ej_arr[i] = nj;
        w_arr[i] = dw;
    }
    if (has_nan) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:nanWeight", "weights contains NaN");
    }
    DBG_PRINT("[blossom5_mex_v2] Step 5: all %d edges valid\n", (int)E);

    // -------- 6. Compute degree statistics --------
    DBG_PRINT("[blossom5_mex_v2] Step 6: computing degree stats...\n");
    std::vector<int> degree(node_count, 0);
    for (mwSize i = 0; i < E; i++) {
        degree[ei_arr[i]]++;
        degree[ej_arr[i]]++;
    }
    int min_deg = node_count, max_deg = 0, zero_deg = 0;
    double sum_deg = 0;
    for (int i = 0; i < node_count; i++) {
        if (degree[i] < min_deg) min_deg = degree[i];
        if (degree[i] > max_deg) max_deg = degree[i];
        if (degree[i] == 0) zero_deg++;
        sum_deg += degree[i];
    }
    double mean_deg = sum_deg / node_count;
    DBG_PRINT("[blossom5_mex_v2]   degree: min=%d, max=%d, mean=%.2f, zero=%d\n",
        min_deg, max_deg, mean_deg, zero_deg);

    if (zero_deg > 0) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:isolatedNode",
            "%d nodes have degree 0 (isolated). Perfect matching impossible.",
            zero_deg);
    }
    if (min_deg < 1) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:lowDegree",
            "Min degree = %d. Every node needs at least 1 edge.", min_deg);
    }

    // -------- 7. Check connectivity --------
    DBG_PRINT("[blossom5_mex_v2] Step 7: checking connectivity...\n");
    UnionFind uf(node_count);
    for (mwSize i = 0; i < E; i++) {
        uf.unite(ei_arr[i], ej_arr[i]);
    }
    int components = 0;
    for (int i = 0; i < node_count; i++) {
        if (uf.find(i) == i) components++;
    }
    DBG_PRINT("[blossom5_mex_v2]   %d connected component(s)\n", components);

    if (components > 1) {
        std::vector<int> reps;
        reps.reserve(components);
        std::vector<bool> seen(node_count, false);
        for (int i = 0; i < node_count; i++) {
            int r = uf.find(i);
            if (!seen[r]) { seen[r] = true; reps.push_back(r); }
        }
        // Component sizes
        std::vector<int> comp_sizes(components, 0);
        for (int i = 0; i < node_count; i++) {
            comp_sizes[std::find(reps.begin(), reps.end(), uf.find(i)) - reps.begin()]++;
        }
        char buf[2048];
        snprintf(buf, sizeof(buf),
            "Graph disconnected (%d components, sizes: %d, %d, %d, ...). "
            "blossom5_solve.m should have added aux edges. "
            "This is an internal error — please report.",
            components,
            comp_sizes.size() > 0 ? comp_sizes[0] : 0,
            comp_sizes.size() > 1 ? comp_sizes[1] : 0,
            comp_sizes.size() > 2 ? comp_sizes[2] : 0);
        mexErrMsgIdAndTxt("blossom5_mex_v2:disconnected", "%s", buf);
    }

    // -------- 8. Create PerfectMatching object --------
    DBG_PRINT("[blossom5_mex_v2] Step 8: creating PerfectMatching(%d nodes, %d edges)...\n",
        node_count, (int)E);
    std::unique_ptr<PerfectMatching> pm;
    try {
        pm.reset(new PerfectMatching(node_count, (int)E));
    } catch (const std::exception& e) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:allocFailed",
            "PerfectMatching constructor failed: %s", e.what());
    } catch (...) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:allocFailed",
            "PerfectMatching constructor failed (unknown exception)");
    }
    DBG_PRINT("[blossom5_mex_v2] Step 8: constructor OK\n");

    // -------- 9. Add edges --------
    DBG_PRINT("[blossom5_mex_v2] Step 9: adding %d edges...\n", (int)E);
    try {
        for (mwSize i = 0; i < E; i++) {
            pm->AddEdge(ei_arr[i], ej_arr[i], (PerfectMatching::REAL)w_arr[i]);
        }
    } catch (const std::exception& e) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:addEdgeFailed",
            "AddEdge failed at edge %d: %s", (int)E, e.what());
    } catch (...) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:addEdgeFailed",
            "AddEdge failed (unknown exception)");
    }
    DBG_PRINT("[blossom5_mex_v2] Step 9: all edges added\n");

    // -------- 10. Solve --------
    DBG_PRINT("[blossom5_mex_v2] Step 10: calling Solve()...\n");
    pm->options.verbose = false;
    try {
        pm->Solve(true);
    } catch (const std::exception& e) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:solveFailed",
            "Blossom V Solve() threw exception: %s\n"
            "This usually means no perfect matching exists.\n"
            "Check that ghost-ghost edges are present in the graph.",
            e.what());
    } catch (...) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:solveFailed",
            "Blossom V Solve() failed (unknown exception).\n"
            "This may be a segfault inside the library — use blossom5_cli for safety.");
    }
    DBG_PRINT("[blossom5_mex_v2] Step 10: Solve() completed\n");

    // -------- 11. Extract matching --------
    DBG_PRINT("[blossom5_mex_v2] Step 11: extracting matching...\n");
    plhs[0] = mxCreateDoubleMatrix((mwSize)node_count, 1, mxREAL);
    double *out = mxGetPr(plhs[0]);

    try {
        for (int i = 0; i < node_count; i++) {
            int j = pm->GetMatch(i);
            if (j < 0 || j >= node_count || j == i) {
                mexWarnMsgIdAndTxt("blossom5_mex_v2:badMatch",
                    "GetMatch(%d) returned %d (invalid)", i, j);
                out[i] = -1;
                continue;
            }
            out[i] = (double)j;
        }
    } catch (const std::exception& e) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:getMatchFailed",
            "GetMatch failed: %s", e.what());
    } catch (...) {
        mexErrMsgIdAndTxt("blossom5_mex_v2:getMatchFailed",
            "GetMatch failed (unknown exception)");
    }

    // -------- 12. Verify matching --------
    DBG_PRINT("[blossom5_mex_v2] Step 12: verifying matching...\n");
    {
        std::vector<bool> seen(node_count, false);
        int pair_count = 0;
        int bad_count = 0;
        for (int i = 0; i < node_count; i++) {
            if (seen[i]) continue;
            int j = (int)out[i];
            if (j < 0 || j >= node_count) { bad_count++; continue; }
            if (i != (int)out[j]) { bad_count++; continue; }
            seen[i] = true;
            seen[j] = true;
            pair_count++;
        }
        DBG_PRINT("[blossom5_mex_v2]   pairs=%d (expected %d), bad=%d\n",
            pair_count, node_count/2, bad_count);

        if (pair_count * 2 != node_count) {
            mexWarnMsgIdAndTxt("blossom5_mex_v2:incompleteMatch",
                "Only %d valid pairs (expected %d). bad=%d",
                pair_count, node_count/2, bad_count);
        }
    }

    DBG_PRINT("[blossom5_mex_v2] Done.\n");
}
