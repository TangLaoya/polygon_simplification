/**
 * blossom5_cli.cpp - Standalone command-line Blossom V solver
 *
 * Runs in a SEPARATE PROCESS from MATLAB.  If Blossom V crashes
 * (segfault, assert failure, etc.), only this process dies — MATLAB
 * survives and can fall back to an alternative method.
 *
 * USAGE:
 *   blossom5_cli <input_file> <output_file> [debug]
 *
 * INPUT FORMAT (simple text, one edge per line):
 *   Line 1: <node_count> <edge_count>
 *   Lines 2..E+1: <node_i> <node_j> <weight>
 *
 *   All values are whitespace-separated, 0-indexed.
 *
 * OUTPUT FORMAT:
 *   Line 1: <node_count> <pair_count>
 *   Lines 2..pair_count+1: <node_i> <node_j>
 *
 * EXIT CODES:
 *   0 = success
 *   1 = usage error
 *   2 = input file error
 *   3 = graph validation error (disconnected, isolated, etc.)
 *   4 = Blossom V exception (no perfect matching, etc.)
 *   5 = unknown crash (segfault handler)
 *
 * COMPILE:
 *   See compile_blossom5_v2.m (compiles both MEX and CLI)
 *
 * Or manually:
 *   g++ -std=c++17 -O2 -DNDEBUG -DPERFECT_MATCHING_DOUBLE \
 *       blossom5_cli.cpp PMinterface.cpp PMinit.cpp PMmain.cpp \
 *       PMduals.cpp PMexpand.cpp PMshrink.cpp PMrepair.cpp misc.cpp \
 *       MinCost/MinCost.cpp -o blossom5_cli
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <string>
#include <stdexcept>
#include <memory>
#include <csignal>
#include <iostream>
#include "PerfectMatching.h"

static int g_debug = 0;

// Signal handler for segfault/abort — write error and exit
static void signal_handler(int sig) {
    FILE* fp = fopen("blossom5_cli_crash.log", "w");
    if (fp) {
        fprintf(fp, "CRASH: signal %d\n", sig);
        fprintf(fp, "This indicates a bug inside Blossom V (segfault or assert failure).\n");
        fprintf(fp, "The matching could not be computed.\n");
        fclose(fp);
    }
    _exit(5);  // Use _exit to avoid flushing buffers (might be corrupted)
}

// Simple union-find for connectivity check
class UnionFind {
public:
    std::vector<int> parent;
    explicit UnionFind(int n) : parent(n) {
        for (int i = 0; i < n; i++) parent[i] = i;
    }
    int find(int x) {
        while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }
        return x;
    }
    void unite(int x, int y) {
        int rx = find(x), ry = find(y);
        if (rx != ry) parent[ry] = rx;
    }
};

int main(int argc, char* argv[]) {
    // Install signal handlers
    signal(SIGSEGV, signal_handler);
    signal(SIGABRT, signal_handler);
    signal(SIGFPE, signal_handler);

    if (argc < 3) {
        fprintf(stderr, "Usage: %s <input_file> <output_file> [debug]\n", argv[0]);
        return 1;
    }
    const char* input_file = argv[1];
    const char* output_file = argv[2];
    if (argc >= 4) g_debug = atoi(argv[3]);

    if (g_debug) fprintf(stderr, "[cli] Reading input: %s\n", input_file);

    // -------- Read input --------
    FILE* fin = fopen(input_file, "r");
    if (!fin) {
        fprintf(stderr, "ERROR: cannot open input file: %s\n", input_file);
        return 2;
    }

    int node_count, edge_count;
    if (fscanf(fin, "%d %d", &node_count, &edge_count) != 2) {
        fprintf(stderr, "ERROR: cannot read header (expected: node_count edge_count)\n");
        fclose(fin);
        return 2;
    }
    if (node_count <= 0 || node_count % 2 != 0) {
        fprintf(stderr, "ERROR: node_count must be positive even, got %d\n", node_count);
        fclose(fin);
        return 3;
    }
    if (edge_count <= 0) {
        fprintf(stderr, "ERROR: edge_count must be positive, got %d\n", edge_count);
        fclose(fin);
        return 3;
    }
    if (g_debug) fprintf(stderr, "[cli] node_count=%d, edge_count=%d\n", node_count, edge_count);

    std::vector<int> ei(edge_count), ej(edge_count);
    std::vector<double> w(edge_count);
    for (int k = 0; k < edge_count; k++) {
        if (fscanf(fin, "%d %d %lf", &ei[k], &ej[k], &w[k]) != 3) {
            fprintf(stderr, "ERROR: cannot read edge %d\n", k+1);
            fclose(fin);
            return 2;
        }
        if (ei[k] < 0 || ei[k] >= node_count || ej[k] < 0 || ej[k] >= node_count) {
            fprintf(stderr, "ERROR: edge %d (%d, %d) out of range [0, %d)\n",
                k+1, ei[k], ej[k], node_count);
            fclose(fin);
            return 3;
        }
        if (ei[k] == ej[k]) {
            fprintf(stderr, "ERROR: edge %d is a self-loop (%d, %d)\n", k+1, ei[k], ej[k]);
            fclose(fin);
            return 3;
        }
    }
    fclose(fin);
    if (g_debug) fprintf(stderr, "[cli] Read %d edges OK\n", edge_count);

    // -------- Check connectivity --------
    if (g_debug) fprintf(stderr, "[cli] Checking connectivity...\n");
    UnionFind uf(node_count);
    for (int k = 0; k < edge_count; k++) {
        uf.unite(ei[k], ej[k]);
    }
    int components = 0;
    for (int i = 0; i < node_count; i++) {
        if (uf.find(i) == i) components++;
    }
    if (components > 1) {
        fprintf(stderr, "ERROR: graph has %d disconnected components\n", components);
        return 3;
    }
    if (g_debug) fprintf(stderr, "[cli] Graph is connected (1 component)\n");

    // -------- Check isolated nodes --------
    std::vector<int> degree(node_count, 0);
    for (int k = 0; k < edge_count; k++) {
        degree[ei[k]]++;
        degree[ej[k]]++;
    }
    int min_deg = node_count, zero_deg = 0;
    for (int i = 0; i < node_count; i++) {
        if (degree[i] < min_deg) min_deg = degree[i];
        if (degree[i] == 0) zero_deg++;
    }
    if (g_debug) fprintf(stderr, "[cli] degree: min=%d, zero=%d\n", min_deg, zero_deg);
    if (zero_deg > 0) {
        fprintf(stderr, "ERROR: %d nodes have degree 0\n", zero_deg);
        return 3;
    }

    // -------- Create PerfectMatching --------
    if (g_debug) fprintf(stderr, "[cli] Creating PerfectMatching...\n");
    std::unique_ptr<PerfectMatching> pm;
    try {
        pm.reset(new PerfectMatching(node_count, edge_count));
    } catch (const std::exception& e) {
        fprintf(stderr, "ERROR: constructor failed: %s\n", e.what());
        return 4;
    } catch (...) {
        fprintf(stderr, "ERROR: constructor failed (unknown)\n");
        return 4;
    }

    // -------- Add edges --------
    if (g_debug) fprintf(stderr, "[cli] Adding %d edges...\n", edge_count);
    try {
        for (int k = 0; k < edge_count; k++) {
            pm->AddEdge(ei[k], ej[k], (PerfectMatching::REAL)w[k]);
        }
    } catch (const std::exception& e) {
        fprintf(stderr, "ERROR: AddEdge failed: %s\n", e.what());
        return 4;
    } catch (...) {
        fprintf(stderr, "ERROR: AddEdge failed (unknown)\n");
        return 4;
    }

    // -------- Solve --------
    if (g_debug) fprintf(stderr, "[cli] Calling Solve()...\n");
    pm->options.verbose = false;
    try {
        pm->Solve(true);
    } catch (const std::exception& e) {
        fprintf(stderr, "ERROR: Solve() failed: %s\n", e.what());
        fprintf(stderr, "This usually means no perfect matching exists.\n");
        fprintf(stderr, "Ensure ghost-ghost edges are present in the graph.\n");
        return 4;
    } catch (...) {
        fprintf(stderr, "ERROR: Solve() failed (unknown exception)\n");
        return 4;
    }
    if (g_debug) fprintf(stderr, "[cli] Solve() completed\n");

    // -------- Extract and write matching --------
    if (g_debug) fprintf(stderr, "[cli] Extracting matching...\n");
    FILE* fout = fopen(output_file, "w");
    if (!fout) {
        fprintf(stderr, "ERROR: cannot open output file: %s\n", output_file);
        return 2;
    }

    std::vector<int> match(node_count);
    try {
        for (int i = 0; i < node_count; i++) {
            match[i] = pm->GetMatch(i);
        }
    } catch (const std::exception& e) {
        fprintf(stderr, "ERROR: GetMatch failed: %s\n", e.what());
        fclose(fout);
        return 4;
    } catch (...) {
        fprintf(stderr, "ERROR: GetMatch failed (unknown)\n");
        fclose(fout);
        return 4;
    }

    // Verify and write
    std::vector<bool> seen(node_count, false);
    int pair_count = 0;
    for (int i = 0; i < node_count; i++) {
        if (seen[i]) continue;
        int j = match[i];
        if (j < 0 || j >= node_count || j == i || match[j] != i) {
            fprintf(stderr, "WARNING: invalid match at node %d (partner %d)\n", i, j);
            continue;
        }
        seen[i] = true;
        seen[j] = true;
        pair_count++;
    }

    fprintf(fout, "%d %d\n", node_count, pair_count);
    std::fill(seen.begin(), seen.end(), false);
    for (int i = 0; i < node_count; i++) {
        if (seen[i]) continue;
        int j = match[i];
        if (j >= 0 && j < node_count && match[j] == i) {
            fprintf(fout, "%d %d\n", i, j);
            seen[i] = true;
            seen[j] = true;
        }
    }
    fclose(fout);

    if (g_debug) fprintf(stderr, "[cli] Done: %d pairs written to %s\n", pair_count, output_file);
    return 0;
}
