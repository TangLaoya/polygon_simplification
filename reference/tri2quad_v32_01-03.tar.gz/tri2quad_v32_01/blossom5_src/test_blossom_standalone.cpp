/**
 * test_blossom_standalone.cpp - Standalone test of patched Blossom V
 *
 * Compiles WITHOUT MATLAB.  Validates that:
 *   1. All patched source files compile cleanly with C++17.
 *   2. The POINTER_TYPE fix works on 64-bit (uintptr_t).
 *   3. exit(1) -> throw replacement works (catch the exception).
 *   4. Perfect matching produces correct result on a small test case.
 *
 * Compile:
 *   g++ -std=c++17 -O2 -DPERFECT_MATCHING_DOUBLE \
 *       test_blossom_standalone.cpp PMinterface.cpp PMinit.cpp PMmain.cpp \
 *       PMduals.cpp PMexpand.cpp PMshrink.cpp PMrepair.cpp misc.cpp \
 *       MinCost/MinCost.cpp -o test_blossom
 *
 * Run:
 *   ./test_blossom
 *
 * Expected output:
 *   Bloss V patch test ... PASS
 *   Test 1 (4-cycle): matching = {(0,1),(2,3)} ... PASS
 *   Test 2 (6-node graph): cost = ... ... PASS
 *   Test 3 (odd node count throws): caught exception ... PASS
 *   Test 4 (disconnected graph): ... PASS
 *   All tests passed.
 */

#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <vector>
#include <string>
#include <iostream>
#include "PerfectMatching.h"

static int test_count = 0;
static int pass_count = 0;

#define CHECK(cond, msg) do { \
    test_count++; \
    if (cond) { \
        pass_count++; \
        printf("[PASS] %s\n", msg); \
    } else { \
        printf("[FAIL] %s (line %d)\n", msg, __LINE__); \
    } \
} while (0)

// Test 1: simple 4-cycle, perfect matching is unique
void test1_4cycle() {
    // 4 nodes: 0-1-2-3-0
    // Edges: (0,1,w=1), (1,2,w=10), (2,3,w=1), (3,0,w=10), (0,2,w=100), (1,3,w=100)
    // Optimal: (0,1) + (2,3) with cost 1+1=2
    PerfectMatching pm(4, 6);
    pm.AddEdge(0, 1, 1.0);
    pm.AddEdge(1, 2, 10.0);
    pm.AddEdge(2, 3, 1.0);
    pm.AddEdge(3, 0, 10.0);
    pm.AddEdge(0, 2, 100.0);
    pm.AddEdge(1, 3, 100.0);
    pm.options.verbose = false;
    pm.Solve();

    int m0 = pm.GetMatch(0);
    int m1 = pm.GetMatch(1);
    int m2 = pm.GetMatch(2);
    int m3 = pm.GetMatch(3);

    // Acceptable optimal: (0,1) and (2,3) OR (0,3) and (1,2)
    // But (0,1)+(2,3) has cost 2, (0,3)+(1,2) has cost 20.
    // So (0,1) and (2,3) is optimal.
    bool correct = ((m0 == 1 && m1 == 0 && m2 == 3 && m3 == 2));
    CHECK(correct, "Test 1 (4-cycle optimal matching)");
}

// Test 2: 6-node graph
void test2_6nodes() {
    // 6 nodes, complete graph K6 with random weights
    PerfectMatching pm(6, 15);
    double weights[6][6] = {
        {0,   3,   1,   4,   2,   5},
        {3,   0,   2,   1,   4,   3},
        {1,   2,   0,   3,   2,   4},
        {4,   1,   3,   0,   1,   2},
        {2,   4,   2,   1,   0,   3},
        {5,   3,   4,   2,   3,   0}
    };
    for (int i = 0; i < 6; i++) {
        for (int j = i + 1; j < 6; j++) {
            pm.AddEdge(i, j, weights[i][j]);
        }
    }
    pm.options.verbose = false;
    pm.Solve();

    // Compute matching cost
    double cost = 0;
    std::vector<bool> seen(6, false);
    for (int i = 0; i < 6; i++) {
        if (seen[i]) continue;
        int j = pm.GetMatch(i);
        seen[i] = true;
        seen[j] = true;
        cost += weights[i][j];
    }
    printf("  Test 2 matching cost = %.2f\n", cost);
    // Several optimal solutions exist; just verify it's a perfect matching
    bool is_perfect = true;
    for (int i = 0; i < 6; i++) {
        int j = pm.GetMatch(i);
        if (j < 0 || j >= 6 || j == i || pm.GetMatch(j) != i) {
            is_perfect = false;
            break;
        }
    }
    CHECK(is_perfect, "Test 2 (6-node K6 perfect matching)");
}

// Test 3: odd node count should throw (not crash)
void test3_odd_throws() {
    bool caught = false;
    try {
        PerfectMatching pm(5, 4);  // odd!
        pm.AddEdge(0, 1, 1.0);
        pm.AddEdge(1, 2, 1.0);
        pm.AddEdge(2, 3, 1.0);
        pm.AddEdge(3, 4, 1.0);
        pm.options.verbose = false;
        pm.Solve();
    } catch (const std::exception& e) {
        caught = true;
        printf("  Caught expected exception: %s\n", e.what());
    } catch (...) {
        caught = true;
        printf("  Caught unknown exception\n");
    }
    CHECK(caught, "Test 3 (odd node count throws, not crash)");
}

// Test 4: bad edge id should throw
void test4_bad_edge_throws() {
    bool caught = false;
    try {
        PerfectMatching pm(4, 2);
        pm.AddEdge(0, 1, 1.0);
        pm.AddEdge(2, 5, 1.0);  // 5 out of range [0,4)
        pm.options.verbose = false;
        pm.Solve();
    } catch (const std::exception& e) {
        caught = true;
        printf("  Caught expected exception: %s\n", e.what());
    } catch (...) {
        caught = true;
    }
    CHECK(caught, "Test 4 (bad edge id throws, not crash)");
}

// Test 5: larger graph (stress test)
void test5_larger() {
    int N = 1000;  // 1000 nodes
    // Build a random-ish graph: each node connected to its 5 nearest neighbors
    // Use a simple ring + random extra edges
    PerfectMatching pm(N, N * 3);
    for (int i = 0; i < N; i++) {
        int j = (i + 1) % N;
        pm.AddEdge(i, j, 1.0 + (i % 7));
    }
    for (int i = 0; i < N; i++) {
        int j = (i + 3) % N;
        if (j != i) pm.AddEdge(i, j, 2.0 + (i % 5));
    }
    for (int i = 0; i < N; i++) {
        int j = (i + 7) % N;
        if (j != i) pm.AddEdge(i, j, 3.0 + (i % 3));
    }
    pm.options.verbose = false;
    pm.Solve();

    bool is_perfect = true;
    for (int i = 0; i < N; i++) {
        int j = pm.GetMatch(i);
        if (j < 0 || j >= N || j == i || pm.GetMatch(j) != i) {
            is_perfect = false;
            break;
        }
    }
    CHECK(is_perfect, "Test 5 (1000-node graph perfect matching)");
}

// Test 6: stress test with 33000 nodes (similar to actual mesh size)
void test6_stress_33k() {
    int N = 33000;  // similar to actual mesh: 29336 triangles + ghosts
    // Each node connects to ~6 neighbors (like a triangular mesh dual)
    std::vector<std::pair<int,int>> edges;
    std::vector<double> weights;
    for (int i = 0; i < N; i++) {
        for (int d : {1, 2, 3, 7, 13, 29}) {
            int j = (i + d) % N;
            if (j != i) {
                edges.push_back({i, j});
                weights.push_back(1.0 + (i % 10) * 0.1 + d * 0.01);
            }
        }
    }
    int E = edges.size();

    printf("  Building PerfectMatching(%d nodes, %d edges)...\n", N, E);
    PerfectMatching pm(N, E);
    for (int k = 0; k < E; k++) {
        pm.AddEdge(edges[k].first, edges[k].second, weights[k]);
    }
    pm.options.verbose = false;

    printf("  Solving...\n");
    clock_t t0 = clock();
    pm.Solve();
    clock_t t1 = clock();
    double elapsed = (double)(t1 - t0) / CLOCKS_PER_SEC;
    printf("  Solve time: %.3f sec\n", elapsed);

    bool is_perfect = true;
    for (int i = 0; i < N; i++) {
        int j = pm.GetMatch(i);
        if (j < 0 || j >= N || j == i || pm.GetMatch(j) != i) {
            is_perfect = false;
            break;
        }
    }
    CHECK(is_perfect, "Test 6 (33000-node stress test)");

    // Report timing
    if (is_perfect) {
        printf("  -> Estimated time for actual mesh: %.1f-%.1f sec\n",
            elapsed * 0.5, elapsed * 2.0);
    }
}

int main() {
    printf("=== Blossom V Patch Test ===\n");
    printf("sizeof(void*)    = %zu\n", sizeof(void*));
    printf("sizeof(uintptr_t) = %zu\n", sizeof(uintptr_t));
    printf("sizeof(unsigned long) = %zu\n", sizeof(unsigned long));
    printf("POINTER_TYPE matches void*? %s\n",
        (sizeof(void*) == sizeof(uintptr_t)) ? "YES" : "NO");

    test1_4cycle();
    test2_6nodes();
    test3_odd_throws();
    test4_bad_edge_throws();
    test5_larger();
    test6_stress_33k();

    printf("\n=== Summary: %d/%d tests passed ===\n", pass_count, test_count);
    if (pass_count == test_count) {
        printf("ALL TESTS PASSED.\n");
        return 0;
    } else {
        printf("SOME TESTS FAILED.\n");
        return 1;
    }
}
