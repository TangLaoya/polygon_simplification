function [start_idx, end_idx] = findLongestContinuousSegment(mask)
    mask = mask(:);
    if ~any(mask)
        start_idx = 1; end_idx = 1;
        return;
    end
    diff_mask = diff([0; mask; 0]);
    starts = find(diff_mask == 1);
    ends = find(diff_mask == -1) - 1;
    if isempty(starts)
        start_idx = 1; end_idx = 1;
        return;
    end
    lengths = ends - starts + 1;
    [~, idx] = max(lengths);
    start_idx = starts(idx);
    end_idx = ends(idx);
end

