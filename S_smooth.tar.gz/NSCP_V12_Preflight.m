function NSCP_V12_Preflight()
% Quick runtime checks for the complete NSCP V12 package.
clc;
fprintf('NSCP V12 preflight\n');
fprintf('==================\n');
assert(exist('Test_beforeFit.s26p','file')==2,'Test_beforeFit.s26p not found.');
M=ss_readTouchstone('Test_beforeFit.s26p');
f=M.Frequency.Vector;
S=M.S;
Z0=M.Network.ReferenceImpedance;
assert(numel(f)==153,'Unexpected frequency count.');
assert(size(S,2)==26 && size(S,3)==26,'Unexpected port count/layout.');
assert(abs(Z0-0.1)<1e-12,'Unexpected Touchstone Z0.');
[Sc,~,~,~]=ss_normalizeS3D(S,f);
[Y,~]=localY(Sc,Z0);
assert(all(isfinite(Y(:))),'Non-finite admittance values.');
[Z,R]=ss_s2z(Sc,Z0,f);
assert(all(isfinite(Z(:))),'Non-finite S->Z result.');
assert(all(isfinite(R.Condition)),'Non-finite condition report.');
fprintf('Input          : OK (153 x 26 x 26)\n');
fprintf('Reference Z0   : %.12g Ohm\n',Z0);
fprintf('S -> Y         : OK\n');
fprintf('S -> Z         : OK\n');
fprintf('Minimum RCOND  : %.6e\n',R.MinimumRCOND);
fprintf('Preflight      : PASS\n');
end
function [Y,CondPlus]=localY(S,Z0)
N=size(S,2); Nf=size(S,1); I=eye(N); Y=zeros(size(S)); CondPlus=zeros(Nf,1);
for k=1:Nf
 Sk=reshape(S(k,:,:),N,N); A=I+Sk; CondPlus(k)=1/max(rcond(A),eps);
 Y(k,:,:)=reshape((I-Sk)/Z0/A,N,N);
end
end
