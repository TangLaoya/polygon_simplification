function scl = getScale(unit)
    switch upper(unit)
        case 'HZ', scl=1;
        case 'KHZ', scl=1e3;
        case 'MHZ', scl=1e6;
        case 'GHZ', scl=1e9;
        otherwise, error('未知频率单位');
    end
end
