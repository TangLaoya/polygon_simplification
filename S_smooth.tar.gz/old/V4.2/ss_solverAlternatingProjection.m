function Runtime = ss_solverAlternatingProjection(Runtime, Problem, Engine)

maxIter = Runtime.Iteration.Max;
Network = Runtime.Network;

S0 = Network.Representation.S;   % 🔥 anchor（永远不动的参考）

for k = 1:maxIter

    Runtime.Iteration.Current = k;

    %=====================================
    % 1. stable projection (weak)
    %=====================================
    Network = ss_projectStableCayley(Network, Problem);

    %=====================================
    % 2. physics projection (Z only, no S distortion)
    %=====================================
    Network = ss_projectPhysics(Network, Problem);

    %=====================================
    % 3. measurement projection (SOFT, anchored to S0)
    %=====================================
    Network = ss_projectMeasurement(Network, Problem, S0);

    Runtime.Network = Network;

    Runtime = ss_computeResidual(Runtime, Problem);
    Runtime = ss_computeObjective(Runtime, Problem);

    Runtime = ss_checkConvergence(Runtime, Problem);
    %=====================================
    % v4.2 convergence (stability-based)
    %=====================================
    if k > 8

        dS = norm(Network.Representation.S(:) - S0(:)) / norm(S0(:));

        obj = Runtime.State.Objective.Total;

        if dS < 1e-3 && obj < 1e3
            Runtime.Convergence.State = "Converged";
            Runtime.Convergence.Finished = true;
            break;
        end

    end

    Runtime = ss_updateHistory(Runtime);

end

Runtime.Network = Network;

end