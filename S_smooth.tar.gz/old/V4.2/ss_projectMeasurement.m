function Network = ss_projectMeasurement(Network, Problem, S0)

if ~Network.Valid.S
    cfg = struct('Z0', Problem.Network.ReferenceImpedance, ...
                 'conditionLimit', 1e12, ...
                 'regularization', 1e-12);

    Network.Representation.S = ss_z2s(Network.Representation.Z, cfg);
end

S = Network.Representation.S;
Smeas = Problem.Measurement.S;

Nf = size(S,1);

% 🔥 v4.2：以 original S0 为 anchor
for k = 1:Nf

    Sk = squeeze(S(k,:,:));
    Sm = squeeze(Smeas(k,:,:));
    Sref = squeeze(S0(k,:,:));

    % ======================================
    % blend is now anchored (NOT drifting)
    % ======================================
    w1 = Problem.Reference.Confidence.Cm(k);
    w2 = 0.3;   % fixed stability anchor

    S(k,:,:) = (1 - w1 - w2)*Sk + w1*Sm + w2*Sref;

end

Network.Representation.S = S;
Network.Valid.S = true;
Network.Valid.Z = false;

end