function Network = ss_projectPhysics(Network, Problem)

if ~Network.Valid.Z
    cfg = struct('Z0', Problem.Network.ReferenceImpedance);
    Network.Representation.Z = ss_s2z(Network.Representation.S, cfg);
end

Z = Network.Representation.Z;
Nf = size(Z,1);

for k = 1:Nf

    Zk = squeeze(Z(k,:,:));

    % =========================
    % ONLY enforce physical consistency
    % NO smoothing across frequency
    % =========================

    Zk = (Zk + Zk')/2;

    % weak RLGC anchor (no distortion)
    if ~isempty(Problem.Physics.RLGC.R)
        Rref = Problem.Physics.RLGC.R(k);
        Zk = Zk + 0.01 * (Rref/size(Zk,1)) * eye(size(Zk));
    end

    Z(k,:,:) = Zk;

end

Network.Representation.Z = Z;
Network.Valid.Z = true;
Network.Valid.S = false;

end