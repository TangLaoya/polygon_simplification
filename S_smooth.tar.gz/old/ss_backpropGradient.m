function gradS = ss_backpropGradient(S,gradZ,cfg)
%===========================================================
%
% Back propagation
%
% dZ = 2*Z0*(I-S)^(-1)dS(I-S)^(-1)
%
% Therefore
%
% gradS
% =
% 2*Z0*(I-S)^(-H)
% gradZ
% (I-S)^(-H)
%
%===========================================================

Nf = size(S,1);

N = size(S,2);

gradS = zeros(size(S));

I = eye(N);

for k = 1:Nf

    Sk = squeeze(S(k,:,:));

    Gz = squeeze(gradZ(k,:,:));

    A = I - Sk;

    %% -------------------------------
    %% numerical stabilization
    %% -------------------------------

    rc = rcond(A);

    if isnan(rc) || rc < 1/cfg.conditionLimit

        epsReg = cfg.regularization * max(norm(A,'fro'),1);

        A = A + epsReg*I;

    end

    %% -------------------------------
    %% inverse
    %% -------------------------------

    IA = A \ I;

    %% -------------------------------
    %% back propagation
    %% -------------------------------

    Gs = 2*cfg.Z0 * (IA') * Gz * (IA');

    %% -------------------------------
    %% Hermitian correction
    %% -------------------------------

    if cfg.enforceHermitianGradient

        Gs = 0.5*(Gs + Gs');

    end

    gradS(k,:,:) = Gs;

end

end