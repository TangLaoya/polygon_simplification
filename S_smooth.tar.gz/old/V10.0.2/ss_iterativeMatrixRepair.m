function [Srepair,IterInfo] = ...
    ss_iterativeMatrixRepair( ...
    freq,...
    S,...
    Option)

%==============================================================
%
% NSCP V10.0
%
% Iterative Matrix Z Repair
%
% Detect
%   ->
% Repair
%   ->
% Detect
%
% Until Convergence
%
%==============================================================

if nargin<3
    Option=struct();
end

%%------------------------------------------------------------
%% Default
%%------------------------------------------------------------

if ~isfield(Option,'MaxIteration')
    Option.MaxIteration=5;
end

if ~isfield(Option,'ConvergenceTol')
    Option.ConvergenceTol=1e-6;
end

if ~isfield(Option,'InitialThreshold')
    Option.InitialThreshold=4.0;
end

if ~isfield(Option,'FinalThreshold')
    Option.FinalThreshold=3.0;
end

%%------------------------------------------------------------
%% Init
%%------------------------------------------------------------

Srepair=S;

IterInfo=struct();

IterInfo.History=[];

fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.0 Iterative Matrix Repair\n');
fprintf('========================================\n');

%%------------------------------------------------------------
%% Loop
%%------------------------------------------------------------

for iter=1:Option.MaxIteration

    fprintf('\n');

    fprintf('Iteration %d\n',iter);

    fprintf('----------------------------------------\n');

    %%--------------------------------------------------------
    %% Adaptive Threshold
    %%--------------------------------------------------------

    Threshold=max( ...
        Option.FinalThreshold,...
        Option.InitialThreshold ...
        -0.5*(iter-1));

    DetectOption=struct();

    DetectOption.Threshold=Threshold;

    %%--------------------------------------------------------
    %% Detect
    %%--------------------------------------------------------

    JumpReport=...
        ss_detectMatrixZJump( ...
        freq,...
        Srepair,...
        DetectOption);

    JumpNumber=JumpReport.JumpNumber;

    %%--------------------------------------------------------
    %% Convergence 1
    %%--------------------------------------------------------

    if JumpNumber==0

        fprintf('\n');
        fprintf('No jump detected.\n');

        break;

    end

    %%--------------------------------------------------------
    %% Repair
    %%--------------------------------------------------------

    Sold=Srepair;

    [Srepair,...
     RepairReport]=...
     ss_repairMatrixSByJump( ...
        freq,...
        Srepair,...
        JumpReport);

    %%--------------------------------------------------------
    %% Delta
    %%--------------------------------------------------------

    Delta=...
        norm(Srepair(:)-Sold(:))...
        /(norm(Sold(:))+eps);

    fprintf('Delta : %.6e\n',Delta);

    %%--------------------------------------------------------
    %% History
    %%--------------------------------------------------------

    H.Iteration=iter;

    H.JumpNumber=JumpNumber;

    H.Delta=Delta;

    H.Threshold=Threshold;

    IterInfo.History=[ ...
        IterInfo.History ; H ];

    %%--------------------------------------------------------
    %% Convergence 2
    %%--------------------------------------------------------

    if Delta<Option.ConvergenceTol

        fprintf('\n');
        fprintf('Converged by Delta.\n');

        break;

    end

end

%%------------------------------------------------------------
%% Summary
%%------------------------------------------------------------

fprintf('\n');

fprintf('========================================\n');

fprintf(' Iterative Repair Finished\n');

fprintf('========================================\n');

fprintf('Total Iterations : %d\n', ...
    length(IterInfo.History));

fprintf('========================================\n');

end