function s_parameter_smoothing_causal()
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

clc; clear;

fprintf('\n');
fprintf('==============================================================\n');
fprintf('              NSCP v4.0 Final Freeze\n');
fprintf('     Network S-Parameter Causal Projection Framework\n');
fprintf('==============================================================\n\n');

%% Select Input File
% [fileName,filePath] = uigetfile( ...
%     {'*.s*p','Touchstone (*.s*p)'}, ...
%     'Select Touchstone File');
% 
% if isequal(fileName,0)
%     fprintf('Operation cancelled.\n');
%     return;
% end
% 
% inputFile = fullfile(filePath,fileName);
filePath='';
inputFile = 'Test_beforeFit.s26p';

fprintf('Input File : %s\n',inputFile);

%% Read Touchstone
[freq, S, params] = readSnP_simple(inputFile);
Measurement.freq = freq;
Measurement.FrequencyNumber = numel(freq);
Measurement.S = S;
Measurement.Params = params;
Measurement.PortNumber = size(S,3);
Measurement.Z0 = 50;

fprintf('Frequency Points : %d\n',Measurement.FrequencyNumber);
fprintf('Port Number      : %d\n',Measurement.PortNumber);

%% Build Default Options
Option = ss_defaultOption();

%% Run NSCP
Result = ss_runNSCP(Measurement, Option);

%% Output File
[pathstr,name,~] = fileparts(inputFile);
outputFile = fullfile(pathstr, [name '_NSCP.s' num2str(Measurement.PortNumber) 'p']);

fprintf('\n');
fprintf('Writing output file...\n');

% 修正调用顺序：filename, freq, S, params
writeSnP_simple(outputFile, Measurement.freq, Result.Network.Representation.S, Measurement.Params);

fprintf('Done.\n');
fprintf('Output : %s\n',outputFile);

fprintf('\n');
fprintf('==============================================================\n');
fprintf('NSCP finished successfully.\n');
fprintf('==============================================================\n');

end
