function Problem = ss_analyseNetwork(Problem, Network)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

S = Network.Representation.S;          % [Nf, Nport, Nport]
freq = Problem.Frequency.Vector;
Nf = Problem.Frequency.Number;

Analysis = struct();
Analysis.ConditionNumber = zeros(Nf,1);
Analysis.StabilityIndex   = zeros(Nf,1);
Analysis.SingularValueMax = zeros(Nf,1);
Analysis.SingularValueMin = zeros(Nf,1);

for k = 1:Nf
    Sk = squeeze(S(k,:,:));            % 提取二维矩阵
    sv = svd(Sk);
    Analysis.SingularValueMax(k) = max(sv);
    Analysis.SingularValueMin(k) = min(sv);
    Analysis.ConditionNumber(k) = ...
        Analysis.SingularValueMax(k) / max(Analysis.SingularValueMin(k), eps);
    Analysis.StabilityIndex(k) = log(Analysis.ConditionNumber(k) + 1);
end

cond = Analysis.ConditionNumber;
Analysis.LowFreqRegion  = find(freq < 0.2 * max(freq));
Analysis.HighFreqRegion = find(freq > 0.8 * max(freq));
Analysis.MidFreqRegion  = setdiff(1:Nf, ...
                                [Analysis.LowFreqRegion; Analysis.HighFreqRegion]);
Analysis.FrequencyRiskMap = normalize(cond, 'range');

Problem.Analysis = Analysis;
end