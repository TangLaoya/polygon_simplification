function Network = ss_projectPhysics(Network, Problem)

if ~Network.Valid.Z
    cfg = struct('Z0', Problem.Network.ReferenceImpedance);
    Network.Representation.Z = ss_s2z(Network.Representation.S, cfg);
end

Z = Network.Representation.Z;
Nf = size(Z,1);

for k = 1:Nf

    Zk = squeeze(Z(k,:,:));

    % =========================
    % 1. Hermitian projection (strict, not soft)
    % =========================
    Zk = (Zk + Zk')/2;

    % =========================
    % 2. RLGC constraint (projection not blending)
    % =========================
    if ~isempty(Problem.Physics.RLGC.R)
        Rref = Problem.Physics.RLGC.R(k);

        H = real(Zk);

        % ❗ projection to constraint manifold
        H = diag(diag(H));
        H = H + (Rref/size(H,1))*eye(size(H));

        Zk = H + 1i*imag(Zk);
    end

    Z(k,:,:) = Zk;

end

Network.Representation.Z = Z;
Network.Valid.Z = true;
Network.Valid.S = false;

end