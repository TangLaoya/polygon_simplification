function Runtime = ss_computeResidual(Runtime, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

Network = Runtime.Network;
S = Network.Representation.S;          % [Nf, Nport, Nport]
Smeas = Problem.Measurement.S;         % [Nf, Nport, Nport]
Physics = Problem.Physics;
freq = Problem.Frequency.Vector;
Nf = Problem.Frequency.Number;

StabRes = zeros(Nf,1);
PhysRes = zeros(Nf,1);
MeasRes = zeros(Nf,1);

for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Sm = squeeze(Smeas(k,:,:));

    % Stability residual (passivity violation)
    eigvals = eig(Sk'*Sk);
    StabRes(k) = max(0, max(real(eigvals)) - 1);

    % Physics residual (RLGC consistency)
    if ~isempty(Physics.RLGC.R)
        Rref = Physics.RLGC.R(k);
        Zk = (eye(size(Sk)) + Sk) \ (eye(size(Sk)) - Sk);
        Rk = real(trace(Zk));
        PhysRes(k) = abs(Rk - Rref) / (abs(Rref) + eps);
    else
        PhysRes(k) = 0;
    end

    % Measurement residual
    MeasRes(k) = norm(Sk - Sm, 'fro');
end

ws = 0.3; wp = 0.3; wm = 0.4;
TotalRes = ws*StabRes + wp*PhysRes + wm*MeasRes;
FreqMap = normalize(TotalRes,'range');

Runtime.State.Residual = struct();
Runtime.State.Residual.StabilityResidual = StabRes;
Runtime.State.Residual.PhysicsResidual = PhysRes;
Runtime.State.Residual.MeasurementResidual = MeasRes;
Runtime.State.Residual.TotalResidual = TotalRes;
Runtime.State.Residual.FrequencyResidualMap = FreqMap;
end