function [Network, Data] = ss_getRepresentation(Network, Name, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Unified Representation Manager
%==========================================================================

arguments
    Network struct
    Name    char
    Problem struct
end

switch upper(Name)
    case 'S'
        if ~Network.Valid.S
            % 尝试从 Z 生成 S
            if Network.Valid.Z && ~isempty(Network.Representation.Z)
                cfg = struct('Z0', Problem.Network.ReferenceImpedance, ...
                             'conditionLimit', 1e12, ...
                             'regularization', 1e-12);
                Network.Representation.S = ss_z2s(Network.Representation.Z, cfg);
                Network.Valid.S = true;
            else
                error('No valid representation available to generate S.');
            end
        end
        Data = Network.Representation.S;

    case 'Z'
        if ~Network.Valid.Z
            % 尝试从 S 生成 Z
            if Network.Valid.S && ~isempty(Network.Representation.S)
                cfg = struct('Z0', Problem.Network.ReferenceImpedance);
                Network.Representation.Z = ss_s2z(Network.Representation.S, cfg);
                Network.Valid.Z = true;
            else
                error('No valid representation available to generate Z.');
            end
        end
        Data = Network.Representation.Z;

    otherwise
        error("Unsupported representation: %s", Name);
end

end