function Runtime = ss_checkConvergence(Runtime, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Convergence controller
%==========================================================================

Solver = Problem.Option.Solver;
TolObjective = Solver.ObjectiveTolerance;
TolRelative  = Solver.RelativeTolerance;
PlateauLimit = Solver.PlateauIteration;

CurrentIter = Runtime.Iteration.Current;
MaxIter     = Runtime.Iteration.Max;
Objective = Runtime.State.Objective.Total;

% 确保 Convergence 结构及子字段存在
if ~isfield(Runtime, 'Convergence')
    Runtime.Convergence = struct();
end
if ~isfield(Runtime.Convergence, 'PreviousObjective')
    Runtime.Convergence.PreviousObjective = inf;
end
if ~isfield(Runtime.Convergence, 'PlateauCounter')
    Runtime.Convergence.PlateauCounter = 0;
end

Prev = Runtime.Convergence.PreviousObjective;

Delta = Prev - Objective;
Relative = Delta / max(abs(Prev), eps);

State = "Running";
Finished = false;

% 数值失效
if isnan(Objective) || isinf(Objective)
    State = "NumericalFailure";
    Finished = true;
end

% 目标容差
if ~Finished && Objective < TolObjective
    State = "Converged";
    Finished = true;
end

% 相对改进
if ~Finished
    if Relative < TolRelative
        Runtime.Convergence.PlateauCounter = Runtime.Convergence.PlateauCounter + 1;
    else
        Runtime.Convergence.PlateauCounter = 0;
    end
end

% 平台检测
if ~Finished && Runtime.Convergence.PlateauCounter >= PlateauLimit
    State = "Plateau";
    Finished = true;
end

% 最大迭代
if ~Finished && CurrentIter >= MaxIter
    State = "MaximumIteration";
    Finished = true;
end

% 发散检测
if ~Finished && Objective > Prev * 5
    State = "Diverged";
    Finished = true;
end

% 存储结果
Runtime.Convergence.State = State;
Runtime.Convergence.Finished = Finished;
Runtime.Convergence.Iteration = CurrentIter;
Runtime.Convergence.Objective = Objective;
Runtime.Convergence.PreviousObjective = Objective;
Runtime.Convergence.DeltaObjective = Delta;
Runtime.Convergence.RelativeImprovement = Relative;

Runtime.Flag.Converged = strcmp(State, "Converged");
Runtime.Flag.Diverged = any(strcmp(State, ["Diverged", "NumericalFailure"]));

end