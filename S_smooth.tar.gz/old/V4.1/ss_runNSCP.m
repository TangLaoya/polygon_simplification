function Result = ss_runNSCP(Measurement, Option)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

%% Build Problem
Problem = ss_buildProblem(Measurement, Option);

%% Initialize Network (initial S from measurement)
Network = ss_initializeNetwork(Problem);

%% Pre-analysis: spectral and physical characterization
Problem = ss_analyseNetwork(Problem, Network);
Problem = ss_buildPhysicsModel(Problem, Network);
Problem = ss_buildReferenceModel(Problem, Network);   % uses Problem.Analysis

%% Build Engine (simple dispatch structure)
Engine = struct();
Engine.Algorithm  = "AlternatingProjection";
Engine.Name       = "NSCP Solver";
Engine.Version    = "4.0 Final Freeze";
Engine.Description = "Alternating Projection Solver";

%% Initialize Runtime
Runtime = ss_initializeRuntime(Problem);
Runtime.Network = Network;

%% Execute Solver
Runtime = ss_executeEngine(Runtime, Problem, Engine);

%% Finalize Result
[Network, Summary] = ss_finalizeSolution(Runtime, Problem);

%% Package Result
Result.Network  = Network;
Result.Summary  = Summary;
Result.Problem  = Problem;

end