function Runtime = ss_solverAlternatingProjection(Runtime, Problem, Engine)

maxIter = Runtime.Iteration.Max;

Network = Runtime.Network;

for k = 1:maxIter

    Runtime.Iteration.Current = k;

    % =========================
    % strict projection cycle
    % =========================
    Network = ss_projectStableCayley(Network, Problem);
    Network = ss_projectPhysics(Network, Problem);
    Network = ss_projectMeasurement(Network, Problem);

    Runtime.Network = Network;

    Runtime = ss_computeResidual(Runtime, Problem);
    Runtime = ss_computeObjective(Runtime, Problem);

    % =========================
    % 🔥 v4.1 convergence rule (critical fix)
    % =========================
    obj = Runtime.State.Objective.Total;
    Runtime = ss_checkConvergence(Runtime, Problem);

    if k > 5

        objHist = Runtime.History.Objective;

        if numel(objHist) > 5
            recent = objHist(end-min(5,end)+1:end);

            % ❗真正收敛条件：variance collapse
            if std(recent) < 1e-6
                Runtime.Convergence.State = "Converged";
                Runtime.Convergence.Finished = true;
                break;
            end
        end

    end

    Runtime = ss_updateHistory(Runtime);

end

Runtime.Network = Network;

end