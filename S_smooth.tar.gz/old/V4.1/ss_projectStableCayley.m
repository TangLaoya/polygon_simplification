function Network = ss_projectStableCayley(Network, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Stable projection (Z-domain)
%==========================================================================

% 确保 Z 存在
if ~Network.Valid.Z
    if Network.Valid.S
        cfg = struct('Z0', Problem.Network.ReferenceImpedance);
        Network.Representation.Z = ss_s2z(Network.Representation.S, cfg);
        Network.Valid.Z = true;
        Network.Valid.S = true;   % S 仍有效（源）
    else
        error('No valid S to generate Z.');
    end
end

Z = Network.Representation.Z;
Nf = size(Z,1);

for k = 1:Nf
    Zk = squeeze(Z(k,:,:));
    H = (Zk + Zk')/2;
    [V,D] = eig(H);
    d = real(diag(D));
    d(d<0) = 0;
    H = V*diag(d)*V';
    A = (Zk - Zk')/2;
    Z(k,:,:) = H + A;
end

Network.Representation.Z = Z;
Network.Valid.Z = true;
Network.Valid.S = false;   % S 已过时（依赖 Z）

end