function Problem = ss_buildPhysicsModel(Problem, Network)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

freq = Problem.Frequency.Vector;
Nf   = Problem.Frequency.Number;
S    = Network.Representation.S;      % [Nf, Nport, Nport]
Z0   = Problem.Network.ReferenceImpedance;

Physics = struct();
Physics.RLGC = struct();
Physics.RLGC.R = zeros(Nf,1);
Physics.RLGC.L = zeros(Nf,1);

for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Zk = (eye(size(Sk)) + Sk) \ (eye(size(Sk)) - Sk) * Z0;
    Physics.RLGC.R(k) = real(trace(Zk));
    Physics.RLGC.L(k) = imag(trace(Zk)) / max(2*pi*freq(k), eps);
end

Physics.Passivity.Energy = zeros(Nf,1);
for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Physics.Passivity.Energy(k) = max(abs(eig(Sk'*Sk)));
end

Physics.Causality.Smoothness = zeros(Nf,1);
for k = 2:Nf
    dS = squeeze(S(k,:,:)) - squeeze(S(k-1,:,:));
    Physics.Causality.Smoothness(k) = norm(dS,'fro');
end

Physics.Operator.Project = @(Sinput) physics_projection_stub(Sinput);
Physics.Constraint.Energy = Physics.Passivity.Energy;
Physics.Constraint.Stability = Physics.Causality.Smoothness;

Problem.Physics = Physics;
end

function Sout = physics_projection_stub(Sin)
Sout = Sin;
end