function Network = ss_initializeNetwork(Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Initialize runtime network
%==========================================================================

Network = struct();

Network.Meta = struct();
Network.Meta.PortNumber = Problem.Network.PortNumber;
Network.Meta.FrequencyNumber = Problem.Dimension.Frequency;
Network.Meta.Z0 = Problem.Network.ReferenceImpedance;

Network.Representation = struct();
Network.Representation.S = Problem.Measurement.S;   % [Nf, Nport, Nport]
Network.Representation.Z = [];

Network.Valid = struct();
Network.Valid.S = true;      % 初始 S 有效
Network.Valid.Z = false;     % Z 尚未生成

Network.Iteration = 0;
Network.Modified = false;

end