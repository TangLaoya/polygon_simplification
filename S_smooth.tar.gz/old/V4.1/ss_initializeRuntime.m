function Runtime = ss_initializeRuntime(Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Initialize Runtime
%==========================================================================

Runtime = struct();

Runtime.Iteration = struct();
Runtime.Iteration.Current = 0;
Runtime.Iteration.Max = Problem.Option.Solver.MaximumIteration;

Runtime.State = struct();
Runtime.State.Residual = [];
Runtime.State.Objective = [];

Runtime.Convergence = struct();   % 预创建，防止后续访问报错

Runtime.History = struct();
Runtime.History.Iteration = [];
Runtime.History.Objective = [];
Runtime.History.Residual = [];
Runtime.History.State = strings(0);
Runtime.History.SNorm = [];
Runtime.History.ZNorm = [];
Runtime.History.TimeStamp = datetime.empty;

Runtime.Flag = struct();
Runtime.Flag.Converged = false;
Runtime.Flag.Diverged = false;

Runtime.Log = struct();
Runtime.Log.Verbose = Problem.Option.Debug.Verbose;
Runtime.Log.Messages = strings(0);

Runtime.Problem = Problem;      % 只读引用
Runtime.Network = [];

Runtime.Summary = struct();
Runtime.Summary.Initialized = true;
Runtime.Summary.TimeStart = datetime("now");

end