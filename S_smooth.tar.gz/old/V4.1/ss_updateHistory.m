function Runtime = ss_updateHistory(Runtime)
%==========================================================================
% NSCP v4.0 Final Freeze – Solver history tracking
%==========================================================================

% 确保 History 结构完整
if ~isfield(Runtime, 'History') || isempty(Runtime.History)
    Runtime.History = struct();
    Runtime.History.Iteration = [];
    Runtime.History.Objective = [];
    Runtime.History.Residual = [];
    Runtime.History.State = strings(0);
    Runtime.History.SNorm = [];
    Runtime.History.ZNorm = [];
    Runtime.History.TimeStamp = datetime.empty;
end

iter = Runtime.Iteration.Current;
obj  = Runtime.State.Objective.Total;

% 将残差向量转换为标量（L2范数）
resVec = Runtime.State.Residual.TotalResidual;
res = norm(resVec);   % 存储总残差的范数

state = string(Runtime.Convergence.State);

% 网络范数（诊断用）
Network = Runtime.Network;
S = Network.Representation.S;
S_norm = norm(S(:),2);

Z = [];
try
    Z = Network.Representation.Z;
catch
    Z = [];
end
Z_norm = nan;
if ~isempty(Z)
    Z_norm = norm(Z(:),2);
end

% 追加历史
Runtime.History.Iteration(end+1,1) = iter;
Runtime.History.Objective(end+1,1) = obj;
Runtime.History.Residual(end+1,1) = res;
Runtime.History.State(end+1,1) = state;
Runtime.History.SNorm(end+1,1) = S_norm;
Runtime.History.ZNorm(end+1,1) = Z_norm;
Runtime.History.TimeStamp(end+1,1) = datetime("now");

% 可选：裁剪过长历史
maxHist = 5000;
if numel(Runtime.History.Iteration) > maxHist
    Runtime.History.Iteration(1) = [];
    Runtime.History.Objective(1) = [];
    Runtime.History.Residual(1) = [];
    Runtime.History.State(1) = [];
    Runtime.History.SNorm(1) = [];
    Runtime.History.ZNorm(1) = [];
    Runtime.History.TimeStamp(1) = [];
end

end