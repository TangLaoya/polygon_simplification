function Network = ss_projectMeasurement(Network, Problem)

if ~Network.Valid.S
    cfg = struct('Z0', Problem.Network.ReferenceImpedance, ...
                 'conditionLimit', 1e12, ...
                 'regularization', 1e-12);

    Network.Representation.S = ss_z2s(Network.Representation.Z, cfg);
end

S = Network.Representation.S;
Smeas = Problem.Measurement.S;

Nf = size(S,1);

% 🔥 v4.1：自适应约束强度（不是混合）
for k = 1:Nf

    Sk = squeeze(S(k,:,:));
    Sm = squeeze(Smeas(k,:,:));

    % =========================
    % 关键变化：projection residual correction
    % =========================
    E = Sk - Sm;

    % 🔥 只纠正“低频结构误差”，避免破坏真实结构
    w = Problem.Reference.Confidence.Cm(k);

    % Fejér-like correction
    S(k,:,:) = Sk - w * E;

end

Network.Representation.S = S;
Network.Valid.S = true;
Network.Valid.Z = false;

end