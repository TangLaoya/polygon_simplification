function Z = ss_s2z(S, cfg)
% Convert S-parameters to Z-parameters
% S: [Nf, Nport, Nport], cfg.Z0
Z0 = cfg.Z0;
Nf = size(S,1);
N = size(S,2);
I = eye(N);
Z = zeros(size(S));

for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Zk = Z0 * (I + Sk) / (I - Sk);   % (I+S)*inv(I-S)
    Z(k,:,:) = Zk;
end

end