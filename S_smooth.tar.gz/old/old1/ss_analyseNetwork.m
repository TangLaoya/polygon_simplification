function Analysis = ss_analyseNetwork(Measurement, Network, Option)
%==========================================================================
%
% NSCP v4.0 Final
%
% File:
%   ss_analyseNetwork.m
%
% Description
% -------------------------------------------------------------------------
% Analyse the current optimization network.
%
% This function performs NO optimization.
%
% It evaluates the numerical and physical characteristics of the
% current network.
%
%==========================================================================

%% ------------------------------------------------------------------------
%% Basic Information
%% ------------------------------------------------------------------------

Analysis = struct();

Analysis.Iteration = Network.Iteration;

Analysis.TimeStamp = datetime('now');

%% ------------------------------------------------------------------------
%% Dimension
%% ------------------------------------------------------------------------

Analysis.Dimension.nPort = Network.nPort;

Analysis.Dimension.nFreq = Network.nFreq;

%% ------------------------------------------------------------------------
%% Numerical Stability
%% ------------------------------------------------------------------------

Analysis.Numerical = ...
    ss_estimateReferenceCondition( ...
        Network, ...
        Option);

%% ------------------------------------------------------------------------
%% Reference Region Detection
%% ------------------------------------------------------------------------

Analysis.ReferenceRegion = ...
    ss_detectReferenceRegion( ...
        Measurement,...
        Network,...
        Option);

%% ------------------------------------------------------------------------
%% Element-wise Physical Analysis
%% ------------------------------------------------------------------------

Analysis.Element = ...
    ss_analyseReferenceElement( ...
        Measurement,...
        Network,...
        Analysis.ReferenceRegion,...
        Option);

%% ------------------------------------------------------------------------
%% Global Physics Analysis
%% ------------------------------------------------------------------------

Analysis.Physics = ...
    ss_analysePhysics( ...
        Measurement,...
        Network,...
        Analysis.Element,...
        Option);

%% ------------------------------------------------------------------------
%% Confidence
%% ------------------------------------------------------------------------

Analysis.Confidence = ...
    ss_estimateReferenceConfidence( ...
        Analysis,...
        Option);

%% ------------------------------------------------------------------------
%% Summary
%% ------------------------------------------------------------------------

Analysis.Status = "Ready";

end