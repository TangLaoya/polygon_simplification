function Problem = ss_buildProblem(Measurement, Option)
%==========================================================================
%
% NSCP v4.0 Final
%
% File:
%   ss_buildProblem.m
%
% Description
% -------------------------------------------------------------------------
% Construct the complete optimization problem.
%
% This function is the only constructor of Problem.
%
% Responsibilities
% -------------------------------------------------------------------------
%   1. Initialize optimization network
%   2. Perform numerical analysis
%   3. Build reference model
%   4. Assemble Problem object
%
% NOTE
% -------------------------------------------------------------------------
% No optimization is performed here.
%
%==========================================================================

%% ========================================================================
%% Initialize optimization variables
%% ========================================================================

Network = ss_initializeNetwork( ...
                Measurement, ...
                Option);

%% ========================================================================
%% Numerical analysis
%% ========================================================================

Analysis = ss_initializeAnalysis( ...
                    Measurement, ...
                    Network, ...
                    Option);

%% ========================================================================
%% Build reference model
%% ========================================================================

Reference = ss_buildReferenceModel( ...
                    Measurement, ...
                    Network, ...
                    Analysis, ...
                    Option);

%% ========================================================================
%% Assemble Problem
%% ========================================================================

Problem = struct();

Problem.Measurement = Measurement;

Problem.Network = Network;

Problem.Analysis = Analysis;

Problem.Reference = Reference;

Problem.Option = Option;

%% ========================================================================
%% Dimension information
%% ========================================================================

Problem.Dimension.nPort = Network.nPort;

Problem.Dimension.nFreq = Network.nFreq;

Problem.Dimension.MatrixSize = ...
    [Network.nPort Network.nPort];

%% ========================================================================
%% Runtime cache
%% ========================================================================

Problem.Cache = struct();

Problem.Cache.Initialized = true;

Problem.Cache.Iteration = 0;

Problem.Cache.Timestamp = datetime('now');

end