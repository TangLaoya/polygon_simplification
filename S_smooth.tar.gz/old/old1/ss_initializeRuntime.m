function Runtime = ss_initializeRuntime(Problem)
%==========================================================================
%
% NSCP v4.0 Final
%
% File:
%   ss_initializeRuntime.m
%
% Description
% -------------------------------------------------------------------------
% Initialize the mutable runtime object.
%
% Problem and Engine are immutable.
%
% Runtime contains every quantity that changes during optimization.
%
%==========================================================================

%% ========================================================================
%% Initialize
%% ========================================================================

Runtime = struct();

%% ========================================================================
%% Iteration
%% ========================================================================

Runtime.Iteration = 0;

%% ========================================================================
%% Optimization Variable
%% ========================================================================

Runtime.Network = Problem.State.Network;

%% ========================================================================
%% Initial Analysis
%% ========================================================================

Runtime.Analysis = Problem.Analysis;

%% ========================================================================
%% Optimization State
%% ========================================================================

Runtime.State = struct();

Runtime.State.Objective = inf;

Runtime.State.Residual.Total = inf;

Runtime.State.Residual.Stability = inf;

Runtime.State.Residual.Physics = inf;

Runtime.State.Residual.Measurement = inf;

Runtime.State.StepLength = 1.0;

Runtime.State.RelativeChange = inf;

Runtime.State.ProjectionError = inf;

%% ========================================================================
%% History
%% ========================================================================

Runtime.History = struct();

Runtime.History.Objective = [];

Runtime.History.Residual = [];

Runtime.History.StepLength = [];

Runtime.History.ConditionNumber = [];

Runtime.History.RelativeChange = [];

%% ========================================================================
%% Cache
%% ========================================================================

Runtime.Cache = struct();

Runtime.Cache.LastObjective = inf;

Runtime.Cache.LastResidual = inf;

Runtime.Cache.LastNetwork = [];

%% ========================================================================
%% Status
%% ========================================================================

Runtime.Status = struct();

Runtime.Status.Converged = false;

Runtime.Status.StopReason = "";

Runtime.Status.Success = false;

%% ========================================================================
%% Meta
%% ========================================================================

Runtime.Meta.Created = datetime('now');

Runtime.Meta.Version = Problem.Option.Project.Version;

end