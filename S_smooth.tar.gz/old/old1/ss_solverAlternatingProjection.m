function Runtime = ss_solverAlternatingProjection( ...
                    Runtime,...
                    Problem,...
                    Engine)
%==========================================================================
%
% NSCP v4.0 Final Frozen
%
% File:
%   ss_solverAlternatingProjection.m
%
% Description
% -------------------------------------------------------------------------
% One iteration of Alternating Projection.
%
% This file contains NO mathematical implementation.
% It only orchestrates the optimization workflow.
%
%==========================================================================

%% ========================================================================
%% Save previous optimization variable
%% ========================================================================

PreviousNetwork = Runtime.Network;

%% ========================================================================
%% Projection 1
%% Stable Cayley Projection
%% ========================================================================

Runtime = ss_projectStableCayley( ...
                Runtime,...
                Problem,...
                Engine);

%% ========================================================================
%% Projection 2
%% Physics Projection
%% ========================================================================

Runtime = ss_projectPhysics( ...
                Runtime,...
                Problem,...
                Engine);

%% ========================================================================
%% Projection 3
%% Measurement Projection
%% ========================================================================

Runtime = ss_projectMeasurement( ...
                Runtime,...
                Problem,...
                Engine);

%% ========================================================================
%% Objective Evaluation
%% ========================================================================

Runtime = ss_computeObjective( ...
                Runtime,...
                PreviousNetwork,...
                Problem,...
                Engine);

%% ========================================================================
%% Update Iteration Counter
%% ========================================================================

Runtime.Iteration = Runtime.Iteration + 1;

end