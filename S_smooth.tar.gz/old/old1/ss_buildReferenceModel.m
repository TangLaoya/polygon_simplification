function Reference = ss_buildReferenceModel( ...
                        Measurement,...
                        Network,...
                        Analysis,...
                        Option)
%==========================================================================
%
% NSCP v4.0 Final
%
% File:
%   ss_buildReferenceModel.m
%
% Description
% -------------------------------------------------------------------------
% Construct an immutable physics reference model from the numerically
% stable frequency region.
%
% The reference model is built only once before optimization.
%
%==========================================================================

%% ========================================================================
%% Initialize
%% ========================================================================

Reference = struct();

%% ========================================================================
%% Reference Region
%% ========================================================================

Reference.Region = Analysis.ReferenceRegion;

%% ========================================================================
%% Build Reference Impedance
%% ========================================================================

Reference.ZReference = ...
    ss_buildPhysicsTarget( ...
        Measurement,...
        Network,...
        Analysis,...
        Option);

%% ========================================================================
%% Distributed Physics Model
%% ========================================================================

Reference.Model = ...
    ss_buildDistributedModel( ...
        Reference.ZReference,...
        Analysis,...
        Option);

%% ========================================================================
%% Weight
%% ========================================================================

Reference.Weight = ...
    ss_buildReferenceWeight( ...
        Analysis,...
        Option);

%% ========================================================================
%% Confidence
%% ========================================================================

Reference.Confidence = ...
    Analysis.Confidence;

%% ========================================================================
%% Meta Information
%% ========================================================================

Reference.Meta.Type = ...
    Option.Problem.Physics.ReferenceModel;

Reference.Meta.Created = datetime('now');

Reference.Meta.Version = ...
    Option.Project.Version;

end