function Runtime = ss_projectReference( ...
                        Runtime,...
                        Problem,...
                        Engine)
%==========================================================================
%
% NSCP v4.0 Final Frozen
%
% Reference Projection
%
% Project the current network toward the immutable reference model.
%
%==========================================================================

Network = Runtime.Network;

%% ------------------------------------------------------------------------
%% Ensure Z Representation
%% ------------------------------------------------------------------------

if ~Network.Valid.Z

    Network.Representation.Z = ...
        ss_s2z( ...
            Network.Representation.S,...
            Problem.Option.Network.Z0);

    Network.Valid.Z = true;

end

%% ------------------------------------------------------------------------
%% Obtain Reference Model
%% ------------------------------------------------------------------------

ReferenceModel = Problem.Reference.Model;

%% ------------------------------------------------------------------------
%% Evaluate Reference
%% ------------------------------------------------------------------------

Zref = ss_evaluateReferenceModel( ...
            ReferenceModel,...
            Problem.Measurement.freq);

%% ------------------------------------------------------------------------
%% Projection
%% ------------------------------------------------------------------------

Network.Representation.Z = ...
    ss_referenceProjection( ...
        Network.Representation.Z,...
        Zref,...
        Problem.Option);

%% ------------------------------------------------------------------------
%% Invalidate dependent representations
%% ------------------------------------------------------------------------

Network.Valid.S      = false;
Network.Valid.Y      = false;
Network.Valid.ABCD   = false;
Network.Valid.Cayley = false;
Network.Valid.RLGC   = false;

Runtime.Network = Network;

end