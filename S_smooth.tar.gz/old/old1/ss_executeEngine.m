function Result = ss_executeEngine(Engine, Problem)
%==========================================================================
%
% NSCP v4.0 Final
%
% File:
%   ss_executeEngine.m
%
% Description
% -------------------------------------------------------------------------
% Execute the optimization engine.
%
% Design Philosophy
% -------------------------------------------------------------------------
% Problem : Immutable
% Engine  : Immutable
% Runtime : Mutable
%
%==========================================================================

%% ========================================================================
%% Initialize Runtime
%% ========================================================================

Runtime = ss_initializeRuntime(Problem);

%% ========================================================================
%% Main Iteration
%% ========================================================================

while ~Runtime.Status.Converged

    %% ------------------------------------------------------------
    %% Execute one solver iteration
    %% ------------------------------------------------------------

    Runtime = ss_solverAlternatingProjection( ...
                    Runtime,...
                    Problem,...
                    Engine);

    %% ------------------------------------------------------------
    %% Re-analyse current network
    %% ------------------------------------------------------------

    Runtime.Analysis = ...
        ss_analyseNetwork( ...
            Problem.Measurement,...
            Runtime.Network,...
            Problem.Option);

    %% ------------------------------------------------------------
    %% Check convergence
    %% ------------------------------------------------------------

    Runtime = ss_checkConvergence( ...
                    Runtime,...
                    Problem,...
                    Engine);

    %% ------------------------------------------------------------
    %% Update history
    %% ------------------------------------------------------------

    Runtime = ss_updateHistory( ...
                    Runtime);

    %% ------------------------------------------------------------
    %% Maximum iteration
    %% ------------------------------------------------------------

    if Runtime.Iteration >= ...
            Problem.Option.Engine.Optimizer.MaxIteration

        Runtime.Status.Converged = false;

        Runtime.Status.StopReason = ...
            "MaximumIteration";

        break;

    end

end

%% ========================================================================
%% Finalize Result
%% ========================================================================

Result = ss_finalizeResult( ...
                Runtime,...
                Problem,...
                Engine);

end