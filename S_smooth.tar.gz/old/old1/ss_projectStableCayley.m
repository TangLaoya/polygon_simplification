function Runtime = ss_projectStableCayley( ...
                    Runtime,...
                    Problem,...
                    Engine)
%==========================================================================
% NSCP v4.0
%
% Stable Cayley Projection
%
% Numerical stabilization is performed in the impedance domain.
%
%==========================================================================

Network = Runtime.Network;

%% ------------------------------------------------------------
%% Ensure impedance representation exists
%% ------------------------------------------------------------

if ~Network.DomainValid.Z

    Network.Z = ss_s2z( ...
        Network.S,...
        Problem.Option.Network.Z0);

    Network.DomainValid.Z = true;
end

%% ------------------------------------------------------------
%% Eigen-spectrum stabilization
%% ------------------------------------------------------------

Network.Z = ss_projectEigenSpectrum( ...
    Network.Z,...
    Problem);

%% ------------------------------------------------------------
%% Condition-number stabilization
%% ------------------------------------------------------------

Network.Z = ss_projectCondition( ...
    Network.Z,...
    Problem);

%% ------------------------------------------------------------
%% Symmetry stabilization
%% ------------------------------------------------------------

if Problem.Option.Stability.EnforceSymmetry

    Network.Z = ss_projectSymmetry( ...
        Network.Z,...
        Problem);

end

%% ------------------------------------------------------------
%% S is no longer valid
%% ------------------------------------------------------------

Network.DomainValid.S = false;

Runtime.Network = Network;

end