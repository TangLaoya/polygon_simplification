function Network = ss_initializeNetwork(Measurement, Option)
%==========================================================================
% NSCP v4.0 Final Frozen
%
% Initialize optimization network.
%==========================================================================

Network = struct();

%% ------------------------------------------------------------------------
%% Network Representation Cache
%% ------------------------------------------------------------------------

Network.Representation = struct();

% Original S-parameter
Network.Representation.S = Measurement.S;

% Lazy generated representations
Network.Representation.Z = [];
Network.Representation.Y = [];
Network.Representation.ABCD = [];
Network.Representation.Cayley = [];
Network.Representation.RLGC = [];

%% ------------------------------------------------------------------------
%% Representation Valid Flags
%% ------------------------------------------------------------------------

Network.Valid = struct();

Network.Valid.S      = true;
Network.Valid.Z      = false;
Network.Valid.Y      = false;
Network.Valid.ABCD   = false;
Network.Valid.Cayley = false;
Network.Valid.RLGC   = false;

%% ------------------------------------------------------------------------
%% Runtime Information
%% ------------------------------------------------------------------------

Network.Iteration = 0;

%% ------------------------------------------------------------------------
%% Meta
%% ------------------------------------------------------------------------

Network.Meta = struct();

Network.Meta.PortNumber      = Measurement.PortNumber;
Network.Meta.FrequencyNumber = Measurement.FrequencyNumber;

end