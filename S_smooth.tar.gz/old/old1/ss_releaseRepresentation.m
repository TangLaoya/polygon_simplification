function Network = ss_releaseRepresentation(Network, Names)
%==========================================================================
% NSCP v4.0 Final Freeze – Representation Cache Lifecycle Manager
%==========================================================================

arguments
    Network struct
    Names   string
end

% 确保缓存结构存在
if ~isfield(Network,'Cache')
    Network.Cache = struct();
    Network.Cache.Status = struct();
    Network.Cache.DirtyFlags = struct();
end

for i = 1:numel(Names)
    name = upper(Names(i));
    if isfield(Network.Valid, name)
        Network.Valid.(name) = false;
    end
    Network.Cache.Status.(name) = "dirty";
    Network.Cache.DirtyFlags.(name) = true;
end

% 依赖传播
if any(strcmpi(Names,'S'))
    % S 变化，则 Z,Y,ABCD 失效
    if isfield(Network.Valid,'Z')
        Network.Valid.Z = false;
        Network.Cache.Status.Z = "dirty";
    end
    if isfield(Network.Valid,'Y')
        Network.Valid.Y = false;
        Network.Cache.Status.Y = "dirty";
    end
    if isfield(Network.Valid,'ABCD')
        Network.Valid.ABCD = false;
        Network.Cache.Status.ABCD = "dirty";
    end
end

if any(strcmpi(Names,'Z'))
    % Z 变化，则 S,Y,ABCD 失效
    if isfield(Network.Valid,'S')
        Network.Valid.S = false;
        Network.Cache.Status.S = "dirty";
    end
    if isfield(Network.Valid,'Y')
        Network.Valid.Y = false;
        Network.Cache.Status.Y = "dirty";
    end
    if isfield(Network.Valid,'ABCD')
        Network.Valid.ABCD = false;
        Network.Cache.Status.ABCD = "dirty";
    end
end

end