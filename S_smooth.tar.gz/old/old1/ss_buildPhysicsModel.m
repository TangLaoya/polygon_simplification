function PhysicsModel = ss_buildPhysicsModel( ...
                            Reference,...
                            Analysis,...
                            Option)
%==========================================================================
%
% NSCP v4.0 Final
%
% File:
%   ss_buildPhysicsModel.m
%
% Description
% -------------------------------------------------------------------------
% Construct a distributed physics model from the reference impedance.
%
% The model is immutable during optimization.
%
%==========================================================================

%% ========================================================================
%% Initialize
%% ========================================================================

PhysicsModel = struct();

%% ========================================================================
%% Model Type
%% ========================================================================

PhysicsModel.Type = ...
    Option.Problem.Physics.ReferenceModel;

%% ========================================================================
%% Valid Frequency Region
%% ========================================================================

PhysicsModel.Region = ...
    Reference.Region;

%% ========================================================================
%% Distributed Parameter Identification
%% ========================================================================

PhysicsModel.Parameterization = ...
    ss_identifyDistributedModel( ...
        Reference,...
        Analysis,...
        Option);

%% ========================================================================
%% Continuous Evaluator
%% ========================================================================

PhysicsModel.Evaluator = ...
    @(freq) ss_evaluatePhysicsModel( ...
        PhysicsModel.Parameterization,...
        freq);

%% ========================================================================
%% Jacobian
%% ========================================================================

PhysicsModel.Jacobian = ...
    @(freq) ss_physicsJacobian( ...
        PhysicsModel.Parameterization,...
        freq);

%% ========================================================================
%% Weight
%% ========================================================================

PhysicsModel.Weight = ...
    Reference.Weight;

%% ========================================================================
%% Confidence
%% ========================================================================

PhysicsModel.Confidence = ...
    Reference.Confidence;

%% ========================================================================
%% Meta
%% ========================================================================

PhysicsModel.Meta.Created = datetime('now');

PhysicsModel.Meta.Version = Option.Project.Version;

end