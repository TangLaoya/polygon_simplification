function s_parameter_smoothing_causal()
%==========================================================================
%
% NSCP v4.0 Final (Frozen)
%
% Main Program
%
% Responsibilities
% ----------------
%   1. Load configuration
%   2. Display banner
%   3. Read measurement
%   4. Run NSCP engine
%   5. Write optimized Touchstone
%   6. Display summary
%
% This file contains NO numerical algorithm.
%
%==========================================================================

clc;
clear;
close all;

%% ========================================================================
%% Load configuration
%% ========================================================================

Option = ss_defaultOption();

%% ========================================================================
%% User Interface
%% ========================================================================

if Option.Output.ShowBanner
    ss_banner();
end

%% ========================================================================
%% Read measurement (immutable)
%% ========================================================================

Measurement = ss_readMeasurement(Option);

%% ========================================================================
%% Run NSCP engine
%% ========================================================================

Result = ss_runNSCP(Measurement, Option);

%% ========================================================================
%% Write optimized Touchstone
%% ========================================================================

writeSnP_simple( ...
    Option.IO.OutputFile, ...
    Measurement.freq, ...
    Result.Network.S, ...
    Measurement.Parameter);

%% ========================================================================
%% Report
%% ========================================================================

if Option.Output.ShowSummary
    ss_showReport(Result.Report, Option);
end

end