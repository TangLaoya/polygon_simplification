function Option = ss_defaultOption()
%==========================================================================
%
% NSCP v4.0 Final (Frozen)
%
% File:
%   ss_defaultOption.m
%
% Description:
%   Generate immutable configuration for the entire NSCP framework.
%
% Design Principle
% ----------------
% Option defines ONLY:
%   (1) Problem definition
%   (2) Solver configuration
%
% Runtime variables are NOT allowed here.
%
%==========================================================================

%% ========================================================================
%% Project
%% ========================================================================

Option.Project.Name        = "NSCP";
Option.Project.Version     = "4.0";
Option.Project.Author      = "TangLaoya";
Option.Project.Description = ...
    "Numerically Stable Cayley Projection";

%% ========================================================================
%% IO
%% ========================================================================

Option.IO.InputFile  = "Test_beforeFit.s26p";
Option.IO.OutputFile = "output.s26p";

Option.IO.ReferenceImpedance = 50;
Option.IO.AutoDetectPort     = true;

%% ========================================================================
%% Engine (How to solve)
%% ========================================================================

%------------------------------------------------------------------
% Optimizer
%------------------------------------------------------------------

Option.Engine.Optimizer.Solver = ...
    "AlternatingProjection";

Option.Engine.Optimizer.MaxIteration = 50;

Option.Engine.Optimizer.RelativeTolerance = 1e-8;

Option.Engine.Optimizer.AbsoluteTolerance = 1e-10;

Option.Engine.Optimizer.EnableAdaptiveStep = true;

%------------------------------------------------------------------
% Scheduler
%------------------------------------------------------------------

Option.Engine.Scheduler.ReferenceUpdateInterval = 1;

Option.Engine.Scheduler.AnalysisUpdateInterval = 1;

Option.Engine.Scheduler.ReportInterval = 1;

%------------------------------------------------------------------
% Initialization
%------------------------------------------------------------------

Option.Engine.Initialization.EnableWarmStart = false;

Option.Engine.Initialization.UseMeasurementAsInitial = true;

%------------------------------------------------------------------
% Convergence
%------------------------------------------------------------------

Option.Engine.Convergence.StopTolerance = 1e-8;

Option.Engine.Convergence.StableIteration = 5;

Option.Engine.Convergence.ResidualTolerance = 1e-10;

%% ========================================================================
%% Numerical Linear Algebra
%% ========================================================================

Option.Numerical.Epsilon = eps;

Option.Numerical.SmallNumber = 1e-15;

Option.Numerical.Regularization = 1e-12;

Option.Numerical.UseSVD = true;

Option.Numerical.UsePseudoInverse = true;

Option.Numerical.UseTikhonov = true;

Option.Numerical.UseScaling = true;

%% ========================================================================
%% Problem Definition
%% ========================================================================

%------------------------------------------------------------------
% Stability Constraint
%------------------------------------------------------------------

Option.Problem.Stability.Enable = true;

Option.Problem.Stability.ConditionThreshold = 1e12;

Option.Problem.Stability.MinimumSingularValue = 1e-8;

Option.Problem.Stability.MaximumCorrection = 0.02;

Option.Problem.Stability.UseAdaptiveRegularization = true;

%------------------------------------------------------------------
% Physics Constraint
%------------------------------------------------------------------

Option.Problem.Physics.Enable = true;

Option.Problem.Physics.ReferenceModel = ...
    "DistributedRLC";

Option.Problem.Physics.KeepDCResistance = true;

Option.Problem.Physics.UseDistributedNetwork = true;

Option.Problem.Physics.UseLogFrequencyModel = true;

Option.Problem.Physics.Weight = 1.0;

%------------------------------------------------------------------
% Reference Model
%------------------------------------------------------------------

Option.Problem.Reference.Enable = true;

Option.Problem.Reference.AutoDetectRegion = true;

Option.Problem.Reference.MinimumRegionPoints = 15;

Option.Problem.Reference.MinimumSmoothLength = 10;

Option.Problem.Reference.MinimumConfidence = 0.95;

Option.Problem.Reference.UseRobustRegression = true;

Option.Problem.Reference.ModelOrder = [];

%------------------------------------------------------------------
% Measurement Constraint
%------------------------------------------------------------------

Option.Problem.Measurement.Enable = true;

Option.Problem.Measurement.Weight = 1.0;

Option.Problem.Measurement.MaximumRelativeError = 0.02;

Option.Problem.Measurement.MaximumAbsoluteError = 1e-4;

Option.Problem.Measurement.UseAdaptiveWeight = true;

Option.Problem.Measurement.ProjectionNorm = 2;

%% ========================================================================
%% Output
%% ========================================================================

Option.Output.ShowBanner = true;

Option.Output.ShowProgress = true;

Option.Output.ShowSummary = true;

Option.Output.SaveHistory = true;

Option.Output.SaveAnalysis = false;

Option.Output.SaveReference = false;

%% ========================================================================
%% Debug
%% ========================================================================

Option.Debug.Enable = false;

Option.Debug.OutputFolder = "debug";

Option.Debug.SaveIntermediateS = false;

Option.Debug.SaveIntermediateZ = false;

end