function Result = ss_runNSCP(Measurement, Option)
%==========================================================================
%
% NSCP v4.0 Final
%
% File:
%   ss_runNSCP.m
%
% Description
% -------------------------------------------------------------------------
% Framework dispatcher of NSCP.
%
% Responsibilities
% -------------------------------------------------------------------------
%   1. Prepare optimization problem
%   2. Select solver
%   3. Execute optimization
%   4. Return result
%
% This file contains NO mathematical implementation.
%
%==========================================================================

%% ========================================================================
%% Prepare optimization problem
%% ========================================================================

Problem = ss_prepareProblem( ...
                Measurement, ...
                Option);

%% ========================================================================
%% Select solver
%% ========================================================================

solverFcn = ss_getSolver( ...
                Option.Engine.Optimizer.Solver);

%% ========================================================================
%% Execute solver
%% ========================================================================

Result = solverFcn( ...
            Problem, ...
            Option);

%% ========================================================================
%% Finalize report
%% ========================================================================

Result.Report = ss_finalizeReport( ...
                        Result, ...
                        Option);

end