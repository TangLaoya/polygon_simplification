function [Sout,Report]=ss_validateMatrixRepair(...
                    freq,...
                    Sold,...
                    Scandidate,...
                    JumpReport)

%==============================================================
%
% NSCP V10.1
%
% Matrix Repair Validation
%
% Reject false repair
%
%==============================================================


Sout=Sold;


JumpIndex=JumpReport.JumpIndex;


AcceptIndex=[];
RejectIndex=[];



for n=1:length(JumpIndex)


    k=JumpIndex(n);



    if k<=1 || k>=length(freq)

        continue;

    end



    %%------------------------------------
    % local jump score
    %%------------------------------------


    scoreOld=...
        ss_localRepairScore(...
            freq,...
            Sold,...
            k);



    scoreNew=...
        ss_localRepairScore(...
            freq,...
            Scandidate,...
            k);



    %%------------------------------------
    % validation rule
    %%------------------------------------


    if scoreNew <= scoreOld


        Sout(k,:,:)=Scandidate(k,:,:);

        AcceptIndex(end+1)=k;


    else


        Sout(k,:,:)=Sold(k,:,:);

        RejectIndex(end+1)=k;


    end


end



Report.AcceptIndex=AcceptIndex;

Report.RejectIndex=RejectIndex;


end