function Z=s2z_simple(S)


N=size(S,1);

I=eye(N);


Z=(I+S)/(I-S);


end