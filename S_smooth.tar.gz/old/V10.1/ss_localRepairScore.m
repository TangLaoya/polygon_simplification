function score=ss_localRepairScore(freq,S,k)


Nport=size(S,2);



%% local window

idx=max(1,k-1):min(length(freq),k+1);



Sloc=S(idx,:,:);



%% S domain


AmpS=abs(Sloc);

PhaseS=unwrap(angle(Sloc),[],1);



sAmp=norm(...
    squeeze(AmpS(2,:,:))-...
    mean(AmpS,1),'fro');



sPhase=norm(...
    squeeze(PhaseS(2,:,:))-...
    mean(PhaseS,1),'fro');



%% Z domain


Z=zeros(size(Sloc));


for n=1:length(idx)

    Z(n,:,:)=...
        s2z_simple(...
        squeeze(Sloc(n,:,:)));

end



AmpZ=abs(Z);

PhaseZ=unwrap(angle(Z),[],1);



zAmp=norm(...
    squeeze(AmpZ(2,:,:))-...
    mean(AmpZ,1),'fro');


zPhase=norm(...
    squeeze(PhaseZ(2,:,:))-...
    mean(PhaseZ,1),'fro');



%% combined


score=...
    sAmp...
   +0.2*sPhase...
   +zAmp...
   +0.2*zPhase;


end