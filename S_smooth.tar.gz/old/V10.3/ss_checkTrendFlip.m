function flag=ss_checkTrendFlip(Aold,Anew)

%==============================================================
%
% Check first derivative direction change
%
%==============================================================


flag=0;


Dold=diff(Aold,1,1);

Dnew=diff(Anew,1,1);



s1=sign(Dold);

s2=sign(Dnew);



% ignore tiny numerical noise

thr=1e-12;


mask=...
    abs(Dold)>thr & ...
    abs(Dnew)>thr;



flip=(s1~=s2)&mask;



if any(flip(:))

    flag=1;

end


end