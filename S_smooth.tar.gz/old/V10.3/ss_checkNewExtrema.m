function score=ss_checkNewExtrema(Yold,Ynew)

%==============================================================
%
% Detect newly created extrema
%
%==============================================================


score=0;


Dold=diff(Yold,1,1);

Dnew=diff(Ynew,1,1);



ExtOld = ...
    Dold(1:end-1,:,:).*...
    Dold(2:end,:,:) < 0;


ExtNew = ...
    Dnew(1:end-1,:,:).*...
    Dnew(2:end,:,:) < 0;



NewExt = ExtNew & ~ExtOld;


if any(NewExt(:))

    score=1;

end


end