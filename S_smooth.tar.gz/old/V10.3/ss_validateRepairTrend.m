function [Sout,Report]=ss_validateRepairTrend(...
                    freq,...
                    Sold,...
                    Snew,...
                    RepairIndex,...
                    Option)

%==============================================================
%
% NSCP V10.4
%
% Repair Trend Validation
%
% Only reject newly created extrema
%
%==============================================================


if nargin<5
    Option=struct();
end


if ~isfield(Option,'Window')
    Option.Window=2;
end


Sout=Snew;


AcceptIndex=[];
RejectIndex=[];


for idx=RepairIndex(:)'


    k1=max(1,idx-Option.Window);
    k2=min(size(Sold,1),idx+Option.Window);


    score=0;


    %%----------------------------------------------------------
    % S magnitude
    %%----------------------------------------------------------

    score=score+...
        ss_checkNewExtrema(...
        abs(Sold(k1:k2,:,:)),...
        abs(Snew(k1:k2,:,:)));


    %%----------------------------------------------------------
    % S phase
    %%----------------------------------------------------------

    Pold=unwrap(angle(Sold(k1:k2,:,:)),[],1);

    Pnew=unwrap(angle(Snew(k1:k2,:,:)),[],1);


    score=score+...
        ss_checkNewExtrema(...
        Pold,...
        Pnew);



    %%----------------------------------------------------------
    % Z real
    %%----------------------------------------------------------

    Zold=ss_s2z_matrix(Sold(k1:k2,:,:));

    Znew=ss_s2z_matrix(Snew(k1:k2,:,:));


    score=score+...
        ss_checkNewExtrema(...
        real(Zold),...
        real(Znew));



    %%----------------------------------------------------------
    % Z imaginary
    %%----------------------------------------------------------

    score=score+...
        ss_checkNewExtrema(...
        imag(Zold),...
        imag(Znew));



    %%----------------------------------------------------------
    % decision
    %%----------------------------------------------------------


    if score>0

        Sout(idx,:,:)=Sold(idx,:,:);

        RejectIndex(end+1)=idx;

        fprintf(...
        'Restore point %d : New extrema\n',...
        idx);


    else

        AcceptIndex(end+1)=idx;

        fprintf(...
        'Keep point %d : Trend OK\n',...
        idx);

    end


end



Report.AcceptIndex=AcceptIndex;

Report.RejectIndex=RejectIndex;

Report.RestoreIndex=RejectIndex;

Report.AcceptNumber=numel(AcceptIndex);

Report.RejectNumber=numel(RejectIndex);


fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.4 Repair Validation\n');
fprintf('========================================\n');

fprintf('Accepted : %d\n',...
    Report.AcceptNumber);

fprintf('Rejected : %d\n',...
    Report.RejectNumber);

fprintf('========================================\n');


end