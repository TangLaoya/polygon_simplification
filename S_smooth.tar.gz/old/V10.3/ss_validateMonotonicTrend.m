function [Sout,Report]=ss_validateMonotonicTrend(...
                    freq,...
                    Sold,...
                    Snew,...
                    RepairIndex,...
                    Option)

%==============================================================
%
% NSCP V10.3
%
% Monotonic Trend Protection
%
% Prevent false repair creating new jumps
%
%==============================================================


if nargin<6
    Option=struct();
end


if ~isfield(Option,'Window')
    Option.Window=2;
end


Sout=Snew;


Accept=[];
Restore=[];


[Nf,~,~]=size(Sold);



for idx=RepairIndex(:)'


    k1=max(1,idx-Option.Window);
    k2=min(Nf,idx+Option.Window);


    %%==========================================================
    % compare multiple representations
    %%==========================================================


    % S magnitude

    Aold=abs(Sold(k1:k2,:,:));

    Anew=abs(Snew(k1:k2,:,:));


    % phase

    Pold=unwrap(angle(Sold(k1:k2,:,:)),[],1);

    Pnew=unwrap(angle(Snew(k1:k2,:,:)),[],1);


    % Z

    Zold=ss_s2z(Sold(k1:k2,:,:));

    Znew=ss_s2z(Snew(k1:k2,:,:));


    %%==========================================================
    % trend violation counter
    %%==========================================================

    score=0;


    score=score+...
        ss_checkTrendFlip(Aold,Anew);


    score=score+...
        ss_checkTrendFlip(Pold,Pnew);


    score=score+...
        ss_checkTrendFlip(real(Zold),real(Znew));


    score=score+...
        ss_checkTrendFlip(imag(Zold),imag(Znew));


    %%==========================================================
    % decision
    %%==========================================================


    if score>0

        Sout(idx,:,:)=Sold(idx,:,:);

        Restore(end+1)=idx;


        fprintf(...
        'Restore point %d : Trend violation\n',...
        idx);


    else

        Accept(end+1)=idx;


        fprintf(...
        'Keep point %d : Trend OK\n',...
        idx);

    end

end


Report.AcceptIndex=Accept;

Report.RestoreIndex=Restore;

Report.AcceptNumber=numel(Accept);

Report.RestoreNumber=numel(Restore);


fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.3 Trend Validation\n');
fprintf('========================================\n');

fprintf('Accepted : %d\n',...
    Report.AcceptNumber);

fprintf('Restored : %d\n',...
    Report.RestoreNumber);

fprintf('========================================\n');


end