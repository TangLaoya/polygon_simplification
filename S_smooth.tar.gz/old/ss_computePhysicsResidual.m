function [J,residual]=ss_computePhysicsResidual(freq,S,physics,cfg)

Z=ss_s2z(S,cfg);

m=physics.mask;

D=physics.D;

J=0;

residual=cell(size(physics.model));

N=size(Z,2);

for i=1:N

    for j=1:N

        Zij=squeeze(Z(m,i,j));

        R=real(Zij);

        X=imag(Zij);

        switch physics.model(i,j)

            case "R"

                q=R;

            case "C"

                q=physics.freq.*X;

            case "L"

                q=physics.invFreq.*X;

        end

        r=D*q;

        residual{i,j}=r;

        J=J+real(r'*r);

    end

end

end