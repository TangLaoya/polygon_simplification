function physics = ss_buildPhysicsTarget(freq,S,detect,cfg)

%==============================================================
%
% Build physics operators
%
% This routine NEVER computes residual.
%
% It only builds
%
% model
%
% finite-difference operator
%
% low-frequency mask
%
% weights
%
%==============================================================

Nf=size(S,1);

N=size(S,2);

physics=struct;

physics.model=strings(N,N);

physics.operator=cell(N,N);

physics.weight=ones(N,N);

physics.mask=false(Nf,1);

physics.mask(1:detect.Mopt)=true;

%% ---------------------------------------
%% finite difference matrix
%% ---------------------------------------

m=detect.Mopt;

e=ones(m-1,1);

D=spdiags([-e e],[0 1],m-1,m);

physics.D=D;

physics.freq=freq(1:m);

physics.invFreq=1./physics.freq;

physics.freqDiag=spdiags(physics.freq,0,m,m);

physics.invFreqDiag=spdiags(physics.invFreq,0,m,m);

%% ---------------------------------------
%% determine every matrix element
%% ---------------------------------------

Z=ss_s2z(S,cfg);

for i=1:N

    for j=1:N

        Zij=squeeze(Z(:,i,j));

        X=imag(Zij(1:m));

        xr=median(X);

        if abs(xr)<cfg.resistiveThreshold

            physics.model(i,j)="R";

        elseif xr<0

            physics.model(i,j)="C";

        else

            physics.model(i,j)="L";

        end

    end

end

end