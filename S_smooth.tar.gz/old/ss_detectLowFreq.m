function detect = ss_detectLowFreq(freq,S,Z,cfg)

% ============================================================
%
% Detect Low-frequency Smooth Region
%
% Output
%
% detect.Mopt
% detect.jumpMask
% detect.fitInfo(i,j)
%
% ============================================================

Nf=size(S,1);
N=size(S,2);

detect=struct;

detect.jumpMask=false(N,N);

detect.fitInfo=cell(N,N);

%% ----------------------------------------------------------
% Step1
% search global smooth start
%% ----------------------------------------------------------

ratio=zeros(Nf,1);

for k=1:Nf

    score=0;

    total=0;

    for i=1:N

        for j=1:N

            total=total+1;

            curve=abs(squeeze(S(:,i,j)));

            curve(curve<1e-30)=1e-30;

            y=20*log10(curve);

            d=abs(diff(y));

            med=median(d);

            mad=median(abs(d-med));

            if mad<1e-12
                mad=std(d);
            end

            if k==1

                score=score+1;

            elseif d(k-1)<med+8*mad

                score=score+1;

            end

        end

    end

    ratio(k)=score/total;

end

idx=find(ratio>0.6);

if isempty(idx)

    detect.Mopt=round(0.4*Nf);

else

    detect.Mopt=idx(1);

end

M=detect.Mopt;

fprintf("Smooth region starts at %d\n",M);

%% ----------------------------------------------------------
% Step2
% analyse every Zij
%% ----------------------------------------------------------

for i=1:N

    for j=1:N

        Zij=squeeze(Z(:,i,j));

        amp=abs(Zij);

        amp(amp<1e-30)=1e-30;

        x=log10(freq);

        y=20*log10(amp);

        lowIndex=1:M-1;

        if length(lowIndex)<cfg.minimumFitPoint

            continue;

        end

        xx=x(lowIndex);

        yy=y(lowIndex);

        valid=isfinite(xx)&isfinite(yy);

        xx=xx(valid);

        yy=yy(valid);

        %% -----------------------------------------
        % linear fitting
        %% -----------------------------------------

        p=polyfit(xx,yy,1);

        yyfit=polyval(p,xx);

        residual=yy-yyfit;

        sigma=std(residual);

        %% -----------------------------------------
        % jump detect
        %% -----------------------------------------

        jump=false;

        count=0;

        for k=1:length(residual)

            if abs(residual(k))>cfg.jumpThreshold

                count=count+1;

                if count>=cfg.minimumContinuousPoint

                    jump=true;

                    break;

                end

            else

                count=0;

            end

        end

        detect.jumpMask(i,j)=jump;

        %% -----------------------------------------
        % save fitting
        %% -----------------------------------------

        info=struct;

        info.poly=p;

        info.std=sigma;

        info.referenceFrequency=freq(M);

        info.referenceValue=Zij(M);

        info.realReference=real(Zij(M));

        info.imagReference=imag(Zij(M));

        info.capacitive=(imag(Zij(M))<0);

        info.inductive=(imag(Zij(M))>0);

        info.resistive=(abs(imag(Zij(M)))<1e-12);

        detect.fitInfo{i,j}=info;

    end

end

fprintf("Detected %d low-frequency jumps.\n",...
    sum(detect.jumpMask(:)));

end