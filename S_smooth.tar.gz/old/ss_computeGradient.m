function gradZ=ss_computeGradient(freq,S,physics,cfg)

Z=ss_s2z(S,cfg);

gradZ=zeros(size(S));

D=physics.D;

m=find(physics.mask);

N=size(Z,2);

for i=1:N

    for j=1:N

        Zij=squeeze(Z(m,i,j));

        R=real(Zij);

        X=imag(Zij);

        switch physics.model(i,j)

            case "R"

                q=R;

                gq=2*(D')*(D*q);

                gR=gq;

                gX=zeros(size(gq));

            case "C"

                q=physics.freq.*X;

                gq=2*(D')*(D*q);

                gR=zeros(size(gq));

                gX=physics.freq.*gq;

            case "L"

                q=physics.invFreq.*X;

                gq=2*(D')*(D*q);

                gR=zeros(size(gq));

                gX=physics.invFreq.*gq;

        end

        %% 写回梯度（相对于Z）
        gradZ(m,i,j)=complex(gR,gX);

    end

end