function [Sout,Report]=ss_validateMatrixRepair(...
                    freq,...
                    Sold,...
                    Scandidate,...
                    JumpReport)


Sout=Sold;


AcceptIndex=[];
RejectIndex=[];


JumpIndex=JumpReport.JumpIndex;


for n=1:length(JumpIndex)


    k=JumpIndex(n);


    if k<=1 || k>=length(freq)

        continue;

    end



    %%--------------------------------
    % local prediction
    %%--------------------------------

    Zold=zeros(size(Sold,2));

    Znew=zeros(size(Sold,2));



    Zbefore=s2z_simple(...
        squeeze(Sold(k,:,:)));



    Zafter=s2z_simple(...
        squeeze(Scandidate(k,:,:)));



    Zpred=ss_predictLocalZ(...
        freq,...
        Sold,...
        k);



    %%--------------------------------
    % physical error
    %%--------------------------------


    Eold=ss_compareZPhysics(...
        Zbefore,...
        Zpred);



    Enew=ss_compareZPhysics(...
        Zafter,...
        Zpred);



    %%--------------------------------
    % curvature protection
    %%--------------------------------


    Cold=ss_checkCurvature(...
        freq,...
        Sold,...
        k);



    Cnew=ss_checkCurvature(...
        freq,...
        Scandidate,...
        k);



    Accept=false;



    if Enew < Eold

        Accept=true;

    end


    if Cnew > 5*Cold

        Accept=false;

    end



    if Accept

        Sout(k,:,:)=Scandidate(k,:,:);

        AcceptIndex(end+1)=k;

    else

        RejectIndex(end+1)=k;

    end


end



Report.AcceptIndex=AcceptIndex;

Report.RejectIndex=RejectIndex;


end