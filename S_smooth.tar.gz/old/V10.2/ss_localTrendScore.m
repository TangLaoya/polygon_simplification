function Score = ss_localTrendScore( ...
                            freq,...
                            S,...
                            k,...
                            Window)

%==============================================================
%
% NSCP V10.1
%
% Local Matrix Trend Score
%
% Repair validation module
%
%==============================================================


%%------------------------------------------------------------
% size
%%------------------------------------------------------------

[Nf,~,~] = size(S);


%%------------------------------------------------------------
% local window
%%------------------------------------------------------------

k1 = max(1,k-Window);

k2 = min(Nf,k+Window);


idx = k1:k2;


if length(idx)<3

    Score = 0;

    return;

end



%%------------------------------------------------------------
% extract local S
%%------------------------------------------------------------

Slocal = S(idx,:,:);



%%------------------------------------------------------------
% S -> Z
%%------------------------------------------------------------

Zlocal = zeros(size(Slocal));



for n = 1:length(idx)

    Zlocal(n,:,:) = ...
        s2z_simple( ...
        squeeze(Slocal(n,:,:)));

end



%%------------------------------------------------------------
% first derivative
%%------------------------------------------------------------


Nlocal = length(idx);


D1S = zeros(Nlocal-1,1);

D1Z = zeros(Nlocal-1,1);



for n = 1:Nlocal-1


    S1 = squeeze(Slocal(n,:,:));

    S2 = squeeze(Slocal(n+1,:,:));


    Z1 = squeeze(Zlocal(n,:,:));

    Z2 = squeeze(Zlocal(n+1,:,:));


    dS = S2-S1;

    dZ = Z2-Z1;


    D1S(n)=norm(dS(:));

    D1Z(n)=norm(dZ(:));


end



%%------------------------------------------------------------
% second derivative
%%------------------------------------------------------------


D2S=zeros(Nlocal-2,1);

D2Z=zeros(Nlocal-2,1);



for n=1:Nlocal-2


    S0=squeeze(Slocal(n,:,:));

    S1=squeeze(Slocal(n+1,:,:));

    S2=squeeze(Slocal(n+2,:,:));


    Z0=squeeze(Zlocal(n,:,:));

    Z1=squeeze(Zlocal(n+1,:,:));

    Z2=squeeze(Zlocal(n+2,:,:));


    ddS = S2 - 2*S1 + S0;

    ddZ = Z2 - 2*Z1 + Z0;



    D2S(n)=norm(ddS(:));

    D2Z(n)=norm(ddZ(:));


end



%%------------------------------------------------------------
% robust statistics
%%------------------------------------------------------------


ScoreS1 = median(D1S);

ScoreZ1 = median(D1Z);


ScoreS2 = median(D2S);

ScoreZ2 = median(D2Z);



%%------------------------------------------------------------
% final trend score
%
% larger:
%   trend distortion stronger
%
%%------------------------------------------------------------


Score = ...
      ScoreS2 ...
    + 0.5*ScoreZ2 ...
    + 0.2*ScoreS1 ...
    + 0.2*ScoreZ1;



end