function [Sout,Validation]=...
    ss_validateRepairTrend( ...
        freq,...
        Sold,...
        Snew,...
        RepairIndex)

%==============================================================
%
% NSCP V10.2
%
% Repair Trend Validation
%
% Unified Interface Edition
%
% Output:
%
% Validation.AcceptIndex
% Validation.RejectIndex
%
%==============================================================


Sout = Snew;


Validation.AcceptIndex=[];

Validation.RejectIndex=[];

Validation.ScoreBefore=[];

Validation.ScoreAfter=[];



fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.2 Repair Validation\n');
fprintf('========================================\n');



for n=1:length(RepairIndex)


    k=RepairIndex(n);



    %% boundary

    if k<=2 || k>=length(freq)-1

        Validation.AcceptIndex(end+1)=k;

        continue;

    end



    %%----------------------------------------------------------
    % calculate before score
    %%----------------------------------------------------------

    ScoreBefore = ...
        ss_localTrendScore(...
            freq,...
            Sold,...
            k,...
            2);



    %%----------------------------------------------------------
    % calculate after score
    %%----------------------------------------------------------

    ScoreAfter = ...
        ss_localTrendScore(...
            freq,...
            Snew,...
            k,...
            2);



    Validation.ScoreBefore(end+1)=ScoreBefore;

    Validation.ScoreAfter(end+1)=ScoreAfter;



    Ratio = ScoreAfter / max(ScoreBefore,eps);



    %%----------------------------------------------------------
    % decision
    %%----------------------------------------------------------

    if Ratio <= 1.05


        Validation.AcceptIndex(end+1)=k;


        fprintf(...
        'Keep point %d : ratio %.3f\n',...
        k,...
        Ratio);


    else


        Sout(k,:,:) = Sold(k,:,:);


        Validation.RejectIndex(end+1)=k;


        fprintf(...
        'Restore point %d : ratio %.3f\n',...
        k,...
        Ratio);


    end



end



fprintf('\n');

fprintf('Accepted : %d\n',...
    length(Validation.AcceptIndex));


fprintf('Rejected : %d\n',...
    length(Validation.RejectIndex));


fprintf('========================================\n');


end