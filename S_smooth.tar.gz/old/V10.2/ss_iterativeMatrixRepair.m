function [Srepair,Report] = ss_iterativeMatrixRepair( ...
                                    freq,...
                                    S,...
                                    Option)

%==============================================================
%
% NSCP V10.1
%
% Iterative Matrix Z Repair
%
% Detection
% Repair
% Validation
%
%==============================================================


if nargin<3
    Option=struct();
end


if ~isfield(Option,'MaxIteration')
    Option.MaxIteration=5;
end


if ~isfield(Option,'ConvergenceTol')
    Option.ConvergenceTol=1e-6;
end


if ~isfield(Option,'Threshold')
    Option.Threshold=4;
end


Srepair=S;


Report.Iteration=0;



fprintf('\n');
fprintf('==============================================================\n');
fprintf(' NSCP V10.1 Iterative Matrix Z Repair\n');
fprintf('==============================================================\n');



for iter=1:Option.MaxIteration


    fprintf('\nIteration %d\n',iter);



    %%-----------------------------------------
    % Z jump detection
    %%-----------------------------------------

    DetectOption.Threshold=Option.Threshold;


    ZJumpReport=ss_detectMatrixZJump(...
        freq,...
        Srepair,...
        DetectOption);



    if ZJumpReport.JumpNumber==0

        fprintf('No jump detected.\n');

        break;

    end



    fprintf('Detected %d jumps\n',...
        ZJumpReport.JumpNumber);



    %%-----------------------------------------
    % repair candidate
    %%-----------------------------------------

    Sold=Srepair;
    
    
    [Srepair,RepairReport] = ss_repairMatrixSByJump( ...
            freq,...
            Srepair,...
            ZJumpReport);
    
    
    
    [Srepair,ValidReport]=...
        ss_validateRepairTrend(...
            freq,...
            Sold,...
            Srepair,...
            RepairReport.RepairIndex);    
    
    
    RepairReport.Validation=ValidReport;

    Delta=norm(Srepair(:)-Sold(:))...
        /max(norm(Sold(:)),eps);



    Report.History(iter).JumpIndex=...
        ZJumpReport.JumpIndex;


    Report.History(iter).RepairIndex=...
        ValidReport.AcceptIndex;


    Report.History(iter).RejectIndex=...
        ValidReport.RejectIndex;


    Report.History(iter).Delta=Delta;



    fprintf('Accepted : %d\n',...
        length(ValidReport.AcceptIndex));


    fprintf('Rejected : %d\n',...
        length(ValidReport.RejectIndex));


    fprintf('Delta : %.3e\n',Delta);



    if Delta<Option.ConvergenceTol

        break;

    end


end



Report.Iteration=iter;


fprintf('\n');
fprintf('==============================================================\n');
fprintf(' Iterative repair finished\n');
fprintf('==============================================================\n');


end