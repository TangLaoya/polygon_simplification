function condInfo = ss_estimateReferenceCondition(Sref,freqRef,cfg)
%==============================================================
%
% Estimate Reference Spectral Manifold
%
% This routine builds the spectral model of
%
% A = I-S
%
% in the smooth reference region.
%
%==============================================================

Nf = size(Sref,1);
N  = size(Sref,2);

I = eye(N);

%% ============================================================
% Allocate
%% ============================================================

Sigma = zeros(N,Nf);

Eigen = cell(Nf,1);

Uref = cell(Nf,1);

Vref = cell(Nf,1);

Condition = zeros(Nf,1);

Gain = zeros(Nf,1);

Margin = zeros(Nf,1);

%% ============================================================
% Analyse every reference frequency
%% ============================================================

for k=1:Nf

    Sk = squeeze(Sref(k,:,:));

    A = I-Sk;

    [U,S,V]=svd(A,'econ');

    sv = diag(S);

    Sigma(:,k)=sv;

    Uref{k}=U;

    Vref{k}=V;

    Eigen{k}=eig(A);

    Condition(k)=sv(1)/max(sv(end),eps);

    Margin(k)=sv(end);

    Gain(k)=2*cfg.Z0/max(sv(end),eps)^2;

end

%% ============================================================
% Build spectral interpolator
%% ============================================================

Projection = struct();

Projection.ppSigma=cell(N,1);

Projection.referenceSigma=zeros(N,1);

Projection.referenceSlope=zeros(N,1);

Projection.referenceCurvature=zeros(N,1);

for i=1:N

    sigma_i=Sigma(i,:);

    Projection.ppSigma{i}=pchip(freqRef,sigma_i);

    Projection.referenceSigma(i)=median(sigma_i);

    ds=gradient(sigma_i,freqRef);

    d2s=gradient(ds,freqRef);

    Projection.referenceSlope(i)=median(ds);

    Projection.referenceCurvature(i)=median(d2s);

end

%% ============================================================
% Jacobian manifold
%% ============================================================

Projection.ppGain=pchip(freqRef,Gain);

Projection.referenceGain=median(Gain);

Projection.referenceCondition=median(Condition);

Projection.referenceMargin=median(Margin);

%% ============================================================
% Output
%% ============================================================

condInfo=struct();

condInfo.freq=freqRef;

condInfo.singularValueTrajectory=Sigma;

condInfo.eigenTrajectory=Eigen;

condInfo.referenceProjection=Projection;

condInfo.U=Uref;

condInfo.V=Vref;

condInfo.condition=Condition;

condInfo.margin=Margin;

condInfo.gain=Gain;

end