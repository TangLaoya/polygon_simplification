function cfg = ss_config()

cfg.Z0 = 50;

cfg.inputFile = "Test_beforeFit.s26p";

cfg.outputFile = "output.s26p";

cfg.maxIteration = 15;

cfg.lambda = 1e-5;

cfg.tolerance = 1e-10;

cfg.regularization = 1e-12;

cfg.conditionLimit = 1e12;

cfg.plotEnable = true;

cfg.onlyLowFrequency = true;

cfg.realWeight = 1.0;

cfg.imagWeight = 0.2;

cfg.verbose = true;

end