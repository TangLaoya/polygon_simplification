function Runtime = ss_executeEngine(Runtime, Problem, Engine)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_executeEngine.m
%
% Description
% -------------------------------------------------------------------------
% Execute optimization engine.
%
% This module dispatches the selected solver algorithm.
% It contains NO numerical optimization code.
%
%==========================================================================

%% ========================================================================
%% Check Engine
%% ========================================================================

if ~isfield(Engine,'Algorithm')

    error('Engine.Algorithm is missing.');

end

Algorithm = lower(string(Engine.Algorithm));

%% ========================================================================
%% Dispatch Solver
%% ========================================================================

switch Algorithm

    case "alternatingprojection"

        Runtime = ss_solverAlternatingProjection( ...
                        Runtime,...
                        Problem,...
                        Engine);

    otherwise

        error("Unsupported solver algorithm: %s",Algorithm);

end

%% ========================================================================
%% Finish
%% ========================================================================

Runtime.Summary.TimeFinish = datetime("now");

Runtime.Summary.ElapsedTime = ...
    Runtime.Summary.TimeFinish - Runtime.Summary.TimeStart;

end