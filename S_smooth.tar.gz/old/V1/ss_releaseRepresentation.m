function Network = ss_releaseRepresentation(Network, Names)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_releaseRepresentation.m
%
% Description
% -------------------------------------------------------------------------
% Representation Cache Lifecycle Manager.
%
% This module marks representations as invalid and propagates dependency
% invalidation across the cache graph.
%
% It does NOT compute any representation.
%
%==========================================================================

arguments
    Network struct
    Names   string
end

%% ========================================================================
%% Ensure cache structure
%% ========================================================================

if ~isfield(Network,'Cache')

    Network.Cache = struct();

    Network.Cache.Status = struct();
    Network.Cache.DirtyFlags = struct();

end

%% ========================================================================
%% Apply invalidation
%% ========================================================================

for i = 1:numel(Names)

    name = upper(Names(i));

    Network.Valid.(name) = false;

    Network.Cache.Status.(name) = "dirty";

    Network.Cache.DirtyFlags.(name) = true;

end

%% ========================================================================
%% Dependency propagation (minimal version)
%% ========================================================================

% If S changes → invalidate Z,Y,ABCD
if any(strcmpi(Names,'S'))

    if isfield(Network.Valid,'Z')
        Network.Valid.Z = false;
        Network.Cache.Status.Z = "dirty";
    end

    if isfield(Network.Valid,'Y')
        Network.Valid.Y = false;
        Network.Cache.Status.Y = "dirty";
    end

    if isfield(Network.Valid,'ABCD')
        Network.Valid.ABCD = false;
        Network.Cache.Status.ABCD = "dirty";
    end

end

% If Z changes → invalidate S,Y,ABCD
if any(strcmpi(Names,'Z'))

    if isfield(Network.Valid,'S')
        Network.Valid.S = false;
        Network.Cache.Status.S = "dirty";
    end

    if isfield(Network.Valid,'Y')
        Network.Valid.Y = false;
        Network.Cache.Status.Y = "dirty";
    end

    if isfield(Network.Valid,'ABCD')
        Network.Valid.ABCD = false;
        Network.Cache.Status.ABCD = "dirty";
    end

end

end