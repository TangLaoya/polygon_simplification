function Runtime = ss_updateHistory(Runtime)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_updateHistory.m
%
% Description
% -------------------------------------------------------------------------
% Solver history tracking module.
%
% This module records full iterative state evolution for diagnostics,
% reproducibility, and convergence analysis.
%
% No computation or modification of solver state is performed here.
%
%==========================================================================

%% ========================================================================
%% Initialize history if needed
%% ========================================================================

if ~isfield(Runtime,'History')

    Runtime.History = struct();

    Runtime.History.Iteration = [];

    Runtime.History.Objective = [];

    Runtime.History.Residual = [];

    Runtime.History.State = strings(0);

    Runtime.History.SNorm = [];

    Runtime.History.ZNorm = [];

    Runtime.History.TimeStamp = datetime.empty;

end

%% ========================================================================
%% Extract current state
%% ========================================================================

iter = Runtime.Iteration.Current;

obj  = Runtime.State.Objective.Total;

res  = Runtime.State.Residual.TotalResidual;

state = string(Runtime.Convergence.State);

%% ========================================================================
%% Network norms (diagnostic only)
%% ========================================================================

Network = Runtime.Network;

S = Network.Representation.S;

Z = [];

try
    Z = Network.Representation.Z;
catch
    Z = [];
end

S_norm = norm(S(:),2);

if isempty(Z)
    Z_norm = NaN;
else
    Z_norm = norm(Z(:),2);
end

%% ========================================================================
%% Append history
%% ========================================================================

Runtime.History.Iteration(end+1,1) = iter;

Runtime.History.Objective(end+1,1)  = obj;

Runtime.History.Residual(end+1,1)   = res;

Runtime.History.State(end+1,1)       = state;

Runtime.History.SNorm(end+1,1)       = S_norm;

Runtime.History.ZNorm(end+1,1)       = Z_norm;

Runtime.History.TimeStamp(end+1,1)   = datetime("now");

%% ========================================================================
%% Optional pruning (memory control)
%% ========================================================================

maxHist = 5000;

if numel(Runtime.History.Iteration) > maxHist

    Runtime.History.Iteration(1) = [];
    Runtime.History.Objective(1) = [];
    Runtime.History.Residual(1)  = [];
    Runtime.History.State(1)     = [];
    Runtime.History.SNorm(1)     = [];
    Runtime.History.ZNorm(1)     = [];
    Runtime.History.TimeStamp(1) = [];

end

end