function Network = ss_initializeNetwork(Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_initializeNetwork.m
%
% Description
% -------------------------------------------------------------------------
% Initialize runtime network state from immutable Problem.
%
% This module does NOT perform any physics, optimization, or projection.
% It only prepares the Network container for runtime execution.
%
%==========================================================================

%% ========================================================================
%% Create Network structure
%% ========================================================================

Network = struct();

%% ========================================================================
%% Meta information (immutable copy from Problem)
%% ========================================================================

Network.Meta = struct();

Network.Meta.PortNumber = Problem.Network.PortNumber;

Network.Meta.FrequencyNumber = Problem.Dimension.Frequency;

Network.Meta.Z0 = Problem.Network.ReferenceImpedance;

%% ========================================================================
%% Representation container
%% ========================================================================

Network.Representation = struct();

% Active representation: S (initial state)
Network.Representation.S = Problem.Measurement.S;

% Lazy representations (computed on demand)
Network.Representation.Z = [];
Network.Representation.Y = [];
Network.Representation.ABCD = [];

%% ========================================================================
%% Valid flags (lazy evaluation system)
%% ========================================================================

Network.Valid = struct();

Network.Valid.S = true;
Network.Valid.Z = false;
Network.Valid.Y = false;
Network.Valid.ABCD = false;

%% ========================================================================
%% Internal runtime bookkeeping
%% ========================================================================

Network.Iteration = 0;

Network.Modified = false;

%% ========================================================================
%% Return initialized network
%% ========================================================================

end