function Network = ss_projectPhysics(Network, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_projectPhysics.m
%
% Description
% -------------------------------------------------------------------------
% Physics consistency projection.
%
% This module projects the current network onto the feasible physical
% manifold defined in Problem.Physics.
%
% Numerical stability has already been enforced by
% ss_projectStableCayley().
%
%==========================================================================

%% ========================================================================
%% Obtain impedance representation
%% ========================================================================

[Network, Z] = ss_getRepresentation( ...
                    Network, ...
                    'Z', ...
                    Problem);

freq = Problem.Frequency.Vector;

Physics = Problem.Physics;

Nf = size(Z,3);

%% ========================================================================
%% Physics Projection
%% ========================================================================

for k = 1:Nf

    Zk = Z(:,:,k);

    %------------------------------------------------------------
    % 1. Hermitian symmetry (reciprocal passive approximation)
    %------------------------------------------------------------
    if Problem.Option.Stability.EnforceHermitian

        Zk = (Zk + Zk')/2;

    end

    %------------------------------------------------------------
    % 2. RL trend constraint (low-frequency regularization)
    %------------------------------------------------------------
    if ~isempty(Physics.RLGC.R)

        Rref = Physics.RLGC.R(k);

        alpha = Problem.Reference.Confidence.Cp(k);

        H = real(Zk);

        H = (1-alpha)*H + alpha*diag(diag(H));

        H = H + (Rref/size(H,1))*eye(size(H));

        Zk = H + 1i*imag(Zk);

    end

    %------------------------------------------------------------
    % 3. Smooth inductive trend
    %------------------------------------------------------------
    if k>1

        beta = Problem.Reference.Confidence.Cp(k);

        Zk = beta*Z(:,:,k-1) + (1-beta)*Zk;

    end

    Z(:,:,k)=Zk;

end

%% ========================================================================
%% Update representation
%% ========================================================================

Network.Representation.Z = Z;

Network.Valid.Z = true;

%% ========================================================================
%% Release dependent cache
%% ========================================================================

Network = ss_releaseRepresentation(Network,"S");

end