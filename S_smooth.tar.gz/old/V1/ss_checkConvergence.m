function Runtime = ss_checkConvergence(Runtime, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_checkConvergence.m
%
% Description
% -------------------------------------------------------------------------
% Solver convergence controller.
%
% This module evaluates solver state according to objective evolution.
%
% No network modification is performed.
%
%==========================================================================

%% ========================================================================
%% Solver option
%% ========================================================================

Solver = Problem.Option.Solver;

TolObjective = Solver.ObjectiveTolerance;
TolRelative  = Solver.RelativeTolerance;
PlateauLimit = Solver.PlateauIteration;

CurrentIter = Runtime.Iteration.Current;
MaxIter     = Runtime.Iteration.Max;

Objective = Runtime.State.Objective.Total;

%% ========================================================================
%% Initialize convergence state
%% ========================================================================

if ~isfield(Runtime,'Convergence')

    Runtime.Convergence = struct();

    Runtime.Convergence.PreviousObjective = inf;

    Runtime.Convergence.PlateauCounter = 0;

end

Prev = Runtime.Convergence.PreviousObjective;

%% ========================================================================
%% Relative improvement
%% ========================================================================

Delta = Prev - Objective;

Relative = Delta / max(abs(Prev),eps);

%% ========================================================================
%% Default state
%% ========================================================================

State = "Running";

Finished = false;

%% ========================================================================
%% Numerical failure
%% ========================================================================

if isnan(Objective) || isinf(Objective)

    State = "NumericalFailure";

    Finished = true;

end

%% ========================================================================
%% Objective tolerance
%% ========================================================================

if ~Finished

    if Objective < TolObjective

        State = "Converged";

        Finished = true;

    end

end

%% ========================================================================
%% Relative improvement
%% ========================================================================

if ~Finished

    if Relative < TolRelative

        Runtime.Convergence.PlateauCounter = ...
            Runtime.Convergence.PlateauCounter + 1;

    else

        Runtime.Convergence.PlateauCounter = 0;

    end

end

%% ========================================================================
%% Plateau detection
%% ========================================================================

if ~Finished

    if Runtime.Convergence.PlateauCounter >= PlateauLimit

        State = "Plateau";

        Finished = true;

    end

end

%% ========================================================================
%% Maximum iteration
%% ========================================================================

if ~Finished

    if CurrentIter >= MaxIter

        State = "MaximumIteration";

        Finished = true;

    end

end

%% ========================================================================
%% Divergence detection
%% ========================================================================

if ~Finished

    if Objective > Prev * 5

        State = "Diverged";

        Finished = true;

    end

end

%% ========================================================================
%% Store
%% ========================================================================

Runtime.Convergence.State = State;

Runtime.Convergence.Finished = Finished;

Runtime.Convergence.Iteration = CurrentIter;

Runtime.Convergence.Objective = Objective;

Runtime.Convergence.PreviousObjective = Objective;

Runtime.Convergence.DeltaObjective = Delta;

Runtime.Convergence.RelativeImprovement = Relative;

Runtime.Flag.Converged = strcmp(State,"Converged");

Runtime.Flag.Diverged = any(strcmp(State, ...
    ["Diverged","NumericalFailure"]));

end