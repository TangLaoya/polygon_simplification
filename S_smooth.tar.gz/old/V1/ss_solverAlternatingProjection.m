function Runtime = ss_solverAlternatingProjection(Runtime, Problem, Engine)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_solverAlternatingProjection.m
%
% Description
% -------------------------------------------------------------------------
% Core iterative solver using Alternating Projection method.
%
% This module performs:
%   - iterative updates of S-parameters
%   - coordination with physics/reference/measurement projections
%
% No model construction is performed here.
%
%==========================================================================

%% ========================================================================
%% Initialization
%% ========================================================================

maxIter = Runtime.Iteration.Max;

freq = Problem.Frequency.Number;

S = Runtime.Network.Representation.S;

Z0 = Problem.Network.ReferenceImpedance;

Runtime.State.Residual = zeros(maxIter,1);
Runtime.State.Objective = zeros(maxIter,1);

%% ========================================================================
%% Iteration loop
%% ========================================================================

for k = 1:maxIter

    Runtime.Iteration.Current = k;

    %% --------------------------------------------------------------
    %% 1. Stable projection (Cayley / numerical stability)
    %% --------------------------------------------------------------

    % S = ss_projectStableCayley(S, Problem);
    Runtime.Network = ss_projectStableCayley( ...
                            Runtime.Network,...
                            Problem);    %% --------------------------------------------------------------
    %% 2. Physics projection
    %% --------------------------------------------------------------

    S = ss_projectPhysics(S, Problem);

    %% --------------------------------------------------------------
    %% 3. Measurement projection
    %% --------------------------------------------------------------

    S = ss_projectMeasurement(S, Problem);

    %% --------------------------------------------------------------
    %% 4. Update representation (via manager)
    %% --------------------------------------------------------------

    Runtime.Network.Representation.S = S;

    [Runtime.Network, S] = ss_getRepresentation( ...
                                Runtime.Network, ...
                                'S', ...
                                Problem);

    %% --------------------------------------------------------------
    %% 5. Residual computation
    %% --------------------------------------------------------------

    Runtime = ss_computeResidual(Runtime, Problem);

    %% --------------------------------------------------------------
    %% 6. Objective computation
    %% --------------------------------------------------------------

    Runtime = ss_computeObjective(Runtime, Problem);

    %% --------------------------------------------------------------
    %% 7. Convergence check
    %% --------------------------------------------------------------

    % if ss_checkConvergence(Runtime, Problem)
    % 
    %     Runtime.Flag.Converged = true;
    % 
    %     break;
    % 
    % end
    Runtime = ss_checkConvergence(Runtime, Problem);
    
    if Runtime.Convergence.Finished
        break;
    end
    %% --------------------------------------------------------------
    %% 8. History update
    %% --------------------------------------------------------------

    Runtime = ss_updateHistory(Runtime);

end

%% ========================================================================
%% Final update
%% ========================================================================

Runtime.Network.Representation.S = S;

end