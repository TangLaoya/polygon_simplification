function Option = ss_defaultOption()
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_defaultOption.m
%
% Description
% -------------------------------------------------------------------------
% Create immutable configuration for NSCP.
%
% This file contains ONLY user configurable parameters.
%
% No runtime state shall appear here.
%
%==========================================================================

Option = struct();

%% ========================================================================
%% Project Information
%% ========================================================================

Option.Project.Name = 'NSCP';

Option.Project.Version = '4.0 Final Freeze';

Option.Project.Author = '';

%% ========================================================================
%% Network
%% ========================================================================

Option.Network.ReferenceImpedance = 50;

Option.Network.MinimumFrequency = 0;

Option.Network.MaximumFrequency = inf;

%% ========================================================================
%% Reference Model
%% ========================================================================

Option.Reference.Enable = true;

Option.Reference.MinimumPoints = 21;

Option.Reference.MinimumBandwidth = 0.05;

Option.Reference.SmoothOrder = 3;

%% ========================================================================
%% Stable Projection
%% ========================================================================

Option.Stability.Enable = true;

Option.Stability.MaximumConditionNumber = 1e8;

Option.Stability.MinimumSingularValue = 1e-12;

Option.Stability.EnforceSymmetry = true;

Option.Stability.EnforceHermitian = false;

%% ========================================================================
%% Physics Projection
%% ========================================================================

Option.Physics.Enable = true;

Option.Physics.MaximumIteration = 10;

Option.Physics.RelativeTolerance = 1e-6;

%% ========================================================================
%% Measurement Projection
%% ========================================================================

Option.Measurement.Enable = true;

Option.Measurement.MinimumConfidence = 0.05;

Option.Measurement.MaximumConfidence = 0.95;

%% ========================================================================
%% Solver
%% ========================================================================

Option.Solver.Name = 'AlternatingProjection';

Option.Solver.MaximumIteration = 50;

Option.Solver.RelativeTolerance = 1e-8;

Option.Solver.AbsoluteTolerance = 1e-10;

%% ========================================================================
%% Residual
%% ========================================================================

Option.Residual.Weight.Stability = 1.0;

Option.Residual.Weight.Physics = 1.0;

Option.Residual.Weight.Measurement = 1.0;

%% ========================================================================
%% Convergence
%% ========================================================================

Option.Convergence.MinimumRelativeChange = 1e-8;

Option.Convergence.MinimumObjectiveChange = 1e-8;

Option.Convergence.MinimumResidual = 1e-10;

%% ========================================================================
%% Debug
%% ========================================================================

Option.Debug.Enable = true;

Option.Debug.Verbose = true;

Option.Debug.SaveHistory = true;

Option.Debug.PlotHistory = false;

end