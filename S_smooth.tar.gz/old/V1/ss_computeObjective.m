function Runtime = ss_computeObjective(Runtime, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_computeObjective.m
%
% Description
% -------------------------------------------------------------------------
% Compute global optimization objective.
%
% This module converts residual diagnostics into a scalar optimization
% energy used by the convergence controller.
%
% No projection or network modification is performed here.
%
%==========================================================================

%% ========================================================================
%% Residual
%% ========================================================================

Residual = Runtime.State.Residual;

Rs = Residual.StabilityResidual(:);

Rp = Residual.PhysicsResidual(:);

Rm = Residual.MeasurementResidual(:);

Nf = numel(Rs);

%% ========================================================================
%% Frequency-dependent confidence weights
%% ========================================================================

Cp = Problem.Reference.Confidence.Cp(:);

Cm = Problem.Reference.Confidence.Cm(:);

%% ========================================================================
%% Objective components
%% ========================================================================

Obj = struct();

Obj.Stability = sum(Rs.^2);

Obj.Physics = sum(Cp .* (Rp.^2));

Obj.Measurement = sum(Cm .* (Rm.^2));

%% ========================================================================
%% Global objective
%% ========================================================================

Obj.Total = ...
      Obj.Stability ...
    + Obj.Physics ...
    + Obj.Measurement;

Obj.RMS = sqrt(Obj.Total / max(Nf,1));

Obj.MaximumResidual = max(Residual.TotalResidual);

Obj.AverageResidual = mean(Residual.TotalResidual);

%% ========================================================================
%% Store
%% ========================================================================

Runtime.State.Objective = Obj;

end