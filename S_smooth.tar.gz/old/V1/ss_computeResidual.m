function Runtime = ss_computeResidual(Runtime, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_computeResidual.m
%
% Description
% -------------------------------------------------------------------------
% Compute unified residual of the current solution state.
%
% This module evaluates:
%   - Stability residual (numerical consistency)
%   - Physics residual (physical model mismatch)
%   - Measurement residual (data fidelity error)
%
% No modification of Network is performed.
%
%==========================================================================

%% ========================================================================
%% Extract Network state
%% ========================================================================

Network = Runtime.Network;

S = Network.Representation.S;

Smeas = Problem.Measurement.S;

Physics = Problem.Physics;

freq = Problem.Frequency.Vector;

Nf = Problem.Frequency.Number;

%% ========================================================================
%% Initialize residuals
%% ========================================================================

StabRes = zeros(Nf,1);
PhysRes = zeros(Nf,1);
MeasRes = zeros(Nf,1);

%% ========================================================================
%% Compute residuals
%% ========================================================================

for k = 1:Nf

    Sk = S(:,:,k);
    Sm = Smeas(:,:,k);

    %% --------------------------------------------------------------
    %% 1. Stability residual
    %% --------------------------------------------------------------

    eigvals = eig(Sk'*Sk);

    StabRes(k) = max(0, max(real(eigvals)) - 1);

    %% --------------------------------------------------------------
    %% 2. Physics residual
    %% --------------------------------------------------------------

    % RLGC consistency deviation
    if ~isempty(Physics.RLGC.R)

        Rref = Physics.RLGC.R(k);

        Zk = (eye(size(Sk)) + Sk) \ (eye(size(Sk)) - Sk);

        Rk = real(trace(Zk));

        PhysRes(k) = abs(Rk - Rref) / (abs(Rref) + eps);

    else

        PhysRes(k) = 0;

    end

    %% --------------------------------------------------------------
    %% 3. Measurement residual
    %% --------------------------------------------------------------

    MeasRes(k) = norm(Sk - Sm, 'fro');

end

%% ========================================================================
%% Weighted total residual
%% ========================================================================

ws = 0.3;
wp = 0.3;
wm = 0.4;

TotalRes = ws*StabRes + wp*PhysRes + wm*MeasRes;

%% ========================================================================
%% Frequency-weighted map
%% ========================================================================

FreqMap = normalize(TotalRes,'range');

%% ========================================================================
%% Store results
%% ========================================================================

Runtime.State.Residual = struct();

Runtime.State.Residual.StabilityResidual = StabRes;

Runtime.State.Residual.PhysicsResidual = PhysRes;

Runtime.State.Residual.MeasurementResidual = MeasRes;

Runtime.State.Residual.TotalResidual = TotalRes;

Runtime.State.Residual.FrequencyResidualMap = FreqMap;

end