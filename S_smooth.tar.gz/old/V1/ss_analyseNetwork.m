function Problem = ss_analyseNetwork(Problem, Network)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_analyseNetwork.m
%
% Description
% -------------------------------------------------------------------------
% Perform spectral and stability pre-analysis of the network.
%
% This module does NOT modify Network or perform any optimization.
% It only extracts numerical stability characteristics.
%
%==========================================================================

%% ========================================================================
%% Extract S-parameters
%% ========================================================================

S = Network.Representation.S;

freq = Problem.Frequency.Vector;

Nf = Problem.Frequency.Number;

%% ========================================================================
%% Initialize Analysis structure
%% ========================================================================

Analysis = struct();

Analysis.ConditionNumber = zeros(Nf,1);
Analysis.StabilityIndex   = zeros(Nf,1);
Analysis.SingularValueMax = zeros(Nf,1);
Analysis.SingularValueMin = zeros(Nf,1);

%% ========================================================================
%% Frequency-wise analysis
%% ========================================================================

for k = 1:Nf

    Sk = S(:,:,k);

    % Singular values
    sv = svd(Sk);

    Analysis.SingularValueMax(k) = max(sv);
    Analysis.SingularValueMin(k) = min(sv);

    % Condition number
    Analysis.ConditionNumber(k) = ...
        Analysis.SingularValueMax(k) / max(Analysis.SingularValueMin(k),eps);

    % Stability heuristic index (Cayley sensitivity proxy)
    Analysis.StabilityIndex(k) = log(Analysis.ConditionNumber(k) + 1);

end

%% ========================================================================
%% Frequency region detection
%% ========================================================================

cond = Analysis.ConditionNumber;

Analysis.LowFreqRegion  = find(freq < 0.2 * max(freq));
Analysis.HighFreqRegion = find(freq > 0.8 * max(freq));
Analysis.MidFreqRegion  = setdiff(1:Nf, ...
                                [Analysis.LowFreqRegion;
                                 Analysis.HighFreqRegion]);

%% ========================================================================
%% Frequency risk map
%% ========================================================================

Analysis.FrequencyRiskMap = normalize(cond, 'range');

%% ========================================================================
%% Store result in Problem (immutable extension)
%% ========================================================================

Problem.Analysis = Analysis;

end