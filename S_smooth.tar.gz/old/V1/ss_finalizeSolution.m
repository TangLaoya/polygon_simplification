function [Network, Summary] = ss_finalizeSolution(Runtime, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_finalizeSolution.m
%
% Description
% -------------------------------------------------------------------------
% Finalize optimization result.
%
% This is the ONLY module allowed to export the optimized network from
% Runtime to the outside world.
%
% No numerical optimization is performed here.
%
%==========================================================================

%% ========================================================================
%% Extract final network
%% ========================================================================

Network = Runtime.Network;

%% ========================================================================
%% Build summary
%% ========================================================================

Summary = struct();

Summary.Status = Runtime.Convergence.State;

Summary.Iteration = Runtime.Iteration.Current;

Summary.Objective = Runtime.State.Objective.Total;

Summary.RMS = Runtime.State.Objective.RMS;

Summary.MaximumResidual = ...
    Runtime.State.Objective.MaximumResidual;

Summary.AverageResidual = ...
    Runtime.State.Objective.AverageResidual;

%% ========================================================================
%% Timing
%% ========================================================================

Summary.StartTime = Runtime.Summary.TimeStart;

Summary.EndTime = Runtime.Summary.TimeFinish;

Summary.ElapsedTime = Runtime.Summary.ElapsedTime;

%% ========================================================================
%% Solver information
%% ========================================================================

Summary.Solver = struct();

Summary.Solver.Version = "NSCP v4.0 Final Freeze";

Summary.Solver.Algorithm = "Alternating Projection";

Summary.Solver.State = Runtime.Convergence.State;

%% ========================================================================
%% Frequency information
%% ========================================================================

Summary.Frequency = struct();

Summary.Frequency.Points = Problem.Frequency.Number;

Summary.Frequency.Start = Problem.Frequency.Vector(1);

Summary.Frequency.Stop = Problem.Frequency.Vector(end);

%% ========================================================================
%% Diagnostics
%% ========================================================================

if isfield(Network,'Diagnostics')

    Summary.Diagnostics = Network.Diagnostics;

else

    Summary.Diagnostics = struct();

end

%% ========================================================================
%% History statistics
%% ========================================================================

Summary.History = struct();

Summary.History.Iterations = ...
    numel(Runtime.History.Iteration);

Summary.History.FinalObjective = ...
    Runtime.History.Objective(end);

Summary.History.FinalResidual = ...
    Runtime.History.Residual(end);

%% ========================================================================
%% Final state
%% ========================================================================

Runtime.Final = struct();

Runtime.Final.Status = Summary.Status;

Runtime.Final.Objective = Summary.Objective;

Runtime.Final.Iteration = Summary.Iteration;

Runtime.Final.ElapsedTime = Summary.ElapsedTime;

end