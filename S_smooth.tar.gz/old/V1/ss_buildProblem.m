function Problem = ss_buildProblem(Measurement, Option)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_buildProblem.m
%
% Description
% -------------------------------------------------------------------------
% Build immutable optimization problem.
%
% Problem contains all information that never changes during optimization.
%
% Runtime data shall NEVER be stored here.
%
%==========================================================================

%% ========================================================================
%% Create problem structure
%% ========================================================================

Problem = struct();

%% ========================================================================
%% User option (immutable)
%% ========================================================================

Problem.Option = Option;

%% ========================================================================
%% Original measurement
%% ========================================================================

Problem.Measurement = Measurement;

%% ========================================================================
%% Frequency information
%% ========================================================================

Problem.Frequency = struct();

Problem.Frequency.Vector = Measurement.freq(:);

Problem.Frequency.Number = numel(Measurement.freq);

Problem.Frequency.Minimum = Measurement.freq(1);

Problem.Frequency.Maximum = Measurement.freq(end);

Problem.Frequency.Step = ...
    median(diff(Measurement.freq));

%% ========================================================================
%% Network information
%% ========================================================================

Problem.Network = struct();

Problem.Network.PortNumber = Measurement.PortNumber;

Problem.Network.ReferenceImpedance = Measurement.Z0;

Problem.Network.MatrixSize = ...
    [Measurement.PortNumber Measurement.PortNumber];

%% ========================================================================
%% Problem dimension
%% ========================================================================

Problem.Dimension = struct();

Problem.Dimension.Port = Measurement.PortNumber;

Problem.Dimension.Frequency = Problem.Frequency.Number;

Problem.Dimension.Matrix = ...
    Measurement.PortNumber^2;

%% ========================================================================
%% Analysis (filled by ss_analyseNetwork)
%% ========================================================================

Problem.Analysis = struct();

Problem.Analysis.Completed = false;

%% ========================================================================
%% Reference model (filled by ss_buildReferenceModel)
%% ========================================================================

Problem.Reference = struct();

Problem.Reference.Completed = false;

Problem.Reference.Model = [];

Problem.Reference.Confidence = [];

%% ========================================================================
%% Physics model (filled by ss_buildPhysicsModel)
%% ========================================================================

Problem.Physics = struct();

Problem.Physics.Completed = false;

Problem.Physics.Model = [];

%% ========================================================================
%% Solver information
%% ========================================================================

Problem.Solver = struct();

Problem.Solver.Name = Option.Solver.Name;

%% ========================================================================
%% Creation time
%% ========================================================================

Problem.CreatedTime = datetime("now");

end