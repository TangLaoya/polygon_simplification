function Runtime = ss_initializeRuntime(Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_initializeRuntime.m
%
% Description
% -------------------------------------------------------------------------
% Initialize execution runtime state.
%
% This module is responsible ONLY for creating runtime containers.
% No computation, projection, or modeling is allowed here.
%
%==========================================================================

%% ========================================================================
%% Create Runtime structure
%% ========================================================================

Runtime = struct();

%% ========================================================================
%% Iteration control
%% ========================================================================

Runtime.Iteration = struct();

Runtime.Iteration.Current = 0;

Runtime.Iteration.Max = Problem.Option.Solver.MaximumIteration;

%% ========================================================================
%% State variables
%% ========================================================================

Runtime.State = struct();

Runtime.State.Residual = [];

Runtime.State.Objective = [];

Runtime.State.Convergence = [];

%% ========================================================================
%% History buffers
%% ========================================================================

Runtime.History = struct();

Runtime.History.ResidualTrace = [];

Runtime.History.ObjectiveTrace = [];

%% ========================================================================
%% Flags
%% ========================================================================

Runtime.Flag = struct();

Runtime.Flag.Converged = false;

Runtime.Flag.Diverged = false;

%% ========================================================================
%% Logging system
%% ========================================================================

Runtime.Log = struct();

Runtime.Log.Verbose = Problem.Option.Debug.Verbose;

Runtime.Log.Messages = strings(0);

%% ========================================================================
%% Attach Problem snapshot (read-only reference)
%% ========================================================================

Runtime.Problem = Problem;

%% ========================================================================
%% Initialize Network placeholder
%% ========================================================================

Runtime.Network = [];

%% ========================================================================
%% Summary state
%% ========================================================================

Runtime.Summary = struct();

Runtime.Summary.Initialized = true;

Runtime.Summary.TimeStart = datetime("now");

end