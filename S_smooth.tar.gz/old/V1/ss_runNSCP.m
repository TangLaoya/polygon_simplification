function Result = ss_runNSCP(Measurement, Option)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_runNSCP.m
%
% Description
% -------------------------------------------------------------------------
% System-level orchestrator of NSCP framework.
%
% This module:
%   1. Builds Problem from Measurement
%   2. Builds Engine from Option
%   3. Initializes Runtime
%   4. Executes Solver
%   5. Returns Result
%
% No numerical algorithm is implemented here.
%
%==========================================================================

%% ========================================================================
%% Build Problem
%% ========================================================================

Problem = ss_buildProblem(Measurement, Option);

%% ========================================================================
%% Build Engine
%% ========================================================================

% Engine = ss_buildEngine(Option);
Engine = struct();
Engine.Algorithm  = "AlternatingProjection";
Engine.Name       = "NSCP Solver";
Engine.Version    = "4.0 Final Freeze";
Engine.Description = "Alternating Projection Solver";
%% ========================================================================

%% Initialize Network
%% ========================================================================
Network = ss_initializeNetwork(Problem);
disp(Network)
%% Initialize Runtime
%% ========================================================================

Runtime = ss_initializeRuntime(Problem);
Runtime.Network = Network;

%% ========================================================================
%% Execute Solver
%% ========================================================================

Runtime = ss_executeEngine( ...
                Runtime, ...
                Problem, ...
                Engine);

%% ========================================================================
%% Finalize Result
%% ========================================================================
[Network, Summary] = ss_finalizeSolution(Runtime, Problem);

%% Write Touchstone
writeSnP_simple( ...
    Option.Output.FileName, ...
    Problem.Frequency.Vector, ...
    Network.Representation.S);
end