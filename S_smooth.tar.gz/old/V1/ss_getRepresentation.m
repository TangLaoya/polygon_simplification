function [Network, Data] = ss_getRepresentation( ...
                                Network, ...
                                Name, ...
                                Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_getRepresentation.m
%
% Description
% -------------------------------------------------------------------------
% Unified representation manager.
%
% This is the ONLY module allowed to access or create matrix
% representations (S, Z, Y, ABCD, ...).
%
% Solver modules must never manipulate Representation directly.
%
%==========================================================================

arguments
    Network struct
    Name    char
    Problem struct
end

switch upper(Name)

    %======================================================================
    % S Representation
    %======================================================================
    case 'S'

        if ~Network.Valid.S

            if Network.Valid.Z

                Network.Representation.S = ...
                    ss_z2s( ...
                        Network.Representation.Z,...
                        Problem.Network.ReferenceImpedance);

            else

                error('No valid representation available to generate S.');

            end

            Network.Valid.S = true;

        end

        Data = Network.Representation.S;

    %======================================================================
    % Z Representation
    %======================================================================
    case 'Z'

        if ~Network.Valid.Z

            if Network.Valid.S

                Network.Representation.Z = ...
                    ss_s2z( ...
                        Network.Representation.S,...
                        Problem.Network.ReferenceImpedance);

            else

                error('No valid representation available to generate Z.');

            end

            Network.Valid.Z = true;

        end

        Data = Network.Representation.Z;

    %======================================================================
    % Unsupported
    %======================================================================
    otherwise

        error("Unsupported representation: %s",Name);

end

end