function Problem = ss_buildReferenceModel(Problem, Network)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_buildReferenceModel.m
%
% Description
% -------------------------------------------------------------------------
% Construct frequency-dependent reference model.
%
% This module defines the physical vs measurement confidence split.
%
% No optimization or projection is performed here.
%
%==========================================================================

%% ========================================================================
%% Extract inputs
%% ========================================================================

freq = Problem.Frequency.Vector;
Nf   = Problem.Frequency.Number;

Analysis = Problem.Analysis;

%% ========================================================================
%% Initialize Reference structure
%% ========================================================================

Reference = struct();

Reference.PhysicsModel = [];
Reference.MeasurementModel = [];

Cp = zeros(Nf,1);
Cm = zeros(Nf,1);

%% ========================================================================
%% Build confidence functions
%% ========================================================================

% Normalize stability index from analysis
stab = Analysis.StabilityIndex;
stab = (stab - min(stab)) / max(max(stab)-min(stab), eps);

for k = 1:Nf

    f = freq(k);

    % ----------------------------------------------------------
    % Physics confidence:
    % high in stable / low-frequency region
    % ----------------------------------------------------------

    Cp(k) = exp(-2 * stab(k)) * (1 - f / max(freq));

    % ----------------------------------------------------------
    % Measurement confidence:
    % high in unstable / high-frequency region
    % ----------------------------------------------------------

    Cm(k) = 1 - Cp(k);

end

%% ========================================================================
%% Normalize
%% ========================================================================

sumC = Cp + Cm + eps;

Cp = Cp ./ sumC;
Cm = Cm ./ sumC;

%% ========================================================================
%% Build weights
%% ========================================================================

Reference.Confidence = struct();

Reference.Confidence.Cp = Cp;
Reference.Confidence.Cm = Cm;

Reference.Weight = struct();

Reference.Weight.Wp = Cp;
Reference.Weight.Wm = Cm;

%% ========================================================================
%% Reference operator (conceptual)
%% ========================================================================

Reference.ReferenceOperator = @(Pphys,Pmeas,fidx) ...
    Cp(fidx).*Pphys + Cm(fidx).*Pmeas;

%% ========================================================================
%% Store result
%% ========================================================================

Problem.Reference = Reference;

end