function Network = ss_projectMeasurement(Network, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_projectMeasurement.m
%
% Description
% -------------------------------------------------------------------------
% Measurement fidelity projection.
%
% This module enforces consistency with measured S-parameters while
% preserving physical and numerical constraints already enforced by:
%
%   014 - Stability projection
%   015 - Physics projection
%
%==========================================================================

%% ========================================================================
%% Obtain S representation
%% ========================================================================

[Network, S] = ss_getRepresentation( ...
                    Network, ...
                    'S', ...
                    Problem);

Smeas = Problem.Measurement.S;

freq = Problem.Frequency.Vector;

Nf = size(S,3);

%% ========================================================================
%% Initialize error tracking
%% ========================================================================

Error = zeros(Nf,1);

%% ========================================================================
%% Measurement projection
%% ========================================================================

for k = 1:Nf

    Sk = S(:,:,k);
    Sm = Smeas(:,:,k);

    %------------------------------------------------------------
    % Frequency-dependent confidence
    %------------------------------------------------------------

    alpha = Problem.Reference.Confidence.Cm(k);

    %------------------------------------------------------------
    % Weighted projection toward measurement
    %------------------------------------------------------------

    Sproj = (1 - alpha)*Sk + alpha*Sm;

    %------------------------------------------------------------
    % Error tracking
    %------------------------------------------------------------

    Error(k) = norm(Sproj - Sm,'fro');

    %------------------------------------------------------------
    % Update
    %------------------------------------------------------------

    S(:,:,k) = Sproj;

end

%% ========================================================================
%% Store updated S
%% ========================================================================

Network.Representation.S = S;

Network.Valid.S = true;

%% ========================================================================
%% Attach measurement error diagnostics
%% ========================================================================

if ~isfield(Network,'Diagnostics')
    Network.Diagnostics = struct();
end

Network.Diagnostics.MeasurementError = Error;

Network.Diagnostics.MeasurementRMSE = sqrt(mean(Error.^2));

%% ========================================================================
%% Release dependent representations
%% ========================================================================

Network = ss_releaseRepresentation(Network,"Z");

end