function S = ss_z2s(Z,cfg)

Nf = size(Z,1);

N = size(Z,2);

I = eye(N);

S = zeros(size(Z));

for k = 1:Nf

    Zk = squeeze(Z(k,:,:));

    A = Zk/cfg.Z0 + I;

    if rcond(A) < 1/cfg.conditionLimit

        A = A + cfg.regularization*norm(A,'fro')*I;

    end

    Sk = (Zk/cfg.Z0 - I)/A;

    S(k,:,:) = Sk;

end

end