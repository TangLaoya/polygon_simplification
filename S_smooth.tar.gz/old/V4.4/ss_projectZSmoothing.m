function S = ss_projectZSmoothing(S,Problem)
%==========================================================================
% NSCP v4.4
% Z discontinuity suppression
%
% Only local correction
% Never change global S trend
%==========================================================================


cfg.Z0=Problem.Network.ReferenceImpedance;
cfg.conditionLimit=1e12;
cfg.regularization=1e-12;


Nf=size(S,1);



Z=zeros(size(S));


for k=1:Nf

    Z(k,:,:)=ss_s2z(reshape(S(k,:,:),...
        [1 size(S,2) size(S,3)]),cfg);

end



for k=2:Nf-1


    Zm=squeeze(Z(k-1,:,:));
    Z0=squeeze(Z(k,:,:));
    Zp=squeeze(Z(k+1,:,:));


    jump1=norm(Z0-Zm,'fro');
    jump2=norm(Zp-Z0,'fro');


    % abnormal jump detection

    if jump1>5*median([jump1 jump2])


        Zsmooth=(Zm+Zp)/2;


        % weak correction only

        Z(k,:,:)=0.9*Z0+0.1*Zsmooth;


    end

end



% back to S

for k=1:Nf

    S(k,:,:)=ss_z2s(reshape(Z(k,:,:),...
        [1 size(S,2) size(S,3)]),cfg);

end


end