function S = ss_projectPassivity(S)
%==========================================================================
% NSCP v4.4
% Strict S passivity projection
%==========================================================================


Nf=size(S,1);


for k=1:Nf


    Sk=squeeze(S(k,:,:));


    [U,D,V]=svd(Sk);


    s=diag(D);


    %------------------------------------
    % enforce |singular value| <= 1
    %------------------------------------

    s(s>0.999)=0.999;


    Sk=U*diag(s)*V';


    S(k,:,:)=Sk;


end


end