function Runtime = ss_solverAlternatingProjection(Runtime, Problem, Engine)
%==========================================================================
% NSCP v4.4
% S-domain master optimization
%
% S preserved
% Z used only as diagnostic field
%==========================================================================


maxIter = Runtime.Iteration.Max;

Network = Runtime.Network;


% original measurement anchor
Sref = Problem.Measurement.S;


for k = 1:maxIter


    Runtime.Iteration.Current = k;


    S = Network.Representation.S;


    %--------------------------------------------------
    % 1. Passivity projection
    %--------------------------------------------------
    S = ss_projectPassivity(S);



    %--------------------------------------------------
    % 2. Z smoothness guidance
    %--------------------------------------------------
    S = ss_projectZSmoothing(S,Problem);



    %--------------------------------------------------
    % 3. Measurement retention
    %--------------------------------------------------

    alpha = 0.05;

    S = (1-alpha)*S + alpha*Sref;



    Network.Representation.S = S;


    % Z only update for diagnostics
    cfg.Z0 = Problem.Network.ReferenceImpedance;
    cfg.conditionLimit = 1e12;
    cfg.regularization = 1e-12;


    Network.Representation.Z = ss_s2z(S,cfg);



    Runtime.Network = Network;



    Runtime = ss_computeResidual(Runtime,Problem);

    Runtime = ss_computeObjective(Runtime,Problem);



    Runtime = ss_checkConvergence(Runtime,Problem);



    if Runtime.Convergence.Finished
        break;
    end


    Runtime = ss_updateHistory(Runtime);


end


Runtime.Network = Network;


end