inputFile='Test_beforeFit.s26p';
s1=ss_readTouchstone(inputFile);s10=s1.S;
n=13;
n=4;
z10=ss_s2z(s10);
z1n=z10(:,n,n);s1n=s10(:,n,n);
inputFile='Test_beforeFit_ZRepair.s26p';
s2=ss_readTouchstone(inputFile);s20=s2.S;
z20=ss_s2z(s20);
z2n=z20(:,n,n);s2n=s20(:,n,n);

format long
ss=[s1.Frequency.Vector z1n abs(s1n) z2n abs(s2n)]