function [Srepair,Report] = ss_iterativeMatrixRepair( ...
                                    freq,...
                                    S,...
                                    Option)

%==============================================================
%
% NSCP V10.4
%
% Iterative Matrix Z Repair
%
% Multi-pass Trend Validation
%
%==============================================================


if nargin<3
    Option=struct();
end


%% default

if ~isfield(Option,'MaxIteration')
    Option.MaxIteration=5;
end


if ~isfield(Option,'ValidationIteration')
    Option.ValidationIteration=5;
end


if ~isfield(Option,'InitialThreshold')
    Option.InitialThreshold=4;
end


if ~isfield(Option,'FinalThreshold')
    Option.FinalThreshold=3;
end



Srepair=S;


fprintf('\n');
fprintf('==============================================================\n');
fprintf(' NSCP V10.4 Iterative Matrix Z Repair\n');
fprintf('==============================================================\n');



for iter=1:Option.MaxIteration


fprintf('\nIteration %d\n',iter);



%%==============================================================
%% Detect
%%==============================================================


Threshold=max(...
    Option.FinalThreshold,...
    Option.InitialThreshold-0.5*(iter-1));


DetectOption.Threshold=Threshold;



ZJumpReport=ss_detectMatrixZJump(...
        freq,...
        Srepair,...
        DetectOption);



if ZJumpReport.JumpNumber==0

    fprintf('No jump detected.\n');
    break;

end



fprintf('Detected %d jumps\n',...
    ZJumpReport.JumpNumber);



%%==============================================================
%% Repair candidate
%%==============================================================


Sold=Srepair;


[Srepair,CandidateReport]=...
    ss_repairMatrixSByJump(...
        freq,...
        Srepair,...
        ZJumpReport);



%%==============================================================
%% Multi-pass validation
%%==============================================================


fprintf('\n');
fprintf('Start Multi-pass Validation\n');


for v=1:Option.ValidationIteration


    [Srepair,ValidReport]=...
        ss_validateRepairTrend(...
            freq,...
            Sold,...
            Srepair,...
            CandidateReport.RepairIndex);



    fprintf('\nValidation pass %d\n',v);


    fprintf('Accepted : %d\n',...
        length(ValidReport.AcceptIndex));


    fprintf('Restored : %d\n',...
        length(ValidReport.RestoreIndex));



    %% no restore

    if isempty(ValidReport.RestoreIndex)

        break;

    end



    %% no change

    if norm(Srepair(:)-Sold(:))...
            /max(norm(Sold(:)),eps)<1e-12

        break;

    end



    %
    % IMPORTANT:
    % restored result becomes new reference
    %

    Sold=Srepair;



end



%%==============================================================
%% convergence
%%==============================================================


Delta=norm(Srepair(:)-Sold(:))...
    /max(norm(Sold(:)),eps);



fprintf('\n');
fprintf('Iteration %d Delta %.3e\n',...
        iter,...
        Delta);



if Delta<1e-8

    break;

end



end



fprintf('\n');
fprintf('==============================================================\n');
fprintf(' Iterative repair finished\n');
fprintf('==============================================================\n');



Report.Iteration=iter;


end