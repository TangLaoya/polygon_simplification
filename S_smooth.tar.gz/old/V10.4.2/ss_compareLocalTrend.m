function score=...
ss_compareLocalTrend(freq,S,idx)


%==============================================================
%
% Local multi-domain trend consistency
%
%==============================================================


[Nf,~,~]=size(S);



if idx<=2 || idx>=Nf-1

    score=0;
    return;

end



%% four neighboring points

I=[idx-2 idx-1 idx idx+1 idx+2];


X=log(freq(I));


Y=S(I,:,:);



score=0;



%%--------------------------------
% Matrix S domain
%%--------------------------------

for p=1:size(S,2)

for q=1:size(S,3)


    y=squeeze(Y(:,p,q));


    % first derivative

    d1=diff(y);


    % second derivative

    d2=diff(d1);



    % center curvature

    c=abs(d2(2));



    % normalized

    scale=max(abs(y))+eps;


    score=max(score,...
        c/scale);



end

end



%%--------------------------------
% Z domain
%%--------------------------------

Z=...
ss_s2z(squeeze(Y));


Amp=abs(Z);

Ph=unwrap(angle(Z));



for domain={Amp,Ph}


    A=domain{1};


    d1=diff(A);

    d2=diff(d1);



    scale=max(abs(A(:)))+eps;


    score=max(score,...
        abs(d2(2))/scale);


end


end