function [Sout,Report]=...
ss_validateRepairTrendIterative(...
        freq,...
        Soriginal,...
        Srepair,...
        RepairIndex,...
        Option)

%==============================================================
%
% NSCP V10.4
%
% Iterative Trend Restore Validation
%
%==============================================================


if nargin<5
    Option=struct();
end


if ~isfield(Option,'MaxRestoreIteration')
    Option.MaxRestoreIteration=10;
end


Sout=Srepair;


CurrentIndex=RepairIndex(:);


Report.Iteration=0;

Report.AcceptIndex=[];
Report.RestoreIndex=[];


fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.4 Trend Validation\n');
fprintf('========================================\n');


for iter=1:Option.MaxRestoreIteration


    if isempty(CurrentIndex)
        break;
    end


    Restore=[];


    for k=1:length(CurrentIndex)


        idx=CurrentIndex(k);



        %% local trend check

        OldPoint=Sout(idx,:,:);


        score=...
        ss_compareLocalTrend(...
            freq,...
            Sout,...
            idx);



        if score>1


            Restore(end+1)=idx;


            fprintf(...
            'Restore point %d : trend violation %.3f\n',...
            idx,...
            score);


        end


    end



    %% no violation

    if isempty(Restore)

        break;

    end



    %% restore

    for k=1:length(Restore)

        idx=Restore(k);

        Sout(idx,:,:)=...
            Soriginal(idx,:,:);

    end



    %% remove restored

    CurrentIndex=...
        setdiff(CurrentIndex,Restore);



end



Report.AcceptIndex=CurrentIndex;

Report.AcceptNumber=length(CurrentIndex);

Report.RestoreIndex=...
    setdiff(RepairIndex,CurrentIndex);

Report.RestoreNumber=...
    length(Report.RestoreIndex);


Report.Iteration=iter;


fprintf('\n');

fprintf('Accepted : %d\n',...
    Report.AcceptNumber);

fprintf('Restored : %d\n',...
    Report.RestoreNumber);

fprintf('========================================\n');


end