function Zdc = ss_buildInitialDC(freq,Z,detect,cfg)

N=size(Z,2);

M=detect.Mopt;

Zdc=zeros(N,N);

for i=1:N

    for j=1:N

        Zij=squeeze(Z(:,i,j));

        info=detect.fitInfo{i,j};

        fref=info.referenceFrequency;

        Zref=info.referenceValue;

        R0=real(Zref);

        X0=imag(Zref);

        %% ----------------------------
        % purely resistive
        %% ----------------------------

        if info.resistive

            Zdc(i,j)=R0;

            continue;

        end

        %% ----------------------------
        % capacitive
        %% ----------------------------

        if info.capacitive

            C=-1/(2*pi*fref*X0);

            fdc=freq(1);

            Xdc=-1/(2*pi*fdc*C);

            Zdc(i,j)=R0+1i*Xdc;

            continue;

        end

        %% ----------------------------
        % inductive
        %% ----------------------------

        if info.inductive

            L=X0/(2*pi*fref);

            fdc=freq(1);

            Xdc=2*pi*fdc*L;

            Zdc(i,j)=R0+1i*Xdc;

        end

    end

end

end