function [Sout,Report]=ss_validateRepairTrend(...
                freq,...
                Sold,...
                Snew,...
                RepairIndex,...
                Option)

%==============================================================
%
% NSCP V10.5
%
% Diagnostic Trend Validation
%
%==============================================================


if nargin<5
    Option=struct();
end


if ~isfield(Option,'CurvatureLimit')
    Option.CurvatureLimit=5;
end


Sout=Snew;


Report.AcceptIndex=[];
Report.RestoreIndex=[];
Report.Reason={};



for idx=RepairIndex(:)'


    fprintf('\n');
    fprintf('----------------------------------------\n');
    fprintf('Validate point %d\n',idx);
    fprintf('----------------------------------------\n');


    Reject=false;

    Reason={};



    %% window

    k1=max(1,idx-2);
    k2=min(size(Sold,1),idx+2);



    %%----------------------------------------------------------
    % S magnitude
    %%----------------------------------------------------------

    [flag,msg]=...
        ss_validateOneCurve(...
        abs(Sold(k1:k2,:,:)),...
        abs(Snew(k1:k2,:,:)),...
        'S Magnitude',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end



    %%----------------------------------------------------------
    % S phase
    %%----------------------------------------------------------

    Pold=unwrap(angle(Sold(k1:k2,:,:)),[],1);

    Pnew=unwrap(angle(Snew(k1:k2,:,:)),[],1);


    [flag,msg]=...
        ss_validateOneCurve(...
        Pold,...
        Pnew,...
        'S Phase',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end



    %%----------------------------------------------------------
    % Z domain
    %%----------------------------------------------------------

    Zold=ss_s2z(Sold(k1:k2,:,:));

    Znew=ss_s2z(Snew(k1:k2,:,:));


    [flag,msg]=...
        ss_validateOneCurve(...
        real(Zold),...
        real(Znew),...
        'Z Real',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end


    [flag,msg]=...
        ss_validateOneCurve(...
        imag(Zold),...
        imag(Znew),...
        'Z Imag',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end



    %%----------------------------------------------------------
    % decision
    %%----------------------------------------------------------

    if Reject


        Sout(idx,:,:)=Sold(idx,:,:);


        Report.RestoreIndex(end+1)=idx;


        fprintf('Restore point %d\n',idx);


        for k=1:length(Reason)

            fprintf('%s\n',Reason{k});

        end


    else


        Report.AcceptIndex(end+1)=idx;


        fprintf('Accept point %d\n',idx);


    end


end



Report.AcceptNumber=...
    length(Report.AcceptIndex);

Report.RestoreNumber=...
    length(Report.RestoreIndex);



fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.5 Trend Validation\n');
fprintf('========================================\n');

fprintf('Accepted : %d\n',...
    Report.AcceptNumber);

fprintf('Restored : %d\n',...
    Report.RestoreNumber);

fprintf('========================================\n');


end