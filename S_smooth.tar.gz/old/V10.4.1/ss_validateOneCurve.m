function [Reject,Message]=...
    ss_validateOneCurve(...
    Old,...
    New,...
    Name,...
    Index,...
    Option)


Reject=false;

Message='';



%% 一阶差分

Dold=diff(Old,1,1);

Dnew=diff(New,1,1);



%% 二阶曲率

Cold=diff(Dold,1,1);

Cnew=diff(Dnew,1,1);



ratio=...
    norm(Cnew(:),'fro') / ...
    max(norm(Cold(:),'fro'),eps);



if ratio > Option.CurvatureLimit


    Reject=true;


    Message=sprintf(...
    ['Reason: %s\n',...
     'Index : %d\n',...
     'New curvature ratio : %.3f'],...
     Name,...
     Index,...
     ratio);


    return;

end



end