function s_parameter_smoothing_causal()
%==============================================================
%
% NSCP V9.8.2
%
% Matrix Trend Edition
%
% Phase 1
%
% Trend Verification
%
%==============================================================

clc;
clear;

fprintf('\n');
fprintf('==============================================================\n');
fprintf('               NSCP V9.8.2\n');
fprintf('          Matrix Trend Edition\n');
fprintf('      Phase 1 : Trend Verification\n');
fprintf('==============================================================\n\n');

%%------------------------------------------------------------
% Input
%%------------------------------------------------------------

inputFile='Test_beforeFit.s26p';

fprintf('Input File : %s\n',inputFile);

%%------------------------------------------------------------
% Read Touchstone
%%------------------------------------------------------------

Measurement=ss_readTouchstone(inputFile);

fprintf('Frequency Points : %d\n', ...
    Measurement.Frequency.Number);

fprintf('Port Number      : %d\n', ...
    Measurement.Network.PortNumber);

%%------------------------------------------------------------
% V10.0 Iterative Matrix Z Repair
%%------------------------------------------------------------

RepairOption = struct();
RepairOption.MaxIteration = 5;
RepairOption.ConvergenceTol = 1e-6;
RepairOption.InitialThreshold = 4.0;
RepairOption.FinalThreshold = 3.0;

[Measurement.S,IterReport] = ss_iterativeMatrixRepair( ...
    Measurement.Frequency.Vector,...
    Measurement.S,...
    RepairOption);

%% optional export

writeSnP_simple( ...
    'Test_beforeFit_ZRepair.s26p',...
    Measurement.Frequency.Vector,...
    Measurement.S,...
    Measurement.Params);

%%------------------------------------------------------------
% Trend Option
%%------------------------------------------------------------

TrendOption=struct();

TrendOption.Lambda=5e-2;

TrendOption.NormalWeight=1;

TrendOption.JumpWeight=0.10;

TrendOption.JumpIndex=[];

%%------------------------------------------------------------
% Trend Solve
%%------------------------------------------------------------

[Trend,...
 Residual,...
 Info]=ss_matrixTrendSolver( ...
    Measurement.Frequency.Vector,...
    Measurement.S,...
    TrendOption);

%%------------------------------------------------------------
% Export Trend
%%------------------------------------------------------------

fprintf('\n');
fprintf('Export Trend...\n');

writeSnP_simple( ...
    'Test_beforeFit_Trend.s26p',...
    Measurement.Frequency.Vector,...
    Trend,...
    Measurement.Params);

%%------------------------------------------------------------
% Export Residual
%%------------------------------------------------------------

fprintf('Export Residual...\n');

writeSnP_simple( ...
    'Test_beforeFit_Residual.s26p',...
    Measurement.Frequency.Vector,...
    Residual,...
    Measurement.Params);

%%------------------------------------------------------------
% Statistics
%%------------------------------------------------------------

fprintf('\n');
fprintf('========================================\n');

fprintf('Trend RMSE      : %.6e\n', ...
    Info.RMSE);

fprintf('Relative Error  : %.6e\n', ...
    Info.RelativeError);

fprintf('Minimum RCOND   : %.6e\n', ...
    Info.RCOND);

fprintf('========================================\n');

fprintf('\n');

fprintf('Generated Files:\n');

fprintf('  Test_beforeFit_Trend.s26p\n');

fprintf('  Test_beforeFit_Residual.s26p\n');

fprintf('\n');

fprintf('Trend verification finished.\n');

end
function scl = getScale(unit)
    switch upper(unit)
        case 'HZ', scl=1;
        case 'KHZ', scl=1e3;
        case 'MHZ', scl=1e6;
        case 'GHZ', scl=1e9;
        otherwise, error('未知频率单位');
    end
end
function writeSnP_simple(filename, freq, S, params)
    fid = fopen(filename, 'w');
    Nport = size(S,2); Nf = size(S,1);
    fprintf(fid, '# %s %s %s R %.1f\n', params.freq_unit, params.param_type, params.format_type, params.R0);
    fprintf(fid, '! Z-domain low-frequency extrapolation with log-linear interpolation\n');
    fprintf(fid, '! Ports: %d, Frequencies: %d\n', Nport, Nf);
    outScale = 1;
    switch upper(params.freq_unit)
        case 'KHZ', outScale=1e-3;
        case 'MHZ', outScale=1e-6;
        case 'GHZ', outScale=1e-9;
    end
    for k = 1:Nf
        fprintf(fid, '%.8e ', freq(k)*outScale);
        for i = 1:Nport
            for j = 1:Nport
                val = S(k,i,j);
                switch params.format_type
                    case 'RI'
                        fprintf(fid, '%.10e %.10e ', real(val), imag(val));
                    case 'MA'
                        fprintf(fid, '%.10e %.10e ', abs(val), angle(val)*180/pi);
                    case 'DB'
                        db = -1e3;
                        if abs(val)>0, db=20*log10(abs(val)); end
                        fprintf(fid, '%.10e %.10e ', db, angle(val)*180/pi);
                end
            end
        end
        fprintf(fid, '\n');
    end
    fclose(fid);
end

function ss_writeTouchstone(filename, Network, Params)
S = Network.S;
freq = Network.Frequency;
writeSnP_simple(filename, freq, S, Params);
end

function Measurement = ss_readTouchstone(filename)
% 读取 Touchstone 并转换为标准 Measurement 结构
[freq, S, params] = readSnP_simple(filename);
Measurement = struct();
Measurement.File = filename;
Measurement.Frequency.Vector = freq(:);
Measurement.Frequency.Number = numel(freq);
Measurement.S = S;
Measurement.Network.PortNumber = size(S,2);
Measurement.Network.ReferenceImpedance = params.R0;
Measurement.Params = params;
end

function [freq, S, params] = readSnP_simple(filename)
    fid = fopen(filename, 'r');
    assert(fid ~= -1, '无法打开文件: %s', filename);
    wholeFile = fread(fid, '*char')';
    fclose(fid);
    hashLine = regexp(wholeFile, '#[^\n\r]*', 'match', 'once');
    if isempty(hashLine), error('未找到 # 选项行'); end
    tokens = strsplit(strtrim(hashLine));
    freq_unit = upper(tokens{2});
    param_type = tokens{3};
    format_type = upper(tokens{4});
    R0 = 50;
    for k = 5:numel(tokens)-1
        if strcmpi(tokens{k}, 'R')
            R0 = str2double(tokens{k+1}); break;
        end
    end
    Nport_declared = str2double(regexp(wholeFile, '\[Number of Ports\]\s*(\d+)', 'tokens', 'once'));
    if isempty(Nport_declared)
        Nport_declared = str2double(regexp(wholeFile, '\Ports:\s*(\d+)', 'tokens', 'once'));
    end
    startIdx = strfind(wholeFile, '[Network Data]');

    % if isempty(startIdx), error('缺少 [Network Data]'); end
    if isempty(startIdx)
        startIdx = strfind(wholeFile, 'Frequencies:');
        offset=1;
    else
        offset=0;
    end
    dataStr = wholeFile(startIdx+14:end);
    endIdx = strfind(dataStr, '[End of Data]');
    if ~isempty(endIdx), dataStr(endIdx:end) = []; end

    dataStr = regexprep(dataStr, '!.*?\n', ' ');
    allNums = sscanf(dataStr, '%f');
    allNums=allNums(offset+1:end);
    totalNums = length(allNums);
    if isempty(Nport_declared)
        Nport = sqrt((totalNums - 1)/2);
        if mod(Nport,1)~=0, error('无法推断端口数'); end
    else
        Nport = Nport_declared;
    end
    inferredNf = floor(totalNums / (1 + 2*Nport^2));
    if inferredNf < 1, error('数据量不足'); end
    Nfreq = inferredNf;
    validNums = Nfreq * (1 + 2*Nport^2);
    allNums = allNums(1:validNums);
    scale = getScale(freq_unit);
    freq = zeros(Nfreq,1); S = zeros(Nfreq,Nport,Nport);
    idx = 1;
    for k = 1:Nfreq
        freq(k) = allNums(idx) * scale;
        idx = idx+1;
        for i = 1:Nport
            for j = 1:Nport
                a = allNums(idx); b = allNums(idx+1);
                switch format_type
                    case 'RI', S(k,i,j) = a + 1i*b;
                    case 'MA', S(k,i,j) = a.*exp(1i*b*pi/180);
                    case 'DB', S(k,i,j) = 10^(a/20).*exp(1i*b*pi/180);
                end
                idx = idx+2;
            end
        end
    end
    params = struct('R0',R0,'param_type',param_type,'format_type',format_type,'freq_unit',freq_unit,'scale',scale);
end
function [Srepair,Report] = ss_iterativeMatrixRepair( ...
                                    freq,...
                                    S,...
                                    Option)

%==============================================================
%
% NSCP V10.1
%
% Iterative Matrix Z Repair
%
% Detection
% Repair
% Validation
%
%==============================================================


if nargin<3
    Option=struct();
end


if ~isfield(Option,'MaxIteration')
    Option.MaxIteration=5;
end


if ~isfield(Option,'ConvergenceTol')
    Option.ConvergenceTol=1e-6;
end


if ~isfield(Option,'Threshold')
    Option.Threshold=4;
end


Srepair=S;


Report.Iteration=0;



fprintf('\n');
fprintf('==============================================================\n');
fprintf(' NSCP V10.1 Iterative Matrix Z Repair\n');
fprintf('==============================================================\n');



for iter=1:Option.MaxIteration


    fprintf('\nIteration %d\n',iter);



    %%-----------------------------------------
    % Z jump detection
    %%-----------------------------------------

    DetectOption.Threshold=Option.Threshold;


    ZJumpReport=ss_detectMatrixZJump(...
        freq,...
        Srepair,...
        DetectOption);



    if ZJumpReport.JumpNumber==0

        fprintf('No jump detected.\n');

        break;

    end



    fprintf('Detected %d jumps\n',...
        ZJumpReport.JumpNumber);



    %%-----------------------------------------
    % repair candidate
    %%-----------------------------------------

    Sold=Srepair;
    
    
    [Srepair,RepairReport] = ss_repairMatrixSByJump( ...
            freq,...
            Srepair,...
            ZJumpReport);
    
    %%------------------------------------------------------
    % Trend protection validation
    %%------------------------------------------------------
    
    
    % [Srepair,ValidReport]=...
    %     ss_validateMonotonicTrend(...
    %         freq,...
    %         Sold,...
    %         Srepair,...
    %         RepairReport.RepairIndex,...
    %         struct());
    
    [Srepair,ValidReport]=...
        ss_validateRepairTrend(...
            freq,...
            Sold,...
            Srepair,...
            RepairReport.RepairIndex);    
    
    
    RepairReport.Validation=ValidReport;
    
    RepairReport.Valid=ValidReport;    
    
    Delta=norm(Srepair(:)-Sold(:))...
        /max(norm(Sold(:)),eps);



    Report.History(iter).JumpIndex=...
        ZJumpReport.JumpIndex;


    Report.History(iter).RepairIndex=...
        ValidReport.AcceptIndex;


    Report.History(iter).RejectIndex=...
        ValidReport.RestoreIndex;


    Report.History(iter).Delta=Delta;



    fprintf('Accepted : %d\n',...
        length(ValidReport.AcceptIndex));


    fprintf('Rejected : %d\n',...
        length(ValidReport.RestoreIndex));


    fprintf('Delta : %.3e\n',Delta);



    if Delta<Option.ConvergenceTol

        break;

    end
end
Report.Iteration=iter;
fprintf('\n');
fprintf('==============================================================\n');
fprintf(' Iterative repair finished\n');
fprintf('==============================================================\n');
end
function Report=...
ss_detectMatrixZJump(...
freq,...
S,...
Option)

%==============================================================
%
% NSCP V9.9
%
% Matrix Z Jump Detector
%
% Detection only
%
%==============================================================

if nargin<3
    Option=struct();
end

if ~isfield(Option,'Threshold')
    Option.Threshold=4.0;
end

freq=freq(:);

[Nf,N,~]=size(S);

Z=ss_s2z(S);

Score=zeros(Nf,1);

%%----------------------------------------------------------
%% Interior Prediction
%%----------------------------------------------------------

for k=2:Nf-1

    f1=freq(k-1);

    f2=freq(k);

    f3=freq(k+1);

    wL=(f3-f2)/(f3-f1);

    wR=(f2-f1)/(f3-f1);

    Zpredict=...
        wL*squeeze(Z(k-1,:,:))...
       +wR*squeeze(Z(k+1,:,:));

    D=squeeze(Z(k,:,:))-Zpredict;

    Score(k)=norm(D(:),'fro');

end

%%----------------------------------------------------------
%% Robust Scale
%%----------------------------------------------------------

Valid=Score(2:end-1);

MedianScore=median(Valid);

MADScore=mad(Valid,1);

if MADScore<eps
    MADScore=eps;
end

Normalized=(Score-MedianScore)/MADScore;

%%----------------------------------------------------------
%% Local Maximum
%%----------------------------------------------------------

Jump=false(Nf,1);

for k=3:Nf-2

    if Normalized(k)>Option.Threshold

        if Score(k)>Score(k-1) && Score(k)>=Score(k+1)

            Jump(k)=true;

        end

    end

end

%%----------------------------------------------------------
%% Report
%%----------------------------------------------------------

Report.Score=Score;

Report.NormalizedScore=Normalized;

Report.JumpIndex=find(Jump);

Report.JumpNumber=length(Report.JumpIndex);

%%----------------------------------------------------------
%% Print
%%----------------------------------------------------------

fprintf("\n");

fprintf("========================================\n");

fprintf(" NSCP V9.9 Matrix Z Jump Detector\n");

fprintf("========================================\n");

fprintf("Detected Jump Points : %d\n", Report.JumpNumber);

fprintf("Median Score : %.6e\n",MedianScore);

fprintf("MAD          : %.6e\n",MADScore);

fprintf("\n");

if Report.JumpNumber>0

    fprintf("Jump List\n");

    fprintf("----------------------------------------\n");

    for n=1:Report.JumpNumber

        k=Report.JumpIndex(n);

        fprintf("%4d  f=%12.6e   Score=%12.5e\n", k, freq(k), Score(k));

    end

end

fprintf("========================================\n");

end
function Z = ss_s2z(S,Z0)
%==============================================================
%
% NSCP V9.9
%
% S -> Z
%
% Whole Matrix
%
%==============================================================

if nargin<2
    Z0=50;
end

[Nf,N,~]=size(S);

I=eye(N);

Z=zeros(size(S));

for k=1:Nf

    Sk=squeeze(S(k,:,:));

    A=I+Sk;

    B=I-Sk;

    Z(k,:,:)=Z0*(A/B);

end

end
function [Srepair,Report]=...
ss_repairMatrixSByJump(...
freq,...
S,...
JumpReport)

%==============================================================
%
% NSCP V9.9
%
% Matrix S Repair
%
% Jump detected in Z
%
% Repair performed in S
%
%==============================================================

freq=freq(:);

[Nf,N,~]=size(S);

Srepair=S;

JumpIndex=JumpReport.JumpIndex(:);

RepairNumber=0;

%%------------------------------------------------------------
%% Repair
%%------------------------------------------------------------

for n=1:length(JumpIndex)

    k=JumpIndex(n);

    %% cannot repair boundary

    if k<=1
        continue;
    end

    if k>=Nf
        continue;
    end

    %% frequency weighted interpolation

    f1=freq(k-1);

    f2=freq(k);

    f3=freq(k+1);

    wL=(f3-f2)/(f3-f1);

    wR=(f2-f1)/(f3-f1);

    %% whole matrix

    Srepair(k,:,:)=...
        wL*Srepair(k-1,:,:)...
      + wR*Srepair(k+1,:,:);

    RepairNumber=RepairNumber+1;

end

%%------------------------------------------------------------
%% Report
%%------------------------------------------------------------

Report.RepairNumber=RepairNumber;

Report.RepairIndex=JumpIndex;

fprintf("\n");

fprintf("========================================\n");

fprintf(" NSCP V9.9 Matrix S Repair\n");

fprintf("========================================\n");

fprintf("Repair Number : %d\n",RepairNumber);

fprintf("\n");

if RepairNumber>0

    fprintf("Repair Points\n");

    fprintf("----------------------------------------\n");

    fprintf("%d ",JumpIndex);

    fprintf("\n");

end

fprintf("========================================\n");

end
function [Sout,Report]=ss_validateRepairTrend(...
                freq,...
                Sold,...
                Snew,...
                RepairIndex,...
                Option)

%==============================================================
%
% NSCP V10.5
%
% Diagnostic Trend Validation
%
%==============================================================


if nargin<5
    Option=struct();
end


if ~isfield(Option,'CurvatureLimit')
    Option.CurvatureLimit=5;
end


Sout=Snew;


Report.AcceptIndex=[];
Report.RestoreIndex=[];
Report.Reason={};



for idx=RepairIndex(:)'


    fprintf('\n');
    fprintf('----------------------------------------\n');
    fprintf('Validate point %d\n',idx);
    fprintf('----------------------------------------\n');


    Reject=false;

    Reason={};



    %% window

    k1=max(1,idx-2);
    k2=min(size(Sold,1),idx+2);



    %%----------------------------------------------------------
    % S magnitude
    %%----------------------------------------------------------

    [flag,msg]=...
        ss_validateOneCurve(...
        abs(Sold(k1:k2,:,:)),...
        abs(Snew(k1:k2,:,:)),...
        'S Magnitude',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end



    %%----------------------------------------------------------
    % S phase
    %%----------------------------------------------------------

    Pold=unwrap(angle(Sold(k1:k2,:,:)),[],1);

    Pnew=unwrap(angle(Snew(k1:k2,:,:)),[],1);


    [flag,msg]=...
        ss_validateOneCurve(...
        Pold,...
        Pnew,...
        'S Phase',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end



    %%----------------------------------------------------------
    % Z domain
    %%----------------------------------------------------------

    Zold=ss_s2z(Sold(k1:k2,:,:));

    Znew=ss_s2z(Snew(k1:k2,:,:));


    [flag,msg]=...
        ss_validateOneCurve(...
        real(Zold),...
        real(Znew),...
        'Z Real',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end


    [flag,msg]=...
        ss_validateOneCurve(...
        imag(Zold),...
        imag(Znew),...
        'Z Imag',...
        idx,...
        Option);


    if flag

        Reject=true;
        Reason{end+1}=msg;

    end



    %%----------------------------------------------------------
    % decision
    %%----------------------------------------------------------

    if Reject


        Sout(idx,:,:)=Sold(idx,:,:);


        Report.RestoreIndex(end+1)=idx;


        fprintf('Restore point %d\n',idx);


        for k=1:length(Reason)

            fprintf('%s\n',Reason{k});

        end


    else


        Report.AcceptIndex(end+1)=idx;


        fprintf('Accept point %d\n',idx);


    end


end



Report.AcceptNumber=...
    length(Report.AcceptIndex);

Report.RestoreNumber=...
    length(Report.RestoreIndex);



fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.5 Trend Validation\n');
fprintf('========================================\n');

fprintf('Accepted : %d\n',...
    Report.AcceptNumber);

fprintf('Restored : %d\n',...
    Report.RestoreNumber);

fprintf('========================================\n');


end
function [Reject,Message]=...
    ss_validateOneCurve(...
    Old,...
    New,...
    Name,...
    Index,...
    Option)


Reject=false;

Message='';



%% 一阶差分

Dold=diff(Old,1,1);

Dnew=diff(New,1,1);

%% 二阶曲率

Cold=diff(Dold,1,1);

Cnew=diff(Dnew,1,1);
ratio=...
    norm(Cnew(:),'fro') / ...
    max(norm(Cold(:),'fro'),eps);
if ratio > Option.CurvatureLimit
    Reject=true;
    Message=sprintf(...
    ['Reason: %s\n',...
     'Index : %d\n',...
     'New curvature ratio : %.3f'],...
     Name,...
     Index,...
     ratio);
    return;
end
end
function [Trend,Residual,Info] = ss_matrixTrendSolver( ...
                                    freq,...
                                    S,...
                                    Option)
%==============================================================
%
% NSCP V9.8.2
%
% Matrix Trend Edition
%
% Solve
%
%     min ||W(S-T)||² + λ||D2*T||²
%
% ==> (W+λL)T = WS
%
% Whole matrix solved together
%
%==============================================================

%%------------------------------------------------------------
% default option
%%------------------------------------------------------------

if nargin<3
    Option=struct();
end

if ~isfield(Option,'Lambda')
    Option.Lambda=5e-2;
end

if ~isfield(Option,'JumpIndex')
    Option.JumpIndex=[];
end

if ~isfield(Option,'NormalWeight')
    Option.NormalWeight=1.0;
end

if ~isfield(Option,'JumpWeight')
    Option.JumpWeight=0.10;
end

if ~isfield(Option,'BoundaryAnchor')
    Option.BoundaryAnchor=0.20;
end
lambda = Option.Lambda;

%%------------------------------------------------------------
% size
%%------------------------------------------------------------

[Nf,Nport,~] = size(S);

Nc = Nport*Nport;

%%------------------------------------------------------------
% reshape
%
% Nf × Nc
%
%%------------------------------------------------------------

Y = reshape(S,Nf,Nc);

%%------------------------------------------------------------
% build operator
%%------------------------------------------------------------

%%------------------------------------------------------------
% Adaptive Weight
%%------------------------------------------------------------

[W,...
 Weight,...
 Deviation,...
 Boundary]=...
    ss_buildAdaptiveWeight(...
        freq,...
        S,...
        Option);

%%------------------------------------------------------------
% Regularization
%%------------------------------------------------------------

L = ss_buildRegularization( ...
        freq,...
        Boundary);

[Aanchor,...
 AnchorY]=...
ss_buildBoundaryAnchor(...
Boundary,...
Nf,...
Option.BoundaryAnchor,...
Y);

Info.Weight=Weight;
Info.Deviation=Deviation;
Info.Boundary=Boundary;
%%------------------------------------------------------------
% linear system
%%------------------------------------------------------------

A = W + lambda*L + Aanchor;
%%------------------------------------------------------------
% numerical stabilization
%%------------------------------------------------------------

A = A + 1e-12*speye(Nf);

Info.RCOND = rcond(full(A));

fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V9.8.2 Matrix Trend Solver\n');
fprintf('========================================\n');
fprintf('Lambda        : %.3e\n',lambda);
fprintf('Unknowns      : %d\n',Nc);
fprintf('Minimum RCOND : %.3e\n',Info.RCOND);

%%------------------------------------------------------------
% factorization
%%------------------------------------------------------------

try

    R = chol(A);

    useChol = true;

catch

    useChol = false;

end

%%------------------------------------------------------------
% solve
%%------------------------------------------------------------

TrendY = zeros(size(Y));

if useChol

    for k = 1:Nc

        rhs = ...
              W*Y(:,k) ...
            + AnchorY(:,k);

        x = R\(R'\rhs);

        TrendY(:,k)=x;

    end

else

    fprintf('Solver : Sparse Backslash\n');

    for k = 1:Nc

        rhs = ...
              W*Y(:,k) ...
            + AnchorY(:,k);
    
        TrendY(:,k)=A\rhs;

    end

end

%%------------------------------------------------------------
% reshape
%%------------------------------------------------------------

Trend = reshape(TrendY,Nf,Nport,Nport);

Residual = S-Trend;

%%------------------------------------------------------------
% statistics
%%------------------------------------------------------------

rmse = norm(Residual(:))/sqrt(numel(S));

rel = rmse/(norm(S(:))/sqrt(numel(S)));

Info.RMSE = rmse;

Info.RelativeError = rel;

fprintf('Residual RMSE : %.6e\n',rmse);
fprintf('Relative Err  : %.6e\n',rel);
fprintf("Minimum Weight : %.3f\n",min(Weight));
fprintf("Maximum Weight : %.3f\n",max(Weight));
fprintf('========================================\n');
end
function [W,Weight,Deviation,Boundary] = ...
    ss_buildAdaptiveWeight(freq,S,Option)
%==============================================================
%
% NSCP V9.8.4
%
% Adaptive Matrix Weight Builder
%
% Boundary Consensus Edition
%
%==============================================================

if nargin<3
    Option=struct();
end

%%----------------------------------------------------------
% Parameters
%%----------------------------------------------------------

if ~isfield(Option,'WeightFloor')
    Option.WeightFloor=0.02;
end

if ~isfield(Option,'WeightPower')
    Option.WeightPower=2;
end

if ~isfield(Option,'BoundaryWindow')
    Option.BoundaryWindow=10;
end

if ~isfield(Option,'ConsensusThreshold')
    Option.ConsensusThreshold=2.5;
end

if ~isfield(Option,'MinimumConsensus')
    Option.MinimumConsensus=3;
end

freq=freq(:);

[Nf,N,~]=size(S);

Deviation=zeros(Nf,1);

Boundary=struct();

%%==========================================================
%% Boundary Consensus
%%==========================================================

Nc=min(Option.BoundaryWindow,Nf);

%%---------------- Left ----------------

LeftBlock=S(1:Nc,:,:);

LeftConsensus=...
    ss_boundaryConsensus(...
        LeftBlock,...
        Option);

LeftBoundary=...
    ss_boundaryPredict(...
        freq(1:Nc),...
        LeftBlock,...
        LeftConsensus,...
        true);

%%---------------- Right ----------------

RightBlock=S(end-Nc+1:end,:,:);

RightConsensus=...
    ss_boundaryConsensus(...
        RightBlock,...
        Option);

RightBoundary=...
    ss_boundaryPredict(...
        freq(end-Nc+1:end),...
        RightBlock,...
        RightConsensus,...
        false);

%%==========================================================
%% Boundary Information
%%==========================================================

Boundary.Left.Value = LeftBoundary;
Boundary.Right.Value = RightBoundary;

%%------------------------------------------
%% Y-space Boundary
%%------------------------------------------

Boundary.LeftY = reshape(LeftBoundary,1,[]);
Boundary.RightY = reshape(RightBoundary,1,[]);

Boundary.Left.Index = LeftConsensus.Index;
Boundary.Right.Index = Nf-Nc + RightConsensus.Index;

Boundary.Left.Number = LeftConsensus.Number;
Boundary.Right.Number = RightConsensus.Number;
%%==========================================================
%% Interior Prediction
%%==========================================================

for k=2:Nf-1

    f1=freq(k-1);
    f2=freq(k);
    f3=freq(k+1);

    wL=(f3-f2)/(f3-f1);
    wR=(f2-f1)/(f3-f1);

    Spredict=...
        wL*S(k-1,:,:)+...
        wR*S(k+1,:,:);

    E=squeeze(S(k,:,:))-...
      squeeze(Spredict);

    Deviation(k)=norm(E(:),'fro');

end

%%==========================================================
%% Boundary Prediction Error
%%==========================================================

E=squeeze(S(1,:,:))-LeftBoundary;
Deviation(1)=norm(E(:),'fro');

E=squeeze(S(end,:,:))-RightBoundary;
Deviation(end)=norm(E(:),'fro');

%%==========================================================
%% Robust Scale
%%==========================================================

sigma=median(Deviation);

if sigma<1e-12
    sigma=1e-12;
end

Deviation=Deviation/sigma;

%%==========================================================
%% Adaptive Weight
%%==========================================================

Weight=1./(1+Deviation.^Option.WeightPower);

Weight=max(Weight,...
           Option.WeightFloor);

%%==========================================================
%% Consensus Protection
%%
%% Consensus区域直接提高可信度
%%==========================================================

Weight(LeftConsensus.Index)=...
Weight(LeftConsensus.Index)*0.30;

Weight(RightConsensus.Index)=...
Weight(RightConsensus.Index)*0.30;
%%==========================================================
%% Sparse Matrix
%%==========================================================

W=spdiags(Weight,...
          0,...
          Nf,...
          Nf);

%%==========================================================
%% Print
%%==========================================================

fprintf("\n");
fprintf("========================================\n");
fprintf(" NSCP V9.8.4 Adaptive Weight\n");
fprintf("========================================\n");

fprintf("Weight Range : %.3f ~ %.3f\n",...
    min(Weight),...
    max(Weight));

fprintf("Median Dev   : %.6e\n",...
    sigma);

fprintf("\n");

fprintf("Left Consensus : %d points\n",...
    LeftConsensus.Number);

fprintf("Right Consensus: %d points\n",...
    RightConsensus.Number);

fprintf("========================================\n");

end
function Consensus = ss_boundaryConsensus(Sblock,Option)
%==============================================================
%
% NSCP V9.8.4
%
% Boundary Consensus Estimator
%
% Input:
%     Sblock   (Nc × N × N)
%
% Output:
%     Consensus.Index
%     Consensus.Mean
%     Consensus.UsePredictor
%
%==============================================================

if nargin<2
    Option=struct();
end

if ~isfield(Option,'ConsensusThreshold')
    Option.ConsensusThreshold=2.5;
end

if ~isfield(Option,'MinimumConsensus')
    Option.MinimumConsensus=3;
end

[Nc,N,~]=size(Sblock);

Keep=true(Nc,1);

while true

    Index=find(Keep);

    if numel(Index)<=Option.MinimumConsensus
        break;
    end

    %%-----------------------------
    % Mean Matrix
    %%-----------------------------
    Mean=zeros(N,N);

    for k=Index.'

        Mean=Mean+squeeze(Sblock(k,:,:));

    end

    Mean=Mean/numel(Index);

    %%-----------------------------
    % Distance
    %%-----------------------------
    Dist=zeros(numel(Index),1);

    for ii=1:numel(Index)

        k=Index(ii);

        E=squeeze(Sblock(k,:,:))-Mean;

        Dist(ii)=norm(E(:),'fro');

    end

    medD=median(Dist);

    madD=median(abs(Dist-medD));

    if madD<1e-12
        madD=1e-12;
    end

    Threshold=medD+Option.ConsensusThreshold*madD;

    [MaxValue,Pos]=max(Dist);

    if MaxValue<=Threshold
        break;
    end

    Keep(Index(Pos))=false;

end

%%---------------------------------
% Final Consensus
%%---------------------------------

Index=find(Keep);

Mean=zeros(N,N);

for k=Index.'

    Mean=Mean+squeeze(Sblock(k,:,:));

end

Mean=Mean/max(numel(Index),1);

Consensus.Index=Index;

Consensus.Mean=Mean;

Consensus.UsePredictor=(numel(Index)>=Option.MinimumConsensus);

Consensus.Number=numel(Index);

Consensus.Removed=find(~Keep);

end
function Boundary = ...
    ss_boundaryPredict( ...
        freq,...
        Block,...
        Consensus,...
        IsLeft)
%==============================================================
%
% NSCP V9.8.7
%
% Amplitude + Unwrapped Phase Predictor
%
%==============================================================

freq=freq(:);

[Nc,Nport,~]=size(Block);

Index=Consensus.Index(:);

Block=Block(Index,:,:);

%%------------------------------------------------------------
%% Amplitude & Phase
%%------------------------------------------------------------

Amp = abs(Block);
Phase = angle(Block);
Phase = unwrap(Phase,[],1);
AmpMean = squeeze(median(Amp,1));
Dev = zeros(size(Amp,1),1);

for k = 1:size(Amp,1)
    D = squeeze(Amp(k,:,:)) - AmpMean;
    Dev(k) = norm(D(:),'fro');
end
thr = median(Dev) + 2.5*mad(Dev,1);
Keep = Dev <= thr;

Amp=Amp(Keep,:,:);
Phase=Phase(Keep,:,:);

AmpBoundary = squeeze(mean(Amp,1));
PhaseBoundary = squeeze(median(Phase,1));
Boundary = AmpBoundary .* exp(1j*PhaseBoundary);
end
function L = ss_buildRegularization(freq,Boundary)
%==============================================================
%
% NSCP V9.8.6
%
% Boundary-aware Regularization
%
% Boundary :
%       First-order
%
% Interior :
%       Second-order
%
%==============================================================

freq=freq(:);

N=length(freq);

%%------------------------------------------------------------
%% Consensus Width
%%------------------------------------------------------------

LeftN  = Boundary.Left.Number;
RightN = Boundary.Right.Number;

%%------------------------------------------------------------
%% Sparse Builder
%%------------------------------------------------------------

row = [];
col = [];
val = [];

r = 0;

%%============================================================
%% Left Boundary
%%
%% D1
%%
%% T(k+1)-T(k)
%%
%%============================================================

for k = 1:LeftN-1

    r = r + 1;

    row = [row r r];
    col = [col k k+1];
    val = [val -1 1];

end

%%============================================================
%% Interior
%%
%% D2
%%
%%============================================================

for k = LeftN : N-RightN-1

    if k<=1
        continue;
    end

    if k>=N-1
        continue;
    end

    h1 = freq(k)-freq(k-1);
    h2 = freq(k+1)-freq(k);

    a = 2/(h1*(h1+h2));
    b = -2/(h1*h2);
    c = 2/(h2*(h1+h2));

    r = r + 1;

    row = [row r r r];
    col = [col k-1 k k+1];
    val = [val a b c];

end

%%============================================================
%% Right Boundary
%%
%% D1
%%
%%============================================================

for k = N-RightN+1 : N-1

    r = r + 1;

    row = [row r r];
    col = [col k k+1];
    val = [val -1 1];

end

%%------------------------------------------------------------
%% Sparse Operator
%%------------------------------------------------------------

D = sparse(row,col,val,r,N);

%%------------------------------------------------------------
%% Regularization
%%------------------------------------------------------------

L = D'*D;

end
function [Aanchor,AnchorY] = ...
    ss_buildBoundaryAnchor( ...
    Boundary,...
    Nf,...
    mu,...
    Y)
%==============================================================
%
% NSCP V9.8.5
%
% Boundary Consensus Anchor
%
% Y-space Version
%
% Input
%
%   Boundary.Left.Index
%   Boundary.Right.Index
%
%   Boundary.LeftY
%   Boundary.RightY
%
%   Nf
%   mu
%   Y
%
% Output
%
%   Aanchor
%
%   AnchorY
%
%==============================================================

Nc=size(Y,2);

%%------------------------------------------------------------
%% Initialize
%%------------------------------------------------------------

Aanchor=sparse(Nf,Nf);

AnchorY=zeros(Nf,Nc);

%%------------------------------------------------------------
%% Left Boundary
%%------------------------------------------------------------

LeftIndex=Boundary.Left.Index(:);

for k=LeftIndex.'

    Aanchor(k,k)=mu;

    AnchorY(k,:)=...
        mu*Boundary.LeftY;

end

%%------------------------------------------------------------
%% Right Boundary
%%------------------------------------------------------------

RightIndex=Boundary.Right.Index(:);

for k=RightIndex.'

    Aanchor(k,k)=mu;

    AnchorY(k,:)=...
        mu*Boundary.RightY;

end

%%------------------------------------------------------------
%% Print
%%------------------------------------------------------------

fprintf("\n");

fprintf("========================================\n");

fprintf(" NSCP V9.8.5 Boundary Anchor\n");

fprintf("========================================\n");

fprintf("Left Anchor Points  : %d\n",...
    length(LeftIndex));

fprintf("Right Anchor Points : %d\n",...
    length(RightIndex));

fprintf("Anchor Strength     : %.3f\n",...
    mu);

fprintf("========================================\n");

end