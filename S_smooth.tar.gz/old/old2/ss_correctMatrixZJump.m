function [Sout,Report]=...
    ss_correctMatrixZJump( ...
        freq,...
        S,...
        JumpIndex)


%==============================================================
%
% NSCP V10.0
%
% Adaptive Z Jump Correction
%
% Validation Edition
%
%==============================================================


Sout=S;


Accepted=[];

Rejected=[];



[Nf,N,~]=size(S);



for ii=1:length(JumpIndex)


    k=JumpIndex(ii);



    if k<=1 || k>=Nf
        continue;
    end



    %% interpolation


    f1=log(freq(k-1));
    f2=log(freq(k));
    f3=log(freq(k+1));


    wL=(f3-f2)/(f3-f1);
    wR=(f2-f1)/(f3-f1);


    Snew=...
        wL*Sout(k-1,:,:)+...
        wR*Sout(k+1,:,:);



    %% validation

    Sold=squeeze(Sout(k,:,:));



    % S variation

    Sjump_old=...
        norm(Sold-...
        squeeze(Sout(k-1,:,:)),'fro');


    Sjump_new=...
        norm(Snew-...
        squeeze(Sout(k-1,:,:)),'fro');



    % prevent creating new jump

    if Sjump_new>Sjump_old*1.2

        Rejected(end+1)=k;

        continue;

    end



    %% accept


    Sout(k,:,:)=Snew;

    Accepted(end+1)=k;


end



Report.Accepted=Accepted;

Report.Rejected=Rejected;


fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.0 Z Jump Correction\n');
fprintf('========================================\n');

fprintf('Accepted : %d\n',length(Accepted));

fprintf('Rejected : %d\n',length(Rejected));

fprintf('========================================\n');


end