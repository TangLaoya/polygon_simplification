function [Srepair,Report]=ss_iterativeMatrixRepair( ...
                    freq,...
                    S,...
                    Option)

%==============================================================
%
% NSCP V10.1
%
% Physics-aware Iterative Matrix Repair
%
% Detect:
%     Z isolated jump
%
% Repair:
%     S matrix frequency interpolation
%
% Iterate:
%     until no physical jump
%
%==============================================================


if nargin<3

    Option=struct();

end



if ~isfield(Option,'MaxIteration')

    Option.MaxIteration=5;

end



if ~isfield(Option,'MinJump')

    Option.MinJump=1;

end



Srepair=S;


Report.Iteration=[];



fprintf('\n');

fprintf('========================================\n');

fprintf(' NSCP V10.1 Iterative Matrix Repair\n');

fprintf('========================================\n');



for iter=1:Option.MaxIteration



    fprintf('\nIteration %d\n',iter);



    %%----------------------------------------------------------
    % Detect
    %%----------------------------------------------------------


    JumpReport=...
        ss_detectMatrixZJump_Physics(...
            freq,...
            Srepair,...
            Option);



    JumpIndex=JumpReport.JumpIndex;



    if length(JumpIndex)<Option.MinJump

        fprintf('No more jump detected.\n');

        break;

    end



    fprintf('Repair Points : %d\n',...
        length(JumpIndex));



    %%----------------------------------------------------------
    % Matrix S interpolation repair
    %%----------------------------------------------------------


    Snew=Srepair;


    for n=1:length(JumpIndex)


        k=JumpIndex(n);



        if k<=1 || k>=length(freq)

            continue;

        end



        f1=freq(k-1);

        f2=freq(k);

        f3=freq(k+1);



        wL=(f3-f2)/(f3-f1);

        wR=(f2-f1)/(f3-f1);



        Snew(k,:,:)=...
            wL*Srepair(k-1,:,:)+...
            wR*Srepair(k+1,:,:);



    end



    %%----------------------------------------------------------
    % Validation
    %
    % Reject if repair introduces larger local variation
    %%----------------------------------------------------------


    Accept=true;



    for n=1:length(JumpIndex)


        k=JumpIndex(n);


        if k<=1 || k>=length(freq)

            continue;

        end



        OldJump=...
            norm(...
            squeeze(Srepair(k,:,:))-...
            squeeze((Srepair(k-1,:,:)+Srepair(k+1,:,:))/2),...
            'fro');


        NewJump=...
            norm(...
            squeeze(Snew(k,:,:))-...
            squeeze((Snew(k-1,:,:)+Snew(k+1,:,:))/2),...
            'fro');



        if NewJump>OldJump*1.2

            Accept=false;

        end



    end



    if Accept

        Srepair=Snew;

        fprintf('Repair accepted.\n');

    else

        fprintf('Repair rejected by physics validation.\n');

        break;

    end



    Report.Iteration(iter).JumpIndex=JumpIndex;



end



fprintf('\n');

fprintf('========================================\n');

fprintf('Repair Finished\n');

fprintf('========================================\n');


end