function Report = ss_detectMatrixZJump( ...
                    freq,...
                    S,...
                    Option)

%==============================================================
%
% NSCP V10.0
%
% Adaptive Z Jump Detector
%
% Hybrid Edition
%
% Z sensitivity +
% S consistency verification
%
%==============================================================


if nargin<3
    Option=struct();
end


if ~isfield(Option,'ZThreshold')
    Option.ZThreshold=8;
end


if ~isfield(Option,'SThreshold')
    Option.SThreshold=6;
end


[Nf,N,~]=size(S);


%%------------------------------------------------------------
% S -> Z
%%------------------------------------------------------------


Z=zeros(size(S));


for k=1:Nf

    Sk=squeeze(S(k,:,:));

    Z(k,:,:)=...
        (eye(N)-Sk)\...
        (eye(N)+Sk);

end



%%------------------------------------------------------------
% Score
%%------------------------------------------------------------

Score=zeros(Nf,1);


for k=2:Nf-1


    Z0=squeeze(Z(k,:,:));

    ZL=squeeze(Z(k-1,:,:));

    ZR=squeeze(Z(k+1,:,:));


    % log frequency interpolation

    f1=log(freq(k-1));
    f2=log(freq(k));
    f3=log(freq(k+1));


    wL=(f3-f2)/(f3-f1);
    wR=(f2-f1)/(f3-f1);


    Zpred=...
        wL*ZL+wR*ZR;


    Err=norm(Z0-Zpred,'fro');


    Ref=(norm(Zpred,'fro')+eps);


    Zscore=Err/Ref;



    %% S verification

    S0=squeeze(S(k,:,:));

    SL=squeeze(S(k-1,:,:));

    SR=squeeze(S(k+1,:,:));


    Spred=wL*SL+wR*SR;


    Serr=norm(S0-Spred,'fro');

    Sref=norm(Spred,'fro')+eps;


    Sscore=Serr/Sref;



    %% combined


    Score(k)=...
        Zscore*...
        (1+0.5*Sscore);


end



%%------------------------------------------------------------
% robust threshold
%%------------------------------------------------------------


base=median(Score);

spread=mad(Score,1);


Threshold=...
    base+Option.ZThreshold*spread;



Candidate=find(Score>Threshold);



%%------------------------------------------------------------
% Secondary validation
%%------------------------------------------------------------


JumpIndex=[];


for ii=1:length(Candidate)


    k=Candidate(ii);


    if k<=2 || k>=Nf-1
        continue;
    end


    % Z magnitude isolated

    zm=abs(squeeze(Z(:,1,1)));


    local=[...
        zm(k-2);
        zm(k-1);
        zm(k);
        zm(k+1);
        zm(k+2)];



    center=local(3);


    neighbor=median([local(1:2);local(4:5)]);


    ratio=center/(neighbor+eps);



    % strong isolated point

    if ratio>3 || ratio<0.33

        JumpIndex(end+1)=k;

        continue;

    end



    % S confirmation

    if Score(k)>10*base

        JumpIndex(end+1)=k;

    end


end



%%------------------------------------------------------------
% output
%%------------------------------------------------------------


Report.JumpIndex=unique(JumpIndex);

Report.Score=Score;

Report.Threshold=Threshold;

Report.Number=length(Report.JumpIndex);



fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V10.0 Adaptive Z Jump Detector\n');
fprintf('========================================\n');

fprintf('Candidates : %d\n',...
    length(Candidate));

fprintf('Confirmed  : %d\n',...
    Report.Number);


fprintf('Threshold  : %.6e\n',...
    Threshold);



if Report.Number>0

fprintf('\nJump Points\n');

for k=Report.JumpIndex'

fprintf('%4d  f=%e  Score=%e\n',...
    k,...
    freq(k),...
    Score(k));

end

end


fprintf('========================================\n');


end