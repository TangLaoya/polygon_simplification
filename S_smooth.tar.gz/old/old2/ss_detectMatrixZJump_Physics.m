function JumpReport = ss_detectMatrixZJump_Physics( ...
                    freq,...
                    S,...
                    Option)

%==============================================================
%
% NSCP V10.1
%
% Physics-aware Matrix Z Jump Detection
%
% Principle:
%
% Detect:
%   isolated abnormal points
%
% Reject:
%   natural trend change
%   resonance curvature
%
% Criteria:
%
%   1. Z deviation
%   2. Direction reversal
%   3. Local physical consistency
%
%==============================================================


if nargin < 3
    Option=struct();
end


if ~isfield(Option,'Threshold')
    Option.Threshold=6;
end


if ~isfield(Option,'DirectionCheck')
    Option.DirectionCheck=true;
end


[Nf,Nport,~]=size(S);



%%==============================================================
% Convert S -> Z
%%==============================================================


Z0=50;


Z=zeros(size(S));


I=eye(Nport);


for k=1:Nf


    Sk=squeeze(S(k,:,:));


    Z(k,:,:)=...
        Z0*(I+Sk)/(I-Sk);


end



%%==============================================================
% Detection variables
%%==============================================================


Score=zeros(Nf,1);


Direction=zeros(Nf,1);



for k=2:Nf-1


    Zm=squeeze(Z(k-1,:,:));
    Z0k=squeeze(Z(k,:,:));
    Zp=squeeze(Z(k+1,:,:));


    %%---------------------------
    % amplitude deviation
    %%---------------------------

    Am=abs(Zm);
    A0=abs(Z0k);
    Ap=abs(Zp);


    Apre=(Am+Ap)/2;


    ErrA=norm(A0-Apre,'fro');



    %%---------------------------
    % phase deviation
    %%---------------------------

    Pm=unwrap(angle(Zm));

    P0=unwrap(angle(Z0k));

    Pp=unwrap(angle(Zp));


    Ppre=(Pm+Pp)/2;


    ErrP=norm(P0-Ppre,'fro');



    %%---------------------------
    % direction reversal
    %%---------------------------


    d1=A0-Am;

    d2=Ap-A0;


    reversal=sum(d1(:).*d2(:)<0);


    Direction(k)=reversal/(Nport*Nport);



    %%---------------------------
    % combined score
    %%---------------------------


    Score(k)=...
        ErrA + ...
        0.2*ErrP;



    if Option.DirectionCheck

        if Direction(k)<0.05

            Score(k)=Score(k)*0.1;

        end

    end


end



%%==============================================================
% Robust threshold
%%==============================================================


valid=Score(2:end-1);


medScore=median(valid);

madScore=mad(valid,1);


if madScore<eps

    madScore=eps;

end



Threshold=...
    medScore + ...
    Option.Threshold*madScore;



JumpIndex=find(Score>Threshold);



%%==============================================================
% Report
%%==============================================================


JumpReport.JumpIndex=JumpIndex;

JumpReport.Score=Score;

JumpReport.MedianScore=medScore;

JumpReport.MAD=madScore;

JumpReport.Threshold=Threshold;



fprintf('\n');

fprintf('========================================\n');

fprintf(' NSCP V10.1 Physics-aware Z Detection\n');

fprintf('========================================\n');

fprintf('Threshold : %.6e\n',Threshold);

fprintf('Median    : %.6e\n',medScore);

fprintf('MAD       : %.6e\n',madScore);


fprintf('\nJump Points : %d\n',...
    length(JumpIndex));


if ~isempty(JumpIndex)

    for k=JumpIndex.'

        fprintf('%4d  f=%e Score=%e Direction=%.3f\n',...
            k,...
            freq(k),...
            Score(k),...
            Direction(k));

    end

end


fprintf('========================================\n');

end