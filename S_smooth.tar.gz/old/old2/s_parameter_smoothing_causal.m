function s_parameter_smoothing_causal()
%==============================================================
%
% NSCP V9.8.2
%
% Matrix Trend Edition
%
% Phase 1
%
% Trend Verification
%
%==============================================================

clc;
clear;

fprintf('\n');
fprintf('==============================================================\n');
fprintf('               NSCP V9.8.2\n');
fprintf('          Matrix Trend Edition\n');
fprintf('      Phase 1 : Trend Verification\n');
fprintf('==============================================================\n\n');

%%------------------------------------------------------------
% Input
%%------------------------------------------------------------

inputFile='Test_beforeFit.s26p';

fprintf('Input File : %s\n',inputFile);

%%------------------------------------------------------------
% Read Touchstone
%%------------------------------------------------------------

Measurement=ss_readTouchstone(inputFile);

fprintf('Frequency Points : %d\n', ...
    Measurement.Frequency.Number);

fprintf('Port Number      : %d\n', ...
    Measurement.Network.PortNumber);

%%------------------------------------------------------------
%% V10.0 Iterative Matrix Repair
%%------------------------------------------------------------

RepairOption.Threshold=6;
RepairOption.MaxIteration=5;
RepairOption.DirectionCheck=true;


[Srepair,RepairReport]=...
    ss_iterativeMatrixRepair(...
        Measurement.Frequency.Vector,...
        Measurement.S,...
        RepairOption);

%% optional export

writeSnP_simple( ...
'Test_beforeFit_ZRepair.s26p',...
Measurement.Frequency.Vector,...
Srepair,...
Measurement.Params);

Measurement.S=Srepair;

%%------------------------------------------------------------
% Trend Option
%%------------------------------------------------------------

TrendOption=struct();

TrendOption.Lambda=5e-2;

TrendOption.NormalWeight=1;

TrendOption.JumpWeight=0.10;

TrendOption.JumpIndex=[];

%%------------------------------------------------------------
% Trend Solve
%%------------------------------------------------------------

[Trend,...
 Residual,...
 Info]=ss_matrixTrendSolver( ...
    Measurement.Frequency.Vector,...
    Measurement.S,...
    TrendOption);

%%------------------------------------------------------------
% Export Trend
%%------------------------------------------------------------

fprintf('\n');
fprintf('Export Trend...\n');

writeSnP_simple( ...
    'Test_beforeFit_Trend.s26p',...
    Measurement.Frequency.Vector,...
    Trend,...
    Measurement.Params);

%%------------------------------------------------------------
% Export Residual
%%------------------------------------------------------------

fprintf('Export Residual...\n');

writeSnP_simple( ...
    'Test_beforeFit_Residual.s26p',...
    Measurement.Frequency.Vector,...
    Residual,...
    Measurement.Params);

%%------------------------------------------------------------
% Statistics
%%------------------------------------------------------------

fprintf('\n');
fprintf('========================================\n');

fprintf('Trend RMSE      : %.6e\n', ...
    Info.RMSE);

fprintf('Relative Error  : %.6e\n', ...
    Info.RelativeError);

fprintf('Minimum RCOND   : %.6e\n', ...
    Info.RCOND);

fprintf('========================================\n');

fprintf('\n');

fprintf('Generated Files:\n');

fprintf('  Test_beforeFit_Trend.s26p\n');

fprintf('  Test_beforeFit_Residual.s26p\n');

fprintf('\n');

fprintf('Trend verification finished.\n');

end