function physics = ss_buildReferenceModel(data,detect,cfg)

%==============================================================
%
% Build Reference Physical Model
%
% This routine NEVER modifies S.
%
% It only extracts the physical behaviour from the smooth
% frequency region.
%
%==============================================================

freq = data.freq(:);

S = data.S;

Z = ss_s2z(S,cfg);

Nf = length(freq);

N = size(Z,2);

physics = struct();

%% ============================================================
% Reference Region
%% ============================================================

idx = detect.referenceIndex(:);

physics.region = idx;

physics.freq = freq(idx);

M = length(idx);

%% ============================================================
% Allocate Memory
%% ============================================================

physics.referenceZ = cell(N,N);

physics.referenceSlope = cell(N,N);

physics.referenceCurvature = cell(N,N);

physics.referenceMean = cell(N,N);

physics.referenceStd = cell(N,N);

physics.referenceCov = cell(N,N);

physics.elementType = strings(N,N);

physics.operator = cell(N,N);

physics.interpolator = cell(N,N);

physics.confidence = zeros(N,N);

physics.statistics = cell(N,N);

physics.weight = ones(N,N);

%% ============================================================
% Analyse every impedance element
%% ============================================================

for i=1:N

    for j=1:N

        Zij = squeeze(Z(idx,i,j));

        info = ss_analyseReferenceElement(...
                    physics.freq,...
                    Zij,...
                    cfg);

        physics.referenceZ{i,j}=info.reference;

        physics.referenceSlope{i,j}=info.slope;

        physics.referenceCurvature{i,j}=info.curvature;

        physics.referenceMean{i,j}=info.mean;

        physics.referenceStd{i,j}=info.std;

        physics.referenceCov{i,j}=info.covariance;

        physics.elementType(i,j)=info.type;

        physics.operator{i,j}=info.operator;

        physics.interpolator{i,j}=info.interpolator;

        physics.confidence(i,j)=info.confidence;

        physics.statistics{i,j}=info.statistics;

    end

end

%% ============================================================
% Global statistics
%% ============================================================

physics.globalCondition = ...
    ss_estimateReferenceCondition(Z(idx,:,:),cfg);

physics.globalWeight = ...
    ss_buildWeightMatrix(physics,cfg);

end