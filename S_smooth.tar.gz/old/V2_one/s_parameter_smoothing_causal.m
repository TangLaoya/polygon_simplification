function s_parameter_smoothing_causal()
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

clc; clear;

fprintf('\n');
fprintf('==============================================================\n');
fprintf('              NSCP v4.0 Final Freeze\n');
fprintf('     Network S-Parameter Causal Projection Framework\n');
fprintf('==============================================================\n\n');

%% Select Input File
% [fileName,filePath] = uigetfile( ...
%     {'*.s*p','Touchstone (*.s*p)'}, ...
%     'Select Touchstone File');
% 
% if isequal(fileName,0)
%     fprintf('Operation cancelled.\n');
%     return;
% end
% 
% inputFile = fullfile(filePath,fileName);
filePath='';
inputFile = 'Test_beforeFit.s26p';

fprintf('Input File : %s\n',inputFile);

%% Read Touchstone
[freq, S, params] = readSnP_simple(inputFile);
Measurement.freq = freq;
Measurement.FrequencyNumber = numel(freq);
Measurement.S = S;
Measurement.Params = params;
Measurement.PortNumber = size(S,3);
Measurement.Z0 = 50;

fprintf('Frequency Points : %d\n',Measurement.FrequencyNumber);
fprintf('Port Number      : %d\n',Measurement.PortNumber);

%% Build Default Options
Option = ss_defaultOption();

%% Run NSCP
Result = ss_runNSCP(Measurement, Option);

%% Output File
[pathstr,name,~] = fileparts(inputFile);
outputFile = fullfile(pathstr, [name '_NSCP.s' num2str(Measurement.PortNumber) 'p']);

fprintf('\n');
fprintf('Writing output file...\n');

% 修正调用顺序：filename, freq, S, params
writeSnP_simple(outputFile, Measurement.freq, Result.Network.Representation.S, Measurement.Params);

fprintf('Done.\n');
fprintf('Output : %s\n',outputFile);

fprintf('\n');
fprintf('==============================================================\n');
fprintf('NSCP finished successfully.\n');
fprintf('==============================================================\n');

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function scl = getScale(unit)
    switch upper(unit)
        case 'HZ', scl=1;
        case 'KHZ', scl=1e3;
        case 'MHZ', scl=1e6;
        case 'GHZ', scl=1e9;
        otherwise, error('未知频率单位');
    end
end

function [freq, S, params] = readSnP_simple(filename)
    fid = fopen(filename, 'r');
    assert(fid ~= -1, '无法打开文件: %s', filename);
    wholeFile = fread(fid, '*char')';
    fclose(fid);
    hashLine = regexp(wholeFile, '#[^\n\r]*', 'match', 'once');
    if isempty(hashLine), error('未找到 # 选项行'); end
    tokens = strsplit(strtrim(hashLine));
    freq_unit = upper(tokens{2});
    param_type = tokens{3};
    format_type = upper(tokens{4});
    R0 = 50;
    for k = 5:numel(tokens)-1
        if strcmpi(tokens{k}, 'R')
            R0 = str2double(tokens{k+1}); break;
        end
    end
    Nport_declared = str2double(regexp(wholeFile, '\[Number of Ports\]\s*(\d+)', 'tokens', 'once'));
    startIdx = strfind(wholeFile, '[Network Data]');
    if isempty(startIdx), error('缺少 [Network Data]'); end
    dataStr = wholeFile(startIdx+14:end);
    endIdx = strfind(dataStr, '[End of Data]');
    if ~isempty(endIdx), dataStr(endIdx:end) = []; end
    dataStr = regexprep(dataStr, '!.*?\n', ' ');
    allNums = sscanf(dataStr, '%f');
    totalNums = length(allNums);
    if isempty(Nport_declared)
        Nport = sqrt((totalNums - 1)/2);
        if mod(Nport,1)~=0, error('无法推断端口数'); end
    else
        Nport = Nport_declared;
    end
    inferredNf = floor(totalNums / (1 + 2*Nport^2));
    if inferredNf < 1, error('数据量不足'); end
    Nfreq = inferredNf;
    validNums = Nfreq * (1 + 2*Nport^2);
    allNums = allNums(1:validNums);
    scale = getScale(freq_unit);
    freq = zeros(Nfreq,1); S = zeros(Nfreq,Nport,Nport);
    idx = 1;
    for k = 1:Nfreq
        freq(k) = allNums(idx) * scale;
        idx = idx+1;
        for i = 1:Nport
            for j = 1:Nport
                a = allNums(idx); b = allNums(idx+1);
                switch format_type
                    case 'RI', S(k,i,j) = a + 1i*b;
                    case 'MA', S(k,i,j) = a.*exp(1i*b*pi/180);
                    case 'DB', S(k,i,j) = 10^(a/20).*exp(1i*b*pi/180);
                end
                idx = idx+2;
            end
        end
    end
    params = struct('R0',R0,'param_type',param_type,'format_type',format_type,'freq_unit',freq_unit,'scale',scale);
end

function writeSnP_simple(filename, freq, S, params)
    fid = fopen(filename, 'w');
    Nport = size(S,2); Nf = size(S,1);
    fprintf(fid, '# %s %s %s R %.1f\n', params.freq_unit, params.param_type, params.format_type, params.R0);
    fprintf(fid, '! Z-domain low-frequency extrapolation with log-linear interpolation\n');
    fprintf(fid, '! Ports: %d, Frequencies: %d\n', Nport, Nf);
    outScale = 1;
    switch upper(params.freq_unit)
        case 'KHZ', outScale=1e-3;
        case 'MHZ', outScale=1e-6;
        case 'GHZ', outScale=1e-9;
    end
    for k = 1:Nf
        fprintf(fid, '%.8e ', freq(k)*outScale);
        for i = 1:Nport
            for j = 1:Nport
                val = S(k,i,j);
                switch params.format_type
                    case 'RI'
                        fprintf(fid, '%.10e %.10e ', real(val), imag(val));
                    case 'MA'
                        fprintf(fid, '%.10e %.10e ', abs(val), angle(val)*180/pi);
                    case 'DB'
                        db = -1e3;
                        if abs(val)>0, db=20*log10(abs(val)); end
                        fprintf(fid, '%.10e %.10e ', db, angle(val)*180/pi);
                end
            end
        end
        fprintf(fid, '\n');
    end
    fclose(fid);
end

function S = ss_z2s(Z,cfg)

Nf = size(Z,1);

N = size(Z,2);

I = eye(N);

S = zeros(size(Z));

for k = 1:Nf

    Zk = squeeze(Z(k,:,:));

    A = Zk/cfg.Z0 + I;

    if rcond(A) < 1/cfg.conditionLimit

        A = A + cfg.regularization*norm(A,'fro')*I;

    end

    Sk = (Zk/cfg.Z0 - I)/A;

    S(k,:,:) = Sk;

end

end

function Z = ss_s2z(S, cfg)
% Convert S-parameters to Z-parameters
% S: [Nf, Nport, Nport], cfg.Z0
Z0 = cfg.Z0;
Nf = size(S,1);
N = size(S,2);
I = eye(N);
Z = zeros(size(S));

for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Zk = Z0 * (I + Sk) / (I - Sk);   % (I+S)*inv(I-S)
    Z(k,:,:) = Zk;
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Option = ss_defaultOption()
%==========================================================================
% NSCP v4.0 Final Freeze – Default Options
%==========================================================================

Option = struct();

%% Project Information
Option.Project.Name = 'NSCP';
Option.Project.Version = '4.0 Final Freeze';
Option.Project.Author = '';

%% Network
Option.Network.ReferenceImpedance = 50;
Option.Network.MinimumFrequency = 0;
Option.Network.MaximumFrequency = inf;

%% Reference Model
Option.Reference.Enable = true;
Option.Reference.MinimumPoints = 21;
Option.Reference.MinimumBandwidth = 0.05;
Option.Reference.SmoothOrder = 3;

%% Stable Projection
Option.Stability.Enable = true;
Option.Stability.MaximumConditionNumber = 1e8;
Option.Stability.MinimumSingularValue = 1e-12;
Option.Stability.EnforceSymmetry = true;
Option.Stability.EnforceHermitian = false;

%% Physics Projection
Option.Physics.Enable = true;
Option.Physics.MaximumIteration = 10;
Option.Physics.RelativeTolerance = 1e-6;

%% Measurement Projection
Option.Measurement.Enable = true;
Option.Measurement.MinimumConfidence = 0.05;
Option.Measurement.MaximumConfidence = 0.95;

%% Solver
Option.Solver.Name = 'AlternatingProjection';
Option.Solver.MaximumIteration = 100;
Option.Solver.RelativeTolerance = 1e-8;
Option.Solver.AbsoluteTolerance = 1e-10;
% 新增：用于收敛判断的容差
Option.Solver.ObjectiveTolerance = 1e-6;      % 目标函数绝对容差
Option.Solver.PlateauIteration = 10;          % 连续无改进的迭代次数上限

%% Residual
Option.Residual.Weight.Stability = 1.0;
Option.Residual.Weight.Physics = 1.0;
Option.Residual.Weight.Measurement = 1.0;

%% Convergence
Option.Convergence.MinimumRelativeChange = 1e-8;
Option.Convergence.MinimumObjectiveChange = 1e-8;
Option.Convergence.MinimumResidual = 1e-10;

%% Debug
Option.Debug.Enable = true;
Option.Debug.Verbose = true;
Option.Debug.SaveHistory = true;
Option.Debug.PlotHistory = false;

end

function Result = ss_runNSCP(Measurement, Option)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

%% Build Problem
Problem = ss_buildProblem(Measurement, Option);

%% Initialize Network (initial S from measurement)
Network = ss_initializeNetwork(Problem);

%% Pre-analysis: spectral and physical characterization
Problem = ss_analyseNetwork(Problem, Network);
Problem = ss_buildPhysicsModel(Problem, Network);
Problem = ss_buildReferenceModel(Problem, Network);   % uses Problem.Analysis

%% Build Engine (simple dispatch structure)
Engine = struct();
Engine.Algorithm  = "AlternatingProjection";
Engine.Name       = "NSCP Solver";
Engine.Version    = "4.0 Final Freeze";
Engine.Description = "Alternating Projection Solver";

%% Initialize Runtime
Runtime = ss_initializeRuntime(Problem);
Runtime.Network = Network;

%% Execute Solver
Runtime = ss_executeEngine(Runtime, Problem, Engine);

%% Finalize Result
[Network, Summary] = ss_finalizeSolution(Runtime, Problem);

%% Package Result
Result.Network  = Network;
Result.Summary  = Summary;
Result.Problem  = Problem;

end

function Problem = ss_buildProblem(Measurement, Option)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_buildProblem.m
%
% Description
% -------------------------------------------------------------------------
% Build immutable optimization problem.
%
% Problem contains all information that never changes during optimization.
%
% Runtime data shall NEVER be stored here.
%
%==========================================================================

%% ========================================================================
%% Create problem structure
%% ========================================================================

Problem = struct();

%% ========================================================================
%% User option (immutable)
%% ========================================================================

Problem.Option = Option;

%% ========================================================================
%% Original measurement
%% ========================================================================

Problem.Measurement = Measurement;

%% ========================================================================
%% Frequency information
%% ========================================================================

Problem.Frequency = struct();

Problem.Frequency.Vector = Measurement.freq(:);

Problem.Frequency.Number = numel(Measurement.freq);

Problem.Frequency.Minimum = Measurement.freq(1);

Problem.Frequency.Maximum = Measurement.freq(end);

Problem.Frequency.Step = ...
    median(diff(Measurement.freq));

%% ========================================================================
%% Network information
%% ========================================================================

Problem.Network = struct();

Problem.Network.PortNumber = Measurement.PortNumber;

Problem.Network.ReferenceImpedance = Measurement.Z0;

Problem.Network.MatrixSize = ...
    [Measurement.PortNumber Measurement.PortNumber];

%% ========================================================================
%% Problem dimension
%% ========================================================================

Problem.Dimension = struct();

Problem.Dimension.Port = Measurement.PortNumber;

Problem.Dimension.Frequency = Problem.Frequency.Number;

Problem.Dimension.Matrix = ...
    Measurement.PortNumber^2;

%% ========================================================================
%% Analysis (filled by ss_analyseNetwork)
%% ========================================================================

Problem.Analysis = struct();

Problem.Analysis.Completed = false;

%% ========================================================================
%% Reference model (filled by ss_buildReferenceModel)
%% ========================================================================

Problem.Reference = struct();

Problem.Reference.Completed = false;

Problem.Reference.Model = [];

Problem.Reference.Confidence = [];

%% ========================================================================
%% Physics model (filled by ss_buildPhysicsModel)
%% ========================================================================

Problem.Physics = struct();

Problem.Physics.Completed = false;

Problem.Physics.Model = [];

%% ========================================================================
%% Solver information
%% ========================================================================

Problem.Solver = struct();

Problem.Solver.Name = Option.Solver.Name;

%% ========================================================================
%% Creation time
%% ========================================================================

Problem.CreatedTime = datetime("now");

end

function Network = ss_initializeNetwork(Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Initialize runtime network
%==========================================================================

Network = struct();

Network.Meta = struct();
Network.Meta.PortNumber = Problem.Network.PortNumber;
Network.Meta.FrequencyNumber = Problem.Dimension.Frequency;
Network.Meta.Z0 = Problem.Network.ReferenceImpedance;

Network.Representation = struct();
Network.Representation.S = Problem.Measurement.S;   % [Nf, Nport, Nport]
Network.Representation.Z = [];

Network.Valid = struct();
Network.Valid.S = true;      % 初始 S 有效
Network.Valid.Z = false;     % Z 尚未生成

Network.Iteration = 0;
Network.Modified = false;

end

function Problem = ss_analyseNetwork(Problem, Network)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

S = Network.Representation.S;          % [Nf, Nport, Nport]
freq = Problem.Frequency.Vector;
Nf = Problem.Frequency.Number;

Analysis = struct();
Analysis.ConditionNumber = zeros(Nf,1);
Analysis.StabilityIndex   = zeros(Nf,1);
Analysis.SingularValueMax = zeros(Nf,1);
Analysis.SingularValueMin = zeros(Nf,1);

for k = 1:Nf
    Sk = squeeze(S(k,:,:));            % 提取二维矩阵
    sv = svd(Sk);
    Analysis.SingularValueMax(k) = max(sv);
    Analysis.SingularValueMin(k) = min(sv);
    Analysis.ConditionNumber(k) = ...
        Analysis.SingularValueMax(k) / max(Analysis.SingularValueMin(k), eps);
    Analysis.StabilityIndex(k) = log(Analysis.ConditionNumber(k) + 1);
end

cond = Analysis.ConditionNumber;
Analysis.LowFreqRegion  = find(freq < 0.2 * max(freq));
Analysis.HighFreqRegion = find(freq > 0.8 * max(freq));
Analysis.MidFreqRegion  = setdiff(1:Nf, ...
                                [Analysis.LowFreqRegion; Analysis.HighFreqRegion]);
Analysis.FrequencyRiskMap = normalize(cond, 'range');

Problem.Analysis = Analysis;
end

function Problem = ss_buildReferenceModel(Problem, Network)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_buildReferenceModel.m
%
% Description
% -------------------------------------------------------------------------
% Construct frequency-dependent reference model.
%
% This module defines the physical vs measurement confidence split.
%
% No optimization or projection is performed here.
%
%==========================================================================

%% ========================================================================
%% Extract inputs
%% ========================================================================

freq = Problem.Frequency.Vector;
Nf   = Problem.Frequency.Number;

Analysis = Problem.Analysis;

%% ========================================================================
%% Initialize Reference structure
%% ========================================================================

Reference = struct();

Reference.PhysicsModel = [];
Reference.MeasurementModel = [];

Cp = zeros(Nf,1);
Cm = zeros(Nf,1);

%% ========================================================================
%% Build confidence functions
%% ========================================================================

% Normalize stability index from analysis
stab = Analysis.StabilityIndex;
stab = (stab - min(stab)) / max(max(stab)-min(stab), eps);

for k = 1:Nf

    f = freq(k);

    % ----------------------------------------------------------
    % Physics confidence:
    % high in stable / low-frequency region
    % ----------------------------------------------------------

    Cp(k) = exp(-2 * stab(k)) * (1 - f / max(freq));

    % ----------------------------------------------------------
    % Measurement confidence:
    % high in unstable / high-frequency region
    % ----------------------------------------------------------

    Cm(k) = 1 - Cp(k);

end

%% ========================================================================
%% Normalize
%% ========================================================================

sumC = Cp + Cm + eps;

Cp = Cp ./ sumC;
Cm = Cm ./ sumC;

%% ========================================================================
%% Build weights
%% ========================================================================

Reference.Confidence = struct();

Reference.Confidence.Cp = Cp;
Reference.Confidence.Cm = Cm;

Reference.Weight = struct();

Reference.Weight.Wp = Cp;
Reference.Weight.Wm = Cm;

%% ========================================================================
%% Reference operator (conceptual)
%% ========================================================================

Reference.ReferenceOperator = @(Pphys,Pmeas,fidx) ...
    Cp(fidx).*Pphys + Cm(fidx).*Pmeas;

%% ========================================================================
%% Store result
%% ========================================================================

Problem.Reference = Reference;

end

function Problem = ss_buildPhysicsModel(Problem, Network)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

freq = Problem.Frequency.Vector;
Nf   = Problem.Frequency.Number;
S    = Network.Representation.S;      % [Nf, Nport, Nport]
Z0   = Problem.Network.ReferenceImpedance;

Physics = struct();
Physics.RLGC = struct();
Physics.RLGC.R = zeros(Nf,1);
Physics.RLGC.L = zeros(Nf,1);

for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Zk = (eye(size(Sk)) + Sk) \ (eye(size(Sk)) - Sk) * Z0;
    Physics.RLGC.R(k) = real(trace(Zk));
    Physics.RLGC.L(k) = imag(trace(Zk)) / max(2*pi*freq(k), eps);
end

Physics.Passivity.Energy = zeros(Nf,1);
for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Physics.Passivity.Energy(k) = max(abs(eig(Sk'*Sk)));
end

Physics.Causality.Smoothness = zeros(Nf,1);
for k = 2:Nf
    dS = squeeze(S(k,:,:)) - squeeze(S(k-1,:,:));
    Physics.Causality.Smoothness(k) = norm(dS,'fro');
end

Physics.Operator.Project = @(Sinput) physics_projection_stub(Sinput);
Physics.Constraint.Energy = Physics.Passivity.Energy;
Physics.Constraint.Stability = Physics.Causality.Smoothness;

Problem.Physics = Physics;
end

function Sout = physics_projection_stub(Sin)
Sout = Sin;
end

function Network = ss_projectStableCayley(Network, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Stable projection (Z-domain)
%==========================================================================

% 确保 Z 存在
if ~Network.Valid.Z
    if Network.Valid.S
        cfg = struct('Z0', Problem.Network.ReferenceImpedance);
        Network.Representation.Z = ss_s2z(Network.Representation.S, cfg);
        Network.Valid.Z = true;
        Network.Valid.S = true;   % S 仍有效（源）
    else
        error('No valid S to generate Z.');
    end
end

Z = Network.Representation.Z;
Nf = size(Z,1);

for k = 1:Nf
    Zk = squeeze(Z(k,:,:));
    H = (Zk + Zk')/2;
    [V,D] = eig(H);
    d = real(diag(D));
    d(d<0) = 0;
    H = V*diag(d)*V';
    A = (Zk - Zk')/2;
    Z(k,:,:) = H + A;
end


Network.Valid.Z = true;
Network.Valid.S = false;   % S 已过时（依赖 Z）

end

function Runtime = ss_solverAlternatingProjection(Runtime, Problem, Engine)
%==========================================================================
% NSCP v4.0 Final Freeze – Alternating Projection Solver
%==========================================================================

maxIter = Runtime.Iteration.Max;
Network = Runtime.Network;   % start with initial network

for k = 1:maxIter
    Runtime.Iteration.Current = k;

    % 1) Stable projection (Z-domain)
    Network = ss_projectStableCayley(Network, Problem);

    % 2) Physics projection (Z-domain)
    Network = ss_projectPhysics(Network, Problem);

    % 3) Measurement projection (S-domain)
    Network = ss_projectMeasurement(Network, Problem);

    % Update Runtime with current network
    Runtime.Network = Network;

    % Compute residuals and objective
    Runtime = ss_computeResidual(Runtime, Problem);
    Runtime = ss_computeObjective(Runtime, Problem);

    % Check convergence
    Runtime = ss_checkConvergence(Runtime, Problem);
    if Runtime.Convergence.Finished
        break;
    end

    % Record history
    Runtime = ss_updateHistory(Runtime);
end

% Ensure final network stored
Runtime.Network = Network;

end

function Runtime = ss_executeEngine(Runtime, Problem, Engine)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_executeEngine.m
%
% Description
% -------------------------------------------------------------------------
% Execute optimization engine.
%
% This module dispatches the selected solver algorithm.
% It contains NO numerical optimization code.
%
%==========================================================================

%% ========================================================================
%% Check Engine
%% ========================================================================

if ~isfield(Engine,'Algorithm')

    error('Engine.Algorithm is missing.');

end

Algorithm = lower(string(Engine.Algorithm));

%% ========================================================================
%% Dispatch Solver
%% ========================================================================

switch Algorithm

    case "alternatingprojection"

        Runtime = ss_solverAlternatingProjection( ...
                        Runtime,...
                        Problem,...
                        Engine);

    otherwise

        error("Unsupported solver algorithm: %s",Algorithm);

end

%% ========================================================================
%% Finish
%% ========================================================================

Runtime.Summary.TimeFinish = datetime("now");

Runtime.Summary.ElapsedTime = ...
    Runtime.Summary.TimeFinish - Runtime.Summary.TimeStart;

end

function Network = ss_projectMeasurement(Network, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Measurement projection (S-domain)
%==========================================================================

% 确保 S 存在
if ~Network.Valid.S
    if Network.Valid.Z
        cfg = struct('Z0', Problem.Network.ReferenceImpedance, ...
                     'conditionLimit', 1e12, ...
                     'regularization', 1e-12);
        Network.Representation.S = ss_z2s(Network.Representation.Z, cfg);
        Network.Valid.S = true;
        Network.Valid.Z = true;
    else
        error('No valid Z to generate S.');
    end
end

S = Network.Representation.S;
Smeas = Problem.Measurement.S;
Nf = size(S,1);

Error = zeros(Nf,1);

for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Sm = squeeze(Smeas(k,:,:));
    alpha = Problem.Reference.Confidence.Cm(k);
    Sproj = (1 - alpha)*Sk + alpha*Sm;
    Error(k) = norm(Sproj - Sm,'fro');
    S(k,:,:) = Sproj;
end

Network.Representation.S = S;
Network.Valid.S = true;
Network.Valid.Z = false;   % Z 已过时（依赖 S）

if ~isfield(Network,'Diagnostics')
    Network.Diagnostics = struct();
end
Network.Diagnostics.MeasurementError = Error;
Network.Diagnostics.MeasurementRMSE = sqrt(mean(Error.^2));

end

function Runtime = ss_initializeRuntime(Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Initialize Runtime
%==========================================================================

Runtime = struct();

Runtime.Iteration = struct();
Runtime.Iteration.Current = 0;
Runtime.Iteration.Max = Problem.Option.Solver.MaximumIteration;

Runtime.State = struct();
Runtime.State.Residual = [];
Runtime.State.Objective = [];

Runtime.Convergence = struct();   % 预创建，防止后续访问报错

Runtime.History = struct();
Runtime.History.Iteration = [];
Runtime.History.Objective = [];
Runtime.History.Residual = [];
Runtime.History.State = strings(0);
Runtime.History.SNorm = [];
Runtime.History.ZNorm = [];
Runtime.History.TimeStamp = datetime.empty;

Runtime.Flag = struct();
Runtime.Flag.Converged = false;
Runtime.Flag.Diverged = false;

Runtime.Log = struct();
Runtime.Log.Verbose = Problem.Option.Debug.Verbose;
Runtime.Log.Messages = strings(0);

Runtime.Problem = Problem;      % 只读引用
Runtime.Network = [];

Runtime.Summary = struct();
Runtime.Summary.Initialized = true;
Runtime.Summary.TimeStart = datetime("now");

end

function Network = ss_projectPhysics(Network, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Physics projection (Z-domain)
%==========================================================================

% 确保 Z 存在
if ~Network.Valid.Z
    if Network.Valid.S
        cfg = struct('Z0', Problem.Network.ReferenceImpedance);
        Network.Representation.Z = ss_s2z(Network.Representation.S, cfg);
        Network.Valid.Z = true;
        Network.Valid.S = true;
    else
        error('No valid S to generate Z.');
    end
end

Z = Network.Representation.Z;
freq = Problem.Frequency.Vector;
Physics = Problem.Physics;
Nf = size(Z,1);

for k = 1:Nf
    Zk = squeeze(Z(k,:,:));

    if Problem.Option.Stability.EnforceHermitian
        Zk = (Zk + Zk')/2;
    end

    if ~isempty(Physics.RLGC.R)
        Rref = Physics.RLGC.R(k);
        alpha = Problem.Reference.Confidence.Cp(k);
        H = real(Zk);
        H = (1-alpha)*H + alpha*diag(diag(H));
        H = H + (Rref/size(H,1))*eye(size(H));
        Zk = H + 1i*imag(Zk);
    end

    if k > 1
        beta = Problem.Reference.Confidence.Cp(k);
        Zprev = squeeze(Z(k-1,:,:));
        Zk = beta*Zprev + (1-beta)*Zk;
    end

    Z(k,:,:) = Zk;
end


Network.Valid.Z = true;
Network.Valid.S = false;   % S 已过时

end

function Runtime = ss_computeResidual(Runtime, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze
%==========================================================================

Network = Runtime.Network;
S = Network.Representation.S;          % [Nf, Nport, Nport]
Smeas = Problem.Measurement.S;         % [Nf, Nport, Nport]
Physics = Problem.Physics;
freq = Problem.Frequency.Vector;
Nf = Problem.Frequency.Number;

StabRes = zeros(Nf,1);
PhysRes = zeros(Nf,1);
MeasRes = zeros(Nf,1);

for k = 1:Nf
    Sk = squeeze(S(k,:,:));
    Sm = squeeze(Smeas(k,:,:));

    % Stability residual (passivity violation)
    eigvals = eig(Sk'*Sk);
    StabRes(k) = max(0, max(real(eigvals)) - 1);

    % Physics residual (RLGC consistency)
    if ~isempty(Physics.RLGC.R)
        Rref = Physics.RLGC.R(k);
        Zk = (eye(size(Sk)) + Sk) \ (eye(size(Sk)) - Sk);
        Rk = real(trace(Zk));
        PhysRes(k) = abs(Rk - Rref) / (abs(Rref) + eps);
    else
        PhysRes(k) = 0;
    end

    % Measurement residual
    MeasRes(k) = norm(Sk - Sm, 'fro');
end

ws = 0.3; wp = 0.3; wm = 0.4;
TotalRes = ws*StabRes + wp*PhysRes + wm*MeasRes;
FreqMap = normalize(TotalRes,'range');

Runtime.State.Residual = struct();
Runtime.State.Residual.StabilityResidual = StabRes;
Runtime.State.Residual.PhysicsResidual = PhysRes;
Runtime.State.Residual.MeasurementResidual = MeasRes;
Runtime.State.Residual.TotalResidual = TotalRes;
Runtime.State.Residual.FrequencyResidualMap = FreqMap;
end

function Runtime = ss_computeObjective(Runtime, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_computeObjective.m
%
% Description
% -------------------------------------------------------------------------
% Compute global optimization objective.
%
% This module converts residual diagnostics into a scalar optimization
% energy used by the convergence controller.
%
% No projection or network modification is performed here.
%
%==========================================================================

%% ========================================================================
%% Residual
%% ========================================================================

Residual = Runtime.State.Residual;

Rs = Residual.StabilityResidual(:);

Rp = Residual.PhysicsResidual(:);

Rm = Residual.MeasurementResidual(:);

Nf = numel(Rs);

%% ========================================================================
%% Frequency-dependent confidence weights
%% ========================================================================

Cp = Problem.Reference.Confidence.Cp(:);

Cm = Problem.Reference.Confidence.Cm(:);

%% ========================================================================
%% Objective components
%% ========================================================================

Obj = struct();

Obj.Stability = sum(Rs.^2);

Obj.Physics = sum(Cp .* (Rp.^2));

Obj.Measurement = sum(Cm .* (Rm.^2));

%% ========================================================================
%% Global objective
%% ========================================================================

Obj.Total = ...
      Obj.Stability ...
    + Obj.Physics ...
    + Obj.Measurement;

Obj.RMS = sqrt(Obj.Total / max(Nf,1));

Obj.MaximumResidual = max(Residual.TotalResidual);

Obj.AverageResidual = mean(Residual.TotalResidual);

%% ========================================================================
%% Store
%% ========================================================================

Runtime.State.Objective = Obj;

end

function Runtime = ss_checkConvergence(Runtime, Problem)
%==========================================================================
% NSCP v4.0 Final Freeze – Convergence controller
%==========================================================================

Solver = Problem.Option.Solver;
TolObjective = Solver.ObjectiveTolerance;
TolRelative  = Solver.RelativeTolerance;
PlateauLimit = Solver.PlateauIteration;

CurrentIter = Runtime.Iteration.Current;
MaxIter     = Runtime.Iteration.Max;
Objective = Runtime.State.Objective.Total;

% 确保 Convergence 结构及子字段存在
if ~isfield(Runtime, 'Convergence')
    Runtime.Convergence = struct();
end
if ~isfield(Runtime.Convergence, 'PreviousObjective')
    Runtime.Convergence.PreviousObjective = inf;
end
if ~isfield(Runtime.Convergence, 'PlateauCounter')
    Runtime.Convergence.PlateauCounter = 0;
end

Prev = Runtime.Convergence.PreviousObjective;

Delta = Prev - Objective;
Relative = Delta / max(abs(Prev), eps);

State = "Running";
Finished = false;

% 数值失效
if isnan(Objective) || isinf(Objective)
    State = "NumericalFailure";
    Finished = true;
end

% 目标容差
if ~Finished && Objective < TolObjective
    State = "Converged";
    Finished = true;
end

% 相对改进
if ~Finished
    if Relative < TolRelative
        Runtime.Convergence.PlateauCounter = Runtime.Convergence.PlateauCounter + 1;
    else
        Runtime.Convergence.PlateauCounter = 0;
    end
end

% 平台检测
if ~Finished && Runtime.Convergence.PlateauCounter >= PlateauLimit
    State = "Plateau";
    Finished = true;
end

% 最大迭代
if ~Finished && CurrentIter >= MaxIter
    State = "MaximumIteration";
    Finished = true;
end

% 发散检测
if ~Finished && Objective > Prev * 5
    State = "Diverged";
    Finished = true;
end

% 存储结果
Runtime.Convergence.State = State;
Runtime.Convergence.Finished = Finished;
Runtime.Convergence.Iteration = CurrentIter;
Runtime.Convergence.Objective = Objective;
Runtime.Convergence.PreviousObjective = Objective;
Runtime.Convergence.DeltaObjective = Delta;
Runtime.Convergence.RelativeImprovement = Relative;

Runtime.Flag.Converged = strcmp(State, "Converged");
Runtime.Flag.Diverged = any(strcmp(State, ["Diverged", "NumericalFailure"]));

end

function Runtime = ss_updateHistory(Runtime)
%==========================================================================
% NSCP v4.0 Final Freeze – Solver history tracking
%==========================================================================

% 确保 History 结构完整
if ~isfield(Runtime, 'History') || isempty(Runtime.History)
    Runtime.History = struct();
    Runtime.History.Iteration = [];
    Runtime.History.Objective = [];
    Runtime.History.Residual = [];
    Runtime.History.State = strings(0);
    Runtime.History.SNorm = [];
    Runtime.History.ZNorm = [];
    Runtime.History.TimeStamp = datetime.empty;
end

iter = Runtime.Iteration.Current;
obj  = Runtime.State.Objective.Total;

% 将残差向量转换为标量（L2范数）
resVec = Runtime.State.Residual.TotalResidual;
res = norm(resVec);   % 存储总残差的范数

state = string(Runtime.Convergence.State);

% 网络范数（诊断用）
Network = Runtime.Network;
S = Network.Representation.S;
S_norm = norm(S(:),2);

Z = [];
try
    Z = Network.Representation.Z;
catch
    Z = [];
end
Z_norm = nan;
if ~isempty(Z)
    Z_norm = norm(Z(:),2);
end

% 追加历史
Runtime.History.Iteration(end+1,1) = iter;
Runtime.History.Objective(end+1,1) = obj;
Runtime.History.Residual(end+1,1) = res;
Runtime.History.State(end+1,1) = state;
Runtime.History.SNorm(end+1,1) = S_norm;
Runtime.History.ZNorm(end+1,1) = Z_norm;
Runtime.History.TimeStamp(end+1,1) = datetime("now");

% 可选：裁剪过长历史
maxHist = 5000;
if numel(Runtime.History.Iteration) > maxHist
    Runtime.History.Iteration(1) = [];
    Runtime.History.Objective(1) = [];
    Runtime.History.Residual(1) = [];
    Runtime.History.State(1) = [];
    Runtime.History.SNorm(1) = [];
    Runtime.History.ZNorm(1) = [];
    Runtime.History.TimeStamp(1) = [];
end

end

function [Network, Summary] = ss_finalizeSolution(Runtime, Problem)
%==========================================================================
%
% NSCP v4.0 Final Freeze
%
% File:
%   ss_finalizeSolution.m
%
% Description
% -------------------------------------------------------------------------
% Finalize optimization result.
%
% This is the ONLY module allowed to export the optimized network from
% Runtime to the outside world.
%
% No numerical optimization is performed here.
%
%==========================================================================

%% ========================================================================
%% Extract final network
%% ========================================================================

Network = Runtime.Network;

%% ========================================================================
%% Build summary
%% ========================================================================

Summary = struct();

Summary.Status = Runtime.Convergence.State;

Summary.Iteration = Runtime.Iteration.Current;

Summary.Objective = Runtime.State.Objective.Total;

Summary.RMS = Runtime.State.Objective.RMS;

Summary.MaximumResidual = ...
    Runtime.State.Objective.MaximumResidual;

Summary.AverageResidual = ...
    Runtime.State.Objective.AverageResidual;

%% ========================================================================
%% Timing
%% ========================================================================

Summary.StartTime = Runtime.Summary.TimeStart;

Summary.EndTime = Runtime.Summary.TimeFinish;

Summary.ElapsedTime = Runtime.Summary.ElapsedTime;

%% ========================================================================
%% Solver information
%% ========================================================================

Summary.Solver = struct();

Summary.Solver.Version = "NSCP v4.0 Final Freeze";

Summary.Solver.Algorithm = "Alternating Projection";

Summary.Solver.State = Runtime.Convergence.State;

%% ========================================================================
%% Frequency information
%% ========================================================================

Summary.Frequency = struct();

Summary.Frequency.Points = Problem.Frequency.Number;

Summary.Frequency.Start = Problem.Frequency.Vector(1);

Summary.Frequency.Stop = Problem.Frequency.Vector(end);

%% ========================================================================
%% Diagnostics
%% ========================================================================

if isfield(Network,'Diagnostics')

    Summary.Diagnostics = Network.Diagnostics;

else

    Summary.Diagnostics = struct();

end

%% ========================================================================
%% History statistics
%% ========================================================================

Summary.History = struct();

Summary.History.Iterations = ...
    numel(Runtime.History.Iteration);

Summary.History.FinalObjective = ...
    Runtime.History.Objective(end);

Summary.History.FinalResidual = ...
    Runtime.History.Residual(end);

%% ========================================================================
%% Final state
%% ========================================================================

Runtime.Final = struct();

Runtime.Final.Status = Summary.Status;

Runtime.Final.Objective = Summary.Objective;

Runtime.Final.Iteration = Summary.Iteration;

Runtime.Final.ElapsedTime = Summary.ElapsedTime;

end