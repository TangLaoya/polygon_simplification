function Runtime = ss_solverAlternatingProjection(Runtime, Problem, Engine)

maxIter = Runtime.Iteration.Max;

Network = Runtime.Network;

% 🔥 v4.3：唯一优化变量 = Z
cfg = struct();

cfg.Z0 = Problem.Network.ReferenceImpedance;

cfg.conditionLimit = 1e12;

cfg.regularization = 1e-12;


Z = ss_s2z(Network.Representation.S, cfg);

Smeas = Problem.Measurement.S;

for k = 1:maxIter

    Runtime.Iteration.Current = k;

    %===========================
    % 1. Z-domain stable projection
    %===========================
    Z = ss_projectZ_Stability(Z);

    %===========================
    % 2. Z-domain physics projection
    %===========================
    Z = ss_projectZ_Physics(Z, Problem);

    %===========================
    % 3. Measurement constraint (back-projection ONLY once)
    %===========================
    Z = ss_projectZ_Measurement(Z, Smeas, Problem);

    %===========================
    % convert to S ONLY for evaluation (NOT feedback)
    %===========================
    S = ss_z2s(Z, cfg);

    Runtime.Network.Representation.S = S;
    Runtime.Network.Representation.Z = Z;

    Runtime = ss_computeResidual(Runtime, Problem);
    Runtime = ss_computeObjective(Runtime, Problem);

    Runtime = ss_checkConvergence(Runtime, Problem);

    if Runtime.Convergence.Finished
        break;
    end

    Runtime = ss_updateHistory(Runtime);

end

end