function Z = ss_projectZ_Measurement(Z, Smeas, Problem)
%==========================================================================
% NSCP v4.3
% Z-domain measurement projection
%
% Z is optimization variable
% S is measurement reference only
%==========================================================================


cfg = struct();

cfg.Z0 = Problem.Network.ReferenceImpedance;

% ===== required by ss_z2s =====
cfg.conditionLimit = 1e12;
cfg.regularization = 1e-12;


Nf = size(Z,1);


for k = 1:Nf


    Zk = squeeze(Z(k,:,:));


    %------------------------------------------------------
    % Current S generated from optimized Z
    %------------------------------------------------------
    S_current = ss_z2s(reshape(Zk,[1 size(Zk)]),cfg);
    S_current = squeeze(S_current);



    %------------------------------------------------------
    % Original measured S
    %------------------------------------------------------
    S_target = squeeze(Smeas(k,:,:));


    %------------------------------------------------------
    % Very weak measurement correction
    %
    % IMPORTANT:
    % keep S almost unchanged
    %------------------------------------------------------
    alpha = 0.02;


    S_corr = ...
        S_current + ...
        alpha*(S_target-S_current);



    %------------------------------------------------------
    % Back to Z
    %------------------------------------------------------
    Z_new = ss_s2z(reshape(S_corr,[1 size(S_corr)]),cfg);

    Z(k,:,:) = squeeze(Z_new);


end


end