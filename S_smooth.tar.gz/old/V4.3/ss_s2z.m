function Z = ss_s2z(S,cfg)
%==========================================================================
% NSCP v4.3 Robust S to Z conversion
%==========================================================================

if ~isfield(cfg,'conditionLimit')
    cfg.conditionLimit = 1e12;
end

if ~isfield(cfg,'regularization')
    cfg.regularization = 1e-12;
end

if ~isfield(cfg,'Z0')
    cfg.Z0 = 50;
end


Z0 = cfg.Z0;

Nf = size(S,1);
N  = size(S,2);

I = eye(N);

Z = zeros(size(S));


for k = 1:Nf

    Sk = squeeze(S(k,:,:));

    A = I - Sk;


    if rcond(A) < 1/cfg.conditionLimit

        A = A + ...
            cfg.regularization * ...
            norm(A,'fro') * I;

    end


    Z(k,:,:) = Z0*(I+Sk)/A;

end

end