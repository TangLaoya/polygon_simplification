function Z = ss_projectZ_Physics(Z, Problem)

Nf = size(Z,1);

for k = 1:Nf

    Zk = squeeze(Z(k,:,:));

    % weak RLGC constraint ONLY diagonal structure
    if ~isempty(Problem.Physics.RLGC.R)
    
        Rref = Problem.Physics.RLGC.R(k);
    
        Rcurrent = real(trace(Zk))/size(Zk,1);
    
    
        correction = ...
            0.01*(Rref-Rcurrent);
    
    
        Zk = Zk + correction*eye(size(Zk));
    
    end
    Z(k,:,:) = Zk;

end

end