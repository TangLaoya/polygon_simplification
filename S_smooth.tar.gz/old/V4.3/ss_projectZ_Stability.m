function Z = ss_projectZ_Stability(Z)

Nf = size(Z,1);

for k = 1:Nf
    Zk = squeeze(Z(k,:,:));

    % Hermitian enforcement
    Zk = (Zk + Zk')/2;

    % remove explosive modes (spectral clipping)
    [V,D] = eig(Zk);
    d = real(diag(D));

    % 🔥 critical fix: clamp instead of zeroing
    dmin = -1e6;
    dmax =  1e6;
    
    d = min(max(d,dmin),dmax);
    Z(k,:,:) = V*diag(d)*V';
end

end