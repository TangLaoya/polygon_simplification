function [Trend,Residual,Info] = ss_matrixTrendSolver( ...
                                    freq,...
                                    S,...
                                    Option)
%==============================================================
%
% NSCP V9.8.2
%
% Matrix Trend Edition
%
% Solve
%
%     min ||W(S-T)||² + λ||D2*T||²
%
% ==> (W+λL)T = WS
%
% Whole matrix solved together
%
%==============================================================

%%------------------------------------------------------------
% default option
%%------------------------------------------------------------

if nargin<3
    Option=struct();
end

if ~isfield(Option,'Lambda')
    Option.Lambda=5e-2;
end

if ~isfield(Option,'JumpIndex')
    Option.JumpIndex=[];
end

if ~isfield(Option,'NormalWeight')
    Option.NormalWeight=1.0;
end

if ~isfield(Option,'JumpWeight')
    Option.JumpWeight=0.10;
end

if ~isfield(Option,'BoundaryAnchor')
    Option.BoundaryAnchor=0.20;
end
lambda = Option.Lambda;

%%------------------------------------------------------------
% size
%%------------------------------------------------------------

[Nf,Nport,~] = size(S);

Nc = Nport*Nport;

%%------------------------------------------------------------
% reshape
%
% Nf × Nc
%
%%------------------------------------------------------------

Y = reshape(S,Nf,Nc);

%%------------------------------------------------------------
% build operator
%%------------------------------------------------------------

%%------------------------------------------------------------
% Adaptive Weight
%%------------------------------------------------------------

[W,...
 Weight,...
 Deviation,...
 Boundary]=...
    ss_buildAdaptiveWeight(...
        freq,...
        S,...
        Option);

%%------------------------------------------------------------
% Regularization
%%------------------------------------------------------------

L = ss_buildRegularization( ...
        freq,...
        Boundary);

[Aanchor,...
 AnchorY]=...
ss_buildBoundaryAnchor(...
Boundary,...
Nf,...
Option.BoundaryAnchor,...
Y);

Info.Weight=Weight;
Info.Deviation=Deviation;
Info.Boundary=Boundary;
%%------------------------------------------------------------
% linear system
%%------------------------------------------------------------

A = W + lambda*L + Aanchor;
%%------------------------------------------------------------
% numerical stabilization
%%------------------------------------------------------------

A = A + 1e-12*speye(Nf);

Info.RCOND = rcond(full(A));

fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V9.8.2 Matrix Trend Solver\n');
fprintf('========================================\n');
fprintf('Lambda        : %.3e\n',lambda);
fprintf('Unknowns      : %d\n',Nc);
fprintf('Minimum RCOND : %.3e\n',Info.RCOND);

%%------------------------------------------------------------
% factorization
%%------------------------------------------------------------

try

    R = chol(A);

    useChol = true;

catch

    useChol = false;

end

%%------------------------------------------------------------
% solve
%%------------------------------------------------------------

TrendY = zeros(size(Y));

if useChol

    for k = 1:Nc

        rhs = ...
              W*Y(:,k) ...
            + AnchorY(:,k);

        x = R\(R'\rhs);

        TrendY(:,k)=x;

    end

else

    fprintf('Solver : Sparse Backslash\n');

    for k = 1:Nc

        rhs = ...
              W*Y(:,k) ...
            + AnchorY(:,k);
    
        TrendY(:,k)=A\rhs;

    end

end

%%------------------------------------------------------------
% reshape
%%------------------------------------------------------------

Trend = reshape(TrendY,Nf,Nport,Nport);

Residual = S-Trend;

%%------------------------------------------------------------
% statistics
%%------------------------------------------------------------

rmse = norm(Residual(:))/sqrt(numel(S));

rel = rmse/(norm(S(:))/sqrt(numel(S)));

Info.RMSE = rmse;

Info.RelativeError = rel;

fprintf('Residual RMSE : %.6e\n',rmse);
fprintf('Relative Err  : %.6e\n',rel);
fprintf("Minimum Weight : %.3f\n",min(Weight));
fprintf("Maximum Weight : %.3f\n",max(Weight));
fprintf('========================================\n');
end