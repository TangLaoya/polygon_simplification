function [W,Weight,Deviation,Boundary] = ...
    ss_buildAdaptiveWeight(freq,S,Option)
%==============================================================
%
% NSCP V9.8.4
%
% Adaptive Matrix Weight Builder
%
% Boundary Consensus Edition
%
%==============================================================

if nargin<3
    Option=struct();
end

%%----------------------------------------------------------
% Parameters
%%----------------------------------------------------------

if ~isfield(Option,'WeightFloor')
    Option.WeightFloor=0.02;
end

if ~isfield(Option,'WeightPower')
    Option.WeightPower=2;
end

if ~isfield(Option,'BoundaryWindow')
    Option.BoundaryWindow=10;
end

if ~isfield(Option,'ConsensusThreshold')
    Option.ConsensusThreshold=2.5;
end

if ~isfield(Option,'MinimumConsensus')
    Option.MinimumConsensus=3;
end

freq=freq(:);

[Nf,N,~]=size(S);

Deviation=zeros(Nf,1);

Boundary=struct();

%%==========================================================
%% Boundary Consensus
%%==========================================================

Nc=min(Option.BoundaryWindow,Nf);

%%---------------- Left ----------------

LeftBlock=S(1:Nc,:,:);

LeftConsensus=...
    ss_boundaryConsensus(...
        LeftBlock,...
        Option);

LeftBoundary=...
    ss_boundaryPredict(...
        freq(1:Nc),...
        LeftBlock,...
        LeftConsensus,...
        true);

%%---------------- Right ----------------

RightBlock=S(end-Nc+1:end,:,:);

RightConsensus=...
    ss_boundaryConsensus(...
        RightBlock,...
        Option);

RightBoundary=...
    ss_boundaryPredict(...
        freq(end-Nc+1:end),...
        RightBlock,...
        RightConsensus,...
        false);

%%==========================================================
%% Boundary Information
%%==========================================================

Boundary.Left.Value = LeftBoundary;
Boundary.Right.Value = RightBoundary;

%%------------------------------------------
%% Y-space Boundary
%%------------------------------------------

Boundary.LeftY = reshape(LeftBoundary,1,[]);
Boundary.RightY = reshape(RightBoundary,1,[]);

Boundary.Left.Index = LeftConsensus.Index;
Boundary.Right.Index = Nf-Nc + RightConsensus.Index;

Boundary.Left.Number = LeftConsensus.Number;
Boundary.Right.Number = RightConsensus.Number;
%%==========================================================
%% Interior Prediction
%%==========================================================

for k=2:Nf-1

    f1=freq(k-1);
    f2=freq(k);
    f3=freq(k+1);

    wL=(f3-f2)/(f3-f1);
    wR=(f2-f1)/(f3-f1);

    Spredict=...
        wL*S(k-1,:,:)+...
        wR*S(k+1,:,:);

    E=squeeze(S(k,:,:))-...
      squeeze(Spredict);

    Deviation(k)=norm(E(:),'fro');

end

%%==========================================================
%% Boundary Prediction Error
%%==========================================================

E=squeeze(S(1,:,:))-LeftBoundary;
Deviation(1)=norm(E(:),'fro');

E=squeeze(S(end,:,:))-RightBoundary;
Deviation(end)=norm(E(:),'fro');

%%==========================================================
%% Robust Scale
%%==========================================================

sigma=median(Deviation);

if sigma<1e-12
    sigma=1e-12;
end

Deviation=Deviation/sigma;

%%==========================================================
%% Adaptive Weight
%%==========================================================

Weight=1./(1+Deviation.^Option.WeightPower);

Weight=max(Weight,...
           Option.WeightFloor);

%%==========================================================
%% Consensus Protection
%%
%% Consensus区域直接提高可信度
%%==========================================================

Weight(LeftConsensus.Index)=...
Weight(LeftConsensus.Index)*0.30;

Weight(RightConsensus.Index)=...
Weight(RightConsensus.Index)*0.30;
%%==========================================================
%% Sparse Matrix
%%==========================================================

W=spdiags(Weight,...
          0,...
          Nf,...
          Nf);

%%==========================================================
%% Print
%%==========================================================

fprintf("\n");
fprintf("========================================\n");
fprintf(" NSCP V9.8.4 Adaptive Weight\n");
fprintf("========================================\n");

fprintf("Weight Range : %.3f ~ %.3f\n",...
    min(Weight),...
    max(Weight));

fprintf("Median Dev   : %.6e\n",...
    sigma);

fprintf("\n");

fprintf("Left Consensus : %d points\n",...
    LeftConsensus.Number);

fprintf("Right Consensus: %d points\n",...
    RightConsensus.Number);

fprintf("========================================\n");

end