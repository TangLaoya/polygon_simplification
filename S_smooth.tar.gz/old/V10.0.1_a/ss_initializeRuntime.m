function Runtime = ss_initializeRuntime(Problem)
Runtime = struct();
Runtime.State.Stage = "Initialize";
Runtime.State.Status = "Running";
Runtime.State.Converged = false;
Runtime.State.Diverged = false;
Runtime.State.Plateau = false;
Runtime.State.NumericalFailure = false;

Runtime.Iteration.Current = 0;
Runtime.Iteration.Maximum = Problem.Option.Solver.MaximumIteration;
Runtime.Iteration.Inner = 0;
Runtime.Iteration.Total = 0;

Runtime.Objective.Current = inf;
Runtime.Objective.Previous = inf;
Runtime.Objective.Best = inf;
Runtime.Objective.Change = inf;
Runtime.Objective.RelativeChange = inf;

Runtime.Residual.Measurement = inf;
Runtime.Residual.Physics = inf;
Runtime.Residual.Smoothness = inf;
Runtime.Residual.Passivity = inf;
Runtime.Residual.Total = inf;

Runtime.Step.CorrectionNorm = 0;
Runtime.Step.MaximumCorrection = 0;
Runtime.Step.ActivePointNumber = 0;
Runtime.Step.Accepted = true;

Runtime.Controller.StepLength = 1.0;
Runtime.Controller.MinimumStep = 1e-6;
Runtime.Controller.MaximumStep = 1.0;
Runtime.Controller.Damping = 0.95;
Runtime.Controller.PlateauCounter = 0;
Runtime.Controller.RestartCounter = 0;

Runtime.Statistics.FunctionEvaluation = 0;
Runtime.Statistics.ProjectionEvaluation = 0;
Runtime.Statistics.ZTransformEvaluation = 0;
Runtime.Statistics.STransformEvaluation = 0;
Runtime.Statistics.ConstraintEvaluation = 0;

Runtime.Time.Start = datetime("now");
Runtime.Time.End = [];
Runtime.Time.Elapsed = duration.empty;

Runtime.History.Iteration = [];
Runtime.History.Objective = [];
Runtime.History.Residual = [];
Runtime.History.CorrectionNorm = [];
Runtime.History.MaximumCorrection = [];
Runtime.History.StepLength = [];
Runtime.History.ActivePointNumber = [];
Runtime.History.Status = strings(0);
Runtime.History.TimeStamp = datetime.empty;

Runtime.Log.Level = "Info";
Runtime.Log.Message = strings(0);

Runtime.Debug.Enable = Problem.Option.Debug.Enable;
Runtime.Debug.SaveHistory = true;
Runtime.Debug.Verbose = Problem.Option.Debug.Verbose;

% Convergence 结构（供后续使用）
Runtime.Convergence.State = "Running";
Runtime.Convergence.Finished = false;
Runtime.Convergence.PreviousObjective = inf;
Runtime.Convergence.PlateauCounter = 0;

Runtime.Flag.Converged = false;
Runtime.Flag.Diverged = false;
end

