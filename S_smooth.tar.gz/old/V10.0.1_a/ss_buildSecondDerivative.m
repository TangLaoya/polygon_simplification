function D2 = ss_buildSecondDerivative(freq)
%==============================================================
%
% NSCP V9.8.2
%
% Build non-uniform second derivative operator
%
% D2*T approximates d²T/df²
%
% Input
% -----
% freq : N×1 frequency vector
%
% Output
% ------
% D2 : (N-2) × N sparse matrix
%
%==============================================================

freq = freq(:);

N = length(freq);

if N < 3
    error('Frequency number must >=3');
end

row = [];
col = [];
val = [];

r = 1;

for k = 2 : N-1

    h1 = freq(k)   - freq(k-1);
    h2 = freq(k+1) - freq(k);

    %----------------------------------
    % avoid numerical issue
    %----------------------------------

    if h1 <= 0 || h2 <= 0

        error('Frequency vector must be strictly increasing.');

    end

    %----------------------------------
    % nonuniform second derivative
    %
    % 2/(h1+h2)
    % *
    % (
    % (Tk+1-Tk)/h2
    % -
    % (Tk-Tk-1)/h1
    % )
    %
    %----------------------------------

    a =  2.0 / ((h1+h2)*h1);

    b = -2.0 / (h1*h2);

    c =  2.0 / ((h1+h2)*h2);

    row = [row r r r];

    col = [col k-1 k k+1];

    val = [val a b c];

    r = r + 1;

end

D2 = sparse(row,col,val,N-2,N);

end