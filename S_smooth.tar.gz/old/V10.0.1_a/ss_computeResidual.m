function Residual=ss_computeResidual(S,Strend)


Residual=S-Strend;


end