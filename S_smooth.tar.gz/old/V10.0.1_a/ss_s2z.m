function Z = ss_s2z(S,Z0)
%==============================================================
%
% NSCP V9.9
%
% S -> Z
%
% Whole Matrix
%
%==============================================================

if nargin<2
    Z0=50;
end

[Nf,N,~]=size(S);

I=eye(N);

Z=zeros(size(S));

for k=1:Nf

    Sk=squeeze(S(k,:,:));

    A=I+Sk;

    B=I-Sk;

    Z(k,:,:)=Z0*(A/B);

end

end