function Consensus = ss_boundaryConsensus(Sblock,Option)
%==============================================================
%
% NSCP V9.8.4
%
% Boundary Consensus Estimator
%
% Input:
%     Sblock   (Nc × N × N)
%
% Output:
%     Consensus.Index
%     Consensus.Mean
%     Consensus.UsePredictor
%
%==============================================================

if nargin<2
    Option=struct();
end

if ~isfield(Option,'ConsensusThreshold')
    Option.ConsensusThreshold=2.5;
end

if ~isfield(Option,'MinimumConsensus')
    Option.MinimumConsensus=3;
end

[Nc,N,~]=size(Sblock);

Keep=true(Nc,1);

while true

    Index=find(Keep);

    if numel(Index)<=Option.MinimumConsensus
        break;
    end

    %%-----------------------------
    % Mean Matrix
    %%-----------------------------
    Mean=zeros(N,N);

    for k=Index.'

        Mean=Mean+squeeze(Sblock(k,:,:));

    end

    Mean=Mean/numel(Index);

    %%-----------------------------
    % Distance
    %%-----------------------------
    Dist=zeros(numel(Index),1);

    for ii=1:numel(Index)

        k=Index(ii);

        E=squeeze(Sblock(k,:,:))-Mean;

        Dist(ii)=norm(E(:),'fro');

    end

    medD=median(Dist);

    madD=median(abs(Dist-medD));

    if madD<1e-12
        madD=1e-12;
    end

    Threshold=medD+Option.ConsensusThreshold*madD;

    [MaxValue,Pos]=max(Dist);

    if MaxValue<=Threshold
        break;
    end

    Keep(Index(Pos))=false;

end

%%---------------------------------
% Final Consensus
%%---------------------------------

Index=find(Keep);

Mean=zeros(N,N);

for k=Index.'

    Mean=Mean+squeeze(Sblock(k,:,:));

end

Mean=Mean/max(numel(Index),1);

Consensus.Index=Index;

Consensus.Mean=Mean;

Consensus.UsePredictor=(numel(Index)>=Option.MinimumConsensus);

Consensus.Number=numel(Index);

Consensus.Removed=find(~Keep);

end