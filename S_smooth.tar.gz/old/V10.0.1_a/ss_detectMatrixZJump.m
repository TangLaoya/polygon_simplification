function Report=...
ss_detectMatrixZJump(...
freq,...
S,...
Option)

%==============================================================
%
% NSCP V9.9
%
% Matrix Z Jump Detector
%
% Detection only
%
%==============================================================

if nargin<3
    Option=struct();
end

if ~isfield(Option,'Threshold')
    Option.Threshold=4.0;
end

freq=freq(:);

[Nf,N,~]=size(S);

Z=ss_s2z(S);

Score=zeros(Nf,1);

%%----------------------------------------------------------
%% Interior Prediction
%%----------------------------------------------------------

for k=2:Nf-1

    f1=freq(k-1);

    f2=freq(k);

    f3=freq(k+1);

    wL=(f3-f2)/(f3-f1);

    wR=(f2-f1)/(f3-f1);

    Zpredict=...
        wL*squeeze(Z(k-1,:,:))...
       +wR*squeeze(Z(k+1,:,:));

    D=squeeze(Z(k,:,:))-Zpredict;

    Score(k)=norm(D(:),'fro');

end

%%----------------------------------------------------------
%% Robust Scale
%%----------------------------------------------------------

Valid=Score(2:end-1);

MedianScore=median(Valid);

MADScore=mad(Valid,1);

if MADScore<eps
    MADScore=eps;
end

Normalized=(Score-MedianScore)/MADScore;

%%----------------------------------------------------------
%% Local Maximum
%%----------------------------------------------------------

Jump=false(Nf,1);

for k=3:Nf-2

    if Normalized(k)>Option.Threshold

        if Score(k)>Score(k-1) && Score(k)>=Score(k+1)

            Jump(k)=true;

        end

    end

end

%%----------------------------------------------------------
%% Report
%%----------------------------------------------------------

Report.Score=Score;

Report.NormalizedScore=Normalized;

Report.JumpIndex=find(Jump);

Report.JumpNumber=length(Report.JumpIndex);

%%----------------------------------------------------------
%% Print
%%----------------------------------------------------------

fprintf("\n");

fprintf("========================================\n");

fprintf(" NSCP V9.9 Matrix Z Jump Detector\n");

fprintf("========================================\n");

fprintf("Detected Jump Points : %d\n", Report.JumpNumber);

fprintf("Median Score : %.6e\n",MedianScore);

fprintf("MAD          : %.6e\n",MADScore);

fprintf("\n");

if Report.JumpNumber>0

    fprintf("Jump List\n");

    fprintf("----------------------------------------\n");

    for n=1:Report.JumpNumber

        k=Report.JumpIndex(n);

        fprintf("%4d  f=%12.6e   Score=%12.5e\n", k, freq(k), Score(k));

    end

end

fprintf("========================================\n");

end