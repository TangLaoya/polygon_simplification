function W = ss_buildWeightMatrix(...
                N,...
                JumpIndex,...
                Option)
%==============================================================
%
% NSCP V9.8.2
%
% Matrix Trend Edition
%
% Build Weight Matrix
%
% W = diag(w)
%
%==============================================================

if nargin<3

    Option=struct();

end

%%------------------------------------------
% default
%%------------------------------------------

if ~isfield(Option,'NormalWeight')

    Option.NormalWeight=1.0;

end

if ~isfield(Option,'JumpWeight')

    Option.JumpWeight=0.10;

end

%%------------------------------------------
% initialize
%%------------------------------------------

w=Option.NormalWeight*ones(N,1);

%%------------------------------------------
% jump
%%------------------------------------------

if ~isempty(JumpIndex)

    JumpIndex=JumpIndex(:);

    JumpIndex=JumpIndex(...
        JumpIndex>=1 & JumpIndex<=N);

    w(JumpIndex)=Option.JumpWeight;

end

%%------------------------------------------
% sparse diagonal
%%------------------------------------------

W=spdiags(w,0,N,N);

end