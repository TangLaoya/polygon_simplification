function Boundary = ...
    ss_boundaryPredict( ...
        freq,...
        Block,...
        Consensus,...
        IsLeft)
%==============================================================
%
% NSCP V9.8.7
%
% Amplitude + Unwrapped Phase Predictor
%
%==============================================================

freq=freq(:);

[Nc,Nport,~]=size(Block);

Index=Consensus.Index(:);

Block=Block(Index,:,:);

%%------------------------------------------------------------
%% Amplitude & Phase
%%------------------------------------------------------------

Amp = abs(Block);
Phase = angle(Block);
Phase = unwrap(Phase,[],1);
AmpMean = squeeze(median(Amp,1));
Dev = zeros(size(Amp,1),1);

for k = 1:size(Amp,1)
    D = squeeze(Amp(k,:,:)) - AmpMean;
    Dev(k) = norm(D(:),'fro');
end
thr = median(Dev) + 2.5*mad(Dev,1);
Keep = Dev <= thr;

Amp=Amp(Keep,:,:);
Phase=Phase(Keep,:,:);

AmpBoundary = squeeze(mean(Amp,1));
PhaseBoundary = squeeze(median(Phase,1));
Boundary = AmpBoundary .* exp(1j*PhaseBoundary);
end