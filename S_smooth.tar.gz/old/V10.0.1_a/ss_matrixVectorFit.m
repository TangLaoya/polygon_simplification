function Model=ss_matrixVectorFit(freq,S,VF)

%==============================================================
% NSCP V9.6
%
% Adaptive Matrix Vector Fitting
%
% Features:
%
% 1. Normalized pole basis
% 2. Matrix low frequency adaptive anchor
% 3. Second order frequency regularization
% 4. SVD stable solver
%
% Matrix operation only
%
%==============================================================


[Nf,N,~]=size(S);



%%==============================================================
% VF parameters
%%==============================================================


Order=24;


lambda_s=0.02;


mu=1e-10;



fprintf('\n');

fprintf('========================================\n');

fprintf(' NSCP V9.6 Adaptive Matrix VF\n');

fprintf('========================================\n');

fprintf('VF Order      : %d\n',Order);

fprintf('Smooth Lambda : %.3e\n',lambda_s);



%%==============================================================
% Frequency normalization
%%==============================================================


fmin=min(freq);

fmax=max(freq);


fn=(freq-fmin)/(fmax-fmin+eps);


s=1i*fn;



%%==============================================================
% Multi-scale poles
%
% low frequency dynamics
% high Q resonance
%
%%==============================================================


poles=zeros(Order,1);


for k=1:Order


    alpha=(k-1)/(Order-1);


    poles(k)=...
        -10^(-5+5*alpha);


end



%%==============================================================
% Normalized VF basis
%%==============================================================


A=zeros(Nf,Order+1);


% constant term

A(:,1)=1;



for k=1:Order


    A(:,k+1)=...
        abs(poles(k))./(s-poles(k));


end



%%==============================================================
% Matrix low frequency anchor detection
%
% IMPORTANT:
%
% S is full matrix
%
%%==============================================================


Anchor=ss_findLowFreqAnchor(S);



%%==============================================================
% Matrix jump / resonance weight
%
% based on whole matrix curvature
%
%%==============================================================


J=zeros(Nf,1);



for k=2:Nf-1


    d2=...
        S(k+1,:,:)-2*S(k,:,:)+S(k-1,:,:);


    J(k)=norm(d2(:),'fro');


end



J=J/(median(J)+eps);



W=ones(Nf,1);



for k=1:Nf


    if J(k)>15


        % possible jump

        W(k)=0.05;


    elseif J(k)>3


        % resonance

        W(k)=0.5;


    else


        % normal

        W(k)=1;


    end


end



%%==============================================================
% Adaptive low frequency anchor weight
%
% overwrite only stable region
%
%%==============================================================


if Anchor.Enable


    for k=Anchor.Index


        W(k)=Anchor.Weight;


    end


end



Wmat=diag(W);



%%==============================================================
% Smooth regularization
%
% second derivative
%
%%==============================================================


D2=zeros(Nf-2,Nf);



for k=1:Nf-2


    D2(k,k:k+2)=...
        [1 -2 1];


end



%%==============================================================
% Build VF matrix
%%==============================================================


ATA=A'*Wmat*A;



Smooth=A'*D2'*D2*A;



M=ATA...
    +lambda_s*Smooth...
    +mu*eye(Order+1);



RCOND=1/cond(M);



fprintf('Minimum RCOND : %.3e\n',RCOND);



%%==============================================================
% Stable inverse
%%==============================================================


if RCOND<1e-12


    warning(...
    'VF matrix ill-conditioned, using SVD solver');


    [U,Sv,V]=svd(M);


    Sinv=zeros(size(Sv));


    threshold=max(Sv(:))*1e-12;



    for k=1:length(Sv)


        if Sv(k,k)>threshold

            Sinv(k,k)=1/Sv(k,k);

        end


    end


    Minv=V*Sinv*U';



else


    Minv=inv(M);


end



%%==============================================================
% Solve all S matrix elements
%
% same pole set
%
%%==============================================================


Coeff=zeros(Order+1,N,N);



for i=1:N


    for j=1:N



        y=squeeze(S(:,i,j));



        rhs=A'*Wmat*y;



        c=Minv*rhs;



        Coeff(:,i,j)=c;



    end


end



%%==============================================================
% Output
%%==============================================================


Model.Poles=poles;


Model.Coeff=Coeff;


Model.Order=Order;


Model.Fmin=fmin;


Model.Fmax=fmax;


Model.Weight=W;


Model.Anchor=Anchor;


Model.MinRcond=RCOND;



fprintf('Anchor Enable : %d\n',Anchor.Enable);



fprintf('========================================\n');


end