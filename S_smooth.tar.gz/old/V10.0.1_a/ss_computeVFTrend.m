function Strend=ss_computeVFTrend(freq,Model,N)

%==============================================================
% NSCP V9.4
%
% VF Trend Reconstruction
% Passive Projection
%
%==============================================================


Nf=length(freq);


Order=Model.Order;



fmin=Model.Fmin;

fmax=Model.Fmax;


fn=(freq-fmin)/(fmax-fmin+eps);


s=1i*fn;



%% VF matrix

A=zeros(Nf,Order+1);


A(:,1)=1;


for k=1:Order

    A(:,k+1)=1./(s-Model.Poles(k));

end



%% reconstruction

Strend=zeros(Nf,N,N);



for i=1:N

    for j=1:N


        c=squeeze(Model.Coeff(:,i,j));


        Strend(:,i,j)=A*c;


    end

end



%%--------------------------------------------------------------
% Passive projection
%
% enforce sigma_max(S)<=1
%
%%--------------------------------------------------------------

for k=1:Nf


    Sk=squeeze(Strend(k,:,:));


    sv=max(svd(Sk));


    if sv>1


        Sk=Sk/sv;


        Strend(k,:,:)=Sk;


    end


end



end