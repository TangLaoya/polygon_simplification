inputFile='Test_beforeFit.s26p';
s1=ss_readTouchstone(inputFile);s10=s1.S;
z10=ss_s2z(s10);
z113=z10(:,13,13);s113=s10(:,13,13);
inputFile='Test_beforeFit_ZRepair.s26p';
s2=ss_readTouchstone(inputFile);s20=s2.S;
z20=ss_s2z(s20);
z213=z20(:,13,13);s213=s20(:,13,13);

format long
ss=[s1.Frequency.Vector z113 abs(s113) z213 abs(s213)]