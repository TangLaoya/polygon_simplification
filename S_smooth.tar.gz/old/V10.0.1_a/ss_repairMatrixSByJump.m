function [Srepair,Report]=...
ss_repairMatrixSByJump(...
freq,...
S,...
JumpReport)

%==============================================================
%
% NSCP V9.9
%
% Matrix S Repair
%
% Jump detected in Z
%
% Repair performed in S
%
%==============================================================

freq=freq(:);

[Nf,N,~]=size(S);

Srepair=S;

JumpIndex=JumpReport.JumpIndex(:);

RepairNumber=0;

%%------------------------------------------------------------
%% Repair
%%------------------------------------------------------------

for n=1:length(JumpIndex)

    k=JumpIndex(n);

    %% cannot repair boundary

    if k<=1
        continue;
    end

    if k>=Nf
        continue;
    end

    %% frequency weighted interpolation

    f1=freq(k-1);

    f2=freq(k);

    f3=freq(k+1);

    wL=(f3-f2)/(f3-f1);

    wR=(f2-f1)/(f3-f1);

    %% whole matrix

    Srepair(k,:,:)=...
        wL*Srepair(k-1,:,:)...
      + wR*Srepair(k+1,:,:);

    RepairNumber=RepairNumber+1;

end

%%------------------------------------------------------------
%% Report
%%------------------------------------------------------------

Report.RepairNumber=RepairNumber;

Report.RepairIndex=JumpIndex;

fprintf("\n");

fprintf("========================================\n");

fprintf(" NSCP V9.9 Matrix S Repair\n");

fprintf("========================================\n");

fprintf("Repair Number : %d\n",RepairNumber);

fprintf("\n");

if RepairNumber>0

    fprintf("Repair Points\n");

    fprintf("----------------------------------------\n");

    fprintf("%d ",JumpIndex);

    fprintf("\n");

end

fprintf("========================================\n");

end