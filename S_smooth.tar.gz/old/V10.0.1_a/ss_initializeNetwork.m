function Network = ss_initializeNetwork(Problem)
Measurement = Problem.Measurement;
Network = struct();
Network.Meta.Version = "NSCP V7.0";
Network.Meta.Type = "SParameterNetwork";

Network.Input.S = Measurement.S;
Network.Input.Frequency = Measurement.Frequency.Vector;
Network.Input.PortNumber = Measurement.Network.PortNumber;
Network.Input.ReferenceImpedance = Measurement.Network.ReferenceImpedance;

Network.Dimension.Frequency = Measurement.Frequency.Number;
Network.Dimension.Port = Measurement.Network.PortNumber;
Network.Dimension.Matrix = Measurement.Network.PortNumber^2;

Network.State.S = Measurement.S;
Network.State.Z = [];
Network.State.ValidS = true;
Network.State.ValidZ = false;

Network.Output.S = [];
Network.Output.Z = [];

Nf = Network.Dimension.Frequency;
Np = Network.Dimension.Port;
Network.Correction.dS = zeros(Nf, Np, Np);
Network.Correction.Mask = false(Nf,1);
Network.Correction.Weight = zeros(Nf,1);

Network.Diagnostics.ErrorField = [];
Network.Diagnostics.JumpMap = [];
Network.Diagnostics.ResonanceMap = [];
Network.Diagnostics.Smoothness = [];
Network.Diagnostics.ConditionNumber = [];
Network.Diagnostics.IterationHistory = [];

Network.Runtime.Iteration = 0;
Network.Runtime.Modified = false;

%% =========================================================
% V7.1 Kernel initialization
%% =========================================================
Network.Kernel = ss_defineKernel(Network, Problem);
end

