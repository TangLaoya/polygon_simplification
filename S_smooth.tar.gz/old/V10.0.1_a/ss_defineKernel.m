function Kernel = ss_defineKernel(Network, Problem)
%==========================================================================
%
% NSCP V7.1
%
% Adaptive S-Z Sensitivity Kernel
%
% Purpose:
% 1. Detect tiny S discontinuity
% 2. Evaluate Z amplification risk
% 3. Generate adaptive smoothing weight
%
%==========================================================================


Kernel = struct();


S = Network.State.S;

Nf = size(S,1);



%% =========================================================
% 1. S local jump sensitivity
%% =========================================================


Kernel.SJump=zeros(Nf,1);


for k=2:Nf-1


    Sm=squeeze(S(k-1,:,:));

    Sc=squeeze(S(k,:,:));

    Sp=squeeze(S(k+1,:,:));


    Kernel.SJump(k)=...
        norm(Sc-(Sm+Sp)/2,'fro');

end



maxJump=max(Kernel.SJump);

if maxJump>0

    Kernel.SJump=Kernel.SJump/maxJump;

end



%% =========================================================
% 2. Z amplification sensitivity
%
% Z=Z0(I+S)(I-S)^-1
%
% Low frequency high impedance area:
% (I-S)^-1 becomes sensitive
%
%% =========================================================


Kernel.ZSensitivity=zeros(Nf,1);



for k=1:Nf


    Sk=squeeze(S(k,:,:));


    I=eye(size(Sk));


    A=I-Sk;


    rc=rcond(A);


    if rc>eps

        Kernel.ZSensitivity(k)=norm(inv(A),'fro');

    else

        Kernel.ZSensitivity(k)=1e12;

    end

end



Kernel.ZWeight=Kernel.ZSensitivity./...
               max(Kernel.ZSensitivity);



%% =========================================================
% 3. Combined kernel
%
% Important:
% Do NOT smooth every point
% Only enhance already suspicious points
%
%% =========================================================


Kernel.Weight = ...
       Kernel.SJump .* ...
       Kernel.ZWeight;



%% Limit

Kernel.Weight(isnan(Kernel.Weight))=0;

Kernel.Weight=min(Kernel.Weight,1);



end