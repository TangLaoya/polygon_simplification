function writeSnP_simple(filename, freq, S, params)
    fid = fopen(filename, 'w');
    Nport = size(S,2); Nf = size(S,1);
    fprintf(fid, '# %s %s %s R %.1f\n', params.freq_unit, params.param_type, params.format_type, params.R0);
    fprintf(fid, '! Z-domain low-frequency extrapolation with log-linear interpolation\n');
    fprintf(fid, '! Ports: %d, Frequencies: %d\n', Nport, Nf);
    outScale = 1;
    switch upper(params.freq_unit)
        case 'KHZ', outScale=1e-3;
        case 'MHZ', outScale=1e-6;
        case 'GHZ', outScale=1e-9;
    end
    for k = 1:Nf
        fprintf(fid, '%.8e ', freq(k)*outScale);
        for i = 1:Nport
            for j = 1:Nport
                val = S(k,i,j);
                switch params.format_type
                    case 'RI'
                        fprintf(fid, '%.10e %.10e ', real(val), imag(val));
                    case 'MA'
                        fprintf(fid, '%.10e %.10e ', abs(val), angle(val)*180/pi);
                    case 'DB'
                        db = -1e3;
                        if abs(val)>0, db=20*log10(abs(val)); end
                        fprintf(fid, '%.10e %.10e ', db, angle(val)*180/pi);
                end
            end
        end
        fprintf(fid, '\n');
    end
    fclose(fid);
end

