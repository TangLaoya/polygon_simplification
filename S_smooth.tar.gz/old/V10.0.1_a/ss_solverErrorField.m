function [Network,Runtime]=ss_solverErrorField(Problem,Network,Runtime)

%==============================================================
% NSCP V9.3
%
% Adaptive Matrix VF
% Jump-aware Trend Extraction
%
%==============================================================


S=Network.State.S;

freq=Network.Input.Frequency;


[Nf,N,~]=size(S);



fprintf('\n');
fprintf('========================================\n');
fprintf(' NSCP V9.3 Adaptive Matrix VF\n');
fprintf('========================================\n');



%% VF configuration

VF.Order=30;

VF.SmoothLambda=0.02;

VF.Iteration=3;



fprintf('VF Order      : %d\n',VF.Order);
fprintf('Smooth Lambda : %.3e\n',VF.SmoothLambda);
fprintf('VF Iteration  : %d\n',VF.Iteration);



%%--------------------------------------------------------------
% Matrix VF
%%--------------------------------------------------------------

Model=ss_matrixVectorFit( ...
        freq,...
        S,...
        VF);



%%--------------------------------------------------------------
% Reconstruction
%%--------------------------------------------------------------

Strend=ss_computeVFTrend( ...
        freq,...
        Model,...
        N);



%%--------------------------------------------------------------
% Residual
%%--------------------------------------------------------------

Residual=S-Strend;



rmse=norm(Residual(:))...
    /sqrt(numel(S));


relative=rmse/(norm(S(:))/sqrt(numel(S)));



fprintf('Residual RMSE : %.6e\n',rmse);

fprintf('Relative Error: %.6e\n',relative);

fprintf('========================================\n');



%%--------------------------------------------------------------
% Output
%%--------------------------------------------------------------

if ~isfield(Network,'Output')

    Network.Output=struct();

end


Network.Output.Strend=Strend;

Network.Output.Residual=Residual;



Network.Diagnostics.VF=Model;

Network.Diagnostics.VFRMSE=rmse;

Network.Diagnostics.VFRelativeError=relative;



Runtime.Objective.Current=rmse;



end