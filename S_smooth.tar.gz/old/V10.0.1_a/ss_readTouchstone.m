function Measurement = ss_readTouchstone(filename)
% 读取 Touchstone 并转换为标准 Measurement 结构
[freq, S, params] = readSnP_simple(filename);
Measurement = struct();
Measurement.File = filename;
Measurement.Frequency.Vector = freq(:);
Measurement.Frequency.Number = numel(freq);
Measurement.S = S;
Measurement.Network.PortNumber = size(S,2);
Measurement.Network.ReferenceImpedance = params.R0;
Measurement.Params = params;
end

