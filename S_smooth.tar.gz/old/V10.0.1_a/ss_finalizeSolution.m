function Result = ss_finalizeSolution(Problem,Network,Runtime)

%==========================================================
% NSCP V9.0
%
% Finalize Solution
%
% Compatible with existing ss_writeTouchstone
%
% Output:
%   *_NSCP.sNp
%   *_VFTrend.sNp
%   *_Residual.sNp
%
%==========================================================


%%==========================================================
% Keep Result
%%==========================================================

Result=struct();


Result.Network=Network;

Result.Diagnostics=Network.Diagnostics;

Result.Solver=Runtime;

Result.Report=struct();



%%==========================================================
% Input information
%%==========================================================

if isfield(Problem.Option.IO,'InputFile')

    infile=Problem.Option.IO.InputFile;

else

    infile='Result.s2p';

end


[pathstr,name,~]=fileparts(infile);


if isempty(pathstr)

    pathstr='.';

end


freq=Network.Input.Frequency;


N=size(Network.State.S,2);



%%==========================================================
% Common exporter structure
%%==========================================================

ExportNetwork=struct();


ExportNetwork.Frequency=freq;


ExportNetwork.Z0=Problem.Option.Network.Z0;



%%==========================================================
% Export VF Trend
%%==========================================================

try


if isfield(Network,'Output') && ...
        isfield(Network.Output,'Strend')


    ExportNetwork.S=Network.Output.Strend;


    trendFile=fullfile( ...
        pathstr,...
        sprintf('%s_VFTrend.s%dp',...
        name,N));


    ss_writeTouchstone( ...
        trendFile,...
        ExportNetwork,...
        Problem.Measurement.Params);


    fprintf('\n');

    fprintf('VF Trend File : %s\n',trendFile);


end


catch ME

    fprintf('\nVF Trend export failed:\n');

    disp(ME.message);

end



%%==========================================================
% Export Residual
%%==========================================================

try


if isfield(Network,'Output') && ...
        isfield(Network.Output,'Residual')


    ExportNetwork.S=Network.Output.Residual;


    residualFile=fullfile( ...
        pathstr,...
        sprintf('%s_Residual.s%dp',...
        name,N));


    ss_writeTouchstone( ...
        residualFile,...
        ExportNetwork,...
        Problem.Measurement.Params);



    fprintf('Residual File : %s\n',residualFile);


end


catch ME

    fprintf('\nResidual export failed:\n');

    disp(ME.message);

end



%%==========================================================
% Original NSCP output
%
% IMPORTANT:
% keep V8.x behavior
%%==========================================================


ExportNetwork.S=Network.State.S;


outfile=fullfile( ...
    pathstr,...
    sprintf('%s_NSCP.s%dp',...
    name,N));


ss_writeTouchstone( ...
    outfile,...
    ExportNetwork,...
    Problem.Measurement.Params);



fprintf('\n');

fprintf('Output File : %s\n',outfile);



Result.Network=ExportNetwork;


Result.Report.Date=datetime("now");


end