function [freq, S, params] = readSnP_simple(filename)
    fid = fopen(filename, 'r');
    assert(fid ~= -1, '无法打开文件: %s', filename);
    wholeFile = fread(fid, '*char')';
    fclose(fid);
    hashLine = regexp(wholeFile, '#[^\n\r]*', 'match', 'once');
    if isempty(hashLine), error('未找到 # 选项行'); end
    tokens = strsplit(strtrim(hashLine));
    freq_unit = upper(tokens{2});
    param_type = tokens{3};
    format_type = upper(tokens{4});
    R0 = 50;
    for k = 5:numel(tokens)-1
        if strcmpi(tokens{k}, 'R')
            R0 = str2double(tokens{k+1}); break;
        end
    end
    Nport_declared = str2double(regexp(wholeFile, '\[Number of Ports\]\s*(\d+)', 'tokens', 'once'));
    if isempty(Nport_declared)
        Nport_declared = str2double(regexp(wholeFile, '\Ports:\s*(\d+)', 'tokens', 'once'));
    end
    startIdx = strfind(wholeFile, '[Network Data]');

    % if isempty(startIdx), error('缺少 [Network Data]'); end
    if isempty(startIdx)
        startIdx = strfind(wholeFile, 'Frequencies:');
        offset=1;
    else
        offset=0;
    end
    dataStr = wholeFile(startIdx+14:end);
    endIdx = strfind(dataStr, '[End of Data]');
    if ~isempty(endIdx), dataStr(endIdx:end) = []; end

    dataStr = regexprep(dataStr, '!.*?\n', ' ');
    allNums = sscanf(dataStr, '%f');
    allNums=allNums(offset+1:end);
    totalNums = length(allNums);
    if isempty(Nport_declared)
        Nport = sqrt((totalNums - 1)/2);
        if mod(Nport,1)~=0, error('无法推断端口数'); end
    else
        Nport = Nport_declared;
    end
    inferredNf = floor(totalNums / (1 + 2*Nport^2));
    if inferredNf < 1, error('数据量不足'); end
    Nfreq = inferredNf;
    validNums = Nfreq * (1 + 2*Nport^2);
    allNums = allNums(1:validNums);
    scale = getScale(freq_unit);
    freq = zeros(Nfreq,1); S = zeros(Nfreq,Nport,Nport);
    idx = 1;
    for k = 1:Nfreq
        freq(k) = allNums(idx) * scale;
        idx = idx+1;
        for i = 1:Nport
            for j = 1:Nport
                a = allNums(idx); b = allNums(idx+1);
                switch format_type
                    case 'RI', S(k,i,j) = a + 1i*b;
                    case 'MA', S(k,i,j) = a.*exp(1i*b*pi/180);
                    case 'DB', S(k,i,j) = 10^(a/20).*exp(1i*b*pi/180);
                end
                idx = idx+2;
            end
        end
    end
    params = struct('R0',R0,'param_type',param_type,'format_type',format_type,'freq_unit',freq_unit,'scale',scale);
end

