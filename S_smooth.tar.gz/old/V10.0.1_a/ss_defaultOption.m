function Option = ss_defaultOption()
Option = struct();
Option.Project.Name = "NSCP";
Option.Project.Version = "V7.0";
Option.Network.Z0 = 50;

Option.Solver = struct();
Option.Solver.MaximumIteration = 100;
Option.Solver.RelativeTolerance = 1e-8;
Option.Solver.ObjectiveTolerance = 1e-10;
Option.Solver.MaximumCorrection = 0.5;
Option.Solver.JumpThreshold = 0.15;
Option.Solver.SmoothStrength = 0.15;
Option.Solver.SCorrection = 0.05;

Option.ZPhysics.Enable = true;
Option.ZPhysics.MaximumCorrection = 0.05;

Option.ZSmooth.Enable = true;
Option.ZSmooth.LogFrequency = true;
Option.ZSmooth.Window = 5;
Option.ZSmooth.Strength = 0.15;

Option.SProtection.MaximumDeviation = 1e-3;
Option.SProtection.ResonanceProtect = true;

Option.Jump.Enable = true;
Option.Jump.Threshold = 5;
Option.Jump.LocalFitOrder = 2;

Option.Passivity.Enable = true;
Option.Passivity.MaximumSingularValue = 1.0;

Option.Debug.Enable = true;
Option.Debug.Verbose = true;

Option.Sensitivity.Enable = true;
Option.Sensitivity.Perturbation = 1e-6;
Option.Sensitivity.Regularization = 1e-8;
end

