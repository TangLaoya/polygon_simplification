function ss_writeTouchstone(filename, Network, Params)
S = Network.S;
freq = Network.Frequency;
writeSnP_simple(filename, freq, S, Params);
end

