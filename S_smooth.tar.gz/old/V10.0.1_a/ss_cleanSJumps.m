function [Ssmooth,Report]=ss_cleanSJumps(freq,S)

%=========================================================
% NSCP V9.8
%
% Matrix S Jump Cleaner
%
% Detect:
%   each Sij independently
%
% Correct:
%   whole matrix together
%
%=========================================================

[Nf,N,~]=size(S);

Ssmooth=S;

JumpFlag=false(Nf,1);

RatioThreshold=2.0;
ErrorFactor=3.0;

for i=1:N

    for j=1:N

        y=squeeze(S(:,i,j));

        dy=abs(diff(y));

        meddy=median(dy);

        if meddy<1e-12
            meddy=1e-12;
        end

        for k=2:Nf-1

            L=abs(y(k)-y(k-1));
            R=abs(y(k+1)-y(k));

            ratio=max(L,R)/(min(L,R)+eps);

            f1=freq(k-1);
            f2=freq(k);
            f3=freq(k+1);

            wL=(f3-f2)/(f3-f1);
            wR=(f2-f1)/(f3-f1);

            ypred=wL*y(k-1)+wR*y(k+1);

            err=abs(y(k)-ypred);

            if ratio>RatioThreshold && ...
               err>ErrorFactor*meddy

                JumpFlag(k)=true;

            end

        end

    end

end

JumpIndex=find(JumpFlag);

%%==============================
% Matrix correction
%%==============================

for idx=1:length(JumpIndex)

    k=JumpIndex(idx);

    if k<=1 || k>=Nf
        continue;
    end

    f1=freq(k-1);
    f2=freq(k);
    f3=freq(k+1);

    wL=(f3-f2)/(f3-f1);
    wR=(f2-f1)/(f3-f1);

    Ssmooth(k,:,:)=...
        wL*S(k-1,:,:)+...
        wR*S(k+1,:,:);

end

%%==============================
% Report
%%==============================

Report.JumpIndex=JumpIndex;
Report.JumpNumber=length(JumpIndex);

fprintf("\n");
fprintf("========================================\n");
fprintf(" NSCP V9.8 Matrix S Jump Cleaning\n");
fprintf("========================================\n");
fprintf("Detected Jump Points : %d\n",Report.JumpNumber);

if ~isempty(JumpIndex)

    fprintf("Points : ");

    fprintf("%d ",JumpIndex);

    fprintf("\n");

end

fprintf("========================================\n");

end