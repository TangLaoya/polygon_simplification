function Problem = ss_buildProblem(Measurement, Option)
Problem = struct();
Problem.Option = Option;
Problem.Measurement = Measurement;
Problem.Frequency = Measurement.Frequency;
Problem.Network = Measurement.Network;
Problem.Solver = Option.Solver;

% 约束
Problem.Constraint.Passivity.Enable = true;
Problem.Constraint.Causality.Enable = true;
Problem.Constraint.Reciprocity.Enable = false;
Problem.Constraint.HighImpedance.Enable = true;
Problem.Constraint.MaximumCorrection = Option.Solver.MaximumCorrection;

% 分析占位
Problem.Analysis.NoiseLevel = [];
Problem.Analysis.JumpMap = [];
Problem.Analysis.Smoothness = [];
Problem.Analysis.Curvature = [];
Problem.Analysis.ResonanceMap = [];
Problem.Analysis.SensitivityMap = [];
Problem.Analysis.LowFreqRegion = [];
Problem.Analysis.MidFreqRegion = [];
Problem.Analysis.HighFreqRegion = [];

Problem.Confidence.Measurement = [];
Problem.Confidence.Physics = [];
Problem.Confidence.Smoothness = [];
Problem.Confidence.Resonance = [];
Problem.Confidence.Final = [];

Problem.Sensitivity.dSdZ = [];
Problem.Sensitivity.dZdS = [];
Problem.Sensitivity.LocalGain = [];
Problem.Sensitivity.GlobalGain = [];
Problem.Sensitivity.RiskMap = [];

Problem.Meta.Version = "NSCP V7.0";
Problem.CreatedTime=datetime("now");

%% ==========================================================
% V7.1 Kernel initialization
%% ==========================================================
Problem.Kernel = struct();
Problem.Kernel.Initialized=false;
end

