function [Srepair,Report] = ss_iterativeMatrixRepair( ...
                                    freq,...
                                    S,...
                                    Option)
%==============================================================
%
% NSCP V10.0
%
% Iterative Matrix Z Repair Controller
%
%==============================================================

if nargin<3
    Option = struct();
end

%%------------------------------------------------------------
% default option
%%------------------------------------------------------------

if ~isfield(Option,'MaxIteration')
    Option.MaxIteration = 5;
end

if ~isfield(Option,'ConvergenceTol')
    Option.ConvergenceTol = 1e-6;
end

if ~isfield(Option,'InitialThreshold')
    Option.InitialThreshold = 4.0;
end

if ~isfield(Option,'FinalThreshold')
    Option.FinalThreshold = 3.0;
end

Srepair = S;

Report.Iteration = 0;
Report.History = struct([]);

fprintf('\n');
fprintf('==============================================================\n');
fprintf(' NSCP V10.0 Iterative Matrix Z Repair\n');
fprintf('==============================================================\n');

%%------------------------------------------------------------
% iterative detect-repair
%%------------------------------------------------------------

for iter = 1:Option.MaxIteration

    %% adaptive threshold
    Threshold = max( ...
        Option.FinalThreshold,...
        Option.InitialThreshold - 0.5*(iter-1));

    DetectOption = struct();
    DetectOption.Threshold = Threshold;

    %% detect jump in Z domain
    ZJumpReport = ss_detectMatrixZJump( ...
        freq,...
        Srepair,...
        DetectOption);

    %% stop if no jump
    if ZJumpReport.JumpNumber == 0

        fprintf('Iteration %d : no jump detected, stop.\n',iter);

        Report.Iteration = iter;
        Report.History(iter).JumpNumber = 0;
        Report.History(iter).Threshold = Threshold;

        break;

    end

    %% repair in S domain
    Sold = Srepair;

    [Srepair,RepairReport] = ss_repairMatrixSByJump( ...
        freq,...
        Srepair,...
        ZJumpReport);

    %% convergence check
    Delta = norm(Srepair(:)-Sold(:)) / max(norm(Sold(:)),eps);

    fprintf('Iteration %d : %d jump(s), Delta = %.3e\n',...
        iter,...
        ZJumpReport.JumpNumber,...
        Delta);

    %% record history
    Report.Iteration = iter;
    Report.History(iter).JumpNumber = ZJumpReport.JumpNumber;
    Report.History(iter).Threshold = Threshold;
    Report.History(iter).Delta = Delta;
    Report.History(iter).JumpIndex = ZJumpReport.JumpIndex;
    Report.History(iter).RepairIndex = RepairReport.RepairIndex;

    %% stop if converged
    if Delta < Option.ConvergenceTol

        fprintf('Iteration %d : converged, stop.\n',iter);
        break;

    end

end

fprintf('==============================================================\n');
fprintf(' Iterative repair finished after %d iteration(s)\n', ...
    Report.Iteration);
fprintf('==============================================================\n');
end