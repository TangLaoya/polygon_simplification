function [Aanchor,AnchorY] = ...
    ss_buildBoundaryAnchor( ...
    Boundary,...
    Nf,...
    mu,...
    Y)
%==============================================================
%
% NSCP V9.8.5
%
% Boundary Consensus Anchor
%
% Y-space Version
%
% Input
%
%   Boundary.Left.Index
%   Boundary.Right.Index
%
%   Boundary.LeftY
%   Boundary.RightY
%
%   Nf
%   mu
%   Y
%
% Output
%
%   Aanchor
%
%   AnchorY
%
%==============================================================

Nc=size(Y,2);

%%------------------------------------------------------------
%% Initialize
%%------------------------------------------------------------

Aanchor=sparse(Nf,Nf);

AnchorY=zeros(Nf,Nc);

%%------------------------------------------------------------
%% Left Boundary
%%------------------------------------------------------------

LeftIndex=Boundary.Left.Index(:);

for k=LeftIndex.'

    Aanchor(k,k)=mu;

    AnchorY(k,:)=...
        mu*Boundary.LeftY;

end

%%------------------------------------------------------------
%% Right Boundary
%%------------------------------------------------------------

RightIndex=Boundary.Right.Index(:);

for k=RightIndex.'

    Aanchor(k,k)=mu;

    AnchorY(k,:)=...
        mu*Boundary.RightY;

end

%%------------------------------------------------------------
%% Print
%%------------------------------------------------------------

fprintf("\n");

fprintf("========================================\n");

fprintf(" NSCP V9.8.5 Boundary Anchor\n");

fprintf("========================================\n");

fprintf("Left Anchor Points  : %d\n",...
    length(LeftIndex));

fprintf("Right Anchor Points : %d\n",...
    length(RightIndex));

fprintf("Anchor Strength     : %.3f\n",...
    mu);

fprintf("========================================\n");

end