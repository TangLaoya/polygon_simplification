function Anchor=ss_findLowFreqAnchor(S)

%==============================================================
% NSCP V9.6
%
% Adaptive Low Frequency Matrix Anchor
%
% Matrix based
%
%==============================================================


[Nf,N,~]=size(S);



%% Matrix difference

Delta=zeros(Nf-1,1);



for k=2:Nf


    d=S(k,:,:)-S(k-1,:,:);


    Delta(k-1)=norm(d(:),'fro');


end



%% normalize

medD=median(Delta);


if medD==0

    medD=eps;

end


Dn=Delta/medD;



%% stable threshold

threshold=0.5;



stable=Dn<threshold;



%% find continuous region

bestStart=0;

bestEnd=0;


current=0;


for k=1:length(stable)


    if stable(k)

        if current==0

            start=k;

        end


        current=current+1;


        if current>bestEnd-bestStart

            bestStart=start;

            bestEnd=k;

        end


    else

        current=0;

    end

end



%% no stable region

if bestEnd-bestStart+1<3


    Anchor.Enable=false;

    Anchor.Index=[];

    Anchor.Matrix=[];

    Anchor.Weight=1;


    return;

end



%% index correction

idx=(bestStart+1):...
    (bestEnd+1);



%% matrix average


Anchor.Matrix=...
    squeeze(mean(S(idx,:,:),1));



Anchor.Index=idx;


Anchor.Enable=true;



% confidence weight

Anchor.Weight=...
    min(100,length(idx)*10);



fprintf('\n');

fprintf('Low Frequency Anchor\n');

fprintf('Start Point : %d\n',idx(1));

fprintf('End Point   : %d\n',idx(end));

fprintf('Point Num   : %d\n',length(idx));

fprintf('Weight      : %.1f\n',Anchor.Weight);


end