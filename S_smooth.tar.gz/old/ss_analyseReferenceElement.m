function info = ss_analyseReferenceElement(freq,Zref,cfg)
%==============================================================
%
% Analyse one impedance element in the reference region
%
% This routine DOES NOT modify the data.
%
% It extracts the local physical behaviour and constructs
% the reference operators for later projection.
%
%==============================================================

freq = freq(:);
w = 2*pi*freq;

N = length(freq);

R = real(Zref(:));
X = imag(Zref(:));

%% ------------------------------------------------------------
%% Automatic physical type identification
%% ------------------------------------------------------------

Qc = w .* X;          % Capacitive invariant
Ql = X ./ max(w,eps); % Inductive invariant

vr = std(R);
vc = std(Qc);
vl = std(Ql);

[~,idx] = min([vr vc vl]);

switch idx
    case 1
        type = "R";
        q = R;

    case 2
        type = "C";
        q = Qc;

    case 3
        type = "L";
        q = Ql;
end

%% ------------------------------------------------------------
%% First derivative
%% ------------------------------------------------------------

dq = gradient(q,freq);

%% ------------------------------------------------------------
%% Second derivative
%% ------------------------------------------------------------

d2q = gradient(dq,freq);

%% ------------------------------------------------------------
%% Robust statistics
%% ------------------------------------------------------------

qMean = median(q);

qStd = 1.4826 * median(abs(q-qMean));

if qStd<eps
    qStd = eps;
end

%% ------------------------------------------------------------
%% Confidence estimation
%% ------------------------------------------------------------

noise = norm(dq);

signal = norm(q);

confidence = signal/(signal+noise+eps);

%% ------------------------------------------------------------
%% Reference operator
%% ------------------------------------------------------------

op = struct();

op.type = type;

op.referenceValue = qMean;

op.firstDerivative = dq;

op.secondDerivative = d2q;

op.weight = 1./(1+abs(dq));

%% ------------------------------------------------------------
%% Interpolation model
%% ------------------------------------------------------------

interp = struct();

interp.freq = freq;

interp.reference = q;

interp.method = "pchip";

%% ------------------------------------------------------------
%% Statistics
%% ------------------------------------------------------------

stat = struct();

stat.max = max(q);

stat.min = min(q);

stat.mean = mean(q);

stat.median = median(q);

stat.std = std(q);

stat.range = max(q)-min(q);

%% ------------------------------------------------------------
%% Output
%% ------------------------------------------------------------

info = struct();

info.type = type;

info.reference = q;

info.slope = dq;

info.curvature = d2q;

info.mean = qMean;

info.std = qStd;

info.covariance = cov([real(Zref(:)) imag(Zref(:))]);

info.operator = op;

info.interpolator = interp;

info.confidence = confidence;

info.statistics = stat;

end